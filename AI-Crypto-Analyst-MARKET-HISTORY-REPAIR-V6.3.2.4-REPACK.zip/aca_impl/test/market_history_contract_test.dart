import 'package:flutter_test/flutter_test.dart';
import 'package:ai_crypto_analyst/services/ai_service.dart';
import 'package:ai_crypto_analyst/services/market_api.dart';

void main() {
  MarketCandle candle(int time, double close, double volume) => MarketCandle(
        time: time,
        open: close - 0.5,
        high: close + 1,
        low: close - 1,
        close: close,
        volume: volume,
      );

  test('each timeframe encodes an independent chronological OHLCV history', () {
    final oneHour = [candle(3600, 100, 10), candle(7200, 101, 12)];
    final fifteenMinutes = [candle(900, 200, 20), candle(1800, 202, 22)];
    final fiveMinutes = [candle(300, 300, 30), candle(600, 303, 33)];

    final h1 = encodeAiMarketHistory(oneHour, 3600);
    final m15 = encodeAiMarketHistory(fifteenMinutes, 900);
    final m5 = encodeAiMarketHistory(fiveMinutes, 300);

    for (final entry in [
      (h1, 3600, 3600),
      (m15, 900, 900),
      (m5, 300, 300),
    ]) {
      expect(entry.$1['intervalSeconds'], entry.$2);
      expect(entry.$1['timeStart'], entry.$3);
      expect(entry.$1['historyStartPrice'], greaterThan(0));
      final rows = entry.$1['rows'] as List;
      expect(rows, hasLength(2));
      expect(rows.first, hasLength(6));
      expect(rows.first[0], 0);
      expect(rows.last[0], entry.$2);
      expect(rows.every((row) => row.every((value) => value is int)), isTrue);
    }

    expect(h1['historyStartPrice'], isNot(m15['historyStartPrice']));
    expect(m15['historyStartPrice'], isNot(m5['historyStartPrice']));
  });

  test('empty timeframe is represented as empty rows and is not fabricated', () {
    final encoded = encodeAiMarketHistory(const <MarketCandle>[], 300);
    expect(encoded['rows'], isEmpty);
    expect(encoded.containsKey('timeStart'), isFalse);
  });
}
