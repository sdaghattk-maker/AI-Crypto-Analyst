import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class ChartScreen extends StatefulWidget {
  const ChartScreen({super.key});
  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  late final WebViewController controller;
  String timeframe = '5m';

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadFlutterAsset('assets/chart.html');
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
        child: Row(children: [
          const Expanded(child: Text('نمودار بازار', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
          DropdownButton<String>(
            value: timeframe,
            items: const ['5m', '15m', '1h'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) => setState(() => timeframe = v ?? timeframe),
          ),
        ]),
      ),
      Expanded(child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: WebViewWidget(controller: controller),
      )),
      const Padding(
        padding: EdgeInsets.all(12),
        child: Text('نمودار نمونه است؛ اتصال کندل‌های واقعی و ترسیم Entry / SL / TP در مرحله اتصال Backend انجام می‌شود.',
          textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.white60)),
      ),
    ]);
  }
}
