import 'package:flutter/material.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final symbols = const ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT'];
  String selected = 'BTCUSDT';
  String exchange = 'Nobitex';

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const SizedBox(height: 8),
        const Text('AI Crypto Analyst', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        Text('تحلیل چندمدلی بازار رمزارز', style: TextStyle(color: Colors.white.withValues(alpha: .65))),
        const SizedBox(height: 22),
        _sectionTitle('انتخاب بازار'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              DropdownButtonFormField<String>(
                value: exchange,
                decoration: const InputDecoration(labelText: 'صرافی', border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: 'Nobitex', child: Text('نوبیتکس')),
                  DropdownMenuItem(value: 'Binance', child: Text('Binance')),
                ],
                onChanged: (v) => setState(() => exchange = v ?? exchange),
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                value: selected,
                decoration: const InputDecoration(labelText: 'نماد', border: OutlineInputBorder()),
                items: symbols.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                onChanged: (v) => setState(() => selected = v ?? selected),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 18),
        _sectionTitle('وضعیت تحلیل'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(Icons.hourglass_empty, color: Colors.amber),
                const SizedBox(width: 8),
                const Text('WAIT', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.amber)),
                const Spacer(),
                Text('در انتظار اتصال موتور تحلیل', style: TextStyle(color: Colors.white.withValues(alpha: .6), fontSize: 12)),
              ]),
              const SizedBox(height: 12),
              const Text('پس از اتصال Backend، تحلیل 1H / 15M / 5M و سطوح ورود، حدضرر و اهداف در این بخش نمایش داده می‌شود.'),
            ]),
          ),
        ),
        const SizedBox(height: 18),
        _sectionTitle('ساختار تصمیم‌گیری'),
        const _StepTile(number: '01', title: 'Technical Engine', subtitle: 'داده کندل، روند، قدرت خریدار/فروشنده، ساختار بازار'),
        const _StepTile(number: '02', title: 'Gemini + DeepSeek', subtitle: 'تحلیل مستقل، سناریوی مخالف و شناسایی تله‌ها'),
        const _StepTile(number: '03', title: 'AI Coordinator', subtitle: 'مقایسه شواهد؛ در نبود تأیید کافی خروجی WAIT'),
      ],
    );
  }

  Widget _sectionTitle(String value) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
  );
}

class _StepTile extends StatelessWidget {
  const _StepTile({required this.number, required this.title, required this.subtitle});
  final String number, title, subtitle;
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: CircleAvatar(backgroundColor: const Color(0xFF24443F), child: Text(number, style: const TextStyle(fontSize: 12))),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle),
    ),
  );
}
