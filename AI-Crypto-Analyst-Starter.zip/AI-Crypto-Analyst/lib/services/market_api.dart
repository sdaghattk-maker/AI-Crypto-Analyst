import 'dart:convert';
import 'package:http/http.dart' as http;
import 'app_config.dart';

class MarketApi {
  Future<Map<String, dynamic>> getHealth() async {
    if (!AppConfig.isConfigured) {
      throw const MarketApiException(
        'آدرس Backend هنوز تنظیم نشده است. راهنمای README را ببینید.',
      );
    }
    final uri = Uri.parse('${AppConfig.apiBaseUrl}/health');
    try {
      final response = await http.get(uri).timeout(const Duration(seconds: 12));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw MarketApiException('خطای سرور: HTTP ${response.statusCode}');
      }
      return jsonDecode(response.body) as Map<String, dynamic>;
    } catch (e) {
      if (e is MarketApiException) rethrow;
      throw MarketApiException('اتصال به سرور برقرار نشد: $e');
    }
  }
}

class MarketApiException implements Exception {
  const MarketApiException(this.message);
  final String message;
  @override
  String toString() => message;
}
