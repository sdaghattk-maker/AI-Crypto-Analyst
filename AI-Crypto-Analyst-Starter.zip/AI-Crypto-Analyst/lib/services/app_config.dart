class AppConfig {
  // Set this to your secured backend URL. Never put model API keys in the APK.
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://YOUR-BACKEND.example',
  );

  static bool get isConfigured =>
      apiBaseUrl.startsWith('https://') &&
      !apiBaseUrl.contains('YOUR-BACKEND');
}
