# AI Gateway connection root-cause repair — V6.3.2.8

## Confirmed defects repaired
1. `ai-gateway/wrangler.toml` deployed the Worker as `ai-crypto-analyst-gateway`, while Flutter's canonical default URL points to `hrs-ai-crypto-gateway.sdaghat-tk.workers.dev`. The Worker name now matches the canonical Flutter URL.
2. APK workflow previously passed an empty `AI_GATEWAY_BASE_URL` Secret as a Dart define, overriding the valid Flutter default. The workflow now falls back to the canonical URL when the Secret is absent and validates HTTPS origin-only URLs before compilation.

## Validation
- `node --check ai-gateway/worker.js`: PASS
- Node test suite: 147 passed, 0 failed.
- Flutter analyzer/tests and APK build: NOT RUN (Flutter SDK unavailable in this environment).
- Cloudflare deployment and live provider inference: NOT RUN. This package alone does not update production.

## Required production action
Deploy `ai-gateway/wrangler.toml` from this package so Cloudflare serves the Worker at `https://hrs-ai-crypto-gateway.sdaghat-tk.workers.dev`. Then verify `GET /health`, `POST /providers/health` (tiny real inference probe), and `POST /analyze` from the deployed endpoint. Provider secrets must already be configured in Cloudflare; they are not included here.
