# AI Auto Model Selection Repair — V6.3.3.3

## Scope
This release repairs automatic model candidate discovery and provider-health result handling. The confirmed AI Gateway URL is intentionally unchanged: `https://hrs-ai-crypto-gateway.sdaghat-tk.workers.dev`. Binance Proxy URL is also unchanged.

## Changes
- Align automatic routing with the advertised `maxAutoAttempts: 4` policy.
- `/providers/health` now discovers up to four eligible models from each selected provider's live account catalog, prioritizing the saved primary and fallback selections, then the live ranked catalog. It probes sequentially and stops on the first routable candidate.
- The health response carries the successful primary plus up to three further live-catalog-eligible candidates.
- Flutter now preserves up to four health-verified candidates and sends the exact sequence to `/analyze`.
- `/analyze` accepts and validates up to four candidates against that provider's live catalog, then attempts them in order. Provider-wide 429/TPM errors still stop retries to avoid amplifying quota failures.
- Provider health failures are no longer silently converted to `not_selected` when another provider is routable. Flutter preserves a separate error result for each failed provider; when all selected providers fail preflight, it returns a provider-specific WAIT result rather than replacing the details with one generic exception.
- Added a stable Worker build ID and updated model-ranking version for deployment verification.
- Synchronized both checked-in Worker snapshots with `ai-gateway/worker.js`.

## Validation
- `node --check ai-gateway/worker.js` passed.
- Full Node suite: 154 passed, 0 failed.
- Regression tests cover four-candidate health discovery, health fallback after two model failures, analysis recovery on the third candidate, provider failure preservation, and the exact confirmed Gateway domain.
- Flutter/Dart SDK is not installed in this environment; `flutter analyze`, `flutter test`, and APK build were not run.
- No live provider API requests and no Cloudflare deployment were performed.
