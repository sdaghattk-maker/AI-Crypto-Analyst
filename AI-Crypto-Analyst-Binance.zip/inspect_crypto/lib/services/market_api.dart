
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import 'app_config.dart';

class MarketCandle {
  const MarketCandle({required this.time, required this.open, required this.high,
    required this.low, required this.close, this.volume = 0});
  final int time;
  final double open, high, low, close, volume;
  Map<String, dynamic> toChartJson() => {
    'time': time, 'open': open, 'high': high, 'low': low, 'close': close, 'volume': volume,
  };

  Map<String, dynamic> toJson() => toChartJson();

  factory MarketCandle.fromJson(Map<String, dynamic> json) => MarketCandle(
    time: (json['time'] as num).toInt(),
    open: (json['open'] as num).toDouble(),
    high: (json['high'] as num).toDouble(),
    low: (json['low'] as num).toDouble(),
    close: (json['close'] as num).toDouble(),
    volume: (json['volume'] as num?)?.toDouble() ?? 0,
  );
}

class MarketApi {
  // Shared by every MarketApi instance (chart + analysis) during this app run.
  static final Map<String, List<MarketCandle>> _memoryCandleCache = {};
  static final Map<String, int> _memoryTailFetchAt = {};
  Future<double> getPrice({required String exchange, required String symbol}) async {
    if (exchange == 'Binance') {
      final json = await _getJson(_binance({'endpoint':'price','symbol':symbol.toUpperCase()}));
      _ensureBinance(json, 'دریافت قیمت');
      final data = json['data'];
      final raw = data is Map ? (data['price'] ?? data['lastPrice']) : (data ?? json['price']);
      final value = _number(raw);
      if (value == null || value <= 0) throw const MarketApiException('قیمت معتبر از Binance دریافت نشد.');
      return value;
    }
    final pair = _nobitexPair(symbol);
    final parts = _splitPair(pair);
    final uri = Uri.https('apiv2.nobitex.ir', '/market/stats', {
      'srcCurrency': parts.$1.toLowerCase(), 'dstCurrency': parts.$2.toLowerCase(),
    });
    final json = await _getJson(uri);
    if (json['status'] != 'ok' || json['stats'] is! Map) {
      throw MarketApiException('پاسخ آمار نوبیتکس معتبر نیست: ${_short(json)}');
    }
    final stats = json['stats'] as Map;
    final row = stats['${parts.$1.toLowerCase()}-${parts.$2.toLowerCase()}'];
    final value = row is Map ? _number(row['latest']) : null;
    if (value == null || value <= 0) {
      throw MarketApiException('بازار $pair در نوبیتکس موجود نیست یا قیمت ندارد.');
    }
    return value;
  }

  Future<List<MarketCandle>> getKlines({
    required String exchange,
    required String symbol,
    required String interval,
    int limit = 500,
    Duration refreshInterval = Duration.zero,
  }) async {
    final target = limit.clamp(1, 5000).toInt();
    final cacheKey = _candleCacheKey(exchange, symbol, interval);
    final cached = await _readCandleCache(cacheKey);

    if (exchange == 'Binance') {
      final merged = <int, MarketCandle>{for (final candle in cached) candle.time: candle};
      var pages = 0;

      // First fill any missing historical window. Each request asks only for
      // the older range absent from the local cache (Binance max: 1000 rows).
      while (merged.length < target && pages < 5) {
        final batch = (target - merged.length).clamp(1, 1000).toInt();
        final query = <String, String>{
          'endpoint': 'klines',
          'symbol': symbol.toUpperCase(),
          'interval': interval,
          'limit': batch.toString(),
        };
        if (merged.isNotEmpty) {
          final oldest = merged.keys.reduce((a, b) => a < b ? a : b);
          query['endTime'] = (oldest * 1000 - 1).toString();
        }
        final json = await _getJson(_binance(query));
        _ensureBinance(json, 'دریافت تاریخچه کندل');
        final page = _parseBinance(json['data'], batch);
        if (page.isEmpty) break;
        final before = merged.length;
        for (final candle in page) { merged[candle.time] = candle; }
        pages++;
        if (merged.length == before || page.length < batch) break;
      }

      // Refresh only the tail from the last cached candle onward. This updates
      // the currently-forming candle and appends newly-created candles without
      // downloading the full history again.
      final prefs = await SharedPreferences.getInstance();
      final lastFetchKey = '${cacheKey}_last_tail_fetch_ms';
      final lastFetch = _memoryTailFetchAt[cacheKey] ?? prefs.getInt(lastFetchKey) ?? 0;
      final nowMs = DateTime.now().millisecondsSinceEpoch;
      final mayRefresh = refreshInterval == Duration.zero ||
          nowMs - lastFetch >= refreshInterval.inMilliseconds;
      if (mayRefresh) {
        try {
          var tailCursor = merged.isEmpty
              ? null
              : merged.keys.reduce((a, b) => a > b ? a : b) * 1000;
          final intervalMs = _intervalSeconds(interval) * 1000;
          final expectedMissing = tailCursor == null
              ? target
              : ((nowMs - tailCursor) / intervalMs).ceil() + 2;
          var remaining = expectedMissing.clamp(1, 5000).toInt();
          var tailPages = 0;
          while (remaining > 0 && tailPages < 5) {
            final batch = remaining.clamp(1, 1000).toInt();
            final query = <String, String>{
              'endpoint': 'klines',
              'symbol': symbol.toUpperCase(),
              'interval': interval,
              'limit': batch.toString(),
            };
            if (tailCursor != null) query['startTime'] = tailCursor.toString();
            final json = await _getJson(_binance(query));
            _ensureBinance(json, 'به‌روزرسانی آخرین کندل‌ها');
            final tail = _parseBinance(json['data'], batch);
            if (tail.isEmpty) break;
            for (final candle in tail) { merged[candle.time] = candle; }
            tailPages++;
            remaining -= tail.length;
            final newestTail = tail.last.time * 1000;
            if (tail.length < batch || (tailCursor != null && newestTail < tailCursor)) break;
            tailCursor = newestTail + 1;
          }
          _memoryTailFetchAt[cacheKey] = nowMs;
          await prefs.setInt(lastFetchKey, nowMs);
        } catch (_) {
          // Keep verified cached candles available to the chart during a
          // temporary upstream failure. Analysis freshness is checked by its
          // controller before it can use this snapshot for a new AI run.
          if (merged.isEmpty) rethrow;
        }
      }

      final all = _finish(merged.values.toList(), 5000);
      await _writeCandleCache(cacheKey, all);
      return all.length > target ? all.sublist(all.length - target) : all;
    }

    // Nobitex also shares the persistent local cache. Its UDF endpoint uses
    // from/to/countback rather than Binance startTime/endTime pagination.
    final pair = _nobitexPair(symbol);
    final seconds = _intervalSeconds(interval);
    final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final enoughCached = cached.length >= target;
    final from = cached.isNotEmpty && enoughCached
        ? cached.last.time
        : now - seconds * (target + 5);
    final uri = Uri.https('apiv2.nobitex.ir', '/market/udf/history', {
      'symbol': pair,
      'resolution': _nobitexResolution(interval),
      'to': now.toString(),
      'countback': (enoughCached ? 5 : target).toString(),
      'from': from.toString(),
    });
    try {
      final json = await _getJson(uri);
      if (json['s'] == 'no_data') {
        if (cached.isNotEmpty) return cached.length > target ? cached.sublist(cached.length-target) : cached;
        throw MarketApiException('برای $pair در نوبیتکس کندلی موجود نیست.');
      }
      if (json['s'] != 'ok') throw MarketApiException('خطای تاریخچه نوبیتکس: ${json['errmsg'] ?? _short(json)}');
      final fresh = _parseUdf(json, interval, target);
      final merged = <int, MarketCandle>{for (final candle in cached) candle.time: candle};
      for (final candle in fresh) { merged[candle.time] = candle; }
      final all = _finish(merged.values.toList(), 5000);
      await _writeCandleCache(cacheKey, all);
      return all.length > target ? all.sublist(all.length-target) : all;
    } catch (_) {
      if (cached.isNotEmpty) return cached.length > target ? cached.sublist(cached.length-target) : cached;
      rethrow;
    }
  }

  String _candleCacheKey(String exchange, String symbol, String interval) =>
      'market_candles_v2_${exchange.toLowerCase()}_${symbol.toUpperCase()}_$interval';

  Future<List<MarketCandle>> _readCandleCache(String key) async {
    final inMemory = _memoryCandleCache[key];
    if (inMemory != null) return List.unmodifiable(inMemory);
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(key);
      if (raw == null || raw.isEmpty) return const [];
      final decoded = jsonDecode(raw);
      if (decoded is! List) return const [];
      final candles = <MarketCandle>[];
      for (final item in decoded) {
        if (item is Map) {
          try { candles.add(MarketCandle.fromJson(Map<String, dynamic>.from(item))); }
          catch (_) { /* Skip a corrupt cache row, not the whole history. */ }
        }
      }
      final normalized = _finish(candles, 5000);
      _memoryCandleCache[key] = List.unmodifiable(normalized);
      return normalized;
    } catch (_) { return const []; }
  }

  Future<void> _writeCandleCache(String key, List<MarketCandle> candles) async {
    final prefs = await SharedPreferences.getInstance();
    final bounded = candles.length > 5000 ? candles.sublist(candles.length - 5000) : candles;
    _memoryCandleCache[key] = List.unmodifiable(bounded);
    await prefs.setString(key, jsonEncode(bounded.map((c) => c.toJson()).toList()));
  }

  Uri _binance(Map<String,String> query) => Uri.parse(AppConfig.binanceWorkerBaseUrl).replace(queryParameters: query);

  Future<Map<String,dynamic>> _getJson(Uri uri) async {
    try {
      final response = await http.get(uri, headers: const {'Accept':'application/json'}).timeout(AppConfig.requestTimeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw MarketApiException('HTTP ${response.statusCode}: ${_short(response.body)}');
      }
      final decoded = jsonDecode(response.body);
      if (decoded is! Map) throw const MarketApiException('پاسخ سرور JSON object نیست.');
      return Map<String,dynamic>.from(decoded);
    } on MarketApiException { rethrow; }
    on TimeoutException {
      throw MarketApiException('مهلت دریافت پاسخ از ${uri.host} پس از ${AppConfig.requestTimeout.inSeconds} ثانیه تمام شد؛ صفحه‌بندی کندل‌ها ممکن است ناقص مانده باشد.');
    } catch (e) { throw MarketApiException('خطا در اتصال به ${uri.host}: $e'); }
  }

  void _ensureBinance(Map<String,dynamic> json, String action) {
    if (json['ok'] == false) throw MarketApiException('$action ناموفق: ${json['error'] ?? _short(json)}');
  }

  List<MarketCandle> _parseBinance(dynamic raw, int limit) {
    if (raw is Map) raw = raw['klines'] ?? raw['data'];
    if (raw is! List) throw const MarketApiException('ساختار کندل Binance نامعتبر است.');
    final map = <int,MarketCandle>{};
    for (final item in raw) {
      if (item is! List || item.length < 7) continue;
      final t=_int(item[0]), o=_number(item[1]), h=_number(item[2]), l=_number(item[3]), c=_number(item[4]);
      final v=_number(item[5]) ?? 0, closeTime=_int(item[6]);
      if (t==null || o==null || h==null || l==null || c==null || closeTime==null || !_valid(o,h,l,c)) continue;
      map[t~/1000]=MarketCandle(time:t~/1000,open:o,high:h,low:l,close:c,volume:v);
    }
    if (map.isEmpty) return const [];
    return _finish(map.values.toList(),limit);
  }

  List<MarketCandle> _parseUdf(Map<String,dynamic> data, String interval, int limit) {
    final t=data['t'], o=data['o'], h=data['h'], l=data['l'], c=data['c'], v=data['v'];
    if ([t,o,h,l,c].any((x)=>x is! List)) throw const MarketApiException('آرایه‌های OHLC نوبیتکس ناقص‌اند.');
    final ts=t as List, os=o as List, hs=h as List, ls=l as List, cs=c as List;
    if ([os,hs,ls,cs].any((x)=>x.length!=ts.length)) throw const MarketApiException('طول آرایه‌های OHLC برابر نیست.');
    final map=<int,MarketCandle>{};
    for(var i=0;i<ts.length;i++){
      final time=_int(ts[i]), op=_number(os[i]), hi=_number(hs[i]), lo=_number(ls[i]), cl=_number(cs[i]);
      if(time==null||op==null||hi==null||lo==null||cl==null||!_valid(op,hi,lo,cl)) continue;
      map[time]=MarketCandle(time:time,open:op,high:hi,low:lo,close:cl,volume:v is List&&i<v.length?(_number(v[i])??0):0);
    }
    return _finish(map.values.toList(),limit);
  }

  List<MarketCandle> _finish(List<MarketCandle> list,int limit) {
    list.sort((a,b)=>a.time.compareTo(b.time));
    final unique=<int,MarketCandle>{for(final c in list)c.time:c};
    final result=unique.values.toList()..sort((a,b)=>a.time.compareTo(b.time));
    if(result.isEmpty) throw const MarketApiException('هیچ کندل بسته‌شده و معتبری دریافت نشد.');
    return result.length>limit?result.sublist(result.length-limit):result;
  }

  String _nobitexPair(String symbol) {
    final s=symbol.toUpperCase().replaceAll('/','');
    if (!s.endsWith('USDT') && !s.endsWith('IRT')) {
      throw MarketApiException('نماد $symbol برای نوبیتکس قابل تبدیل نیست.');
    }
    return s;
  }
  (String,String) _splitPair(String pair) => pair.endsWith('USDT')
      ? (pair.substring(0,pair.length-4),'usdt')
      : (pair.substring(0,pair.length-3),'rls');
  String _nobitexResolution(String tf) => const {'1m':'1','5m':'5','15m':'15','30m':'30','1h':'60','4h':'240','1d':'D'}[tf] ?? '5';
  int _intervalSeconds(String tf) => const {'1m':60,'5m':300,'15m':900,'30m':1800,'1h':3600,'4h':14400,'1d':86400}[tf] ?? 300;
  bool _valid(double o,double h,double l,double c)=>[o,h,l,c].every((x)=>x.isFinite&&x>0)&&h>=o&&h>=c&&l<=o&&l<=c&&h>=l;
  int? _int(dynamic x)=>x is num?x.toInt():int.tryParse('$x');
  double? _number(dynamic x)=>x is num?x.toDouble():double.tryParse('$x');
  String _short(dynamic x){final s=x.toString();return s.length>220?'${s.substring(0,220)}…':s;}
}
class MarketApiException implements Exception {
  const MarketApiException(this.message);
  final String message;
  @override String toString()=>message;
}
