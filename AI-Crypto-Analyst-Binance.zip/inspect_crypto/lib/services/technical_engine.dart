import 'market_api.dart';

double _min(double a,double b)=>a<b?a:b;
double _max(double a,double b)=>a>b?a:b;

enum TradeBias { bullish, bearish, neutral }
enum SignalState { buy, sell, wait }

class TechnicalReport {
  const TechnicalReport({
    required this.state, required this.bias1h, required this.bias15m,
    required this.bias5m, required this.entry, required this.stopLoss,
    required this.tp1, required this.tp2, required this.tp3,
    required this.score, required this.buyerPower, required this.sellerPower,
    required this.rangeHigh, required this.rangeLow, required this.rsi,
    required this.atr, required this.reasons, required this.warnings,
    required this.poiSummary, required this.overlays,
  });
  final SignalState state;
  final TradeBias bias1h, bias15m, bias5m;
  final double? entry, stopLoss, tp1, tp2, tp3;
  final int score, buyerPower, sellerPower;
  final double rangeHigh, rangeLow, rsi, atr;
  final List<String> reasons, warnings, poiSummary;
  final List<Map<String,dynamic>> overlays;

  Map<String,dynamic> toJson() => {
    'signal':state.name,'bias1h':bias1h.name,'bias15m':bias15m.name,'bias5m':bias5m.name,
    'entry':entry,'stopLoss':stopLoss,'tp1':tp1,'tp2':tp2,'tp3':tp3,
    'score':score,'buyerPower':buyerPower,'sellerPower':sellerPower,
    'crt15m':{'high':rangeHigh,'low':rangeLow},'rsi5m':rsi,'atr5m':atr,
    'reasons':reasons,'warnings':warnings,'poiSummary':poiSummary,'overlays':overlays,
  };

  factory TechnicalReport.fromJson(Map<String, dynamic> json) {
    T enumValue<T extends Enum>(List<T> values, dynamic raw, T fallback) {
      return values.firstWhere((v) => v.name == raw?.toString(), orElse: () => fallback);
    }
    double number(dynamic value, [double fallback = 0]) =>
        value is num ? value.toDouble() : double.tryParse('$value') ?? fallback;
    int integer(dynamic value, [int fallback = 0]) =>
        value is num ? value.round() : int.tryParse('$value') ?? fallback;
    final range = json['crt15m'] is Map ? json['crt15m'] as Map : const {};
    final overlaysRaw = json['overlays'] is List ? json['overlays'] as List : const [];
    List<String> strings(dynamic value) => value is List ? value.map((e) => e.toString()).toList() : <String>[];
    return TechnicalReport(
      state: enumValue(SignalState.values, json['signal'], SignalState.wait),
      bias1h: enumValue(TradeBias.values, json['bias1h'], TradeBias.neutral),
      bias15m: enumValue(TradeBias.values, json['bias15m'], TradeBias.neutral),
      bias5m: enumValue(TradeBias.values, json['bias5m'], TradeBias.neutral),
      entry: json['entry'] is num ? number(json['entry']) : null,
      stopLoss: json['stopLoss'] is num ? number(json['stopLoss']) : null,
      tp1: json['tp1'] is num ? number(json['tp1']) : null,
      tp2: json['tp2'] is num ? number(json['tp2']) : null,
      tp3: json['tp3'] is num ? number(json['tp3']) : null,
      score: integer(json['score']), buyerPower: integer(json['buyerPower'], 50),
      sellerPower: integer(json['sellerPower'], 50),
      rangeHigh: number(range['high']), rangeLow: number(range['low']),
      rsi: number(json['rsi5m']), atr: number(json['atr5m']),
      reasons: strings(json['reasons']), warnings: strings(json['warnings']),
      poiSummary: strings(json['poiSummary']),
      overlays: overlaysRaw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList(),
    );
  }
}

class TechnicalEngine {
  TechnicalReport analyze({
    required List<MarketCandle> h1,
    required List<MarketCandle> m15,
    required List<MarketCandle> m5,
  }) {
    // Filter by each candle's actual close time. This avoids dropping a valid
    // last candle when a provider returns only closed candles, and prevents
    // a still-forming candle from influencing signals.
    final c1=_closedCandles(h1,3600);
    final c15=_closedCandles(m15,900);
    final c5=_closedCandles(m5,300);
    if (c1.length<60 || c15.length<60 || c5.length<60) {
      throw MarketApiException('پس از حذف کندل‌های باز، داده کافی نیست؛ تعداد بسته‌شده: 1H=${c1.length}، 15M=${c15.length}، 5M=${c5.length}.');
    }
    final b1=_bias(c1), b15=_bias(c15), b5=_bias(c5);
    final rsi=_rsi(c5,14), atr=_atr(c5,14);
    final last=c5.last;
    final range=c15.sublist(c15.length-20);
    final rangeHigh=range.map((c)=>c.high).reduce(_max);
    final rangeLow=range.map((c)=>c.low).reduce(_min);
    // Detect liquidity events over a short sequence, not only on the final bar.
    // A sweep must reclaim the prior 12-bar extreme on its own candle; a later
    // MSS/displacement may confirm the reaction within the next four bars.
    final recent=c5.sublist(c5.length-13,c5.length-1);
    final priorLow=recent.map((c)=>c.low).reduce(_min);
    final priorHigh=recent.map((c)=>c.high).reduce(_max);
    var bullishSweep=false, bearishSweep=false;
    var bullSweepIndex=-1, bearSweepIndex=-1;
    final eventStart=c5.length-7>0?c5.length-7:1;
    for(var i=eventStart;i<c5.length;i++){
      final candle=c5[i];
      final before=c5.sublist(i-12<0?0:i-12,i);
      if(before.isEmpty)continue;
      final localLow=before.map((c)=>c.low).reduce(_min);
      final localHigh=before.map((c)=>c.high).reduce(_max);
      if(candle.low<localLow && candle.close>localLow && candle.close>candle.open){
        bullishSweep=true; bullSweepIndex=i;
      }
      if(candle.high>localHigh && candle.close<localHigh && candle.close<candle.open){
        bearishSweep=true; bearSweepIndex=i;
      }
    }
    final bullishDisplacement=c5.skip(c5.length-3).any((c)=>c.close>c.open&&(c.close-c.open)>atr*0.55);
    final bearishDisplacement=c5.skip(c5.length-3).any((c)=>c.close<c.open&&(c.open-c.close)>atr*0.55);
    final bullMss=c5.skip(c5.length-3).toList().asMap().entries.any((e){
      final i=c5.length-3+e.key; if(i<12)return false;
      final hi=c5.sublist(i-12,i).map((c)=>c.high).reduce(_max);
      return e.value.close>hi;
    });
    final bearMss=c5.skip(c5.length-3).toList().asMap().entries.any((e){
      final i=c5.length-3+e.key; if(i<12)return false;
      final lo=c5.sublist(i-12,i).map((c)=>c.low).reduce(_min);
      return e.value.close<lo;
    });
    final bullSequence=bullishSweep&&bullSweepIndex>=0&&c5.length-1-bullSweepIndex<=4&&(bullMss||bullishDisplacement);
    final bearSequence=bearishSweep&&bearSweepIndex>=0&&c5.length-1-bearSweepIndex<=4&&(bearMss||bearishDisplacement);
    final buyer=_power(c5), seller=100-buyer;

    final reasons=<String>[], warnings=<String>[], poiSummary=<String>[];
    var buyScore=0, sellScore=0;
    final overlays=<Map<String,dynamic>>[];
    // Confirmed swing pivots from completed candles only (2 bars left/right).
    final structStart=c5.length-121>0?c5.length-121:0;
    final struct=c5.sublist(structStart);
    double? swingHigh, swingLow;
    for(var i=2;i<struct.length-2;i++){
      final v=struct[i];
      final isHigh=v.high>struct[i-1].high && v.high>struct[i-2].high &&
          v.high>=struct[i+1].high && v.high>=struct[i+2].high;
      final isLow=v.low<struct[i-1].low && v.low<struct[i-2].low &&
          v.low<=struct[i+1].low && v.low<=struct[i+2].low;
      if(isHigh){swingHigh=v.high;}
      if(isLow){swingLow=v.low;}
    }
    // Fallback to recent extremes only when no confirmed pivot exists.
    swingHigh??=struct.map((c)=>c.high).reduce(_max);
    swingLow??=struct.map((c)=>c.low).reduce(_min);
    overlays.add({'type':'line','kind':'Swing High','price':swingHigh,'color':'#D6A84B'});
    overlays.add({'type':'line','kind':'Swing Low','price':swingLow,'color':'#D6A84B'});
    poiSummary.add('Swing High ${swingHigh.toStringAsFixed(2)} | Swing Low ${swingLow.toStringAsFixed(2)}');
    final bullishBos=last.close>swingHigh;
    final bearishBos=last.close<swingLow;
    if(bullishBos){poiSummary.add('BOS صعودی');overlays.add({'type':'line','kind':'BOS+','price':swingHigh,'color':'#22C99A'});}
    if(bearishBos){poiSummary.add('BOS نزولی');overlays.add({'type':'line','kind':'BOS−','price':swingLow,'color':'#F05D6C'});}

    // Scan a wider closed-candle window for the most recent FVGs.
    // Prefer unmitigated gaps; if none remain, show the latest mitigated gap
    // with a muted fill so the user can still see the recent structure.
    final fvgStart=c5.length-151>2?c5.length-151:2;
    Map<String,dynamic>? latestBullFvg, latestBearFvg;
    Map<String,dynamic>? fallbackBullFvg, fallbackBearFvg;
    for(var i=c5.length-1;i>=fvgStart;i--){
      final a=c5[i-2], b=c5[i];
      if(b.low>a.high && (b.low-a.high)>=atr*0.035){
        final lo=a.high, hi=b.low;
        var mitigated=false;
        for(var j=i+1;j<c5.length;j++){if(c5[j].low<=lo){mitigated=true;break;}}
        final item={'type':'zone','kind':'Bullish FVG','low':lo,'high':hi,
          'color':mitigated?'rgba(34,201,154,0.09)':'rgba(34,201,154,0.24)',
          'status':mitigated?'mitigated':'active'};
        if(mitigated){fallbackBullFvg??=item;}else{latestBullFvg??=item;}
      }
      if(b.high<a.low && (a.low-b.high)>=atr*0.035){
        final lo=b.high, hi=a.low;
        var mitigated=false;
        for(var j=i+1;j<c5.length;j++){if(c5[j].high>=hi){mitigated=true;break;}}
        final item={'type':'zone','kind':'Bearish FVG','low':lo,'high':hi,
          'color':mitigated?'rgba(240,93,108,0.09)':'rgba(240,93,108,0.24)',
          'status':mitigated?'mitigated':'active'};
        if(mitigated){fallbackBearFvg??=item;}else{latestBearFvg??=item;}
      }
      if(latestBullFvg!=null && latestBearFvg!=null)break;
    }
    latestBullFvg??=fallbackBullFvg;
    latestBearFvg??=fallbackBearFvg;
    final bullFvgZone=latestBullFvg;
    if(bullFvgZone!=null){
      overlays.add(bullFvgZone);
      final low=(bullFvgZone['low'] as num).toDouble(), high=(bullFvgZone['high'] as num).toDouble();
      poiSummary.add('FVG صعودی: ${low.toStringAsFixed(2)} تا ${high.toStringAsFixed(2)}');
    }
    final bearFvgZone=latestBearFvg;
    if(bearFvgZone!=null){
      overlays.add(bearFvgZone);
      final low=(bearFvgZone['low'] as num).toDouble(), high=(bearFvgZone['high'] as num).toDouble();
      poiSummary.add('FVG نزولی: ${low.toStringAsFixed(2)} تا ${high.toStringAsFixed(2)}');
    }

    // Order blocks: scan up to 120 completed bars for displacement + a
    // ten-bar structure break, then select the last opposing candle.
    MarketCandle? bullOb, bearOb;
    bool bullObMitigated=false, bearObMitigated=false;
    final obStart=c5.length-121>10?c5.length-121:10;
    for(var i=c5.length-1;i>=obStart;i--){
      final impulse=c5[i], body=(impulse.close-impulse.open).abs();
      final prior=c5.sublist(i-10,i);
      final localPriorHigh=prior.map((c)=>c.high).reduce(_max);
      final localPriorLow=prior.map((c)=>c.low).reduce(_min);
      final displacement=body>=atr*0.55;
      if(bullOb==null && impulse.close>impulse.open && displacement && impulse.close>localPriorHigh){
        for(var j=i-1;j>=i-8 && j>=0;j--){
          if(c5[j].close<c5[j].open){
            final candidate=c5[j];
            var invalidated=false, mitigated=false;
            for(var k=j+1;k<c5.length;k++){
              if(c5[k].close<candidate.low){invalidated=true;break;}
              if(c5[k].low<=candidate.high)mitigated=true;
            }
            if(!invalidated){bullOb=candidate;bullObMitigated=mitigated;}
            break;
          }
        }
      }
      if(bearOb==null && impulse.close<impulse.open && displacement && impulse.close<localPriorLow){
        for(var j=i-1;j>=i-8 && j>=0;j--){
          if(c5[j].close>c5[j].open){
            final candidate=c5[j];
            var invalidated=false, mitigated=false;
            for(var k=j+1;k<c5.length;k++){
              if(c5[k].close>candidate.high){invalidated=true;break;}
              if(c5[k].high>=candidate.low)mitigated=true;
            }
            if(!invalidated){bearOb=candidate;bearObMitigated=mitigated;}
            break;
          }
        }
      }
      if(bullOb!=null && bearOb!=null)break;
    }
    if(bullOb!=null){
      final lo=bullOb.low, hi=bullOb.high;
      overlays.add({'type':'zone','kind':'Bullish OB','low':lo,'high':hi,
        'color':bullObMitigated?'rgba(34,201,154,0.10)':'rgba(34,201,154,0.27)',
        'status':bullObMitigated?'mitigated':'active'});
      poiSummary.add('OB صعودی ${lo.toStringAsFixed(2)} تا ${hi.toStringAsFixed(2)}${bullObMitigated?' (برخورد شده)':''}');
    }
    if(bearOb!=null){
      final lo=bearOb.low, hi=bearOb.high;
      overlays.add({'type':'zone','kind':'Bearish OB','low':lo,'high':hi,
        'color':bearObMitigated?'rgba(240,93,108,0.10)':'rgba(240,93,108,0.27)',
        'status':bearObMitigated?'mitigated':'active'});
      poiSummary.add('OB نزولی ${lo.toStringAsFixed(2)} تا ${hi.toStringAsFixed(2)}${bearObMitigated?' (برخورد شده)':''}');
    }

    // Equal-high / equal-low liquidity pools from confirmed pivots.
    final pivotsHigh=<double>[], pivotsLow=<double>[];
    for(var i=2;i<struct.length-2;i++){
      final v=struct[i];
      if(v.high>struct[i-1].high && v.high>struct[i-2].high && v.high>=struct[i+1].high && v.high>=struct[i+2].high) pivotsHigh.add(v.high);
      if(v.low<struct[i-1].low && v.low<struct[i-2].low && v.low<=struct[i+1].low && v.low<=struct[i+2].low) pivotsLow.add(v.low);
    }
    double? equalHigh, equalLow;
    for(var i=pivotsHigh.length-1;i>=1 && equalHigh==null;i--){
      for(var j=i-1;j>=0;j--){if((pivotsHigh[i]-pivotsHigh[j]).abs()<=atr*0.12){equalHigh=(pivotsHigh[i]+pivotsHigh[j])/2;break;}}
    }
    for(var i=pivotsLow.length-1;i>=1 && equalLow==null;i--){
      for(var j=i-1;j>=0;j--){if((pivotsLow[i]-pivotsLow[j]).abs()<=atr*0.12){equalLow=(pivotsLow[i]+pivotsLow[j])/2;break;}}
    }
    if(equalHigh!=null){overlays.add({'type':'line','kind':'EQH','price':equalHigh,'color':'#B58BE8'});poiSummary.add('نقدینگی سقف برابر EQH ${equalHigh.toStringAsFixed(2)}');}
    if(equalLow!=null){overlays.add({'type':'line','kind':'EQL','price':equalLow,'color':'#B58BE8'});poiSummary.add('نقدینگی کف برابر EQL ${equalLow.toStringAsFixed(2)}');}
    overlays.add({'type':'line','kind':'CRT-H','price':rangeHigh,'color':'#64748B'});
    overlays.add({'type':'line','kind':'CRT-L','price':rangeLow,'color':'#64748B'});
    overlays.add({'type':'line','kind':'EQ','price':(rangeHigh+rangeLow)/2,'color':'#64748B'});

    // Evidence score: normalized to 100. HTF bias is contextual rather than
    // an absolute veto; local structure, reaction and POI quality can outweigh it.
    if(b1==TradeBias.bullish){buyScore+=15;reasons.add('سوگیری 1H صعودی (+15)');}
    if(b1==TradeBias.bearish){sellScore+=15;reasons.add('سوگیری 1H نزولی (+15)');}
    if(b15==TradeBias.bullish){buyScore+=12;reasons.add('ساختار 15M صعودی (+12)');}
    if(b15==TradeBias.bearish){sellScore+=12;reasons.add('ساختار 15M نزولی (+12)');}
    if(b5==TradeBias.bullish)buyScore+=8;
    if(b5==TradeBias.bearish)sellScore+=8;
    if(bullishSweep){buyScore+=10;reasons.add('جمع‌آوری نقدینگی و بازپس‌گیری کف در ۶ کندل اخیر (+10)');}
    if(bearishSweep){sellScore+=10;reasons.add('جمع‌آوری نقدینگی و بازپس‌گیری سقف در ۶ کندل اخیر (+10)');}
    if(bullMss){buyScore+=15;reasons.add('تغییر/شکست ساختار صعودی در ۳ کندل اخیر (+15)');}
    if(bearMss){sellScore+=15;reasons.add('تغییر/شکست ساختار نزولی در ۳ کندل اخیر (+15)');}
    if(bullishDisplacement){buyScore+=12;reasons.add('جابجایی قدرتمند صعودی در ۳ کندل اخیر (+12)');}
    if(bearishDisplacement){sellScore+=12;reasons.add('جابجایی قدرتمند نزولی در ۳ کندل اخیر (+12)');}

    bool nearBullPoi=false, nearBearPoi=false;
    bool touchedRecently(List<MarketCandle> candles,double low,double high){
      final from=candles.length-4>0?candles.length-4:0;
      return candles.skip(from).any((c)=>c.low<=high+atr*0.12&&c.high>=low-atr*0.12);
    }
    if(bullOb!=null)nearBullPoi=touchedRecently(c5,bullOb.low,bullOb.high);
    if(bullFvgZone!=null){
      nearBullPoi=nearBullPoi||touchedRecently(c5,(bullFvgZone['low'] as num).toDouble(),(bullFvgZone['high'] as num).toDouble());
    }
    if(bearOb!=null)nearBearPoi=touchedRecently(c5,bearOb.low,bearOb.high);
    if(bearFvgZone!=null){
      nearBearPoi=nearBearPoi||touchedRecently(c5,(bearFvgZone['low'] as num).toDouble(),(bearFvgZone['high'] as num).toDouble());
    }
    if(nearBullPoi){buyScore+=12;reasons.add('واکنش قیمت در ناحیه تقاضا/ FVG صعودی (+12)');}
    if(nearBearPoi){sellScore+=12;reasons.add('واکنش قیمت در ناحیه عرضه/ FVG نزولی (+12)');}
    if(buyer>=58)buyScore+=5;
    if(seller>=58)sellScore+=5;
    if(rsi>=50&&rsi<=72)buyScore+=5;
    if(rsi<=50&&rsi>=28)sellScore+=5;

    final insideRange=last.close<rangeHigh&&last.close>rangeLow;
    final rangeMid=(rangeHigh+rangeLow)/2;
    if(insideRange){
      // CRT location is a mild location adjustment, not a blanket range penalty.
      if(last.close<rangeMid)buyScore+=6;
      if(last.close>rangeMid)sellScore+=6;
      if(!bullishSweep&&!bearishSweep)warnings.add('قیمت داخل محدوده CRT است؛ شکست معتبر یا واکنش از لبه محدوده اهمیت دارد.');
    }
    if(b1==TradeBias.bearish&&buyScore>sellScore)warnings.add('خرید خلاف جهت 1H است؛ برای اعتبار به تأیید محلی قوی‌تر نیاز دارد.');
    if(b1==TradeBias.bullish&&sellScore>buyScore)warnings.add('فروش خلاف جهت 1H است؛ برای اعتبار به تأیید محلی قوی‌تر نیاز دارد.');

    var state=SignalState.wait;
    double? entry, sl, t1, t2, t3;
    final buyTrigger=(bullSequence||bullMss)&&bullishDisplacement;
    final sellTrigger=(bearSequence||bearMss)&&bearishDisplacement;
    final buyThreshold=b1==TradeBias.bearish?74:62;
    final sellThreshold=b1==TradeBias.bullish?74:62;
    final buyAllowed=buyScore>=buyThreshold&&buyScore-sellScore>=10&&buyTrigger;
    final sellAllowed=sellScore>=sellThreshold&&sellScore-buyScore>=10&&sellTrigger;
    if(buyAllowed){
      final entryPrice=last.close;
      entry=entryPrice;
      final candidates=<double>[swingLow];
      if(bullOb!=null)candidates.add(bullOb.low);
      final recentLow=c5.skip(c5.length-12).map((c)=>c.low).reduce(_min);
      candidates.add(recentLow);
      final valid=candidates.where((v)=>v<entryPrice).toList();
      final structural=valid.isEmpty?entryPrice-atr*1.2:valid.reduce(_max);
      final rawRisk=entryPrice-structural+atr*0.15;
      if(rawRisk>atr*2.5){
        warnings.add('ریسک ساختاری خرید بیش از ۲٫۵ ATR است؛ ورود برای جلوگیری از حدضرر نامتناسب رد شد.');
      }else{
        final risk=rawRisk<atr*0.5?atr*0.5:rawRisk;
        sl=entryPrice-risk;
        if(risk>0){state=SignalState.buy;t1=entryPrice+risk;t2=entryPrice+risk*2;t3=entryPrice+risk*3;}
        reasons.add('خرید تأیید شد؛ حدضرر پشت ساختار با حداقل فاصله ۰٫۵ ATR');
      }
    }else if(sellAllowed){
      final entryPrice=last.close;
      entry=entryPrice;
      final candidates=<double>[swingHigh];
      if(bearOb!=null)candidates.add(bearOb.high);
      final recentHigh=c5.skip(c5.length-12).map((c)=>c.high).reduce(_max);
      candidates.add(recentHigh);
      final valid=candidates.where((v)=>v>entryPrice).toList();
      final structural=valid.isEmpty?entryPrice+atr*1.2:valid.reduce(_min);
      final rawRisk=structural-entryPrice+atr*0.15;
      if(rawRisk>atr*2.5){
        warnings.add('ریسک ساختاری فروش بیش از ۲٫۵ ATR است؛ ورود برای جلوگیری از حدضرر نامتناسب رد شد.');
      }else{
        final risk=rawRisk<atr*0.5?atr*0.5:rawRisk;
        sl=entryPrice+risk;
        if(risk>0){state=SignalState.sell;t1=entryPrice-risk;t2=entryPrice-risk*2;t3=entryPrice-risk*3;}
        reasons.add('فروش تأیید شد؛ حدضرر پشت ساختار با حداقل فاصله ۰٫۵ ATR');
      }
    }else{
      final missing=<String>[];
      if(!buyTrigger&&!sellTrigger)missing.add('توالی sweep/MSS همراه displacement کامل نیست');
      if(buyScore<buyThreshold&&sellScore<sellThreshold)missing.add('امتیاز شواهد به حدنصاب نرسیده');
      if((buyScore-sellScore).abs()<10)missing.add('برتری جهت‌دار کمتر از ۱۰ امتیاز است');
      warnings.addAll(missing);
      warnings.add('شرایط اجرایی ورود کامل نیست؛ خروجی WAIT باقی می‌ماند.');
    }
    if(state!=SignalState.wait){
      overlays.add({'type':'line','kind':'Entry','price':entry,'color':'#46D6B3'});
      overlays.add({'type':'line','kind':'SL','price':sl,'color':'#F05D6C'});
      overlays.add({'type':'line','kind':'TP1','price':t1,'color':'#22C99A'});
      overlays.add({'type':'line','kind':'TP2','price':t2,'color':'#22C99A'});
      overlays.add({'type':'line','kind':'TP3','price':t3,'color':'#22C99A'});
    }
    return TechnicalReport(
      state:state,bias1h:b1,bias15m:b15,bias5m:b5,entry:entry,stopLoss:sl,
      tp1:t1,tp2:t2,tp3:t3,score:buyScore>sellScore?buyScore:sellScore,
      buyerPower:buyer,sellerPower:seller,rangeHigh:rangeHigh,rangeLow:rangeLow,
      rsi:rsi,atr:atr,reasons:reasons,warnings:warnings,poiSummary:poiSummary,overlays:overlays,
    );
  }

  List<MarketCandle> _closedCandles(List<MarketCandle> candles,int seconds){
    final now=DateTime.now().toUtc().millisecondsSinceEpoch~/1000;
    return candles.where((c)=>c.time+seconds<=now).toList()
      ..sort((a,b)=>a.time.compareTo(b.time));
  }

  TradeBias _bias(List<MarketCandle> c){
    final closes=c.map((x)=>x.close).toList();
    final e20=_ema(closes,20), e50=_ema(closes,50), last=closes.last;
    if(last>e20&&e20>e50)return TradeBias.bullish;
    if(last<e20&&e20<e50)return TradeBias.bearish;
    return TradeBias.neutral;
  }
  double _ema(List<double> v,int period){
    final k=2/(period+1);var e=v.take(period).reduce((a,b)=>a+b)/period;
    for(var i=period;i<v.length;i++){e=v[i]*k+e*(1-k);}
    return e;
  }
  // Wilder RSI (RMA), seeded with the first n observations.
  double _rsi(List<MarketCandle> c,int n){
    var gain=0.0,loss=0.0;
    for(var i=1;i<=n;i++){
      final d=c[i].close-c[i-1].close;
      if(d>=0)gain+=d;else loss-=d;
    }
    var avgGain=gain/n,avgLoss=loss/n;
    for(var i=n+1;i<c.length;i++){
      final d=c[i].close-c[i-1].close;
      avgGain=(avgGain*(n-1)+(d>0?d:0))/n;
      avgLoss=(avgLoss*(n-1)+(d<0?-d:0))/n;
    }
    if(avgLoss==0)return avgGain==0?50:100;
    final rs=avgGain/avgLoss;return 100-(100/(1+rs));
  }
  // Wilder ATR (RMA), including gaps from the previous close.
  double _atr(List<MarketCandle> c,int n){
    final ranges=<double>[];
    for(var i=1;i<c.length;i++){
      final p=c[i-1].close;
      ranges.add([c[i].high-c[i].low,(c[i].high-p).abs(),(c[i].low-p).abs()].reduce(_max));
    }
    var value=ranges.take(n).reduce((a,b)=>a+b)/n;
    for(var i=n;i<ranges.length;i++)value=(value*(n-1)+ranges[i])/n;
    return value;
  }
  int _power(List<MarketCandle> c){
    final recent=c.sublist(c.length-20);var buy=0.0,sell=0.0;
    for(final x in recent){
      final range=x.high-x.low;if(range<=0)continue;
      final closeLocation=((x.close-x.low)/range).clamp(0.0,1.0);
      final weighted=x.volume>0?x.volume:1.0;
      buy+=closeLocation*weighted;sell+=(1-closeLocation)*weighted;
    }
    final total=buy+sell;if(total==0)return 50;
    return ((buy/total)*100).round().clamp(0,100).toInt();
  }
}
