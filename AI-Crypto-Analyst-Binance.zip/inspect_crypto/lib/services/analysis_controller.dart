import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import 'ai_service.dart';
import 'market_api.dart';
import 'technical_engine.dart';

class AnalysisController extends ChangeNotifier {
  AnalysisController(this.appState)
      : _lastExchange = appState.exchange,
        _lastSymbol = appState.symbol;
  final AppState appState;
  final MarketApi api = MarketApi();
  final TechnicalEngine engine = TechnicalEngine();

  bool loading = false;
  bool restoring = true;
  String status = 'در حال بازیابی آخرین تحلیل ذخیره‌شده...';
  String? error;
  TechnicalReport? report;
  AiConsensus? consensus;
  DateTime? technicalAt;
  DateTime? aiAt;
  List<MarketCandle> history1h = const [];
  List<MarketCandle> history15m = const [];
  List<MarketCandle> history5m = const [];
  int historyCount1h = 0, historyCount15m = 0, historyCount5m = 0;
  String? snapshotId;
  String _lastExchange;
  String _lastSymbol;
  int _requestId = 0;

  String get cacheKey => 'analysis_cache_${appState.exchange}_${appState.symbol}';
  bool get isStale => technicalAt == null ||
      DateTime.now().difference(technicalAt!) > const Duration(minutes: 15);
  bool get isAiStale => aiAt == null ||
      DateTime.now().difference(aiAt!) > const Duration(minutes: 15);

  Future<void> restore() async {
    final requestedExchange = appState.exchange;
    final requestedSymbol = appState.symbol;
    restoring = true;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('analysis_cache_${requestedExchange}_$requestedSymbol');
      if (requestedExchange != appState.exchange || requestedSymbol != appState.symbol) return;
      if (raw != null) {
        final decoded = jsonDecode(raw);
        if (decoded is Map) {
          final map = Map<String, dynamic>.from(decoded);
          if (map['report'] is Map) {
            report = TechnicalReport.fromJson(Map<String, dynamic>.from(map['report']));
            technicalAt = DateTime.tryParse('${map['technicalAt'] ?? ''}');
            historyCount1h = (map['historyCount1h'] as num?)?.toInt() ?? 0;
            historyCount15m = (map['historyCount15m'] as num?)?.toInt() ?? 0;
            historyCount5m = (map['historyCount5m'] as num?)?.toInt() ?? 0;
            snapshotId = map['snapshotId']?.toString();
            history1h = _restoreCandles(map['snapshot1h']);
            history15m = _restoreCandles(map['snapshot15m']);
            history5m = _restoreCandles(map['snapshot5m']);
            // Invalidate pre-Persian / pre-independent-plan AI cache while preserving
            // the technical report and its saved market snapshot.
            if (map['aiSchemaVersion'] == 2 && map['consensus'] is Map) {
              consensus = AiConsensus.fromJson(Map<String, dynamic>.from(map['consensus']));
              aiAt = DateTime.tryParse('${map['aiAt'] ?? ''}');
            } else {
              consensus = null;
              aiAt = null;
            }
            status = 'آخرین تحلیل ذخیره‌شده بازیابی شد؛ ${isStale ? 'قدیمی' : 'تازه'}.';
          }
        }
      } else {
        status = 'هنوز تحلیلی برای این نماد ذخیره نشده است.';
      }
    } catch (e) {
      error = 'بازیابی تحلیل ذخیره‌شده ناموفق بود: $e';
      status = 'خطا در بازیابی تحلیل قبلی.';
    } finally {
      restoring = false;
      notifyListeners();
    }
  }

  Future<void> _persist({String? exchange, String? symbol}) async {
    if (report == null || technicalAt == null) return;
    final targetExchange = exchange ?? appState.exchange;
    final targetSymbol = symbol ?? appState.symbol;
    final prefs = await SharedPreferences.getInstance();
    if (targetExchange != appState.exchange || targetSymbol != appState.symbol) return;
    final data = <String, dynamic>{
      'exchange': targetExchange,
      'symbol': targetSymbol,
      'technicalAt': technicalAt!.toIso8601String(),
      'historyCount1h': historyCount1h,
      'historyCount15m': historyCount15m,
      'historyCount5m': historyCount5m,
      'snapshotId': snapshotId,
      'snapshot1h': history1h.map((c)=>c.toJson()).toList(),
      'snapshot15m': history15m.map((c)=>c.toJson()).toList(),
      'snapshot5m': history5m.map((c)=>c.toJson()).toList(),
      'aiAt': aiAt?.toIso8601String(),
      'aiSchemaVersion': 2,
      'report': report!.toJson(),
      'consensus': consensus?.toJson(),
    };
    await prefs.setString('analysis_cache_${targetExchange}_$targetSymbol', jsonEncode(data));
  }

  List<MarketCandle> _restoreCandles(dynamic raw) {
    if(raw is! List)return const [];
    final out=<MarketCandle>[];
    for(final item in raw){if(item is Map){try{out.add(MarketCandle.fromJson(Map<String,dynamic>.from(item)));}catch(_){}}}
    return List.unmodifiable(out);
  }

  Future<void> saveConsensus(AiConsensus value) async {
    consensus = value;
    aiAt = DateTime.now();
    await _persist();
    notifyListeners();
  }

  Future<void> onStateChanged() async {
    if (_lastExchange == appState.exchange && _lastSymbol == appState.symbol) return;
    _lastExchange = appState.exchange;
    _lastSymbol = appState.symbol;
    _requestId++;
    loading = false;
    report = null;
    consensus = null;
    technicalAt = null;
    aiAt = null;
    history1h = const [];
    history15m = const [];
    history5m = const [];
    historyCount1h = historyCount15m = historyCount5m = 0;
    snapshotId = null;
    error = null;
    status = 'در حال بازیابی تحلیل ذخیره‌شده برای نماد جدید...';
    notifyListeners();
    await restore();
  }

  List<MarketCandle> _closedHistory(List<MarketCandle> candles, int intervalSeconds, int targetCount) {
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final closed = candles.where((c) => c.time + intervalSeconds <= now).toList()
      ..sort((a,b)=>a.time.compareTo(b.time));
    return List.unmodifiable(closed.length > targetCount
        ? closed.sublist(closed.length-targetCount) : closed);
  }


  void _validateFreshCandles(List<MarketCandle> candles, int intervalSeconds, String label) {
    if (candles.isEmpty) throw MarketApiException('تاریخچه $label خالی است.');
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final latest = candles.last;
    final age = now - (latest.time + intervalSeconds);
    // Never run a new analysis from a cache that is more than 2.5 candles old.
    if (age > intervalSeconds * 2.5) {
      throw MarketApiException('داده $label قدیمی است (${(age / 60).round()} دقیقه). دریافت تازه از صرافی ناموفق بود؛ تحلیل با داده قدیمی اجرا نشد.');
    }
  }

  Future<bool> run() async {
    final id = ++_requestId;
    loading = true;
    error = null;
    status = 'دریافت داده‌های 1H، 15M و 5M...';
    notifyListeners();
    final exchange = appState.exchange, symbol = appState.symbol;
    try {
      final responses = await Future.wait([
        api.getKlines(exchange: exchange, symbol: symbol, interval: '1h', limit: 1001, refreshInterval: const Duration(seconds: 15)),
        api.getKlines(exchange: exchange, symbol: symbol, interval: '15m', limit: 1501, refreshInterval: const Duration(seconds: 15)),
        api.getKlines(exchange: exchange, symbol: symbol, interval: '5m', limit: 2001, refreshInterval: const Duration(seconds: 15)),
      ]);
      if (id != _requestId) return false;
      _validateFreshCandles(responses[0], 3600, '1H');
      _validateFreshCandles(responses[1], 900, '15M');
      _validateFreshCandles(responses[2], 300, '5M');
      status = 'محاسبه روند، ساختار، نقدینگی و قدرت خریدار/فروشنده...';
      notifyListeners();
      final result = engine.analyze(h1: responses[0], m15: responses[1], m5: responses[2]);
      if (id != _requestId) return false;
      // The AI receives the same completed candles used by the technical engine;
      // the still-forming candle is excluded to avoid a moving/inconsistent snapshot.
      history1h = _closedHistory(responses[0], 3600, 1000);
      history15m = _closedHistory(responses[1], 900, 1500);
      history5m = _closedHistory(responses[2], 300, 2000);
      historyCount1h = history1h.length;
      historyCount15m = history15m.length;
      historyCount5m = history5m.length;
      snapshotId = '${exchange}_${symbol}_${DateTime.now().toUtc().microsecondsSinceEpoch}_${history1h.last.time}_${history15m.last.time}_${history5m.last.time}';
      report = result;
      // Keep the last AI result independently cached. A technical refresh must
      // not erase the AI result; timestamps make its age visible to the user.
      technicalAt = DateTime.now();
      final historyShort = historyCount1h < 1000 || historyCount15m < 1500 || historyCount5m < 2000;
      status = historyShort
          ? 'تحلیل با تاریخچه کمتر از هدف تکمیل شد: 1H=$historyCount1h/1000، 15M=$historyCount15m/1500، 5M=$historyCount5m/2000. صفحه‌بندی پروکسی را بررسی کنید.'
          : 'تحلیل تکمیل و ذخیره شد؛ کندل بسته‌شده: 1H=$historyCount1h، 15M=$historyCount15m، 5M=$historyCount5m.';
      await _persist(exchange: exchange, symbol: symbol);
      return true;
    } catch (e) {
      if (id != _requestId) return false;
      error = e.toString();
      status = 'تحلیل کامل نشد؛ آخرین تحلیل ذخیره‌شده حفظ شده است.';
      return false;
    } finally {
      if (id == _requestId) {
        loading = false;
        notifyListeners();
      }
    }
  }
}
