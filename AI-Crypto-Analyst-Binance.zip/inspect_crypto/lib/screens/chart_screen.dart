
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import '../services/market_api.dart';
import '../services/analysis_controller.dart';
import '../services/ai_service.dart';

class ChartScreen extends StatefulWidget {
  const ChartScreen({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  @override State<ChartScreen> createState()=>_ChartScreenState();
}
class _ChartScreenState extends State<ChartScreen>{
  int _timeframeSeconds(String tf)=>const {'1m':60,'5m':300,'15m':900,'30m':1800,'1h':3600,'4h':14400,'1d':86400}[tf]??300;
  final MarketApi api=MarketApi();
  Timer? _refreshTimer;
  bool _requestInFlight=false;
  late final WebViewController controller;
  String status='در حال آماده‌سازی نمودار...';
  String? error;
  double? price;
  double? _previousPrice;
  bool _priceUp=true;
  bool loading=false,webReady=false;
  int requestId=0;
  String overlaySource='technical';
  String aiOverlayProvider='gemini';
  bool _sourceLoaded=false;

  @override void initState(){
    super.initState();
    widget.state.addListener(_selectionChanged);
    widget.analysis.addListener(_analysisChanged);
    _loadOverlaySource();
    _refreshTimer=Timer.periodic(const Duration(seconds:5), (_) {
      if(mounted && webReady && !_requestInFlight) _loadMarketData(silent:true);
    });
    controller=WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished:(_){
        webReady=true;
        controller.runJavaScript('window.setCandleDurationSeconds(${_timeframeSeconds(widget.state.timeframe)});');
        _analysisChanged();
        _loadMarketData();
      }))
      ..loadFlutterAsset('assets/chart.html');
  }
  Future<void> _loadOverlaySource() async {
    final prefs=await SharedPreferences.getInstance();
    if(!mounted)return;
    final saved=prefs.getString('chart_overlay_source_v1');
    final savedProvider=prefs.getString('chart_ai_overlay_provider_v1');
    setState(() {
      overlaySource=saved=='ai'?'ai':'technical';
      aiOverlayProvider=const {'gemini','openrouter','groq'}.contains(savedProvider) ? savedProvider! : 'gemini';
      _sourceLoaded=true;
    });
    _analysisChanged();
  }

  AiModelResult? get _selectedAiResult {
    final c=widget.analysis.consensus;
    if(c==null)return null;
    switch(aiOverlayProvider){
      case 'openrouter': return c.openrouter;
      case 'groq': return c.groq;
      default: return c.gemini;
    }
  }

  String _aiOverlayStatus(){
    final result=_selectedAiResult;
    if(result==null)return 'هنوز پاسخی از AI دریافت نشده';
    if(result.status!='ok')return 'مدل انتخابی پاسخ معتبر ندارد';
    final bias=(result.bias??'WAIT').toUpperCase();
    final direction=bias=='BUY'?'خرید':bias=='SELL'?'فروش':'انتظار';
    final valid=_activeOverlays();
    final zones=valid.where((o)=>o['type']=='zone').length;
    final levels=valid.where((o)=>const {'Entry','SL','TP1','TP2','TP3'}.contains(o['kind'])).length;
    return '${result.model} • $direction • $zones ناحیه • $levels سطح معامله';
  }

  List<Map<String,dynamic>> _activeOverlays(){
    if(overlaySource=='technical') return widget.analysis.report?.overlays ?? const [];
    // AI mode is strictly provider-specific: never substitute consensus or technical overlays.
    final result=_selectedAiResult;
    if(result==null || result.status!='ok') return const [];
    return result.overlays.where((o){
      final type=o['type']?.toString();
      if(type=='zone') {
        final low=double.tryParse('${o['low']}');
        final high=double.tryParse('${o['high']}');
        return low!=null && high!=null && low>0 && high>low;
      }
      if(type=='line') {
        final price=double.tryParse('${o['price']}');
        return price!=null && price>0;
      }
      return false;
    }).map((o)=>Map<String,dynamic>.from(o)).toList();
  }

  void _analysisChanged(){
    if(!mounted||!webReady)return;
    final payload=jsonEncode(_activeOverlays());
    controller.runJavaScript('window.setTradeOverlays($payload);');
  }

  Future<void> _changeAiOverlayProvider(String provider) async {
    if(!const {'gemini','openrouter','groq'}.contains(provider) || provider==aiOverlayProvider)return;
    setState(()=>aiOverlayProvider=provider);
    final prefs=await SharedPreferences.getInstance();
    await prefs.setString('chart_ai_overlay_provider_v1',provider);
    _analysisChanged();
  }

  Future<void> _changeOverlaySource(String source) async {
    if(source==overlaySource)return;
    setState(()=>overlaySource=source);
    final prefs=await SharedPreferences.getInstance();
    await prefs.setString('chart_overlay_source_v1',source);
    _analysisChanged();
  }

  void _selectionChanged(){
    requestId++;
    if(!mounted)return;
    if(webReady) {
      controller.runJavaScript('window.setCandleDurationSeconds(${_timeframeSeconds(widget.state.timeframe)});');
      controller.runJavaScript('window.clearTradeOverlays();');
    }
    setState(() { price=null; _previousPrice=null; _priceUp=true; error=null; status='در حال دریافت داده نماد و تایم‌فریم جدید...'; });
    if(webReady && !_requestInFlight)_loadMarketData();
  }

  Future<void> _loadMarketData({bool silent=false}) async {
    if(!webReady || _requestInFlight)return;
    _requestInFlight=true;
    final id=++requestId;
    final exchange=widget.state.exchange,symbol=widget.state.symbol,tf=widget.state.timeframe;
    try{
    if(!silent){
      setState(() {
        loading=true; error=null; price=null; status='در حال دریافت داده واقعی $exchange برای $symbol ($tf)...';
      });
      await controller.runJavaScript('window.clearMarketCandles(${jsonEncode('در حال دریافت داده $exchange...')});');
    }
      final candles=await api.getKlines(
        exchange:exchange,symbol:symbol,interval:tf,limit:silent?2:2000,
        // The chart polls every 5s, but candle history is refreshed at most
        // once per 15s and only the cached tail is requested from Binance.
        refreshInterval:silent?const Duration(seconds:15):Duration.zero,
      );
      if(!mounted||id!=requestId)return;
      // The latest candle close is the freshest available price during incremental updates.
      final lastPrice=silent?candles.last.close:await api.getPrice(exchange:exchange,symbol:symbol);
      if(!mounted||id!=requestId)return;
      final payload=jsonEncode(candles.map((c)=>c.toChartJson()).toList());
      final chartMethod = silent ? 'updateMarketCandles' : 'setMarketCandles';
      final accepted=await controller.runJavaScriptReturningResult('window.$chartMethod($payload)');
      if(!mounted||id!=requestId)return;
      await controller.runJavaScript('window.setTradeOverlays(${jsonEncode(_activeOverlays())});');
      await controller.runJavaScript('window.setLivePrice(${lastPrice.toStringAsFixed(8)});');
      if(!mounted||id!=requestId)return;
      setState((){
        _priceUp = _previousPrice != null
            ? lastPrice >= _previousPrice!
            : lastPrice >= candles.last.close;
        _previousPrice = lastPrice;
        price=lastPrice;loading=false;error=null;
        status=silent
          ? 'داده زنده • به‌روزرسانی خودکار هر ۵ ثانیه • ${TimeOfDay.now().format(context)}'
          : '${candles.length} کندل از $exchange • به‌روزرسانی خودکار فعال است';
        if(accepted.toString()=='false')error='نمودار داده را نپذیرفت.';
      });
    }catch(e){
      if(!mounted||id!=requestId)return;
      setState(() {
        loading=false; error=e.toString(); status=silent?'به‌روزرسانی خودکار ناموفق بود؛ تلاش بعدی انجام می‌شود.':'دریافت داده ناموفق بود.';
      });
      if(!silent) await controller.runJavaScript('window.setChartMessage(${jsonEncode(error)});');
    }finally{
      _requestInFlight=false;
      // If the user changed symbol/timeframe during a request, immediately load the new selection.
      if(mounted && id!=requestId) {
        Future<void>.microtask(() => _loadMarketData());
      }
    }
  }

  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:Listenable.merge([widget.state,widget.analysis]),
    builder:(context,_){
      final exchange=widget.state.exchange,symbol=widget.state.symbol,tf=widget.state.timeframe;
      return Column(children:[
        Padding(padding:const EdgeInsets.fromLTRB(14,14,14,8),child:Row(children:[
          Expanded(child:Text('نمودار ${exchange=='Nobitex'?'نوبیتکس':'Binance'}',style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold))),
          DropdownButton<String>(
            value:tf,items:const ['1m','5m','15m','1h','4h','1d'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),
            onChanged:(v){if(v!=null)widget.state.selectTimeframe(v);},
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal:10, vertical:6),
            decoration: BoxDecoration(
              color: const Color(0xFF163B36),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF46D6B3).withOpacity(.45)),
            ),
            child: Row(mainAxisSize:MainAxisSize.min, children:[
              Container(width:7,height:7,decoration:const BoxDecoration(color:Color(0xFF46D6B3),shape:BoxShape.circle)),
              const SizedBox(width:6),
              Text(error!=null?'اختلال':loading?'اتصال...':'زنده',style:const TextStyle(fontSize:11,color:Color(0xFF8CE5CF))),
            ]),
          ),
        ])),
        Padding(padding:const EdgeInsets.fromLTRB(14,0,14,4),child:Row(children:[
          const Text('منبع ترسیم:',style:TextStyle(color:Colors.white70,fontSize:12)),
          const SizedBox(width:8),
          DropdownButton<String>(
            value:overlaySource,
            isDense:true,
            items:const [
              DropdownMenuItem(value:'technical',child:Text('تکنیکال')),
              DropdownMenuItem(value:'ai',child:Text('هوش مصنوعی')),
            ],
            onChanged:_sourceLoaded?(v){if(v!=null)_changeOverlaySource(v);}:null,
          ),
          if(overlaySource=='ai') ...[
            const SizedBox(width:8),
            DropdownButton<String>(
              value:aiOverlayProvider,
              isDense:true,
              items:const [
                DropdownMenuItem(value:'gemini',child:Text('Gemini')),
                DropdownMenuItem(value:'openrouter',child:Text('OpenRouter')),
                DropdownMenuItem(value:'groq',child:Text('Groq')),
              ],
              onChanged:_sourceLoaded?(v){if(v!=null)_changeAiOverlayProvider(v);}:null,
            ),
          ],
          const Spacer(),
          Expanded(child:Text(overlaySource=='ai'
            ? _aiOverlayStatus()
            : 'تکنیکال • ${widget.analysis.report?.overlays.length ?? 0} سطح',
            textAlign:TextAlign.end,maxLines:1,overflow:TextOverflow.ellipsis,
            style:const TextStyle(fontSize:10,color:Colors.white54))),
        ])),
        Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:4),child:Row(children:[
          Text('$symbol  •  $exchange',style:const TextStyle(color:Colors.white70)),
          const Spacer(),
          if(price!=null)Text(price!.toStringAsFixed(2),style:TextStyle(fontWeight:FontWeight.bold,color:_priceUp?const Color(0xFF22C99A):const Color(0xFFF05D6C))),
        ])),
        Expanded(child:ClipRRect(borderRadius:BorderRadius.circular(14),child:WebViewWidget(controller:controller))),
        Padding(padding:const EdgeInsets.fromLTRB(12,8,12,12),child:Column(children:[
          Text(status,textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:error==null?Colors.white70:Colors.orangeAccent)),
          if(error!=null)TextButton(onPressed:loading?null:_loadMarketData,child:const Text('تلاش مجدد')),
        ])),
      ]);
    },
  );

  @override void dispose(){
    widget.state.removeListener(_selectionChanged);
    widget.analysis.removeListener(_analysisChanged);
    _refreshTimer?.cancel();
    requestId++;
    super.dispose();
  }
}
