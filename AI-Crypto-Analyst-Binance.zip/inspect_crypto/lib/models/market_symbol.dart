class MarketSymbol {
  const MarketSymbol({required this.symbol, required this.exchange});
  final String symbol;
  final String exchange;
}
