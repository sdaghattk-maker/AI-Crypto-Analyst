
import 'package:flutter/foundation.dart';

class AppState extends ChangeNotifier {
  String exchange = 'Binance';
  String symbol = 'BTCUSDT';
  String timeframe = '5m';

  void selectExchange(String value) {
    if (exchange == value) return;
    exchange = value;
    // Keep the same base asset, but do not silently substitute unavailable markets.
    notifyListeners();
  }

  void selectSymbol(String value) {
    if (symbol == value) return;
    symbol = value;
    notifyListeners();
  }

  void selectTimeframe(String value) {
    if (timeframe == value) return;
    timeframe = value;
    notifyListeners();
  }
}
