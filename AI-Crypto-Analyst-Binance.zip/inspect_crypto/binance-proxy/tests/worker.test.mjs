import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker.js';

test('forwards endTime pagination and clamps Binance page size', async () => {
  const originalFetch = globalThis.fetch;
  let requested;
  globalThis.fetch = async url => {
    requested = new URL(url);
    return new Response(JSON.stringify([[1, '100', '101', '99', '100.5', '10', 2]]), {status: 200});
  };
  try {
    const request = new Request('https://proxy.test/?endpoint=klines&symbol=BTCUSDT&interval=5m&limit=2500&endTime=1794943685000');
    const response = await worker.fetch(request);
    const body = await response.json();
    assert.equal(response.status, 200);
    assert.equal(body.ok, true);
    assert.equal(requested.searchParams.get('limit'), '1000');
    assert.equal(requested.searchParams.get('endTime'), '1794943685000');
  } finally { globalThis.fetch = originalFetch; }
});

test('rejects invalid symbols and unsupported intervals before upstream fetch', async () => {
  const invalidSymbol = await worker.fetch(new Request('https://proxy.test/?endpoint=klines&symbol=BTC%2FUSDT&interval=5m'));
  assert.equal(invalidSymbol.status, 400);
  const invalidInterval = await worker.fetch(new Request('https://proxy.test/?endpoint=klines&symbol=BTCUSDT&interval=2m'));
  assert.equal(invalidInterval.status, 400);
});
