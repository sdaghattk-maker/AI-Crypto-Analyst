/**
 * AI Crypto Analyst - Binance public market-data proxy
 * Deploy as Cloudflare Worker: hrs-binance-proxy
 * GET /?endpoint=price&symbol=BTCUSDT
 * GET /?endpoint=klines&symbol=BTCUSDT&interval=5m&limit=1000&endTime=...
 *
 * Uses Binance-documented REST hosts with bounded failover. It does not
 * fabricate data or fall back to cached/stale candles when every host fails.
 */
const BINANCE_HOSTS = [
  "https://api.binance.com",
  "https://api-gcp.binance.com",
  "https://api1.binance.com",
  "https://api2.binance.com",
  "https://api3.binance.com",
  "https://api4.binance.com",
];
const ALLOWED_INTERVALS = new Set(["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w", "1M"]);
const PER_HOST_TIMEOUT_MS = 3500;

function json(data, status = 200, origin = "*") {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Max-Age": "86400",
      "Cache-Control": "no-store",
      "Vary": "Origin",
    },
  });
}

function buildTarget(base, endpoint, params) {
  const target = new URL(base);
  if (endpoint === "price") {
    target.pathname = "/api/v3/ticker/price";
    target.searchParams.set("symbol", params.symbol);
  } else {
    target.pathname = "/api/v3/klines";
    target.searchParams.set("symbol", params.symbol);
    target.searchParams.set("interval", params.interval);
    target.searchParams.set("limit", String(params.limit));
    if (params.startTime) target.searchParams.set("startTime", params.startTime);
    if (params.endTime) target.searchParams.set("endTime", params.endTime);
  }
  return target;
}

export default {
  async fetch(request) {
    const origin = request.headers.get("Origin") || "*";
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: {
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Max-Age": "86400",
      "Vary": "Origin",
    }});
    if (request.method !== "GET") return json({ ok: false, error: "Method not allowed" }, 405, origin);

    const incoming = new URL(request.url);
    const endpoint = incoming.searchParams.get("endpoint");
    const symbol = (incoming.searchParams.get("symbol") || "").toUpperCase();
    if (!/^[A-Z0-9]{5,20}$/.test(symbol)) return json({ ok: false, error: "Invalid symbol" }, 400, origin);

    const params = { symbol };
    if (endpoint === "klines") {
      params.interval = incoming.searchParams.get("interval") || "5m";
      if (!ALLOWED_INTERVALS.has(params.interval)) return json({ ok: false, error: "Invalid interval" }, 400, origin);
      const requestedLimit = Number.parseInt(incoming.searchParams.get("limit") || "500", 10);
      params.limit = Math.max(1, Math.min(1000, Number.isFinite(requestedLimit) ? requestedLimit : 500));
      for (const key of ["startTime", "endTime"]) {
        const value = incoming.searchParams.get(key);
        if (value !== null) {
          if (!/^\d{1,16}$/.test(value)) return json({ ok: false, error: `Invalid ${key}` }, 400, origin);
          params[key] = value;
        }
      }
    } else if (endpoint !== "price") {
      return json({ ok: false, error: "Unsupported endpoint. Use price or klines." }, 400, origin);
    }

    const failures = [];
    for (const base of BINANCE_HOSTS) {
      const target = buildTarget(base, endpoint, params);
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), PER_HOST_TIMEOUT_MS);
      try {
        const upstream = await fetch(target.toString(), {
          method: "GET",
          headers: { "Accept": "application/json" },
          cf: { cacheTtl: 0, cacheEverything: false },
          signal: controller.signal,
        });
        const body = await upstream.text();
        if (upstream.ok) {
          let parsed;
          try { parsed = JSON.parse(body); }
          catch {
            failures.push({ host: target.host, status: upstream.status, error: "Upstream returned invalid JSON" });
            continue;
          }
          return json({ ok: true, data: parsed, source: target.origin, failoverCount: failures.length }, 200, origin);
        }

        let message = body;
        try {
          const parsedError = JSON.parse(body);
          message = parsedError?.msg || parsedError?.message || body;
        } catch { /* retain short HTML/text response for diagnostics */ }
        failures.push({ host: target.host, status: upstream.status, error: String(message).replace(/\s+/g, " ").slice(0, 180) });
        // 429 indicates rate limiting; rotating hosts can worsen it. Stop clearly.
        if (upstream.status === 429 || upstream.status === 418) {
          return json({ ok: false, error: "Binance rate limit or temporary IP ban", upstreamStatus: upstream.status, source: target.origin, attempts: failures }, 503, origin);
        }
      } catch (error) {
        failures.push({ host: target.host, status: 0, error: error?.name === "AbortError" ? "timeout" : String(error?.message || error).slice(0, 180) });
      } finally {
        clearTimeout(timer);
      }
    }

    const last = failures[failures.length - 1] || {};
    return json({
      ok: false,
      error: "All official Binance REST hosts failed; no market data was substituted.",
      upstreamStatus: last.status || 502,
      source: last.host ? `https://${last.host}` : null,
      attempts: failures,
    }, 502, origin);
  },
};
