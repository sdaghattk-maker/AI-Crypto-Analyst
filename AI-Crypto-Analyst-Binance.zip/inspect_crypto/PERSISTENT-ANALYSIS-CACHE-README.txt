Persistent Analysis Cache

The app now stores the latest technical report, chart overlays and Gemini/OpenRouter consensus locally with SharedPreferences.
On app startup, it restores the snapshot for the currently selected exchange and symbol. Restoring never calls the AI Gateway.
A report older than 15 minutes is labeled stale; it remains visible until the user explicitly runs a new analysis.
A failed technical refresh does not overwrite the previous saved snapshot.

Validation: ZIP integrity and static source checks only. Flutter/Dart SDK was not available in this environment, so flutter pub get, flutter analyze, APK build and device restart test were not run.
