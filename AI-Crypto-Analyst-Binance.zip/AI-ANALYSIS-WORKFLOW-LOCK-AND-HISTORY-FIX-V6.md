# AI Crypto Analyst — Workflow Lock & AI History Fix (V6)

## Changes

1. Added a shared `AnalysisController` workflow lock used by Dashboard refresh, full AI analysis, and AI retry. Parallel entry points cannot launch overlapping analysis workflows.
2. Centralized per-provider execution state (`idle`, `running`, `success`, `failed`, `incomplete`) in `AnalysisController`.
3. Separated provider enablement from saved provider output. Disabling a provider does not delete its prior result.
4. When all providers are disabled, the AI action saves settings and exits without refreshing the technical snapshot or clearing the prior AI results.
5. Added a persisted, bounded history of up to ten AI Snapshot results. Historical cards are explicitly marked as previous results and are not used in current Dashboard consensus or Hybrid decisions.
6. Retry filters to providers that remain enabled and are not consensus-eligible; successful providers are not called again. Partial merge continues to preserve earlier successful provider responses.
7. Snapshot IDs are stable for identical closed-candle timestamps and reference price. Re-running the same market snapshot retains its successful AI results and prevents duplicate model requests.
8. Added request-generation checks for symbol/exchange/timeframe changes and snapshot checks before accepting late provider responses.
9. Added Dart regression tests for lock ownership, centralized provider states, and timeframe-generation invalidation; added Node source-contract regression tests for the end-to-end wiring.

## Validation

- Existing Node regression suite: 103 tests passed.
- New Node workflow contract suite: run as part of final validation.
- Flutter/Dart tests and `flutter analyze` require the Flutter/Dart SDK; the current environment did not provide either executable, so these cannot be claimed as executed.
- No live provider API calls, GitHub changes, or Cloudflare Worker deployments were performed.
