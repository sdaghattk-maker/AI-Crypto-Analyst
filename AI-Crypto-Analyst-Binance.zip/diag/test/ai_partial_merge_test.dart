import 'package:flutter_test/flutter_test.dart';
import 'package:ai_crypto_analyst/services/ai_service.dart';

AiModelResult result(String model, String status, {String? bias, String? error}) =>
    AiModelResult(model: model, status: status, bias: bias, error: error);

void main() {
  group('AiConsensus partial retry merge', () {
    test('keeps successful answers when other providers are retried', () {
      final previous = AiConsensus(
        gemini: result('Gemini', 'ok', bias: 'BUY'),
        openrouter: result('OpenRouter', 'error', error: 'rate limit'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-1',
      );
      final retry = AiConsensus(
        gemini: result('Gemini', 'not_selected'),
        openrouter: result('OpenRouter', 'ok', bias: 'BUY'),
        groq: result('Groq', 'not_selected'),
        decision: 'BUY', conflicts: const [], snapshotId: 'snapshot-1',
      );

      final merged = previous.mergePartial(retry);
      expect(merged.gemini.status, 'ok');
      expect(merged.gemini.bias, 'BUY');
      expect(merged.openrouter.status, 'ok');
      expect(merged.groq.status, 'not_selected');
      expect(merged.decision, 'BUY');
      expect(merged.snapshotId, 'snapshot-1');
    });


    test('one successful model is WAIT, not a directional consensus', () {
      final previous = AiConsensus(
        gemini: result('Gemini', 'ok', bias: 'BUY'),
        openrouter: result('OpenRouter', 'error', error: 'timeout'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-3',
      );
      final retry = AiConsensus(
        gemini: result('Gemini', 'not_selected'),
        openrouter: result('OpenRouter', 'error', error: 'still unavailable'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-3',
      );
      final merged = previous.mergePartial(retry);
      expect(merged.decision, 'WAIT');
      expect(merged.conflicts.any((x) => x.contains('اجماع چندمدلی نیست')), isTrue);
    });

    test('returns WAIT when successful providers conflict', () {
      final previous = AiConsensus(
        gemini: result('Gemini', 'ok', bias: 'BUY'),
        openrouter: result('OpenRouter', 'error', error: 'temporary'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-2',
      );
      final retry = AiConsensus(
        gemini: result('Gemini', 'not_selected'),
        openrouter: result('OpenRouter', 'ok', bias: 'SELL'),
        groq: result('Groq', 'not_selected'),
        decision: 'SELL', conflicts: const [], snapshotId: 'snapshot-2',
      );
      expect(previous.mergePartial(retry).decision, 'WAIT');
    });
  });
}
