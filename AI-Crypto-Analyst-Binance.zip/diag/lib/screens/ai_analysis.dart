
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import '../services/analysis_controller.dart';
import '../services/ai_service.dart';
import '../services/hybrid_engine.dart';
import '../services/altfins_service.dart';
import '../services/smart_connectivity_service.dart';

class AiAnalysisScreen extends StatefulWidget{
  const AiAnalysisScreen({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  @override State<AiAnalysisScreen> createState()=>_AiAnalysisScreenState();
}
class _AiAnalysisScreenState extends State<AiAnalysisScreen>{
  final AiService ai=AiService();
  final HybridEngine hybridEngine=HybridEngine();
  final AltFinsService altFins=AltFinsService();
  final SmartConnectivityService _connectivity = SmartConnectivityService();
  ConnectivityReport? _connectivityReport;
  bool _connectivityLoading = false;
  String? _connectivityError;
  bool _altFinsLoading=false;
  Map<String,dynamic>? _altFinsQuota;
  Map<String,Map<String,dynamic>> _altFinsValidation={};
  String? _altFinsError;
  DateTime? _altFinsCheckedAt;
  bool aiLoading=false;
  String status='برای شروع، ابتدا تحلیل تکنیکال سه تایم‌فریم اجرا می‌شود.';
  String? error;
  final Map<String, TextEditingController> _modelControllers = {
    'gemini': TextEditingController(text: 'gemini-3.8-flash'),
    'openrouter': TextEditingController(text: 'qwen/qwen3.8-27b'),
    'groq': TextEditingController(text: 'qwen/qwen3.8-27b'),
  };
  final Map<String, TextEditingController> _fallbackControllers = {
    'gemini': TextEditingController(text: 'gemini-3.7-flash'),
    'openrouter': TextEditingController(text: 'qwen/qwen3.8-27b'),
    'groq': TextEditingController(text: 'openai/gpt-oss-120b'),
  };
  final Map<String, bool> _providerEnabled = {'gemini': true, 'openrouter': true, 'groq': false};
  bool _settingsLoaded = false;
  final Map<String,List<String>> _availableModels = {};
  String? _catalogError;
  bool _catalogLoading = false;
  AiConsensus? get consensus {
    final value = widget.analysis.consensus;
    // Defensive UI gate: only display/use AI output from the active market snapshot.
    return value != null && value.snapshotId != null &&
            value.snapshotId == widget.analysis.snapshotId
        ? value
        : null;
  }

  @override void initState(){ super.initState(); widget.state.addListener(_onAltFinsMarketContextChanged); _initializeSettingsAndCatalog(); _refreshAltFinsQuota(); _loadAltFinsCache(); _refreshConnectivity(); }
  String get _altFinsContextKey => '${widget.state.exchange.toUpperCase()}_${widget.state.symbol.toUpperCase()}';
  String _loadedAltFinsContextKey = '';
  void _onAltFinsMarketContextChanged(){
    final key=_altFinsContextKey;
    if(key==_loadedAltFinsContextKey)return;
    _loadedAltFinsContextKey=key;
    if(mounted)setState(()=>_altFinsValidation={});
    _loadAltFinsCache();
  }
  Future<void> _initializeSettingsAndCatalog() async {
    await _loadAiSettings();
    if (mounted) await _loadModelCatalog();
  }
  @override void dispose(){ widget.state.removeListener(_onAltFinsMarketContextChanged); for(final c in _modelControllers.values){c.dispose();} for(final c in _fallbackControllers.values){c.dispose();} _connectivity.dispose(); super.dispose(); }
  Future<void> _refreshConnectivity() async {
    if (_connectivityLoading) return;
    if (mounted) setState(() { _connectivityLoading = true; _connectivityError = null; });
    try {
      final report = await _connectivity.inspect();
      if (mounted) setState(() => _connectivityReport = report);
    } catch (e) {
      if (mounted) setState(() => _connectivityError = e.toString());
    } finally {
      if (mounted) setState(() => _connectivityLoading = false);
    }
  }

  Widget _connectivityCard() {
    final report = _connectivityReport;
    IconData iconFor(LinkState state) => switch (state) {
      LinkState.available => Icons.check_circle,
      LinkState.degraded => Icons.warning_amber_rounded,
      LinkState.blocked => Icons.block,
      LinkState.notConfigured => Icons.settings_outlined,
      LinkState.unknown => Icons.help_outline,
    };
    Color colorFor(LinkState state) => switch (state) {
      LinkState.available => const Color(0xFF46D6B3),
      LinkState.degraded => Colors.orangeAccent,
      LinkState.blocked => Colors.redAccent,
      LinkState.notConfigured => Colors.blueGrey,
      LinkState.unknown => Colors.white54,
    };
    return Card(
      color: const Color(0xFF10182A),
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.alt_route, color: Color(0xFF8CE5CF)),
            const SizedBox(width: 8),
            const Expanded(child: Text('Smart Connectivity • وضعیت مسیرها', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
            IconButton(
              tooltip: 'بررسی دوباره اتصال‌ها',
              onPressed: _connectivityLoading ? null : _refreshConnectivity,
              icon: _connectivityLoading
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.refresh),
            ),
          ]),
          const Text('مسیر امن: AIها و altFINS از Gateway؛ Chart Analyzer از WebView رسمی؛ Binance از Proxy مستقل. کلیدها داخل APK قرار نمی‌گیرند.',
              style: TextStyle(fontSize: 10, color: Colors.white60)),
          if (_connectivityError != null) Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(_connectivityError!, style: const TextStyle(color: Colors.orangeAccent, fontSize: 11)),
          ),
          if (report == null && _connectivityLoading) const Padding(
            padding: EdgeInsets.symmetric(vertical: 10), child: LinearProgressIndicator(),
          ),
          if (report != null) ...[
            const SizedBox(height: 8),
            ...report.items.map((item) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(iconFor(item.state), size: 17, color: colorFor(item.state)),
                const SizedBox(width: 8),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(item.name, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                  Text(item.detail, style: const TextStyle(fontSize: 10, color: Colors.white60)),
                ])),
                if (item.latencyMs != null) Text('${item.latencyMs}ms', style: const TextStyle(fontSize: 10, color: Colors.white38)),
              ]),
            )),
            Text('آخرین بررسی: ${report.checkedAt.toLocal().toString().substring(0, 16)}',
                style: const TextStyle(fontSize: 10, color: Colors.white38)),
          ],
          const SizedBox(height: 5),
          const Text('توجه: خطای Gateway به‌تنهایی اثبات فیلترینگ ISP نیست. VPN محدودیت مجوز یا سیاست منطقه‌ای ارائه‌دهنده را رفع نمی‌کند؛ برنامه مسیر جایگزین غیرمجاز ایجاد نمی‌کند.',
              style: TextStyle(fontSize: 10, color: Colors.orangeAccent)),
        ]),
      ),
    );
  }

  Future<void> _loadAiSettings() async {
    final prefs=await SharedPreferences.getInstance();
    if(!mounted)return;
    setState((){
      for(final key in _modelControllers.keys){
        _modelControllers[key]!.text=prefs.getString('ai_model_$key')??_modelControllers[key]!.text;
        _fallbackControllers[key]!.text=prefs.getString('ai_fallback_model_$key')??_fallbackControllers[key]!.text;
        _providerEnabled[key]=prefs.getBool('ai_provider_$key')??(_providerEnabled[key]??true);
      }
      _settingsLoaded=true;
    });
  }
  // Curated models are ordered by published reasoning/finance evidence.
  // Provider live catalogs only confirm availability; they do not set ranking.
  List<String> _rankedModelsFor(String provider, List<String> live) {
    const ranking = <String, List<String>>{
      'gemini': [
        'gemini-3.8-flash', 'gemini-3.7-flash', 'gemini-3.6-flash',
        'gemini-3.5-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite',
        'gemini-2.5-flash',
      ],
      'openrouter': [
        'qwen/qwen4-max', 'qwen/qwen3.8-27b', 'openai/gpt-oss-120b', 'inclusionai/ling-3.2-flash:free',
        'baidu/ernie-5.5-flash-preview:free', 'nvidia/nemotron-3-ultra-550b-a55b',
        'google/gemma-4-31b-it', 'google/gemma-4-26b-a4b-it', 'openai/gpt-oss-20b',
      ],
      'groq': [
        'qwen/qwen3.8-27b', 'openai/gpt-oss-120b', 'openai/gpt-oss-20b',
        'llama-3.3-70b-versatile', 'llama-3.1-8b-instant',
      ],
    };
    final allowed = ranking[provider] ?? const <String>[];
    return allowed.where(live.contains).toList(growable: false);
  }

  Future<void> _loadModelCatalog() async {
    if (_catalogLoading) return;
    setState(() => _catalogLoading = true);
    try {
      final models = await ai.fetchModelCatalog();
      if (!mounted) return;
      setState(() {
        for (final key in ['gemini','openrouter','groq']) {
          _availableModels[key] = _rankedModelsFor(key, models[key] ?? const <String>[]);
          // Keep saved selection if it still exists; otherwise choose a valid live model.
          final list = _availableModels[key]!;
          if (list.isNotEmpty && !list.contains(_modelControllers[key]!.text)) {
            _modelControllers[key]!.text = list.first;
          }
          if (list.isNotEmpty && (!list.contains(_fallbackControllers[key]!.text) || _fallbackControllers[key]!.text == _modelControllers[key]!.text)) {
            _fallbackControllers[key]!.text = list.firstWhere((m) => m != _modelControllers[key]!.text, orElse: () => list.first);
          }
        }
        _catalogError = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _catalogError = e.toString());
    } finally {
      if (mounted) setState(() => _catalogLoading = false);
    }
  }
  Future<void> _saveAiSettings() async {
    final prefs=await SharedPreferences.getInstance();
    for(final key in _modelControllers.keys){
      final model=_modelControllers[key]!.text.trim();
      if(model.isNotEmpty) await prefs.setString('ai_model_$key',model);
      final fallback=_fallbackControllers[key]!.text.trim();
      if(fallback.isNotEmpty) await prefs.setString('ai_fallback_model_$key',fallback);
      await prefs.setBool('ai_provider_$key',_providerEnabled[key]??false);
    }
  }

  List<String> get _failedProviders {
    final current = consensus;
    if (current == null) return const [];
    final results = <String, AiModelResult>{
      'gemini': current.gemini,
      'openrouter': current.openrouter,
      'groq': current.groq,
    };
    return results.entries
        .where((e) => e.value.status != 'ok' && e.value.status != 'not_selected')
        .map((e) => e.key)
        .toList();
  }

  Future<void> _refreshAltFinsQuota() async {
    try {
      final result=await altFins.getQuota();
      if(!mounted)return;
      setState((){_altFinsQuota=result;_altFinsError=null;_altFinsCheckedAt=DateTime.now();});
    } catch(e) {
      if(!mounted)return;
      setState(()=>_altFinsError='دریافت سهمیه altFINS ناموفق بود: $e');
    }
  }

  Future<void> _loadAltFinsCache() async {
    final symbol=widget.state.symbol, exchange=widget.state.exchange;
    _loadedAltFinsContextKey='${exchange.toUpperCase()}_${symbol.toUpperCase()}';
    try {
      final results=await Future.wait([
        altFins.loadCached(symbol:symbol,timeframe:'15m',exchange:exchange),
        altFins.loadCached(symbol:symbol,timeframe:'1h',exchange:exchange),
      ]);
      if(!mounted || widget.state.symbol!=symbol || widget.state.exchange!=exchange)return;
      setState(() {
        _altFinsValidation={
          if(results[0]!=null)'15m':results[0]!,
          if(results[1]!=null)'1h':results[1]!,
        };
        _altFinsCheckedAt=DateTime.now();
      });
    } catch (_) { /* Cache is optional; network/analysis must remain usable. */ }
  }

  Future<void> _refreshAltFinsValidation({bool forceRefresh=true}) async {
    if(_altFinsLoading)return;
    final symbol=widget.state.symbol, exchange=widget.state.exchange;
    setState(()=>_altFinsLoading=true);
    try {
      final results=await Future.wait([
        altFins.validateSmart(symbol:symbol,timeframe:'15m',exchange:exchange,forceRefresh:forceRefresh),
        altFins.validateSmart(symbol:symbol,timeframe:'1h',exchange:exchange,forceRefresh:forceRefresh),
      ]);
      if(!mounted || widget.state.symbol!=symbol || widget.state.exchange!=exchange)return;
      setState((){
        _altFinsValidation={'15m':results[0],'1h':results[1]};
        _altFinsCheckedAt=DateTime.now();
        final failed=results.any((r)=>r['ok']!=true || r['status']!='AVAILABLE');
        _altFinsError=failed?'بروزرسانی کامل نبود؛ داده قبلی فقط برای نمایش و با وضعیت منقضی نگهداری شده است.':null;
      });
    } catch(e) {
      if(mounted)setState(()=>_altFinsError='اعتبارسنجی altFINS در دسترس نیست: $e');
    } finally { if(mounted)setState(()=>_altFinsLoading=false); }
  }

  String _altValue(dynamic value) {
    if(value==null)return '—';
    if(value is num)return value.toStringAsFixed(value.abs()>=100?2:4);
    return value.toString();
  }

  Widget _altFinsCard() {
    final quota=_altFinsQuota?['quota'];
    final monthly=quota is Map ? quota['monthlyAvailablePermits'] : null;
    final aiPrompts=quota is Map ? quota['monthlyAvailableAiTradeSetupPrompts'] : null;
    final quotaStatus='${_altFinsQuota?['status']??'در انتظار بررسی'}';
    return Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[const Icon(Icons.query_stats,color:Color(0xFF8CE5CF)),const SizedBox(width:8),const Expanded(child:Text('اعتبارسنجی کمکی altFINS',style:TextStyle(fontWeight:FontWeight.bold,fontSize:16))),Text(quotaStatus,style:TextStyle(fontSize:11,color:quotaStatus=='AVAILABLE'?const Color(0xFF46D6B3):Colors.orangeAccent))]),
      const SizedBox(height:6),
      Text('سهمیه ماهانه: ${monthly??'—'} درخواست • AI Trade Setup: ${aiPrompts??'—'}',style:const TextStyle(fontSize:11,color:Colors.white70)),
      const SizedBox(height:8),
      SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:_altFinsLoading?null:()=>_refreshAltFinsValidation(forceRefresh:true),icon:_altFinsLoading?const SizedBox(width:15,height:15,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.sync,size:17),label:Text(_altFinsLoading?'در حال دریافت داده‌ها...':'به‌روزرسانی اعتبارسنجی 15M و 1H'))),
      if(_altFinsValidation.isEmpty)const Text('هنوز داده اعتبارسنجی دریافت نشده است.',style:TextStyle(fontSize:11,color:Colors.white54)),
      ...['15m','1h'].where(_altFinsValidation.containsKey).map((tf){
        final rawResult = _altFinsValidation[tf];
        final r = rawResult == null ? <String, dynamic>{} : Map<String, dynamic>.from(rawResult);
        final rawCache = r['_cache'];
        final cache = rawCache is Map ? Map<String, dynamic>.from(rawCache) : <String, dynamic>{};
        final fresh=cache['fresh']==true && r['ok']==true && r['status']=='AVAILABLE';
        final rawData=r['data'] is Map?r['data']:r['_previousData'];
        final data=rawData is Map?Map<String,dynamic>.from(rawData):<String,dynamic>{};
        final st=fresh?'AVAILABLE':(data.isNotEmpty?'STALE • فقط نمایش':'${r['status']??'UNAVAILABLE'}');
        return Padding(padding:const EdgeInsets.only(top:8),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('$tf • $st',style:TextStyle(fontWeight:FontWeight.bold,color:st=='AVAILABLE'?const Color(0xFF46D6B3):Colors.orangeAccent)),
          if(data.isNotEmpty)Wrap(spacing:12,runSpacing:5,children:[
            Text('RSI ${_altValue(data['rsi14'])}'),Text('ADX ${_altValue(data['adx'])}'),Text('MACD ${_altValue(data['macd'])}'),
            Text('EMA9 ${_altValue(data['ema9'])}'),Text('EMA50 ${_altValue(data['ema50'])}'),Text('EMA200 ${_altValue(data['ema200'])}'),
            Text('RVOL ${_altValue(data['relativeVolume'])}'),Text('Trend ${_altValue(data['shortTermTrend'])}'),
            Text('Support ${_altValue(data['support'])}'),Text('Resistance ${_altValue(data['resistance'])}'),
          ].map((w)=>DefaultTextStyle(style:const TextStyle(fontSize:10,color:Colors.white70),child:w)).toList()),
          if(!fresh)Text(data.isNotEmpty?'این داده منقضی است و در تحلیل/هم‌سنجی استفاده نمی‌شود.':'${r['error']??'داده تازه در دسترس نیست.'}',style:const TextStyle(fontSize:10,color:Colors.orangeAccent)),
          if(cache['fetchedAt']!=null)Text('دریافت: ${cache['fetchedAt']} • اعتبار: ${fresh? 'معتبر':'پایان‌یافته'}',style:const TextStyle(fontSize:9,color:Colors.white38)),
        ]));
      }),
      if(_altFinsCheckedAt!=null)Text('آخرین بررسی: ${_altFinsCheckedAt!.toLocal().toString().substring(0,16)}',style:const TextStyle(fontSize:10,color:Colors.white38)),
      if(_altFinsError!=null)Text(_altFinsError!,style:const TextStyle(fontSize:10,color:Colors.orangeAccent)),
      const Text('نقش altFINS فقط اعتبارسنجی کمکی است؛ در تصمیم Technical، AI یا Hybrid دخالت نمی‌کند. تایم‌فریم 5M پشتیبانی نمی‌شود.',style:TextStyle(fontSize:10,color:Colors.white54)),
    ])));
  }

  String _directionLabel(String value) {
    switch(value.toUpperCase()) { case 'BUY': case 'BULLISH': return 'صعودی'; case 'SELL': case 'BEARISH': return 'نزولی'; default: return 'خنثی/نامشخص'; }
  }

  String _altInterpretation(Map<String,dynamic> d) {
    final parts=<String>[];
    final trend='${d['shortTermTrend']??''}'.toUpperCase();
    if(trend.contains('BULL')||trend.contains('UP')) parts.add('روند کوتاه‌مدت صعودی');
    else if(trend.contains('BEAR')||trend.contains('DOWN')) parts.add('روند کوتاه‌مدت نزولی');
    final rsi=num.tryParse('${d['rsi14']??''}');
    if(rsi!=null) parts.add(rsi>=70?'RSI در اشباع خرید':rsi<=30?'RSI در اشباع فروش':rsi>=55?'مومنتوم متمایل به خریدار':rsi<=45?'مومنتوم متمایل به فروشنده':'RSI خنثی');
    final adx=num.tryParse('${d['adx']??''}');
    if(adx!=null) parts.add(adx>=25?'قدرت روند مناسب':'قدرت روند ضعیف/محدود');
    final macd=num.tryParse('${d['macd']??''}');
    if(macd!=null) parts.add(macd>0?'MACD مثبت':macd<0?'MACD منفی':'MACD نزدیک صفر');
    final e9=num.tryParse('${d['ema9']??''}'), e50=num.tryParse('${d['ema50']??''}'), e200=num.tryParse('${d['ema200']??''}');
    if(e9!=null&&e50!=null&&e200!=null) parts.add(e9>e50&&e50>e200?'چیدمان EMA صعودی':e9<e50&&e50<e200?'چیدمان EMA نزولی':'چیدمان EMA مختلط');
    return parts.isEmpty?'داده کافی برای تفسیر موجود نیست':parts.join(' • ');
  }

  String _altDirection(Map<String,dynamic> d) {
    var score=0;
    final trend='${d['shortTermTrend']??''}'.toUpperCase();
    if(trend.contains('BULL')||trend.contains('UP')) score+=2;
    if(trend.contains('BEAR')||trend.contains('DOWN')) score-=2;
    final rsi=num.tryParse('${d['rsi14']??''}'); if(rsi!=null){if(rsi>=55&&rsi<70)score++;if(rsi<=45&&rsi>30)score--;}
    final macd=num.tryParse('${d['macd']??''}'); if(macd!=null){if(macd>0)score++;if(macd<0)score--;}
    final a=num.tryParse('${d['ema9']??''}'),b=num.tryParse('${d['ema50']??''}'),c=num.tryParse('${d['ema200']??''}');
    if(a!=null&&b!=null&&c!=null){if(a>b&&b>c)score+=2;if(a<b&&b<c)score-=2;}
    return score>=2?'BUY':score<=-2?'SELL':'WAIT';
  }

  String _alignment(String a,String b) {
    if(a=='WAIT'||b=='WAIT'||a.isEmpty||b.isEmpty)return 'قابل‌مقایسه نیست';
    return a==b?'هم‌راستا':'ناهم‌راستا';
  }

  Widget _marketIntelCard(dynamic report, AiConsensus? c) {
    final rows=<Widget>[];
    for(final tf in ['15m','1h']) {
      final r=_altFinsValidation[tf]; if(r==null || r['usableForAnalysis']!=true) continue;
      final rawData = r['data'];
      final data = rawData is Map ? Map<String, dynamic>.from(rawData) : <String, dynamic>{};
      if(data.isEmpty) continue;
      final alt=_altDirection(data);
      final technical=report==null?'WAIT':(report.state.toString().split('.').last.toUpperCase()=='BUY'?'BUY':report.state.toString().split('.').last.toUpperCase()=='SELL'?'SELL':'WAIT');
      Widget alignLine(String name,String direction)=>Padding(padding:const EdgeInsets.only(top:3),child:Row(children:[Expanded(child:Text(name,style:const TextStyle(fontSize:10,color:Colors.white60))),Text(_alignment(alt,direction),style:TextStyle(fontSize:10,fontWeight:FontWeight.bold,color:_alignment(alt,direction)=='هم‌راستا'?const Color(0xFF46D6B3):_alignment(alt,direction)=='ناهم‌راستا'?Colors.orangeAccent:Colors.white54))]));
      rows.add(Container(margin:const EdgeInsets.only(top:8),padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFF0D1726),borderRadius:BorderRadius.circular(10)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[Expanded(child:Text('altFINS • ${tf.toUpperCase()}',style:const TextStyle(fontWeight:FontWeight.bold))),Text(_directionLabel(alt),style:TextStyle(fontWeight:FontWeight.bold,color:alt=='BUY'?const Color(0xFF46D6B3):alt=='SELL'?const Color(0xFFF06470):Colors.amber))]),
        const SizedBox(height:5),Text(_altInterpretation(data),style:const TextStyle(fontSize:11,color:Colors.white70,height:1.45)),
        const SizedBox(height:6),const Text('هم‌سنجی با منابع',style:TextStyle(fontSize:10,fontWeight:FontWeight.bold,color:Colors.white54)),
        alignLine('Technical',technical),
        if(c!=null) ...[
          alignLine('Gemini',c.gemini.status=='ok'?(c.gemini.bias??'WAIT').toUpperCase():'WAIT'),
          alignLine('OpenRouter',c.openrouter.status=='ok'?(c.openrouter.bias??'WAIT').toUpperCase():'WAIT'),
          alignLine('Groq',c.groq.status=='ok'?(c.groq.bias??'WAIT').toUpperCase():'WAIT'),
          alignLine('Hybrid + Gemini',report==null?'WAIT':hybridEngine.evaluate(report,c.gemini).decision),
          alignLine('Hybrid + OpenRouter',report==null?'WAIT':hybridEngine.evaluate(report,c.openrouter).decision),
          alignLine('Hybrid + Groq',report==null?'WAIT':hybridEngine.evaluate(report,c.groq).decision),
        ],
      ])));
    }
    return Card(child:Padding(padding:const EdgeInsets.all(13),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Row(children:[Icon(Icons.insights,color:Color(0xFF8CE5CF)),SizedBox(width:7),Expanded(child:Text('Market Intelligence • تفسیر و هم‌سنجی',style:TextStyle(fontWeight:FontWeight.bold,fontSize:15)))]),
      const SizedBox(height:5),
      const Text('ابتدا برداشت قابل‌فهم نمایش داده می‌شود؛ مقادیر خام شاخص‌ها نیز در پنل altFINS بالا قابل مشاهده‌اند. مقایسه صرفاً هم‌جهتی را نشان می‌دهد و altFINS وارد محاسبه Technical یا Hybrid نمی‌شود.',style:TextStyle(fontSize:10,color:Colors.white54,height:1.4)),
      if(rows.isEmpty)const Padding(padding:EdgeInsets.only(top:8),child:Text('پس از دریافت داده 15M و 1H، تفسیر و هم‌سنجی اینجا نمایش داده می‌شود.',style:TextStyle(fontSize:11,color:Colors.white54))) else ...rows,
    ])));
  }

  Future<void> _runAiProviders(List<String> providers, {required String label}) async {
    final report = widget.analysis.report;
    if (report == null || widget.analysis.snapshotId == null ||
        widget.analysis.latestReferencePrice == null ||
        widget.analysis.latestReferencePrice! <= 0 ||
        widget.analysis.history1h.isEmpty || widget.analysis.history15m.isEmpty ||
        widget.analysis.history5m.isEmpty) {
      setState(() { aiLoading = false; error = 'Snapshot معتبر شامل قیمت مرجع و تاریخچه کندل در دسترس نیست؛ ابتدا تحلیل کامل و تازه را اجرا کنید.'; });
      return;
    }
    if (providers.isEmpty) {
      setState(() { status = 'همه مدل‌های انتخاب‌شده پاسخ معتبر دارند؛ درخواست جدیدی ارسال نشد.'; });
      return;
    }
    final requestedExchange = widget.state.exchange;
    final requestedSymbol = widget.state.symbol;
    final snapshot = widget.analysis.snapshotId;
    // Freeze the complete request payload before the first await. Otherwise a
    // concurrent technical refresh could pair an old Snapshot ID with new data.
    final snapshotHistory1h = widget.analysis.history1h;
    final snapshotHistory15m = widget.analysis.history15m;
    final snapshotHistory5m = widget.analysis.history5m;
    final snapshotReferencePrice = widget.analysis.latestReferencePrice!;
    setState(() { aiLoading = true; error = null; status = '$label: ${providers.join(', ')}'; });
    try {
      await _saveAiSettings();
      if (widget.state.exchange != requestedExchange ||
          widget.state.symbol != requestedSymbol ||
          widget.analysis.snapshotId != snapshot ||
          widget.analysis.report != report) {
        if (mounted) setState(() { aiLoading = false; status = 'Snapshot پیش از ارسال درخواست تغییر کرد؛ درخواست قدیمی ارسال نشد.'; });
        return;
      }
      final result = await ai.analyze(
        exchange: requestedExchange,
        symbol: requestedSymbol,
        history1h: snapshotHistory1h,
        history15m: snapshotHistory15m,
        history5m: snapshotHistory5m,
        modelSelection: {for (final e in _modelControllers.entries) e.key: e.value.text.trim()},
        fallbackSelection: {for (final e in _fallbackControllers.entries) e.key: e.value.text.trim()},
        selectedProviders: providers,
        snapshotId: snapshot,
        referencePrice: snapshotReferencePrice,
      );
      if (!mounted) return;
      if (widget.state.exchange != requestedExchange || widget.state.symbol != requestedSymbol ||
          widget.analysis.snapshotId != snapshot || widget.analysis.report != report) {
        setState(() { aiLoading = false; status = 'Snapshot هنگام دریافت پاسخ تغییر کرد؛ نتیجه برای جلوگیری از اختلاط ذخیره نشد.'; });
        return;
      }
      // Same-snapshot merge preserves successful answers for providers that
      // were not selected in this retry.
      final saved = await widget.analysis.saveConsensus(result, mergeSameSnapshot: true);
      if (!mounted) return;
      if (!saved) {
        setState(() { aiLoading = false; status = 'پاسخ دریافت شد اما Snapshot در این فاصله تغییر کرده بود؛ پاسخ قدیمی ذخیره یا نمایش داده نشد.'; });
        return;
      }
      final stillFailed = _failedProviders;
      setState(() {
        aiLoading = false;
        status = stillFailed.isEmpty
            ? 'مدل‌های اجراشده برای همین Snapshot پاسخ معتبر دارند.'
            : 'پاسخ‌ها ذخیره شد؛ هنوز بدون پاسخ معتبر: ${stillFailed.join(', ')}. فقط همین مدل‌ها را دوباره اجرا کنید.';
      });
    } catch (e) {
      if (!mounted) return;
      // A transport-level failure has no provider payload. Persist an explicit
      // error per requested provider so the user can retry only those models.
      final failure = AiConsensus(
        gemini: providers.contains('gemini')
            ? AiModelResult(model: 'Gemini', status: 'error', error: e.toString())
            : const AiModelResult(model: 'Gemini', status: 'not_selected'),
        openrouter: providers.contains('openrouter')
            ? AiModelResult(model: 'OpenRouter', status: 'error', error: e.toString())
            : const AiModelResult(model: 'OpenRouter', status: 'not_selected'),
        groq: providers.contains('groq')
            ? AiModelResult(model: 'Groq', status: 'error', error: e.toString())
            : const AiModelResult(model: 'Groq', status: 'not_selected'),
        decision: 'WAIT',
        conflicts: [e.toString()],
        snapshotId: snapshot,
      );
      final failureSaved = await widget.analysis.saveConsensus(failure, mergeSameSnapshot: true);
      if (!mounted) return;
      if (!failureSaved) {
        setState(() { aiLoading = false; status = 'درخواست ناموفق بود و Snapshot نیز تغییر کرده است؛ خطای مربوط به Snapshot قدیمی ذخیره نشد.'; });
        return;
      }
      setState(() {
        aiLoading = false;
        error = e.toString();
        status = 'ارتباط ناموفق بود؛ پاسخ‌های قبلی حفظ شدند. امکان تلاش مجدد فقط برای مدل‌های ناموفق فراهم است.';
      });
    }
  }

  Future<void> _retryFailedOnly() async {
    final failed = _failedProviders;
    if (failed.isEmpty) return;
    await _runAiProviders(failed, label: 'تلاش مجدد فقط برای مدل‌های ناموفق');
  }

  Future<void> _runFullAnalysis() async{
    setState(() {
      aiLoading=true; error=null; status='در حال اجرای موتور تکنیکال...';
    });
    final completed = await widget.analysis.run();
    if(!mounted)return;
    if(!completed){
      setState(() { aiLoading=false; error=widget.analysis.error??'تحلیل جدید تکمیل نشد؛ تحلیل قبلی حفظ شده است.'; status='درخواست AI ارسال نشد تا تحلیل قدیمی به‌اشتباه دوباره پردازش نشود.'; });
      return;
    }
    final report=widget.analysis.report;
    if(report==null){
      setState(() {
        aiLoading=false; error=widget.analysis.error??'تحلیل تکنیکال انجام نشد.'; status='تحلیل AI متوقف شد.';
      });
      return;
    }
    // altFINS is a non-blocking 15m/1h validation layer; never delay AI execution.
    _refreshAltFinsValidation(forceRefresh:false);
    if(!ai.isConfigured){
      setState(() {
        aiLoading=false; status='موتور تکنیکال آماده است؛ اتصال AI Gateway در انتظار تنظیم است.';
      });
      return;
    }
    final selectedProviders = _providerEnabled.entries.where((e) => e.value).map((e) => e.key).toList();
    if (selectedProviders.isEmpty) {
      setState(() { aiLoading = false; error = 'حداقل یک ارائه‌دهنده را انتخاب کنید.'; });
      return;
    }
    // A fresh full run uses the newly-created snapshot. The controller replaces
    // old-snapshot results automatically; retries use the same snapshot and merge.
    await _runAiProviders(selectedProviders, label: 'ارسال Snapshot ذخیره‌شده به مدل‌های انتخاب‌شده');
  }

  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:Listenable.merge([widget.state,widget.analysis]),
    builder:(context,_){
      final report=widget.analysis.report;
      return ListView(padding:const EdgeInsets.all(18),children:[
        const SizedBox(height:8),
        const Text('گزارش تحلیل AI',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        Text('${widget.state.symbol} • ${widget.state.exchange}',style:const TextStyle(color:Colors.white60)),
        const SizedBox(height:8),
        if(widget.analysis.report!=null) Card(child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[
          Icon(widget.analysis.isStale?Icons.warning_amber_rounded:Icons.check_circle_outline,
            color:widget.analysis.isStale?Colors.orangeAccent:const Color(0xFF46D6B3)),
          const SizedBox(width:8),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(widget.analysis.isStale?'تحلیل ذخیره‌شده قدیمی است':'آخرین تحلیل ذخیره و بازیابی شده',style:const TextStyle(fontWeight:FontWeight.bold)),
            Text('زمان تحلیل: ${widget.analysis.technicalAt?.toLocal().toString().substring(0,16) ?? '—'}',style:const TextStyle(fontSize:11,color:Colors.white60)),
            if(widget.analysis.technicalAt!=null) Text('سن تحلیل: ${_age(widget.analysis.technicalAt!)}',style:const TextStyle(fontSize:11,color:Colors.white60)),
            if(widget.analysis.aiAt!=null) Text('پاسخ AI: ${widget.analysis.aiAt!.toLocal().toString().substring(0,16)} • ${widget.analysis.isAiStale ? 'قدیمی' : 'تازه'}',style:TextStyle(fontSize:11,color:widget.analysis.isAiStale?Colors.orangeAccent:Colors.white60)),
            Text('تاریخچه کندل بسته‌شده: 1H ${widget.analysis.historyCount1h} • 15M ${widget.analysis.historyCount15m} • 5M ${widget.analysis.historyCount5m}',style:const TextStyle(fontSize:11,color:Colors.white60)),
          ])),
          Text(widget.analysis.isStale?'قدیمی':'تازه',style:TextStyle(color:widget.analysis.isStale?Colors.orangeAccent:const Color(0xFF46D6B3))),
        ]))),
        _connectivityCard(),
        _altFinsCard(),
        _marketIntelCard(report, consensus),
        const SizedBox(height:14),
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('اجرای تحلیل کامل',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),
          const Text('کندل‌های بسته‌شده 1H، 15M و 5M پس از ذخیره در یک Snapshot ثابت، مستقل برای هر مدل ارسال می‌شوند. پاسخ هر مدل جداگانه نگهداری می‌شود. تحلیل تکنیکال مستقل باقی می‌ماند و منبع رسم چارت طبق انتخاب شما فقط تکنیکال یا AI است.'),
          const SizedBox(height:10),
          if(!_settingsLoaded) const LinearProgressIndicator(),
          ..._modelControllers.entries.map((entry)=>_modelSetting(entry.key,entry.value,_fallbackControllers[entry.key]!)),
          if(_catalogError!=null) Padding(padding:const EdgeInsets.only(top:4),child:Text('فهرست مدل‌ها دریافت نشد؛ شناسه را دستی وارد کنید. $_catalogError',style:const TextStyle(fontSize:11,color:Colors.orangeAccent))),
          Align(alignment:Alignment.centerLeft,child:TextButton.icon(onPressed:_catalogLoading?null:_loadModelCatalog,icon:_catalogLoading?const SizedBox(width:16,height:16,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.refresh,size:16),label:Text(_catalogLoading?'در حال دریافت مدل‌های فعال...':'به‌روزرسانی زنده فهرست مدل‌ها'))),
          const SizedBox(height:12),
          SizedBox(width:double.infinity,child:FilledButton.icon(
            onPressed:aiLoading?null:_runFullAnalysis,
            icon:aiLoading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.psychology),
            label:Text(aiLoading?'در حال تحلیل...':'اجرای تحلیل با مدل‌های انتخاب‌شده'),
          )),
          if (_failedProviders.isNotEmpty) ...[
            const SizedBox(height:8),
            SizedBox(width:double.infinity,child:OutlinedButton.icon(
              onPressed:aiLoading?null:_retryFailedOnly,
              icon:const Icon(Icons.replay),
              label:Text('تلاش مجدد فقط برای ${_failedProviders.length} مدل ناموفق'),
            )),
            const Padding(padding:EdgeInsets.only(top:4),child:Text('پاسخ‌های موفق قبلی حفظ می‌شوند و دوباره درخواست نمی‌خورند؛ فقط مدل‌های ناموفق برای همان Snapshot اجرا می‌شوند.',style:TextStyle(fontSize:10,color:Colors.white54))),
          ],
          const SizedBox(height:8),
          Text(status,style:const TextStyle(color:Colors.white70,fontSize:12)),
          if(widget.analysis.restoring) const Padding(padding:EdgeInsets.only(top:6),child:LinearProgressIndicator()),
          if(error!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(error!,style:const TextStyle(color:Colors.orangeAccent))),
        ]))),
        if(report!=null)...[
          _section('گزارش فنی مبنا'),
          Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('سیگنال تکنیکال: ${report.state.toString().split('.').last.toUpperCase()}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
            Text('سوگیری 1H: ${report.bias1h.toString().split('.').last} | 15M: ${report.bias15m.toString().split('.').last} | 5M: ${report.bias5m.toString().split('.').last}'),
            const SizedBox(height:8),
            Text('برآورد قدرت کندلی خریدار ${report.buyerPower}% • فروشنده ${report.sellerPower}%'),
            if(report.entry!=null)Text('Entry ${_p(report.entry)} | SL ${_p(report.stopLoss)} | TP ${_p(report.tp1)} / ${_p(report.tp2)} / ${_p(report.tp3)}'),
            ...report.reasons.map((x)=>Text('• $x')),
            if(report.poiSummary.isNotEmpty)const Padding(padding:EdgeInsets.only(top:10),child:Text('ساختار و نواحی مهم بازار',style:TextStyle(fontWeight:FontWeight.bold))),
            ...report.poiSummary.map((x)=>Text('• $x',style:const TextStyle(color:Color(0xFF8CE5CF)))),
            ...report.warnings.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent))),
          ]))),
        ],
        _section('وضعیت مدل‌ها'),
        _modelCard('Gemini','تحلیل مستقل تاریخچه 1H/15M/5M و سناریوها',consensus?.gemini),
        _modelCard('OpenRouter','تحلیل مستقل همان Snapshot',consensus?.openrouter),
        _modelCard('Groq','تحلیل مستقل همان Snapshot',consensus?.groq),
        if(report!=null && consensus!=null)...[
          _section('تصمیم ترکیبی مستقل برای هر مدل'),
          const Padding(padding:EdgeInsets.only(bottom:8),child:Text('وزن معیارها را هر AI مستقلاً تعیین می‌کند؛ وزن تکنیکال از شواهد موتور تکنیکال محاسبه می‌شود. تا زمان جمع‌آوری نمونه کافی، سهم اعتبار دو موتور ۵۰/۵۰ و خنثی است.',style:TextStyle(fontSize:11,color:Colors.white60))),
          _hybridCard(hybridEngine.evaluate(report,consensus!.gemini)),
          _hybridCard(hybridEngine.evaluate(report,consensus!.openrouter)),
          _hybridCard(hybridEngine.evaluate(report,consensus!.groq)),
        ],
        if(consensus?.snapshotId!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text('شناسه Snapshot: ${consensus!.snapshotId}',style:const TextStyle(fontSize:10,color:Colors.white38))),
        if(consensus!=null)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('اجماع مستقل مدل‌های هوش مصنوعی',style:TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
          const SizedBox(height:8),
          Text(consensus!.decision.toUpperCase(),style:TextStyle(fontSize:24,fontWeight:FontWeight.bold,color:consensus!.decision.toUpperCase()=='WAIT'?Colors.amber:const Color(0xFF46D6B3))),
          ...consensus!.conflicts.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent))),
        ]))),
        if(!ai.isConfigured)Card(child:Padding(padding:const EdgeInsets.all(14),child:const Text(
          'اتصال AI Gateway فعال نیست: آدرس Worker باید در GitHub Actions با Secret به نام AI_GATEWAY_BASE_URL تنظیم شود و کلیدهای Gemini، Groq و OpenRouter فقط به‌صورت Secret در Cloudflare نگهداری شوند. کلید API نباید داخل APK قرار گیرد.',
          style:TextStyle(color:Colors.amber),
        ))),
        const SizedBox(height:12),
        const Text('سیاست تحلیل: هر ارائه‌دهنده AI مستقل از موتور تکنیکال و سایر مدل‌ها تصمیم می‌گیرد. خروجی، جهت، دلایل و سطوح هر مدل جداگانه نمایش داده می‌شود؛ نتیجه اجماع صرفاً یک نمای کمکی است و تصمیم مستقل هیچ مدلی را تغییر نمی‌دهد. منبع رسم نمودار فقط از انتخاب شما پیروی می‌کند.'),
      ]);
    },
  );

  Widget _modelSetting(String key,TextEditingController controller,TextEditingController fallbackController){
    final labels={'gemini':'Google Gemini','openrouter':'OpenRouter','groq':'Groq'};
    final models=_availableModels[key]??const <String>[];
    final enabled=_providerEnabled[key]??false;
    final rankedNames=models.asMap().entries.map((e)=>'${e.key+1}) ${e.value}').join('  ←  ');
    Widget modelDropdown(String value, String label, ValueChanged<String?> onChanged) =>
      Directionality(textDirection:TextDirection.rtl,child:DropdownButtonFormField<String>(
        value:models.contains(value)?value:null,
        isExpanded:true,
        decoration:InputDecoration(labelText:label,isDense:true,border:const OutlineInputBorder(),floatingLabelBehavior:FloatingLabelBehavior.always),
        items:models.map((m)=>DropdownMenuItem<String>(value:m,child:Directionality(textDirection:TextDirection.ltr,child:Align(alignment:Alignment.centerLeft,child:Text(m,textAlign:TextAlign.left,maxLines:1,softWrap:false,overflow:TextOverflow.ellipsis,style:const TextStyle(fontFamily:'monospace',fontSize:12)))))).toList(),
        selectedItemBuilder:(context)=>models.map((m)=>Align(alignment:Alignment.centerLeft,child:Directionality(textDirection:TextDirection.ltr,child:Text(m,textDirection:TextDirection.ltr,textAlign:TextAlign.left,maxLines:1,overflow:TextOverflow.ellipsis,softWrap:false,style:const TextStyle(fontFamily:'monospace',fontSize:12))))).toList(),
        onChanged:enabled?onChanged:null,
      ));
    InputDecoration idDecoration(String label,String hint)=>InputDecoration(labelText:label,hintText:hint,isDense:true,border:const OutlineInputBorder(),floatingLabelBehavior:FloatingLabelBehavior.always,alignLabelWithHint:true);
    return Card(color:const Color(0xFF10182A),child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      SwitchListTile(contentPadding:EdgeInsets.zero,dense:true,title:Text(labels[key]??key),value:enabled,onChanged:(v)=>setState(()=>_providerEnabled[key]=v)),
      if(models.isNotEmpty) Padding(padding:const EdgeInsets.only(bottom:8),child:Text('اولویت انتخاب بر اساس قابلیت عمومی (نه دقت معاملاتی اثبات‌شده): $rankedNames',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:10,color:Colors.white60))),
      if(models.isNotEmpty) modelDropdown(controller.text,'انتخاب مدل فعال اصلی',(v){if(v!=null)setState(()=>controller.text=v);}),
      const SizedBox(height:10),
      Directionality(textDirection:TextDirection.ltr,child:TextField(controller:controller,enabled:enabled,textDirection:TextDirection.ltr,textAlign:TextAlign.left,textAlignVertical:TextAlignVertical.center,style:const TextStyle(fontFamily:'monospace',fontSize:13),decoration:idDecoration('مدل اصلی (شناسه دقیق)','provider/model-id'))),
      const SizedBox(height:10),
      if(models.isNotEmpty) modelDropdown(fallbackController.text,'انتخاب مدل جایگزین فعال',(v){if(v!=null)setState(()=>fallbackController.text=v);}),
      const SizedBox(height:10),
      Directionality(textDirection:TextDirection.ltr,child:TextField(controller:fallbackController,enabled:enabled,textDirection:TextDirection.ltr,textAlign:TextAlign.left,textAlignVertical:TextAlignVertical.center,style:const TextStyle(fontFamily:'monospace',fontSize:13),decoration:idDecoration('مدل جایگزین (شناسه دقیق)','provider/fallback-model'))),
    ])));
  }
  Widget _section(String s)=>Padding(padding:const EdgeInsets.only(top:18,bottom:8),child:Text(s,style:const TextStyle(fontSize:16,fontWeight:FontWeight.bold)));
  Widget _hybridCard(HybridDecision d){
    final color=d.decision=='BUY'?const Color(0xFF28C99A):d.decision=='SELL'?const Color(0xFFF06470):const Color(0xFFE7B84E);
    String weights(Map<String,int> values)=>values.entries.map((e)=>'${HybridEngine.labels[e.key]??e.key} ${e.value}%').join('  •  ');
    return Card(color:const Color(0xFF111A2B),child:Padding(padding:const EdgeInsets.all(13),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Expanded(child:Text('تکنیکال + ${d.provider}',style:const TextStyle(fontWeight:FontWeight.bold))),Text(d.decision,style:TextStyle(fontSize:19,fontWeight:FontWeight.bold,color:color))]),
      Text('امتیاز ترکیبی: ${d.score.toStringAsFixed(1)} | شواهد تکنیکال: ${d.technicalScore.toStringAsFixed(1)} | شواهد AI: ${d.aiScore.toStringAsFixed(1)}',style:const TextStyle(fontSize:11,color:Colors.white70)),
      const SizedBox(height:7),const Text('وزن‌های تکنیکال',style:TextStyle(fontWeight:FontWeight.bold,fontSize:11)),
      Text(weights(d.technicalWeights),style:const TextStyle(fontSize:10,color:Colors.white60,height:1.5)),
      const SizedBox(height:5),const Text('وزن‌های اختصاصی AI',style:TextStyle(fontWeight:FontWeight.bold,fontSize:11)),
      Text(weights(d.aiWeights),style:const TextStyle(fontSize:10,color:Colors.white60,height:1.5)),
      ...d.reasons.map((x)=>Text('• $x',style:const TextStyle(fontSize:11,color:Colors.orangeAccent))),
      Text(d.calibration,style:const TextStyle(fontSize:10,color:Colors.white38)),
    ])));
  }

  Widget _modelCard(String name,String role,AiModelResult? result){
    final bias=(result?.bias??'').toUpperCase();
    final Color tone=bias=='BUY'?const Color(0xFF28C99A):bias=='SELL'?const Color(0xFFF06470):const Color(0xFFE7B84E);
    final String direction=bias=='BUY'?'خرید':bias=='SELL'?'فروش':bias=='WAIT'?'انتظار':'نامشخص';
    final String statusLabel=result?.status=='ok'?'پاسخ دریافت شد':result?.status=='error'?'خطا':result?.status=='not_selected'?'انتخاب نشده':(result?.status??'در انتظار');
    final overlays=result?.overlays??const <Map<String,dynamic>>[];
    String overlayName(dynamic value){
      const names={'Swing High':'سقف نوسانی','Swing Low':'کف نوسانی','FVG':'شکاف ارزش منصفانه','Bullish FVG':'FVG صعودی','Bearish FVG':'FVG نزولی','Bullish OB':'اوردر بلاک صعودی','Bearish OB':'اوردر بلاک نزولی','EQH':'سقف‌های برابر','EQL':'کف‌های برابر','BOS+':'شکست ساختار صعودی','BOS-':'شکست ساختار نزولی','CRT-H':'سقف CRT','CRT-L':'کف CRT','EQ':'تعادل'};
      return names[value?.toString()]??value?.toString()??'ناحیه';
    }
    Widget panel(String title,IconData icon,List<Widget> children,{Color color=Colors.white70}){
      if(children.isEmpty)return const SizedBox.shrink();
      return Container(margin:const EdgeInsets.only(top:10),padding:const EdgeInsets.all(11),decoration:BoxDecoration(color:const Color(0xFF0B1422),borderRadius:BorderRadius.circular(11),border:Border.all(color:color.withOpacity(.20))),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Row(children:[Icon(icon,size:17,color:color),const SizedBox(width:7),Text(title,style:TextStyle(fontWeight:FontWeight.bold,color:color,fontSize:13))]),
        const SizedBox(height:8),...children,
      ]));
    }
    List<Widget> bulletItems(List<String> items)=>items.map((x)=>Padding(padding:const EdgeInsets.only(bottom:6),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[const Padding(padding:EdgeInsets.only(top:5),child:Icon(Icons.circle,size:5,color:Colors.white54)),const SizedBox(width:8),Expanded(child:Text(x,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:12,height:1.45,color:Color(0xE0FFFFFF))))]))).toList();
    final structure=overlays.where((o){final k='${o['kind']??''}'.toLowerCase();return k.contains('bos')||k.contains('swing')||k.contains('eqh')||k.contains('eql')||k.contains('crt')||k=='eq';}).toList();
    final zones=overlays.where((o){final k='${o['kind']??''}'.toLowerCase();return k.contains('fvg')||k.contains('ob')||k.contains('order');}).toList();
    final other=overlays.where((o)=>!structure.contains(o)&&!zones.contains(o)&&!const {'Entry','SL','TP1','TP2','TP3'}.contains(o['kind'])).toList();
    Widget overlayChips(List<Map<String,dynamic>> values){
      if(values.isEmpty)return const SizedBox.shrink();
      return Wrap(spacing:6,runSpacing:6,children:values.map((o){
        final kind=overlayName(o['kind']);final tf=(o['timeframe']??'').toString().toUpperCase();final price=o['price'];final low=o['low'];final high=o['high'];
        final value=price is num?'${price.toStringAsFixed(2)}':(low is num&&high is num?'${low.toStringAsFixed(2)} – ${high.toStringAsFixed(2)}':'');
        final dir='${o['direction']??''}';final c=dir=='bullish'?const Color(0xFF28C99A):dir=='bearish'?const Color(0xFFF06470):const Color(0xFF8DA8C8);
        return Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:6),decoration:BoxDecoration(color:c.withOpacity(.10),borderRadius:BorderRadius.circular(8),border:Border.all(color:c.withOpacity(.25))),child:Text('$kind ${tf.isEmpty?'':'• $tf'} ${value.isEmpty?'':'• $value'}',textDirection:TextDirection.rtl,style:TextStyle(fontSize:10,color:c,fontWeight:FontWeight.w600)));
      }).toList());
    }
    return Card(color:const Color(0xFF111A2B),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Row(children:[const Icon(Icons.memory,size:20),const SizedBox(width:8),Expanded(child:Text(name,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16))),
        Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),decoration:BoxDecoration(color:(result?.status=='error'?Colors.redAccent:Colors.tealAccent).withOpacity(.13),borderRadius:BorderRadius.circular(20)),child:Text(statusLabel,style:TextStyle(fontSize:10,color:result?.status=='error'?Colors.redAccent:Colors.tealAccent)))
      ]),
      const SizedBox(height:10),
      if(result?.bias!=null && result?.status!='error')Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:tone.withOpacity(.10),border:Border.all(color:tone.withOpacity(.35)),borderRadius:BorderRadius.circular(12)),child:Column(children:[
        Row(children:[Container(width:42,height:42,decoration:BoxDecoration(color:tone.withOpacity(.18),shape:BoxShape.circle),child:Icon(bias=='BUY'?Icons.trending_up:bias=='SELL'?Icons.trending_down:Icons.pause_circle_outline,color:tone,size:25)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(direction,style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:tone)),const Text('تصمیم مستقل این مدل',style:TextStyle(fontSize:10,color:Colors.white60))])),Text('${result!.confidence}%',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold,color:tone))]),
        const SizedBox(height:9),ClipRRect(borderRadius:BorderRadius.circular(8),child:LinearProgressIndicator(value:result.confidence/100,minHeight:8,backgroundColor:Colors.white10,color:tone)),const SizedBox(height:3),const Align(alignment:Alignment.centerLeft,child:Text('درصد اطمینان اعلام‌شده توسط مدل',style:TextStyle(fontSize:10,color:Colors.white54)))
      ])) else Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Text(result?.status=='error'?'این مدل در این اجرا پاسخ معتبر نداد؛ مدل جایگزین را انتخاب کنید. ${result?.error??''}':role,style:const TextStyle(color:Colors.white70,fontSize:12))),
      if(overlays.isNotEmpty) ...[
        const SizedBox(height:10),
        Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFF0B1422),borderRadius:BorderRadius.circular(12),border:Border.all(color:Colors.white12)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Row(children:[Icon(Icons.candlestick_chart_rounded,size:17,color:Color(0xFF8CE5CF)),SizedBox(width:7),Text('نقشه تصویری سطوح استخراج‌شده',style:TextStyle(fontSize:12,fontWeight:FontWeight.bold,color:Color(0xFF8CE5CF)))]),
          const SizedBox(height:7),
          SizedBox(height:158,width:double.infinity,child:CustomPaint(painter:_AiOverlayMapPainter(overlays))),
          const Text('نمای شماتیک قیمت‌ها و نواحی اعلام‌شده توسط همین مدل؛ نه نمودار قیمت زنده.',style:TextStyle(fontSize:9,color:Colors.white38)),
        ])),
      ],
      if(result?.contractVersion==2 || result?.contractStatus=='DEGRADED')panel('اعتبار قالب تحلیل',Icons.verified_outlined,[Text(result?.contractStatus=='VALID'?'قالب استاندارد v2 کامل و معتبر است.':'قالب استاندارد v2 ناقص است؛ این پاسخ نباید رأی معتبر Hybrid محسوب شود.',textDirection:TextDirection.rtl,style:TextStyle(fontSize:11,color:result?.contractStatus=='VALID'?Colors.tealAccent:Colors.orangeAccent))],color:result?.contractStatus=='VALID'?Colors.tealAccent:Colors.orangeAccent),
      if(result?.timeframeAnalysis.isNotEmpty==true)panel('تحلیل ساختاریافته تایم‌فریم‌ها',Icons.stacked_line_chart,[
        ...['1h','15m','5m'].where((tf)=>result!.timeframeAnalysis[tf] is Map).map((tf){final item=Map<String,dynamic>.from(result!.timeframeAnalysis[tf] as Map);return Padding(padding:const EdgeInsets.only(bottom:6),child:Text('$tf  |  روند: ${item['trend']}  |  ساختار: ${item['structure']}  |  فاز: ${item['phase']}  |  خریدار: ${item['buyerStrength']??'—'}  |  فروشنده: ${item['sellerStrength']??'—'}  |  نقدینگی: ${item['liquidity']}',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:10,color:Colors.white70,height:1.5)));})
      ],color:const Color(0xFF82B7FF)),
      if((result?.invalidation??'').isNotEmpty)panel('شرط ابطال سناریو',Icons.gpp_bad_outlined,[Text(result!.invalidation!,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:12,color:Colors.orangeAccent))],color:Colors.orangeAccent),
      panel('شواهد ساختاریافته',Icons.fact_check_outlined,bulletItems((result?.evidence??const []).map((e)=>'${e['timeframe']??''} • ${e['event']??''} • ${e['status']??''}: ${e['explanation']??''}').toList()),color:const Color(0xFF8CE5CF)),
      if((result?.summary??'').isNotEmpty)panel('خلاصه سناریوی بازار',Icons.subject,[Text(result!.summary!,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:13,height:1.6,color:Colors.white))],color:const Color(0xFF82B7FF)),
      panel('شواهد و مشاهدات',Icons.fact_check_outlined,bulletItems(result?.observations??const []),color:const Color(0xFF8CE5CF)),
      panel('ریسک‌ها و موارد احتیاط',Icons.warning_amber_rounded,bulletItems(result?.risks??const []),color:Colors.orangeAccent),
      if(structure.isNotEmpty)panel('ساختار بازار و نقدینگی',Icons.account_tree_outlined,[overlayChips(structure)],color:const Color(0xFFB5A0FF)),
      if(zones.isNotEmpty)panel('نواحی عرضه و تقاضا',Icons.layers_outlined,[overlayChips(zones)],color:const Color(0xFF8CE5CF)),
      if(overlays.any((o)=>const {'Entry','SL','TP1','TP2','TP3'}.contains(o['kind'])))panel('نقشه معامله مستقل این مدل',Icons.track_changes,[
        Wrap(spacing:7,runSpacing:7,children:overlays.where((o)=>const {'Entry','SL','TP1','TP2','TP3'}.contains(o['kind'])).map((o){
          final kind='${o['kind']}';final price=o['price'];final label=kind=='Entry'?'ورود':kind=='SL'?'حد ضرر':kind.replaceFirst('TP','هدف ');
          final c=kind=='Entry'?const Color(0xFF46D6B3):kind=='SL'?const Color(0xFFF06470):const Color(0xFF28C99A);
          return Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:8),decoration:BoxDecoration(color:c.withOpacity(.10),borderRadius:BorderRadius.circular(9),border:Border.all(color:c.withOpacity(.35))),child:Text('$label: ${price is num?price.toStringAsFixed(2):'—'}',style:TextStyle(color:c,fontSize:12,fontWeight:FontWeight.bold)));
        }).toList())
      ],color:const Color(0xFF46D6B3)),
      if(other.isNotEmpty)panel('سایر سطوح مستقل مدل',Icons.place_outlined,[overlayChips(other)],color:const Color(0xFF8DA8C8)),
      if((result?.error??'').isNotEmpty && result?.status!='error')Padding(padding:const EdgeInsets.only(top:10),child:Text('هشدار ارائه‌دهنده: ${result!.error}',style:const TextStyle(color:Colors.orangeAccent,fontSize:12))),
      const Divider(height:22,color:Colors.white12),
      Wrap(spacing:12,runSpacing:6,children:[
        if((result?.providerModel??'').isNotEmpty)Text('مدل: ${result!.providerModel}',style:const TextStyle(fontSize:10,color:Colors.white54)),
        if(result?.responseTimeMs!=null)Text('زمان پاسخ: ${(result!.responseTimeMs!/1000).toStringAsFixed(1)} ثانیه',style:const TextStyle(fontSize:10,color:Colors.white54)),
        if(result?.fallbackUsed==true)const Text('مدل جایگزین فعال شد',style:TextStyle(fontSize:10,color:Colors.orangeAccent)),
      ]),
      if((result?.rawText??'').isNotEmpty)Theme(data:Theme.of(context).copyWith(dividerColor:Colors.transparent),child:ExpansionTile(tilePadding:EdgeInsets.zero,childrenPadding:const EdgeInsets.only(bottom:8),title:const Text('متن اصلی پاسخ مدل',style:TextStyle(fontSize:12,color:Colors.white60)),subtitle:const Text('برای مشاهده جزئیات خام باز کنید',style:TextStyle(fontSize:10,color:Colors.white38)),children:[Container(width:double.infinity,padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFF090F1B),borderRadius:BorderRadius.circular(8)),child:SelectableText(result!.rawText!,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:11,height:1.5)))])),
    ])));
  }
  String _p(double? x)=>x==null?'—':x.toStringAsFixed(2);
  String _age(DateTime value){final d=DateTime.now().difference(value);if(d.inDays>0)return '${d.inDays} روز و ${d.inHours%24} ساعت';if(d.inHours>0)return '${d.inHours} ساعت و ${d.inMinutes%60} دقیقه';return '${d.inMinutes} دقیقه';}
}


class _AiOverlayMapPainter extends CustomPainter {
  _AiOverlayMapPainter(this.overlays);
  final List<Map<String, dynamic>> overlays;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF09111E);
    canvas.drawRRect(RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(9)), bg);
    final values = <double>[];
    for (final o in overlays) {
      final p = (o['price'] as num?)?.toDouble();
      final lo = (o['low'] as num?)?.toDouble();
      final hi = (o['high'] as num?)?.toDouble();
      if (p != null && p > 0) values.add(p);
      if (lo != null && lo > 0) values.add(lo);
      if (hi != null && hi > 0) values.add(hi);
    }
    if (values.isEmpty) return;
    var minP = values.reduce((a,b)=>a<b?a:b);
    var maxP = values.reduce((a,b)=>a>b?a:b);
    if ((maxP-minP).abs() < 1e-9) { minP *= .995; maxP *= 1.005; }
    final pad = (maxP-minP)*.12;
    minP -= pad; maxP += pad;
    const left = 10.0, right = 10.0, top = 10.0, bottom = 10.0;
    final plotH = size.height-top-bottom;
    double y(double price) => top + (maxP-price)/(maxP-minP)*plotH;
    final grid = Paint()..color = Colors.white.withOpacity(.07)..strokeWidth=1;
    for (var i=0;i<=4;i++) {
      final yy=top+plotH*i/4;
      canvas.drawLine(Offset(left,yy),Offset(size.width-right,yy),grid);
    }
    Color colorFor(Map<String,dynamic> o) {
      final kind='${o['kind']??''}'.toUpperCase();
      final direction='${o['direction']??''}'.toLowerCase();
      if (kind=='SL') return const Color(0xFFF06470);
      if (kind=='ENTRY') return const Color(0xFF58CDB2);
      if (kind.startsWith('TP')) return const Color(0xFF35C995);
      if (direction=='bullish' || kind.contains('BULL')) return const Color(0xFF35C995);
      if (direction=='bearish' || kind.contains('BEAR')) return const Color(0xFFF06470);
      return const Color(0xFFB49AF4);
    }
    for (final o in overlays.where((x)=>x['type']=='zone')) {
      final lo=(o['low'] as num?)?.toDouble(), hi=(o['high'] as num?)?.toDouble();
      if (lo==null||hi==null||hi<=lo) continue;
      final c=colorFor(o);
      final rect=Rect.fromLTRB(left,y(hi),size.width-right,y(lo));
      canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(3)),Paint()..color=c.withOpacity(.20));
      canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(3)),Paint()..color=c.withOpacity(.75)..style=PaintingStyle.stroke..strokeWidth=1);
      _label(canvas,'${o['kind']??'ZONE'}',Offset(size.width-right-5,(rect.top+rect.bottom)/2),c,align:TextAlign.right);
    }
    for (final o in overlays.where((x)=>x['type']=='line')) {
      final p=(o['price'] as num?)?.toDouble();
      if (p==null||p<=0) continue;
      final yy=y(p), c=colorFor(o);
      final paint=Paint()..color=c..strokeWidth=1.4;
      canvas.drawLine(Offset(left,yy),Offset(size.width-right,yy),paint);
      _label(canvas,'${o['kind']??'LEVEL'}  ${p.toStringAsFixed(2)}',Offset(size.width-right-4,yy-2),c,align:TextAlign.right);
    }
  }

  void _label(Canvas canvas,String text,Offset point,Color color,{TextAlign align=TextAlign.left}) {
    final tp=TextPainter(text:TextSpan(text:text,style:TextStyle(color:color,fontSize:8.5,fontWeight:FontWeight.w700,backgroundColor:const Color(0xCC09111E))),textDirection:TextDirection.ltr,textAlign:align,maxLines:1)..layout(maxWidth:120);
    tp.paint(canvas,Offset((point.dx-tp.width).clamp(2.0,10000.0), (point.dy-tp.height/2).clamp(1.0,10000.0)));
  }

  @override
  bool shouldRepaint(covariant _AiOverlayMapPainter oldDelegate) => oldDelegate.overlays != overlays;
}
