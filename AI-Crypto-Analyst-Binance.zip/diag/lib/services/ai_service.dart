import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'app_config.dart';
import 'market_api.dart';

class AiModelResult {
  const AiModelResult({
    required this.model,
    required this.status,
    this.bias,
    this.summary,
    this.risks = const [],
    this.observations = const [],
    this.confidence = 0,
    this.analyticalWeights = const {},
    this.factorScores = const {},
    this.weightsProvided = false,
    this.overlays = const [],
    this.providerModel,
    this.finishReason,
    this.nativeFinishReason,
    this.promptTokens,
    this.completionTokens,
    this.reasoningTokens,
    this.error,
    this.rawText,
    this.responseFormat,
    this.fallbackUsed = false,
    this.attemptedModels = const [],
    this.responseTimeMs,
    this.contractVersion = 1,
    this.contractStatus = 'DEGRADED',
    this.timeframeAnalysis = const {},
    this.evidence = const [],
    this.invalidation,
  });

  final String model;
  final String status;
  final String? bias;
  final String? summary;
  final List<String> risks;
  final List<String> observations;
  final int confidence;
  final Map<String, int> analyticalWeights;
  final Map<String, int> factorScores;
  final bool weightsProvided;
  final List<Map<String, dynamic>> overlays;
  final String? providerModel;
  final String? finishReason;
  final String? nativeFinishReason;
  final int? promptTokens;
  final int? completionTokens;
  final int? reasoningTokens;
  final String? error;
  final String? rawText;
  final String? responseFormat;
  final bool fallbackUsed;
  final List<String> attemptedModels;
  final int? responseTimeMs;
  final int contractVersion;
  final String contractStatus;
  final Map<String, dynamic> timeframeAnalysis;
  final List<Map<String, dynamic>> evidence;
  final String? invalidation;

  Map<String, dynamic> toJson() => {
    'model': model, 'status': status, 'bias': bias, 'summary': summary,
    'risks': risks, 'observations': observations, 'confidence': confidence, 'analyticalWeights': analyticalWeights, 'factorScores': factorScores, 'weightsProvided': weightsProvided, 'overlays': overlays, 'providerModel': providerModel,
    'finishReason': finishReason, 'nativeFinishReason': nativeFinishReason,
    'promptTokens': promptTokens, 'completionTokens': completionTokens,
    'reasoningTokens': reasoningTokens, 'error': error, 'rawText': rawText, 'responseFormat': responseFormat, 'fallbackUsed': fallbackUsed, 'attemptedModels': attemptedModels, 'responseTimeMs': responseTimeMs, 'contractVersion': contractVersion, 'contractStatus': contractStatus, 'timeframeAnalysis': timeframeAnalysis, 'evidence': evidence, 'invalidation': invalidation,
  };

  factory AiModelResult.fromJson(String model, dynamic raw) {
    if (raw is! Map) {
      return AiModelResult(model: model, status: 'not_selected');
    }
    final confidenceValue = raw['confidence'];
    final parsedConfidence = confidenceValue is num
        ? confidenceValue.round().clamp(0, 100).toInt()
        : int.tryParse('$confidenceValue') ?? 0;
    Map<String, int> intMap(dynamic value) {
      if (value is! Map) return const {};
      return value.map((key, item) => MapEntry(key.toString(), item is num ? item.round().clamp(0, 100).toInt() : int.tryParse('$item') ?? 0));
    }
    return AiModelResult(
      model: model,
      status: (raw['status'] ?? 'ok').toString(),
      bias: raw['bias']?.toString(),
      summary: raw['summary']?.toString(),
      risks: raw['risks'] is List
          ? (raw['risks'] as List).map((e) => e.toString()).toList()
          : const [],
      observations: raw['observations'] is List
          ? (raw['observations'] as List).map((e) => e.toString()).toList()
          : const [],
      confidence: parsedConfidence,
      analyticalWeights: intMap(raw['analyticalWeights']),
      factorScores: intMap(raw['factorScores']),
      weightsProvided: raw['weightsProvided'] == true,
      overlays: raw['overlays'] is List
          ? (raw['overlays'] as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
          : const [],
      providerModel: raw['providerModel']?.toString(),
      finishReason: raw['finishReason']?.toString(),
      nativeFinishReason: raw['nativeFinishReason']?.toString(),
      promptTokens: (raw['promptTokens'] as num?)?.toInt(),
      completionTokens: (raw['completionTokens'] as num?)?.toInt(),
      reasoningTokens: (raw['reasoningTokens'] as num?)?.toInt(),
      error: raw['error']?.toString(),
      rawText: raw['rawText']?.toString(),
      responseFormat: raw['responseFormat']?.toString(),
      fallbackUsed: raw['fallbackUsed'] == true,
      attemptedModels: raw['attemptedModels'] is List ? (raw['attemptedModels'] as List).map((x)=>x.toString()).toList() : const [],
      responseTimeMs: (raw['responseTimeMs'] as num?)?.toInt(),
      contractVersion: (raw['contractVersion'] as num?)?.toInt() ?? 1,
      contractStatus: raw['contractStatus']?.toString() ?? 'DEGRADED',
      timeframeAnalysis: raw['timeframeAnalysis'] is Map ? Map<String,dynamic>.from(raw['timeframeAnalysis'] as Map) : const {},
      evidence: raw['evidence'] is List ? (raw['evidence'] as List).whereType<Map>().map((e)=>Map<String,dynamic>.from(e)).toList() : const [],
      invalidation: raw['invalidation']?.toString(),
    );
  }
}

class AiConsensus {
  const AiConsensus({
    required this.gemini,
    required this.openrouter,
    required this.groq,
    required this.decision,
    required this.conflicts,
    this.aiOverlays = const [],
    this.snapshotId,
  });

  final AiModelResult gemini;
  final AiModelResult openrouter;
  final AiModelResult groq;
  final String decision;
  final List<String> conflicts;
  final List<Map<String, dynamic>> aiOverlays;
  final String? snapshotId;

  Map<String, dynamic> toJson() => {
    'gemini': gemini.toJson(), 'openrouter': openrouter.toJson(), 'groq': groq.toJson(),
    'decision': decision, 'conflicts': conflicts, 'aiOverlays': aiOverlays, 'snapshotId': snapshotId,
  };

  factory AiConsensus.fromJson(Map<String, dynamic> json) {
    final conflictsRaw = json['conflicts'];
    return AiConsensus(
      gemini: AiModelResult.fromJson('Gemini', json['gemini']),
      openrouter: AiModelResult.fromJson('OpenRouter', json['openrouter']),
      groq: AiModelResult.fromJson('Groq', json['groq']),
      decision: const {'BUY', 'SELL', 'WAIT'}.contains('${json['decision']}'.toUpperCase())
          ? '${json['decision']}'.toUpperCase() : 'WAIT',
      conflicts: conflictsRaw is List ? conflictsRaw.map((e) => e.toString()).toList() : const [],
      aiOverlays: json['aiOverlays'] is List
          ? (json['aiOverlays'] as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
          : const [],
      snapshotId: json['snapshotId']?.toString(),
    );
  }

  /// Merge a partial provider response into the saved result for the same
  /// market snapshot. `not_selected` means "not requested in this run", not
  /// "erase the previous answer".
  AiConsensus mergePartial(AiConsensus incoming) {
    AiModelResult keepOrUpdate(AiModelResult previous, AiModelResult next) =>
        next.status == 'not_selected' ? previous : next;

    final mergedGemini = keepOrUpdate(gemini, incoming.gemini);
    final mergedOpenRouter = keepOrUpdate(openrouter, incoming.openrouter);
    final mergedGroq = keepOrUpdate(groq, incoming.groq);
    final active = [mergedGemini, mergedOpenRouter, mergedGroq]
        .where((r) => r.status == 'ok' && r.contractStatus == 'VALID' && r.weightsProvided && r.bias != null)
        .toList();
    final votes = <String, int>{'BUY': 0, 'SELL': 0, 'WAIT': 0};
    for (final r in active) {
      final direction = r.bias!.toUpperCase();
      votes[votes.containsKey(direction) ? direction : 'WAIT'] =
          (votes[votes.containsKey(direction) ? direction : 'WAIT'] ?? 0) + 1;
    }
    final majorityEntries = votes.entries.where((e) => e.value >= 2).toList();
    final majority = majorityEntries.isEmpty ? 'WAIT' : majorityEntries.first.key;
    final agreeing = active.where((r) => r.bias!.toUpperCase() == majority).toList();
    final confidenceOk = agreeing.length >= 2 && agreeing.every((r) => r.confidence >= 55);
    // A single model may provide an independent opinion, but it is never a
    // multi-model consensus signal. Directional consensus requires >=2 votes.
    final decision = active.length >= 2 &&
            (majority == 'BUY' || majority == 'SELL') && confidenceOk
        ? majority
        : 'WAIT';
    final conflicts = <String>[];
    if (active.length == 1) {
      conflicts.add('فقط یک مدل پاسخ معتبر دارد؛ این جهت، اجماع چندمدلی نیست.');
    } else if (active.length >= 2 && decision == 'WAIT') {
      conflicts.add('بین مدل‌های پاسخ‌گو اجماع جهت‌دار با اطمینان کافی وجود ندارد.');
    }
    for (final r in [mergedGemini, mergedOpenRouter, mergedGroq]) {
      if (r.status == 'error' && (r.error ?? '').isNotEmpty) {
        conflicts.add('${r.model}: ${r.error}');
      }
    }
    final overlays = <Map<String, dynamic>>[
      ...mergedGemini.overlays,
      ...mergedOpenRouter.overlays,
      ...mergedGroq.overlays,
    ];
    return AiConsensus(
      gemini: mergedGemini,
      openrouter: mergedOpenRouter,
      groq: mergedGroq,
      decision: decision,
      conflicts: conflicts,
      aiOverlays: overlays,
      snapshotId: incoming.snapshotId ?? snapshotId,
    );
  }
}

class AiService {
  bool get isConfigured =>
      AppConfig.aiGatewayBaseUrl.startsWith('https://') &&
      !AppConfig.aiGatewayBaseUrl.contains('YOUR_');

  Future<Map<String, List<String>>> fetchModelCatalog() async {
    if (!isConfigured) return const {};
    final base = AppConfig.aiGatewayBaseUrl.replaceFirst(RegExp(r'/+$'), '');
    final response = await http.get(Uri.parse('$base/models'), headers: const {'Accept':'application/json'})
        .timeout(const Duration(seconds: 12));
    if (response.statusCode != 200) throw AiServiceException('دریافت فهرست مدل‌ها ناموفق بود: HTTP ${response.statusCode}');
    final decoded = jsonDecode(response.body);
    if (decoded is! Map || decoded['providers'] is! Map) throw const AiServiceException('ساختار فهرست مدل‌ها معتبر نیست.');
    final result = <String, List<String>>{};
    final providers = decoded['providers'] as Map;
    for (final key in ['gemini','openrouter','groq']) {
      final entry = providers[key];
      final models = entry is Map && entry['models'] is List ? (entry['models'] as List).map((x)=>x.toString()).where((x)=>x.isNotEmpty).toList() : <String>[];
      result[key] = models;
    }
    return result;
  }

  Map<String, dynamic> _encodeHistory(List<MarketCandle> candles, int intervalSeconds) {
    if (candles.isEmpty) return {'rows': <List<int>>[]};
    final positiveVolumes = candles.map((c) => c.volume).where((v) => v > 0).toList()..sort();
    final medianVolume = positiveVolumes.isEmpty
        ? 1.0
        : positiveVolumes[positiveVolumes.length ~/ 2];
    var previousClose = candles.first.open;
    var previousTime = candles.first.time;
    final rows = <List<int>>[];
    for (var i = 0; i < candles.length; i++) {
      final c = candles[i];
      int delta(double value) => (((value / previousClose) - 1) * 1000000).round();
      final timeDelta = i == 0 ? 0 : c.time - previousTime;
      rows.add([
        timeDelta,
        delta(c.open),
        delta(c.high),
        delta(c.low),
        delta(c.close),
        ((c.volume / medianVolume) * 100).round().clamp(0, 1000000).toInt(),
      ]);
      previousClose = c.close;
      previousTime = c.time;
    }
    return {
      'timeStart': candles.first.time,
      'intervalSeconds': intervalSeconds,
      'basePrice': candles.first.open,
      'baseVolumeMedian': medianVolume,
      'rows': rows,
    };
  }

  Future<AiConsensus> analyze({
    required String exchange,
    required String symbol,
    required List<MarketCandle> history1h,
    required List<MarketCandle> history15m,
    required List<MarketCandle> history5m,
    Map<String, String> modelSelection = const {},
    Map<String, String> fallbackSelection = const {},
    List<String> selectedProviders = const ['gemini', 'openrouter', 'groq'],
    String? snapshotId,
    double? referencePrice,
  }) async {
    if (referencePrice == null || !referencePrice.isFinite || referencePrice <= 0) {
      throw const AiServiceException('قیمت مرجع لحظه‌ای در این Snapshot موجود نیست؛ ابتدا تحلیل بازار را تازه‌سازی کنید.');
    }

    if (!isConfigured) {
      throw const AiServiceException(
        'آدرس AI Gateway در تنظیمات Build تعریف نشده است. '
        'مقدار AI_GATEWAY_BASE_URL را در GitHub Actions Secret بررسی کنید.',
      );
    }

    final base = AppConfig.aiGatewayBaseUrl.replaceFirst(RegExp(r'/+$'), '');
    final uri = Uri.parse('$base/analyze');
    final stableSnapshotId = snapshotId ?? '${exchange}_${symbol}_${history1h.first.time}_${history1h.last.time}_${history15m.last.time}_${history5m.last.time}_${history1h.length}_${history15m.length}_${history5m.length}';

    final requestBody = jsonEncode({
            'exchange': exchange,
            'symbol': symbol,
            'snapshotId': stableSnapshotId,
            if (referencePrice != null && referencePrice > 0) 'referencePrice': referencePrice,
            if (history5m.isNotEmpty) 'lastClosed5mClose': history5m.last.close,
            'asOfUtc': DateTime.now().toUtc().toIso8601String(),
            'modelSelection': modelSelection,
            'fallbackSelection': fallbackSelection,
            'selectedProviders': selectedProviders,
            // Full completed history is preserved in compact delta-OHLCV form to fit free-model context limits.
            'marketHistory': {
              'format': 'rows=[delta_time_seconds, open_delta_0.01bps, high_delta_0.01bps, low_delta_0.01bps, close_delta_0.01bps, volume_ratio_x100]; price deltas reference previous close; volume ratio references timeframe median',
              '1h': _encodeHistory(history1h, 3600),
              '15m': _encodeHistory(history15m, 900),
              '5m': _encodeHistory(history5m, 300),
            },
          });
    if (utf8.encode(requestBody).length > 900 * 1024) {
      throw const AiServiceException('حجم تاریخچه کندل‌ها برای ارسال به AI بیش از حد مجاز است.');
    }

    late final http.Response response;
    try {
      response = await http
          .post(
            uri,
            headers: const {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: requestBody,
          )
          .timeout(AppConfig.aiRequestTimeout);
    } on http.ClientException catch (e) {
      throw AiServiceException(
        'اتصال برنامه به AI Gateway قطع شد و پاسخی از سرور دریافت نشد. '
        'این خطا به معنی رد تحلیل توسط مدل‌ها نیست. از تکرار پشت‌سرهم خودداری کنید؛ '
        'اتصال Worker و گزارش‌های Cloudflare را بررسی کنید. (${e.message})',
      );
    } on TimeoutException {
      throw const AiServiceException(
        'پاسخ AI Gateway در مهلت تعیین‌شده نرسید. ممکن است ارائه‌دهنده‌ها شلوغ باشند؛ '
        'آخرین تحلیل ذخیره‌شده حفظ می‌شود.',
      );
    }

    final decoded = _decodeResponse(response.body);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = decoded is Map
          ? (decoded['error'] ?? decoded['message'] ?? response.body).toString()
          : response.body;
      final providerMap = decoded is Map && decoded['providers'] is Map
          ? decoded['providers'] as Map
          : decoded is Map ? decoded : const <dynamic, dynamic>{};
      String providerDiagnostic(String key, String label) {
        final raw = providerMap[key];
        if (raw is! Map) return '';
        final providerStatus = (raw['status'] ?? '').toString();
        final detail = (raw['error'] ?? raw['message'] ?? '').toString().trim();
        if (providerStatus == 'ok' && detail.isEmpty) return '';
        final text = detail.isEmpty ? (providerStatus.isEmpty ? 'پاسخ نامشخص' : providerStatus) : detail;
        return '$label: ${text.length > 260 ? text.substring(0, 260) : text}';
      }
      final diagnostics = <String>[
        providerDiagnostic('gemini', 'Gemini'),
        providerDiagnostic('openrouter', 'OpenRouter'),
        providerDiagnostic('groq', 'Groq'),
      ].where((x) => x.isNotEmpty).toList();
      final shortMessage = message.length > 220 ? message.substring(0, 220) : message;
      throw AiServiceException(
        'AI Gateway خطای HTTP ${response.statusCode}: $shortMessage'
        '${diagnostics.isEmpty ? '' : '\n${diagnostics.join('\n')}'}',
      );
    }

    if (decoded is! Map || decoded['ok'] == false) {
      throw const AiServiceException('ساختار پاسخ AI Gateway معتبر نیست.');
    }

    // Support both the current nested contract and the previous flat response.
    final providers = decoded['providers'] is Map
        ? decoded['providers'] as Map
        : decoded;
    final gemini = AiModelResult.fromJson(
      'Gemini',
      providers['gemini'] ?? decoded['gemini'],
    );
    final openrouter = AiModelResult.fromJson(
      'OpenRouter',
      providers['openrouter'] ?? decoded['openrouter'],
    );
    final groq = AiModelResult.fromJson(
      'Groq',
      providers['groq'] ?? decoded['groq'],
    );

    final consensus = decoded['consensus'] is Map
        ? decoded['consensus'] as Map
        : const <dynamic, dynamic>{};

    final decision =
        (consensus['decision'] ?? decoded['decision'] ?? 'WAIT')
            .toString()
            .toUpperCase();
    final conflicts = decoded['conflicts'] is List
        ? (decoded['conflicts'] as List).map((e) => e.toString()).toList()
        : <String>[];

    final aiOverlaysRaw = decoded['aiOverlays'] is List ? decoded['aiOverlays'] as List : consensus['aiOverlays'] is List ? consensus['aiOverlays'] as List : const [];
    return AiConsensus(
      gemini: gemini,
      openrouter: openrouter,
      groq: groq,
      decision: const {'BUY', 'SELL', 'WAIT'}.contains(decision)
          ? decision
          : 'WAIT',
      conflicts: conflicts,
      aiOverlays: aiOverlaysRaw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList(),
      snapshotId: decoded['snapshotId']?.toString() ?? stableSnapshotId,
    );
  }

  dynamic _decodeResponse(String body) {
    try {
      return jsonDecode(body);
    } on FormatException {
      throw const AiServiceException(
        'پاسخ Worker JSON معتبر نیست؛ کد یا مسیر API را بررسی کنید.',
      );
    }
  }
}

class AiServiceException implements Exception {
  const AiServiceException(this.message);
  final String message;

  @override
  String toString() => message;
}
