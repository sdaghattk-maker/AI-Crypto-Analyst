# AI Reference Price & Consensus Fix — 2026-11-20

## Changes
- Analysis snapshots now fetch the exchange's live ticker price alongside 1h/15m/5m candles.
- Analysis is blocked when the live reference price differs from the latest closed 5m close by more than 2.5%; this prevents mixed or shifted price snapshots from being sent to AI.
- AI requests carry `referencePrice`, `lastClosed5mClose`, and `asOfUtc` in addition to the shared snapshot ID and candle history.
- Worker prompts explicitly identify the live reference-price anchor.
- AI overlay validation applies tighter caps around the live reference price (4% for execution lines, 6% for zones), in addition to the historical envelope. Invalid execution plans are downgraded to WAIT by existing validation logic.
- A single successful model is no longer treated as a directional multi-model consensus; consensus requires at least two agreeing valid model responses.
- AI analysis from a restored snapshot without a current reference-price anchor is blocked until the market analysis is refreshed.

## Verification
- AI Gateway Worker tests: 30 passed.
- Binance Proxy Worker tests: 2 passed.
- Flutter/Dart tests and APK build were not run because Flutter/Dart SDK is not available in the execution environment.

## Model quality policy
This change does not claim a measured model ranking. The existing provider catalog is still dynamic. A model should only be removed as low-quality after a fair same-snapshot benchmark with completed outcome labels; otherwise model deletion would be an unsupported guess. The benchmark/ranking phase remains outstanding.
