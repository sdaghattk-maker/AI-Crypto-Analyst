# AI Analysis Contract v2 — 2026-11-20

## Goal

Gemini, OpenRouter and Groq receive the same immutable market snapshot and must return the same machine-readable analysis structure. Providers remain independent: no model sees another provider's output or the technical engine's directional opinion.

## Ownership boundaries

**Server-owned immutable metadata** (never generated or overwritten by a model):
- `contractVersion`, `snapshotId`, `symbol`, `exchange`;
- `referencePrice`, `lastClosed5mClose`, `asOfUtc`;
- `historyHash` / snapshot identity and input history;
- provider ID, requested model ID, actual model ID, timing, usage and error metadata.

**Model-owned analytical fields:** timeframe assessment, evidence, bias, confidence estimate, summary, invalidation, risks and its independent overlays/trade plan.

The model must never be treated as the source of live price. UI price display uses server-owned ticker fields only. Model-generated absolute levels are separate trade-plan fields and must pass server validation before display.

## Contract v2 response

Top-level required fields:
- `contractVersion`: integer `2`;
- `bias`: `BUY | SELL | WAIT`;
- `timeframeAnalysis`: exactly `1h`, `15m`, `5m`;
- `evidence`: 1–12 structured observations;
- `invalidation`: concise Persian invalidation condition;
- `summary`, `observations`, `risks` in Persian;
- `confidence`: model self-assessment 0–100, explicitly not a calibrated probability;
- `analyticalWeights`: five nonnegative integer percentages summing to 100;
- `factorScores`: five evidence scores from 0–100;
- `overlays`: independent model levels/zones.

Each timeframe object contains:
- `trend`: `BULLISH | BEARISH | RANGE | UNKNOWN`;
- `structure`: `BULLISH | BEARISH | RANGE | TRANSITION | UNKNOWN`;
- `phase`: `TRENDING | RANGING | ACCUMULATION | DISTRIBUTION | REVERSAL | UNKNOWN`;
- `buyerStrength` and `sellerStrength`: integers 0–100, summing to 100 within a 2-point tolerance;
- `liquidity`: `BUY_SIDE_SWEEP | SELL_SIDE_SWEEP | BOTH | NONE | UNKNOWN`;
- `evidence`: up to five concise Persian evidence notes.

Each top-level evidence item contains `timeframe`, `type`, `event`, `status` (`CONFIRMED | PENDING | REJECTED | NOT_CONFIRMED`) and Persian `explanation`.

## Trade-plan rules

- `WAIT`: no Entry, SL or TP execution lines.
- A provider response with a truncation finish reason is always downgraded to `WAIT`/`DEGRADED`; execution overlays are removed even if the partial JSON happens to parse.
- `BUY` / `SELL`: exactly one Entry, SL, TP1, TP2 and TP3; 5m execution timeframe; consistent direction and monotonic target order; positive risk; minimum RR checks remain server-side.
- A directional plan requires at least one objectively identifiable POI: matching OB OR matching FVG OR a directionally relevant swing/equal-high/equal-low retest. Requiring OB and FVG simultaneously is prohibited. Never fabricate a POI.
- Price values must be consistent with the same snapshot history and reference anchor. The Worker scans narrative fields for absolute price-like numbers outside the submitted history envelope, sanitizes those claims, downgrades the result to `DEGRADED`/`WAIT`, and disables its Hybrid weight qualification. The app does not print free-form model numbers as live market price.

## Validation states

- `VALID`: all required v2 fields pass shape, enum, Persian text and numeric checks. Only this state can vote in multi-model consensus. Model-authored factor weights are not treated as reliability weights until out-of-sample calibration exists.
- `DEGRADED`: response is parseable but v2 timeframe/evidence/invalidation fields are missing or incomplete. It may be shown as a clearly marked unqualified model response; it cannot supply Hybrid weights.
- `INVALID`: malformed JSON, invalid bias, non-Persian required narrative, impossible trade geometry, price/reference violations or unsafe structure. Do not display as a valid analysis or count as a vote.

## Current implementation status

Implemented in the current source snapshot:
- shared v2 prompt requirements for all three providers;
- OpenRouter JSON Schema v2 requirements;
- Worker normalizer for timeframe analysis, evidence and invalidation;
- `VALID` / `DEGRADED` status;
- `weightsProvided` is true only when both weights and factor scores exist and the v2 contract validates;
- Flutter model parsing and display of v2 timeframe/evidence/invalidation fields;
- legacy/incomplete responses remain visible as degraded but cannot qualify for Hybrid weights.

Still requires live verification after deployment:
- confirm all three provider endpoints return v2 fields consistently;
- inspect raw requests/responses for actual model IDs and structured-output endpoint behavior;
- verify all price text in summaries is not mistaken for live ticker price (server-owned price labels remain authoritative);
- run end-to-end Flutter tests and APK build.


## Cross-layer decision invariants (2026-11-20 patch)

- Worker and Flutter use the same vote eligibility rule: `status=ok`, `contractStatus=VALID`, and `weightsProvided=true`.
- A directional consensus requires at least two eligible providers agreeing on BUY or SELL; a single provider remains an independent opinion and consensus stays WAIT.
- Hybrid uses equal factor weights until empirical out-of-sample calibration is available. Model-declared confidence is displayed as self-assessment, not used as a calibrated probability multiplier.
- A trade setup may be supported by OB OR FVG OR a directionally appropriate swing/equal-level retest, alongside the complete Entry/SL/TP plan and server-side geometry checks.
