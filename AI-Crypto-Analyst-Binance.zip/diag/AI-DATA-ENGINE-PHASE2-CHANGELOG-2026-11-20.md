# AI Data Engine — Phase 2

## Changes
- Removed forced `responseMimeType: application/json` from Gemini requests.
- Removed Groq strict JSON Schema enforcement. Gemini, Groq and OpenRouter may now return provider-native JSON or prose; parsing and validation happen locally.
- Added generic recursive fact extraction for provider-native nested JSON, including previously unknown model-specific fields.
- Added category normalization for market regime, market structure, liquidity, POIs, momentum/volume, scenarios, trade plans, risk/invalidation, fundamentals/sentiment and data quality.
- Added conservative section extraction for explicitly titled plain-text responses. Unlabeled prose remains available in the original raw response rather than being guessed into categories.
- Exposed `dataCategories` and `extractedFacts` in the Flutter result model and added category panels to the per-provider analysis UI.
- Kept raw provider response available, kept unknown fields in `extractedFacts`, and did not infer missing trade levels.
- Expanded provider response tests for native JSON, unfamiliar keys and titled prose.

## Validation
- `node --check ai-gateway/worker.js`: passed.
- `node --test ai-gateway/tests/worker.test.mjs binance-proxy/tests/worker.test.mjs`: 44 passed, 0 failed.
- ZIP integrity: verified after packaging.

## Not performed
- Flutter/Dart analyze, Android build, live Gemini/Groq/OpenRouter requests, or Cloudflare deployment. These require Flutter tooling and live provider credentials/deployment access.
