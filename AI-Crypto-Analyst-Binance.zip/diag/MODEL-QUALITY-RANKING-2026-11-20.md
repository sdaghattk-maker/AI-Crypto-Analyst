# Model selection and evidence policy — 2026-11-20

## What this list means
The Worker and UI model order is a **capability and live-availability shortlist**, not a proven BTC/ETH trading-accuracy ranking. General AI benchmarks, model vendor claims, and self-reported confidence are not evidence of profitable 5m/15m/1h crypto decisions.

## OpenRouter default
- Default selection: `qwen/qwen3.8-27b:free` when the authenticated live catalog exposes it.
- Free candidates are selected only after the live `/models` catalog confirms text input/output, zero prompt/completion price and adequate context.
- JSON Schema support is endpoint-specific. The Worker first attempts strict structured output; on a compatible 400/404/422 routing/parameter error it retries without schema/reasoning restrictions and still validates the complete V3 contract locally.
- No paid model is silently chosen as the default. The current UI/Worker curated OpenRouter list is restricted to reviewed `:free` candidates.
- Free model availability, rate limits, context, output caps and provider health can change. A free model can still fail due to account limits or provider availability.

## Evidence-based future ranking
For each model, retain identical timestamped snapshots and measure forward outcomes on a chronological holdout. Initial publication threshold: at least 50 completed independent observations per model; report sample size and confidence intervals. Track direction accuracy, calibration, MAE of projected levels, invalidation hit rate, target reach sequence, expectancy after fees/slippage, latency, truncation, schema validity and cost. Do not combine overlapping snapshots as independent samples. Do not rank models with fewer than the minimum observations.

## Safety
No provider's self-declared confidence is treated as win probability. Hybrid weights remain equal until a separate, out-of-sample calibration dataset justifies changes. A single model cannot issue aggregate BUY/SELL.
