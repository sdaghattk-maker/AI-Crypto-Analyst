# AI Crypto Analyst — Model Ranking & Availability Policy (2026-11-20.2)

## Purpose and important distinction

The picker order is a **capability-based priority order**, not a measured crypto-trading leaderboard. No public general benchmark, vendor model card, token throughput, or self-reported confidence proves a model's BTC/ETH signal accuracy. A trading-specific ranking must be learned from identical snapshots and forward outcomes.

The app and Worker use the same ordered candidate lists. The Worker intersects candidates with each user's live provider catalog. A candidate absent from that account's catalog is not displayed or attempted.

## Candidate priority lists

### Gemini — direct Gemini API

1. `gemini-3.8-flash` — default primary.
2. `gemini-3.7-flash` — default fallback.
3. `gemini-3.6-flash`
4. `gemini-3.5-flash`
5. `gemini-3.5-flash-lite`
6. `gemini-3.1-flash-lite`
7. `gemini-2.5-flash`

The Google model directory lists these model families/IDs and release/deprecation status. The live `models.list` response is the final account-level availability check. Models are not silently upgraded to an unverified alias.

### OpenRouter — free OR low-cost, structured-output-capable text models

1. `qwen/qwen4-max` — latest higher-capability candidate; low-cost, not free.
2. `qwen/qwen3.8-27b` — default primary; very low-cost, not necessarily free.
3. `openai/gpt-oss-120b` — default fallback; low-cost, not necessarily free.
4. `inclusionai/ling-3.2-flash:free`
5. `baidu/ernie-5.5-flash-preview:free`
6. `nvidia/nemotron-3-ultra-550b-a55b`
7. `google/gemma-4-31b-it`
8. `google/gemma-4-26b-a4b-it`
9. `openai/gpt-oss-20b`

The Worker no longer requires every OpenRouter model to have zero price. It accepts only text-in/text-out models that advertise `structured_outputs`, have at least 32K context, and are either free or below the current low-cost ceiling: input <= USD 2 per million tokens and output <= USD 6 per million tokens. Some nominally free models (for example, the free Nemotron 3 Ultra and Gemma 4 26B variants in the live catalog snapshot) do not advertise `structured_outputs`; those variants are deliberately excluded. Paid low-cost variants are listed only when they pass the same capability check. The candidate ID must also exist in the live OpenRouter catalog. OpenRouter notes that structured-output capability can differ by serving endpoint; `require_parameters` is used where supported and endpoint errors trigger bounded fallback.

Free model availability and rate limits can change. A `:free` model is not a guarantee of uninterrupted capacity. Low-cost candidates may incur charges; the UI must not describe them as free.

### Groq

1. `qwen/qwen3.8-27b` — default primary where the Groq account exposes it.
2. `openai/gpt-oss-120b` — default fallback.
3. `openai/gpt-oss-20b`
4. `llama-3.3-70b-versatile`
5. `llama-3.1-8b-instant`

The live Groq `/models` catalog remains authoritative. Some candidates may not be active on a particular account or may be retired; they are omitted automatically when absent.

## Automatic fallback policy

- User-selected primary is attempted first.
- User-selected fallback is attempted second.
- Remaining live candidates are attempted in priority order.
- Maximum: **4 model attempts per provider per analysis** to bound latency and quota consumption.
- A successful response ends that provider's fallback chain.
- Failure of one provider does not discard successful responses from other providers.
- Groq remains disabled by default unless the user enables it.

## Ranking methodology

The present ordering uses task-relevant capability signals: general reasoning/model generation, ability to return constrained structured output, context capacity for the three timeframes, operational availability, and cost. This ordering is provisional and intentionally does not invent a numerical accuracy score.

The final trading rank will be calculated from a controlled dataset. Each model must receive the same immutable snapshot and the same prompt/contract. Collect at least 50 completed snapshots per model as an initial sample, then continue toward a larger sample. Score separately:

- schema compliance and completeness;
- reference-price and historical-price consistency;
- evidence validity and timeframe alignment;
- direction accuracy at fixed horizons;
- entry distance and whether entry was actually reachable;
- stop-loss validity and adverse excursion;
- TP1/TP2/TP3 hit rates and realized R multiple;
- false-positive rate in ranges and missed valid moves;
- latency, error rate, token cost and fallback frequency.

Use chronological out-of-sample evaluation; avoid tuning and scoring on the same snapshots. Confidence reported by the model is tracked but is not treated as calibrated probability until calibration is measured.

## Runtime safety

- The live provider catalog is intersected with the code-owned priority list.
- Unknown models are not automatically promoted into the app.
- OpenRouter catalog filtering checks price ceiling, text modalities, context and structured-output capability.
- Provider endpoint availability is checked at request time; model-level capability metadata alone is not a guarantee for every endpoint.
- Model/API keys remain in Cloudflare Worker secrets, never in the APK.

## References

- Google official model directory: https://firebase.google.com/docs/ai-logic/models?api=dev
- Google structured outputs: https://blog.google/innovation-and-ai/technology/developers-tools/gemini-api-structured-outputs/
- OpenRouter live model catalog: https://openrouter.ai/api/v1/models
- OpenRouter free model list and rate-limit notes: https://openrouter.ai/collections/free-models/
- OpenRouter structured outputs and endpoint-specific support: https://openrouter.ai/docs/guides/features/structured-outputs
- Groq model catalog and API docs: https://console.groq.com/docs/models
- Groq structured outputs: https://console.groq.com/docs/structured-outputs
