/**
 * AI Crypto Analyst Gateway - PHASE 7.7 ROOT-CAUSE FIX
 *
 * Cloudflare Worker Secrets:
 *   GEMINI_API_KEY       - Google AI Studio free-tier API key
 *   OPENROUTER_API_KEY   - OpenRouter API key (use a :free model/router)
 *   GROQ_API_KEY         - Groq API key (free-tier availability depends on account/model)
 *   ALTFINS_API_KEY      - optional altFINS API key (server-side only)
 *   GATEWAY_TOKEN        - protects /provider-test only
 *
 * Cloudflare Binding:
 *   RATE_LIMITER         - Rate Limiter binding, Limit 5, Period 60 seconds
 *
 * Routes:
 *   GET  /health
 *   POST /provider-test
 *   POST /analyze
 *   GET  /altfins/quota
 *   POST /altfins/validation
 *   GET  /altfins/diagnostics?symbol=BTCUSDT&timeframe=15m (safe support/resistance diagnostics)
 *
 * IMPORTANT:
 *   /analyze is protected by the RATE_LIMITER binding.
 *   No API key or gateway token is embedded in the app.
 */

const GEMINI_DEFAULT = "gemini-3.8-flash";
const OPENROUTER_DEFAULT = "qwen/qwen3.8-27b:free";
const GROQ_DEFAULT = "qwen/qwen3.8-27b";
// Versioned, capability-based candidate order. This is NOT a crypto-trading
// performance leaderboard. Live provider catalogs intersect this list, so a
// model is selectable only when the user's provider account currently exposes it.
// OpenRouter candidates are free or low-cost text-generation models; endpoint-specific
// structured-output support is still checked by the request/response validator.
const MODEL_RANKING_VERSION = "2026-11-20.3";
const CURATED_MODEL_RANKING = {
  gemini: [
    "gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.6-flash",
    "gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite"
  ],
  openrouter: [
    "qwen/qwen3.8-27b:free", "openai/gpt-oss-20b:free",
    "inclusionai/ling-3.2-flash:free", "baidu/ernie-5.5-flash-preview:free"
  ],
  groq: [
    "qwen/qwen3.8-27b", "openai/gpt-oss-120b", "openai/gpt-oss-20b",
    "llama-3.3-70b-versatile", "llama-3.1-8b-instant"
  ]
};
const PROVIDER_KEYS = { gemini: "GEMINI", openrouter: "OPENROUTER", groq: "GROQ" };
const MAX_AI_OVERLAYS = 10;
const MAX_BODY_BYTES = 1024 * 1024;
const PROVIDER_TIMEOUT_MS = 18000;
const ALTFINS_BASE = "https://altfins.com/api/v2/public";
const ALTFINS_TIMEOUT_MS = 10000;
const ALTFINS_CACHE_TTL_SECONDS = 900;

function responseJson(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Vary": "Origin"
    }
  });
}

function getAllowedOrigin(request, env) {
  const configured = (env.ALLOWED_ORIGIN || "*").trim();
  const incoming = request.headers.get("Origin");
  if (configured === "*") return "*";
  if (!incoming) return configured;
  return incoming === configured ? configured : "null";
}

function normalizeSignal(value) {
  const signal = String(value || "WAIT").trim().toUpperCase();
  if (["BUY", "LONG", "BULLISH", "STRONG_BUY"].includes(signal)) return "BUY";
  if (["SELL", "SHORT", "BEARISH", "STRONG_SELL"].includes(signal)) return "SELL";
  if (["WAIT", "HOLD", "NEUTRAL", "NO_TRADE"].includes(signal)) return "WAIT";
  return "WAIT";
}

function safeError(error) {
  return String(error?.message || error || "Unknown provider error")
    .replace(/(key|token|authorization)\s*[:=]\s*[^,\s]+/ig, "$1=[redacted]")
    .slice(0, 500);
}

async function fetchTimed(url, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), PROVIDER_TIMEOUT_MS);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function fetchProvider(url, options) {
  // HTTP errors (503/429/404) are returned immediately so the model fallback
  // can run. Only a transport-level failure gets one short retry.
  try {
    return await fetchTimed(url, options);
  } catch (firstError) {
    await new Promise(resolve => setTimeout(resolve, 300));
    try {
      return await fetchTimed(url, options);
    } catch (_) {
      throw firstError;
    }
  }
}

function openRouterErrorDetails(body) {
  const error = body?.error || {};
  const meta = error?.metadata || {};
  const router = body?.openrouter_metadata || {};
  const pipeline = Array.isArray(router.pipeline)
    ? router.pipeline.slice(0, 4).map(stage => {
        const parts = [stage?.type, stage?.name, stage?.summary].filter(Boolean);
        return parts.join("/");
      }).join(";")
    : "";
  const fields = [
    meta.error_type ? `error_type=${meta.error_type}` : "",
    meta.provider_name ? `provider=${meta.provider_name}` : "",
    meta.provider_code ? `provider_code=${meta.provider_code}` : "",
    meta.limit_source ? `limit_source=${meta.limit_source}` : "",
    meta.model_slug ? `model=${meta.model_slug}` : "",
    Array.isArray(meta.reasons) && meta.reasons.length ? `reasons=${meta.reasons.slice(0, 3).join(",")}` : "",
    router.region ? `region=${router.region}` : "",
    router.requested ? `requested=${router.requested}` : "",
    router.strategy ? `strategy=${router.strategy}` : "",
    pipeline ? `pipeline=${pipeline}` : ""
  ].filter(Boolean);
  return fields.join(" | ");
}

async function readJsonResponse(response, provider) {
  const raw = await response.text();
  let body;
  try {
    body = JSON.parse(raw);
  } catch {
    const plain = String(raw || "").replace(/\\s+/g, " ").slice(0, 240);
    throw new Error(`${provider} returned non-JSON HTTP ${response.status}: ${plain || "empty response"}`);
  }
  if (!response.ok) {
    const message = body?.error?.message || body?.message || raw;
    const details = provider === "OpenRouter" ? openRouterErrorDetails(body) : "";
    const hint = provider === "OpenRouter" && response.status === 403 && !details
      ? " | OpenRouter returned 403 but did not provide policy metadata; check API-key permissions/guardrails and provider-side access."
      : "";
    throw new Error(`${provider} HTTP ${response.status}: ${String(message).slice(0, 260)}${details ? ` | ${details}` : ""}${hint}`);
  }
  return body;
}

function extractJsonObject(raw, provider) {
  if (raw && typeof raw === "object" && !Array.isArray(raw)) return raw;
  const text = String(raw || "").trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "");

  try {
    return JSON.parse(text);
  } catch (_) {
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(text.slice(start, end + 1));
      } catch (_) {}
    }
    if (text.length >= 8) {
      return {
        bias: "WAIT",
        summary: "مدل پاسخ ساختاریافته و فارسی ارائه نکرد؛ برای جلوگیری از نمایش تحلیل ناقص، این پاسخ به‌عنوان سیگنال معاملاتی پذیرفته نشد.",
        observations: [],
        risks: ["پاسخ مدل JSON معتبر و فارسی نبود؛ مدل جایگزین یا اجرای دوباره را امتحان کنید."],
        confidence: 0,
        analyticalWeights: {trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20}, factorScores: {trend:0,marketStructure:0,liquidity:0,entryConfirmation:0,riskReward:0}, weightsProvided: false,
        overlays: [],
        rawText: null,
        responseFormat: "text"
      };
    }
    throw new Error(`${provider} response was empty or not usable`);
  }
}

function hasPersianText(value) {
  return /[\u0600-\u06FF]/.test(String(value || ""));
}

function normalizeAnalyticalWeights(raw) {
  const keys = ["trend", "marketStructure", "liquidity", "entryConfirmation", "riskReward"];
  const source = raw && typeof raw === "object" ? raw : {};
  const values = keys.map(key => Number(source[key]));
  if (values.some(value => !Number.isFinite(value) || value < 0 || value > 100)) {
    throw new Error("analyticalWeights must contain five numeric values from 0 to 100");
  }
  const total = values.reduce((sum, value) => sum + value, 0);
  if (total <= 0) throw new Error("analyticalWeights total must be greater than zero");
  const normalized = values.map(value => Math.round(value * 100 / total));
  // Correct rounding drift so the five percentages always total exactly 100.
  normalized[0] += 100 - normalized.reduce((sum, value) => sum + value, 0);
  return Object.fromEntries(keys.map((key, index) => [key, normalized[index]]));
}

function normalizeFactorScores(raw) {
  const keys = ["trend", "marketStructure", "liquidity", "entryConfirmation", "riskReward"];
  const source = raw && typeof raw === "object" ? raw : {};
  const out = {};
  for (const key of keys) {
    const value = Number(source[key]);
    if (!Number.isFinite(value) || value < 0 || value > 100) {
      throw new Error(`factorScores.${key} must be a number from 0 to 100`);
    }
    out[key] = Math.round(value);
  }
  return out;
}

function normalizeTimeframeContractV3(value) {
  const tf = value?.timeframeAnalysis;
  const enums = {
    trend: new Set(["BULLISH", "BEARISH", "RANGE", "UNKNOWN"]),
    structure: new Set(["BULLISH", "BEARISH", "RANGE", "TRANSITION", "UNKNOWN"]),
    phase: new Set(["TRENDING", "RANGING", "ACCUMULATION", "DISTRIBUTION", "REVERSAL", "UNKNOWN"]),
    liquidity: new Set(["BUY_SIDE_SWEEP", "SELL_SIDE_SWEEP", "BOTH", "NONE", "UNKNOWN"])
  };
  const normalized = {};
  let valid = value?.contractVersion === 3 && !!tf && typeof tf === "object";
  for (const timeframe of ["1h", "15m", "5m"]) {
    const item = tf?.[timeframe];
    const scoresValid = Number.isInteger(item?.buyerStrength) && item.buyerStrength >= 0 && item.buyerStrength <= 100 &&
      Number.isInteger(item?.sellerStrength) && item.sellerStrength >= 0 && item.sellerStrength <= 100 &&
      Math.abs(item.buyerStrength + item.sellerStrength - 100) <= 2;
    const fieldsValid = item && enums.trend.has(item.trend) && enums.structure.has(item.structure) &&
      enums.phase.has(item.phase) && enums.liquidity.has(item.liquidity) && scoresValid &&
      Array.isArray(item.evidence) && item.evidence.length <= 5 && item.evidence.every(x => typeof x === "string" && hasPersianText(x));
    if (!fieldsValid) valid = false;
    normalized[timeframe] = fieldsValid ? {
      trend: item.trend, structure: item.structure, phase: item.phase,
      buyerStrength: item.buyerStrength, sellerStrength: item.sellerStrength,
      liquidity: item.liquidity, evidence: item.evidence.map(x => String(x).slice(0, 180))
    } : {trend:"UNKNOWN", structure:"UNKNOWN", phase:"UNKNOWN", buyerStrength:null, sellerStrength:null, liquidity:"UNKNOWN", evidence:[]};
  }
  const evidence = Array.isArray(value?.evidence) ? value.evidence.slice(0, 12).filter(item =>
    item && ["1h", "15m", "5m"].includes(item.timeframe) && typeof item.type === "string" &&
    typeof item.event === "string" && ["CONFIRMED", "PENDING", "REJECTED", "NOT_CONFIRMED"].includes(item.status) &&
    typeof item.explanation === "string" && hasPersianText(item.explanation)
  ).map(item => ({timeframe:item.timeframe, type:String(item.type).slice(0,32), event:String(item.event).slice(0,48), status:item.status, explanation:String(item.explanation).slice(0,180)})) : [];
  if (!Array.isArray(value?.evidence) || evidence.length !== value.evidence.length || evidence.length === 0) valid = false;
  const invalidation = String(value?.invalidation || "").trim();
  if (!invalidation || !hasPersianText(invalidation)) valid = false;
  return {valid, timeframeAnalysis:normalized, evidence, invalidation:hasPersianText(invalidation) ? invalidation.slice(0,220) : "شرایط ابطال سناریو در پاسخ مدل مشخص نشده است."};
}

const ANALYSIS_SECTION_KEYS = ["regime", "structure", "liquidity", "poi", "premiumDiscount", "volumeMomentum", "scenarios", "execution", "dataQuality"];
const ANALYSIS_SECTION_LABELS = {
  regime: "رژیم و فاز بازار", structure: "ساختار بازار و چندتایم‌فریمی", liquidity: "نقدینگی و شکار حدضرر",
  poi: "نواحی مهم و نقاط علاقه", premiumDiscount: "محدوده تعادلی و Premium/Discount",
  volumeMomentum: "حجم، مومنتوم و نوسان", scenarios: "سناریوهای جایگزین و شروط فعال‌سازی",
  execution: "کیفیت ورود و مدیریت معامله", dataQuality: "کیفیت داده و محدودیت‌های تحلیل"
};
function normalizeAnalysisContractV3(value) {
  const source = value?.analysisSections;
  const out = {};
  let valid = value?.contractVersion === 3 && source && typeof source === "object";
  for (const key of ANALYSIS_SECTION_KEYS) {
    const section = source?.[key];
    const statusOk = ["AVAILABLE", "NOT_AVAILABLE", "NOT_APPLICABLE", "INSUFFICIENT_DATA"].includes(section?.status);
    const findingsOk = Array.isArray(section?.findings) && section.findings.length >= 1 && section.findings.length <= 4 &&
      section.findings.every(x => typeof x === "string" && x.trim().length >= 4 && hasPersianText(x));
    if (!statusOk || !findingsOk) valid = false;
    out[key] = statusOk && findingsOk
      ? {status: section.status, findings: section.findings.map(x => String(x).trim().slice(0, 260))}
      : {status: "INSUFFICIENT_DATA", findings: ["اطلاعات کافی و قابل اتکا برای ارزیابی این بخش ارائه نشده است."]};
  }
  return {valid, analysisSections: out};
}

function analysisSectionsOutputSchema() {
  const section = {type:"object", additionalProperties:false,
    properties:{status:{type:"string",enum:["AVAILABLE","NOT_AVAILABLE","NOT_APPLICABLE","INSUFFICIENT_DATA"]},findings:{type:"array",minItems:1,maxItems:3,items:{type:"string",minLength:4,maxLength:260}}},
    required:["status","findings"]};
  return {type:"object",additionalProperties:false,properties:Object.fromEntries(ANALYSIS_SECTION_KEYS.map(k=>[k,section])),required:ANALYSIS_SECTION_KEYS};
}

function downgradeTruncatedAnalysis(parsed, provider) {
  const execution = new Set(["Entry", "SL", "TP1", "TP2", "TP3"]);
  return {
    ...parsed,
    bias: "WAIT",
    confidence: 0,
    weightsProvided: false,
    contractStatus: "DEGRADED",
    overlays: (parsed.overlays || []).filter(item => !execution.has(item.kind)),
    risks: [...(parsed.risks || []).slice(0, 4), "پاسخ مدل به سقف طول خروجی رسید؛ برای جلوگیری از استفاده از تحلیل ناقص، سیگنال اجرایی صادر نشد."],
  };
}

function parseModelJson(raw, provider) {
  const value = extractJsonObject(raw, provider);
  const rawBias = String(value.bias || value.decision || value.signal || value.direction || "").trim().toUpperCase();
  const recognizedBias = ["BUY", "LONG", "BULLISH", "STRONG_BUY", "SELL", "SHORT", "BEARISH", "STRONG_SELL", "WAIT", "HOLD", "NEUTRAL", "NO_TRADE"];
  if (!recognizedBias.includes(rawBias)) throw new Error(`${provider} response is missing a recognized BUY/SELL/WAIT bias`);
  const bias = normalizeSignal(rawBias);
  const confidenceNumber = Number(value.confidence);
  if (!Number.isFinite(confidenceNumber) || confidenceNumber < 0 || confidenceNumber > 100) {
    throw new Error(`${provider} response has invalid confidence; expected a number from 0 to 100`);
  }
  const summary = String(value.summary || "").trim();
  const observations = Array.isArray(value.observations) ? value.observations.slice(0, 5).map(item => String(item).slice(0, 220)) : [];
  const risks = Array.isArray(value.risks) ? value.risks.slice(0, 5).map(item => String(item).slice(0, 220))
    : Array.isArray(value.risk_factors) ? value.risk_factors.slice(0, 5).map(item => String(item).slice(0, 220)) : [];
  const humanText = [summary, ...observations, ...risks].filter(Boolean);
  if (!summary || !hasPersianText(summary) || humanText.some(item => !hasPersianText(item))) {
    throw new Error(`${provider} response language validation failed: all summary, observations and risks must be Persian`);
  }
  const timeframeContract = normalizeTimeframeContractV3(value);
  const contractV3 = normalizeAnalysisContractV3(value);
  const weightsProvided = !!value.analyticalWeights && !!value.factorScores && timeframeContract.valid && contractV3.valid;
  const analyticalWeights = value.analyticalWeights && value.factorScores ? normalizeAnalyticalWeights(value.analyticalWeights)
    : {trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20};
  const factorScores = value.analyticalWeights && value.factorScores ? normalizeFactorScores(value.factorScores)
    : {trend:confidenceNumber,marketStructure:confidenceNumber,liquidity:confidenceNumber,entryConfirmation:confidenceNumber,riskReward:confidenceNumber};
  const overlays = normalizeAiOverlays(value.overlays);
  const tradeKinds = new Set(overlays.map(item => item.kind));
  if (bias === "BUY" || bias === "SELL") {
    const required = ["Entry", "SL", "TP1", "TP2", "TP3"];
    const side = bias === "BUY" ? "bullish" : "bearish";
    const matchingOb = overlays.some(x => x.type === "zone" && x.kind === (bias === "BUY" ? "Bullish OB" : "Bearish OB") && x.direction === side);
    const matchingFvg = overlays.some(x => x.type === "zone" && ["FVG", bias === "BUY" ? "Bullish FVG" : "Bearish FVG"].includes(x.kind) && x.direction === side);
    // A valid setup needs one evidenced point of interest, not an artificial
    // requirement that both an OB and an FVG exist simultaneously.
    const matchingRetest = overlays.some(x => x.type === "line" && x.direction === side &&
      (bias === "BUY" ? ["Swing Low", "EQL"].includes(x.kind) : ["Swing High", "EQH"].includes(x.kind)));
    const missing = required.filter(kind => !tradeKinds.has(kind));
    if (!(matchingOb || matchingFvg || matchingRetest)) missing.push("یک POI معتبر (OB یا FVG یا بازآزمایی Swing/Liquidity)");
    if (missing.length) throw new Error(`${provider} returned ${bias} without a complete independent POI/trade plan: missing ${missing.join(",")}`);
    const entry = overlays.find(x => x.kind === "Entry")?.price;
    const stop = overlays.find(x => x.kind === "SL")?.price;
    const targets = [1,2,3].map(n => overlays.find(x => x.kind === `TP${n}`)?.price);
    const execution = overlays.filter(x => ["Entry", "SL", "TP1", "TP2", "TP3"].includes(x.kind));
    const correctDirection = execution.every(x => x.timeframe === "5m" && x.direction === (bias === "BUY" ? "bullish" : "bearish"));
    const risk = Math.abs(entry - stop);
    const rewards = targets.map(target => Math.abs(target - entry) / risk);
    const ordered = bias === "BUY"
      ? stop < entry && targets[0] > entry && targets[1] > targets[0] && targets[2] > targets[1]
      : stop > entry && targets[0] < entry && targets[1] < targets[0] && targets[2] < targets[1];
    const coherent = ordered && correctDirection && Number.isFinite(risk) && risk > 0 && rewards[0] >= 1 && rewards[1] >= 1.5 && rewards[2] >= 2;
    if (!coherent) throw new Error(`${provider} returned inconsistent Entry/SL/TP direction or risk-reward levels for ${bias}`);
  } else if (["Entry", "SL", "TP1", "TP2", "TP3"].some(kind => tradeKinds.has(kind))) {
    throw new Error(`${provider} returned trade execution levels while bias is WAIT`);
  }
  return {
    status: "ok", bias, summary: summary.slice(0, 420), observations, risks,
    confidence: Math.max(0, Math.min(100, Math.round(confidenceNumber))), analyticalWeights, factorScores, weightsProvided, overlays,
    contractVersion: 3, contractStatus: timeframeContract.valid && contractV3.valid ? "VALID" : "DEGRADED",
    timeframeAnalysis: timeframeContract.timeframeAnalysis, evidence: timeframeContract.evidence, invalidation: timeframeContract.invalidation, analysisSections: contractV3.analysisSections,
    rawText: typeof value.rawText === "string" && hasPersianText(value.rawText) ? value.rawText.slice(0, 6000) : null,
    responseFormat: value.responseFormat === "text" ? "text" : "json"
  };
}

// Every provider owns its own plan. Levels are validated structurally and
// against the submitted candle history; no technical-engine or peer-model data is used.
function normalizeAiOverlays(raw) {
  if (!Array.isArray(raw)) return [];
  const allowedKinds = new Set(["Swing High", "Swing Low", "FVG", "Bullish FVG", "Bearish FVG", "Bullish OB", "Bearish OB", "EQH", "EQL", "BOS+", "BOS-", "CRT-H", "CRT-L", "EQ", "Entry", "SL", "TP1", "TP2", "TP3"]);
  const out = [];
  for (const item of raw.slice(0, MAX_AI_OVERLAYS)) {
    if (!item || typeof item !== "object") continue;
    const kind = String(item.kind || "").trim().slice(0, 32);
    const type = item.type === "zone" ? "zone" : item.type === "line" ? "line" : "";
    if (!allowedKinds.has(kind)) continue;
    if (!["1h", "15m", "5m"].includes(item.timeframe)) continue;
    if (!["bullish", "bearish", "neutral"].includes(item.direction)) continue;
    const timeframe = item.timeframe, direction = item.direction;
    const isZone = ["FVG", "Bullish FVG", "Bearish FVG", "Bullish OB", "Bearish OB"].includes(kind);
    if (!type || type !== (isZone ? "zone" : "line")) continue;
    // Directional zone labels and direction metadata must agree. A model may
    // not label a bearish supply block as a bullish demand zone (or vice versa).
    if ((kind === "Bullish OB" || kind === "Bullish FVG") && direction !== "bullish") continue;
    if ((kind === "Bearish OB" || kind === "Bearish FVG") && direction !== "bearish") continue;
    if (type === "line") {
      const price = Number(item.price);
      if (!Number.isFinite(price) || price <= 0) continue;
      out.push({type, kind, price, timeframe, direction});
    } else {
      const low = Number(item.low), high = Number(item.high);
      if (!Number.isFinite(low) || !Number.isFinite(high) || low <= 0 || high <= low) continue;
      out.push({type, kind, low, high, timeframe, direction});
    }
  }
  // A model cannot quietly provide duplicate execution levels.
  const unique = new Map();
  for (const item of out) unique.set(item.kind, item);
  return [...unique.values()];
}

function openRouterOutputSchema() {
  return {
    type: "object",
    additionalProperties: false,
    properties: {
      contractVersion: {type:"integer", const:3},
      analysisSections: analysisSectionsOutputSchema(),
      bias: {type: "string", enum: ["BUY", "SELL", "WAIT"]},
      timeframeAnalysis: {
        type: "object", additionalProperties: false,
        properties: Object.fromEntries(["1h", "15m", "5m"].map(tf => [tf, {
          type:"object", additionalProperties:false,
          properties:{trend:{type:"string",enum:["BULLISH","BEARISH","RANGE","UNKNOWN"]},structure:{type:"string",enum:["BULLISH","BEARISH","RANGE","TRANSITION","UNKNOWN"]},phase:{type:"string",enum:["TRENDING","RANGING","ACCUMULATION","DISTRIBUTION","REVERSAL","UNKNOWN"]},buyerStrength:{type:"integer",minimum:0,maximum:100},sellerStrength:{type:"integer",minimum:0,maximum:100},liquidity:{type:"string",enum:["BUY_SIDE_SWEEP","SELL_SIDE_SWEEP","BOTH","NONE","UNKNOWN"]},evidence:{type:"array",maxItems:5,items:{type:"string",maxLength:180}}},
          required:["trend","structure","phase","buyerStrength","sellerStrength","liquidity","evidence"]
        }])) ,
        required:["1h","15m","5m"]
      },
      evidence: {type:"array",minItems:1,maxItems:12,items:{type:"object",additionalProperties:false,properties:{timeframe:{type:"string",enum:["1h","15m","5m"]},type:{type:"string",maxLength:32},event:{type:"string",maxLength:48},status:{type:"string",enum:["CONFIRMED","PENDING","REJECTED","NOT_CONFIRMED"]},explanation:{type:"string",maxLength:180}},required:["timeframe","type","event","status","explanation"]}},
      invalidation: {type:"string",maxLength:220},
      summary: {type: "string", maxLength: 260},
      observations: {type: "array", maxItems: 5, items: {type: "string", maxLength: 220}},
      risks: {type: "array", maxItems: 5, items: {type: "string", maxLength: 220}},
      confidence: {type: "integer", minimum: 0, maximum: 100},
      factorScores: {
        type: "object", additionalProperties: false,
        properties: {trend: {type: "integer", minimum: 0, maximum: 100}, marketStructure: {type: "integer", minimum: 0, maximum: 100}, liquidity: {type: "integer", minimum: 0, maximum: 100}, entryConfirmation: {type: "integer", minimum: 0, maximum: 100}, riskReward: {type: "integer", minimum: 0, maximum: 100}},
        required: ["trend", "marketStructure", "liquidity", "entryConfirmation", "riskReward"]
      },
      analyticalWeights: {
        type: "object", additionalProperties: false,
        properties: {
          trend: {type: "integer", minimum: 0, maximum: 100},
          marketStructure: {type: "integer", minimum: 0, maximum: 100},
          liquidity: {type: "integer", minimum: 0, maximum: 100},
          entryConfirmation: {type: "integer", minimum: 0, maximum: 100},
          riskReward: {type: "integer", minimum: 0, maximum: 100}
        },
        required: ["trend", "marketStructure", "liquidity", "entryConfirmation", "riskReward"]
      },
      overlays: {
        type: "array",
        maxItems: 10,
        items: {
          type: "object",
          additionalProperties: false,
          properties: {
            type: {type: "string", enum: ["line", "zone"]},
            kind: {type: "string", enum: ["Swing High", "Swing Low", "FVG", "Bullish FVG", "Bearish FVG", "Bullish OB", "Bearish OB", "EQH", "EQL", "BOS+", "BOS-", "CRT-H", "CRT-L", "EQ", "Entry", "SL", "TP1", "TP2", "TP3"]},
            price: {type: ["number", "null"]},
            low: {type: ["number", "null"]},
            high: {type: ["number", "null"]},
            timeframe: {type: "string", enum: ["1h", "15m", "5m"]},
            direction: {type: "string", enum: ["bullish", "bearish", "neutral"]}
          },
          required: ["type", "kind", "price", "low", "high", "timeframe", "direction"]
        }
      }
    },
    required: ["contractVersion", "analysisSections", "bias", "timeframeAnalysis", "evidence", "invalidation", "summary", "observations", "risks", "confidence", "analyticalWeights", "factorScores", "overlays"]
  };
}

function compressHistory(history, recentLimit, oldBuckets = 10) {
  const source = Array.isArray(history?.rows) ? history.rows : [];
  if (source.length <= recentLimit) return {...history, rows: source};
  const split = source.length - recentLimit;
  const basePrice = Number(history.basePrice);
  let previousClose = basePrice;
  let timestamp = Number(history.timeStart || 0);
  const decoded = [];
  for (const row of source) {
    timestamp += Number(row[0] || 0);
    const open = previousClose * (1 + Number(row[1] || 0) / 1000000);
    const high = previousClose * (1 + Number(row[2] || 0) / 1000000);
    const low = previousClose * (1 + Number(row[3] || 0) / 1000000);
    const close = previousClose * (1 + Number(row[4] || 0) / 1000000);
    decoded.push({time: timestamp, open, high, low, close, volume: Number(row[5] || 0)});
    previousClose = close;
  }
  const old = decoded.slice(0, split);
  const recent = source.slice(split);
  const bucketSize = Math.ceil(old.length / oldBuckets);
  const compact = [];
  let prevClose = basePrice;
  let prevTime = Number(history.timeStart || 0);
  for (let i = 0; i < old.length; i += bucketSize) {
    const group = old.slice(i, i + bucketSize);
    if (!group.length) continue;
    const first = group[0], last = group[group.length - 1];
    const values = [first.open, Math.max(...group.map(x => x.high)), Math.min(...group.map(x => x.low)), last.close];
    const delta = value => Math.round((value / prevClose - 1) * 1000000);
    compact.push([
      compact.length === 0 ? 0 : first.time - prevTime,
      delta(values[0]), delta(values[1]), delta(values[2]), delta(values[3]),
      Math.round(group.reduce((sum, x) => sum + x.volume, 0) / group.length)
    ]);
    prevClose = last.close;
    prevTime = last.time;
  }
  // The recent exact rows are still relative to the actual close at the end
  // of the old section, which is also the final compact bucket close.
  compact.push(...recent);
  return {
    timeStart: history.timeStart,
    intervalSeconds: history.intervalSeconds,
    basePrice: history.basePrice,
    baseVolumeMedian: history.baseVolumeMedian,
    originalCount: source.length,
    rows: compact
  };
}

function buildPrompt(input) {
  const history = input.marketHistory || {};
  // All original closed candles remain saved in the app. To respect free-tier
  // TPM/context limits, older history is OHLC-aggregated while recent candles
  // stay exact. This preserves range extremes and recent execution detail.
  const h1 = compressHistory(history["1h"], 48);
  const m15 = compressHistory(history["15m"], 64);
  const m5 = compressHistory(history["5m"], 80);
  const payload = {
    exchange: input.exchange,
    symbol: input.symbol,
    referencePrice: Number.isFinite(Number(input.referencePrice)) ? Number(input.referencePrice) : null,
    lastClosed5mClose: Number.isFinite(Number(input.lastClosed5mClose)) ? Number(input.lastClosed5mClose) : null,
    asOfUtc: typeof input.asOfUtc === 'string' ? input.asOfUtc : null,
    encoding: "rows=[delta_time_seconds, open/high/low/close_delta_ppm_from_previous_close, average_volume_ratio_x100]; older rows are OHLC-aggregated buckets preserving each bucket high/low; latest rows are exact candles",
    history: {
      "1h": h1,
      "15m": m15,
      "5m": m5
    }
  };
  return [
    "Act as an independent crypto market analyst. Analyze ONLY the supplied OHLCV market history. Do not receive or infer any technical-indicator engine decision; there is no technical opinion in this task.",
    "Reconstruct each timeframe sequentially from basePrice. Analyze 1h context, 15m structure and 5m execution. Consider trend, swings, displacement, volatility, volume, liquidity sweeps, range boundaries and alignment. The explicit referencePrice is the live market-price anchor; lastClosed5mClose is the latest completed 5m close. Never invent or shift absolute prices. If reconstructed history disagrees materially with the reference anchor, return WAIT and explain the mismatch in Persian.",
    "MANDATORY LANGUAGE: Every human-readable field (summary, each observation, each risk, each evidence explanation, invalidation) MUST be written in natural Persian/Farsi using Persian script. English sentences are invalid. Only BUY/SELL/WAIT, field names, timeframe codes and enum values remain English. If you cannot write Persian, return WAIT with a short Persian explanation.",
    "Analyze only this model's supplied OHLCV data. Do not receive, infer, copy or agree with any technical-engine result or another AI model. Each provider must independently produce its own zones and trade plan.",
    "Choose BUY, SELL or WAIT from your own evidence. Never force a trade or invent prices. For BUY or SELL, you MUST provide exactly one Entry, one SL, and TP1, TP2, TP3, all as valid line overlays with numeric prices. BUY: SL < Entry < TP1 < TP2 < TP3. SELL: SL > Entry > TP1 > TP2 > TP3. If no valid plan exists, choose WAIT and omit all five execution lines. For a directional setup, identify at least one valid POI: OB OR FVG OR a directionally relevant swing/equal-level retest; do not require both OB and FVG and never fabricate a zone. Return JSON only with contractVersion=3 and analysisSections: timeframeAnalysis for exactly 1h, 15m and 5m (each has trend, structure, phase, buyerStrength, sellerStrength, liquidity and evidence); evidence (1-12 structured items with timeframe,type,event,status,Persian explanation); invalidation (Persian condition); then bias, Persian summary, Persian observations (max 5), Persian risks (max 5), confidence (0-100), analyticalWeights (five integer percentages totaling exactly 100: trend, marketStructure, liquidity, entryConfirmation, riskReward), factorScores (five integer scores from 0 to 100 using the same keys), and overlays (max 10). Weights express how important each factor was to your decision; factorScores express the evidence quality you actually observed. Do not omit either object.",
    "MANDATORY COMPREHENSIVE ANALYSIS SECTIONS: analysisSections must contain exactly regime, structure, liquidity, poi, premiumDiscount, volumeMomentum, scenarios, execution, dataQuality. Each is {status: AVAILABLE|NOT_AVAILABLE|NOT_APPLICABLE|INSUFFICIENT_DATA, findings: [1-3 concise Persian findings]}. regime: trend/range/accumulation/distribution and volatility regime. structure: 1h/15m/5m alignment, BOS/CHOCH/MSS/displacement and protected swings. liquidity: BSL/SSL, EQH/EQL, sweep and reclaim evidence. poi: OB/Breaker/FVG or swing retest, timeframe, boundaries and mitigation state. premiumDiscount: dealing range, equilibrium and location; if range cannot be objectively derived mark insufficient. volumeMomentum: volume expansion/contraction, candle impulse, momentum and volatility based only on OHLCV. scenarios: bullish and bearish alternatives, activation and invalidation conditions; never force direction. execution: location quality, trigger, stop placement logic, target logic and R multiple; WAIT if not executable. dataQuality: supplied data coverage, stale/missing inputs and explicit limitations. If order book, funding, open interest, delta, news or liquidation feed is not supplied, mark NOT_AVAILABLE and explicitly say it was not provided; never infer it from candles. Each finding must be Persian.",
    "Overlay schema: {type:line|zone,kind:Swing High|Swing Low|FVG|Bullish FVG|Bearish FVG|Bullish OB|Bearish OB|EQH|EQL|BOS+|BOS-|CRT-H|CRT-L|EQ|Entry|SL|TP1|TP2|TP3,price:number|null,low:number|null,high:number|null,timeframe:1h|15m|5m,direction:bullish|bearish|neutral}. For line set price and null low/high; for zone set low/high and null price. Entry/SL/TP lines use timeframe 5m and direction matching BUY=bullish or SELL=bearish. Never put prose in enum fields. No markdown or chain-of-thought.",
    JSON.stringify(payload)
  ].join("\n");
}


async function callGemini(prompt, env) {
  if (!env.GEMINI_API_KEY) {
    throw new Error("GEMINI_API_KEY is not configured");
  }

  const model = env.GEMINI_MODEL || GEMINI_DEFAULT;
  const endpoint =
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;

  const response = await fetchProvider(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": env.GEMINI_API_KEY
    },
    body: JSON.stringify({
      system_instruction: {
        parts: [{ text: "Independently analyze only the supplied OHLCV history. Every human-readable field MUST be Persian/Farsi script. Return the complete contractVersion=3 object, including all nine analysisSections, timeframeAnalysis for 1h/15m/5m, structured evidence and invalidation. For BUY/SELL provide Entry, SL, TP1, TP2, TP3 line overlays with coherent numeric prices; for WAIT omit execution lines. Include a valid OB OR FVG OR directionally relevant swing/equal-level retest when objectively identifiable; never fabricate POIs. Return concise valid JSON only. Never invent trade prices or use technical-engine/other-model opinions." }]
      },
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: {
        responseMimeType: "application/json",
        temperature: 0.2,
        maxOutputTokens: 5000
      }
    })
  });

  const body = await readJsonResponse(response, "Gemini");
  const candidate = body?.candidates?.[0];
  if (!candidate) throw new Error("Gemini returned no candidate");
  const wasTruncated = candidate.finishReason === "MAX_TOKENS";
  if (candidate.finishReason === "SAFETY") throw new Error("Gemini response was blocked by safety filtering");
  const raw = candidate?.content?.parts?.map(part => part.text || "").join("");
  const parsed = parseModelJson(raw, "Gemini");
  const safeParsed = wasTruncated ? downgradeTruncatedAnalysis(parsed, "Gemini") : parsed;
  const usage = body?.usageMetadata || {};
  return {
    ...safeParsed,
    providerModel: model,
    finishReason: String(candidate.finishReason || "unknown"),
    promptTokens: Number.isFinite(Number(usage.promptTokenCount)) ? Number(usage.promptTokenCount) : null,
    completionTokens: Number.isFinite(Number(usage.candidatesTokenCount)) ? Number(usage.candidatesTokenCount) : null,
    reasoningTokens: Number.isFinite(Number(usage.thoughtsTokenCount)) ? Number(usage.thoughtsTokenCount) : null
  };
}

async function callOpenRouter(prompt, env) {
  if (!env.OPENROUTER_API_KEY) {
    throw new Error("OPENROUTER_API_KEY is not configured");
  }

  const model = env.OPENROUTER_MODEL || OPENROUTER_DEFAULT;

  const openRouterUrl = "https://openrouter.ai/api/v1/chat/completions";
  const headers = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${env.OPENROUTER_API_KEY}`,
    "X-OpenRouter-Metadata": "enabled",
    "X-OpenRouter-Experimental-Metadata": "enabled",
    "HTTP-Referer": "https://ai-crypto-analyst.app",
    "X-Title": "AI Crypto Analyst"
  };
  const payload = {
    model,
    messages: [
      { role: "system", content: "Independently analyze only the supplied OHLCV history. Every human-readable field MUST be Persian/Farsi script; English prose is invalid. Return the complete contractVersion=3 object with all nine analysisSections, timeframeAnalysis for 1h/15m/5m, structured evidence and invalidation. For BUY/SELL provide Entry, SL, TP1, TP2, TP3 coherent line overlays; for WAIT omit execution lines. Include a valid OB OR FVG OR directionally relevant swing/equal-level retest when objectively identifiable; never fabricate POIs. Return analyticalWeights (five integer percentages totaling 100) and factorScores (five evidence scores 0-100) for trend, marketStructure, liquidity, entryConfirmation, riskReward. Return JSON only. Never invent prices or use technical-engine/other-model opinions." },
      { role: "user", content: prompt }
    ],
    temperature: 0.1,
    reasoning: { effort: "none" },
    max_tokens: 4000,
    response_format: { type: "json_schema", json_schema: {name: "crypto_market_analysis", strict: true, schema: openRouterOutputSchema()} },
    provider: { require_parameters: true, sort: "throughput", allow_fallbacks: true },
    stream: false
  };
  let response = await fetchProvider(openRouterUrl, {method:"POST", headers, body:JSON.stringify(payload)});
  // Some free endpoints do not implement JSON Schema or reasoning controls.
  // Retry once without those optional constraints; parse JSON if present, otherwise preserve plain text.
  if ([400, 404, 422].includes(response.status)) {
    const errorText = await response.clone().text();
    if (/response_format|json_schema|reasoning|unsupported parameter|not supported|no endpoints|no provider|no available provider|no endpoints found|no compatible/i.test(errorText)) {
      const fallbackPayload = {...payload};
      delete fallbackPayload.response_format;
      delete fallbackPayload.reasoning;
      // Allow a healthy endpoint even when it does not implement JSON Schema.
      // JSON parsing and the full V3 contract are still enforced locally.
      fallbackPayload.provider = {sort:"throughput", allow_fallbacks:true};
      response = await fetchProvider(openRouterUrl, {method:"POST", headers, body:JSON.stringify(fallbackPayload)});
    }
  }
  const body = await readJsonResponse(response, "OpenRouter");
  const choice = body?.choices?.[0];
  const message = choice?.message;
  if (!choice || !message) throw new Error("OpenRouter returned no completion choice");
  const usage = body?.usage || {};
  const actualModel = String(body?.model || model);
  const wasTruncated = choice.finish_reason === "length";
  if (choice.finish_reason === "content_filter") throw new Error(`OpenRouter completion blocked by content filtering (model=${actualModel})`);
  let raw = message?.content;
  if (Array.isArray(raw)) {
    raw = raw.map(part => typeof part === "string" ? part : (part?.text || "")).join("\n");
  }
  if ((raw === null || raw === undefined || raw === "") && message?.parsed && typeof message.parsed === "object") {
    raw = message.parsed;
  }
  if ((raw === null || raw === undefined || raw === "") && message?.refusal) {
    throw new Error(`OpenRouter refused the request: ${String(message.refusal).slice(0, 220)}`);
  }
  const parsed = parseModelJson(raw, "OpenRouter");
  const safeParsed = wasTruncated ? downgradeTruncatedAnalysis(parsed, "OpenRouter") : parsed;
  return {
    ...safeParsed,
    providerModel: actualModel,
    finishReason: String(choice.finish_reason || "unknown"),
    nativeFinishReason: choice.native_finish_reason == null ? null : String(choice.native_finish_reason),
    promptTokens: Number.isFinite(Number(usage.prompt_tokens)) ? Number(usage.prompt_tokens) : null,
    completionTokens: Number.isFinite(Number(usage.completion_tokens)) ? Number(usage.completion_tokens) : null,
    reasoningTokens: Number.isFinite(Number(usage.completion_tokens_details?.reasoning_tokens))
      ? Number(usage.completion_tokens_details.reasoning_tokens) : null
  };
}

async function callGroq(prompt, env) {
  if (!env.GROQ_API_KEY) throw new Error("GROQ_API_KEY is not configured");
  const model = env.GROQ_MODEL || GROQ_DEFAULT;
  const strictSchemaModels = new Set(["openai/gpt-oss-20b", "openai/gpt-oss-120b", "qwen/qwen3.8-27b", "meta-models/muse-spark-open"]);
  const payload = {
    model,
    messages: [
      { role: "system", content: "Independently analyze only the supplied OHLCV history. Every human-readable field MUST use Persian/Farsi script; English prose is invalid. Return the complete contractVersion=3 object with all nine analysisSections, timeframeAnalysis for 1h/15m/5m, structured evidence and invalidation. For BUY/SELL provide Entry, SL, TP1, TP2, TP3 coherent line overlays; for WAIT omit execution lines. Include a valid OB OR FVG OR directionally relevant swing/equal-level retest when objectively identifiable; never fabricate POIs. Include analyticalWeights (five integer percentages totaling 100) and factorScores (five evidence scores 0-100) for trend, marketStructure, liquidity, entryConfirmation, riskReward. Keep BUY/SELL/WAIT and schema enums in English. Return exactly one syntactically valid JSON object. Never invent prices or use technical-engine/other-model opinions." },
      { role: "user", content: prompt }
    ],
    temperature: 0.1,
    max_completion_tokens: 5000,
    stream: false
  };
  if (strictSchemaModels.has(model)) payload.response_format = {type:"json_schema",json_schema:{name:"crypto_market_analysis",strict:true,schema:openRouterOutputSchema()}};
  let response = await fetchProvider("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST", headers: {"Content-Type":"application/json","Authorization":`Bearer ${env.GROQ_API_KEY}`}, body: JSON.stringify(payload)
  });
  if ([400,422].includes(response.status) && payload.response_format) {
    const errorText = await response.clone().text();
    if (/response_format|json_schema|unsupported|not supported/i.test(errorText)) {
      const fallbackPayload = {...payload}; delete fallbackPayload.response_format;
      response = await fetchProvider("https://api.groq.com/openai/v1/chat/completions", {method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${env.GROQ_API_KEY}`},body:JSON.stringify(fallbackPayload)});
    }
  }
  const body = await readJsonResponse(response, "Groq");
  const choice = body?.choices?.[0];
  const message = choice?.message;
  if (!choice || !message) throw new Error("Groq returned no completion choice");
  const wasTruncated = choice.finish_reason === "length";
  if (choice.finish_reason === "content_filter") throw new Error("Groq completion blocked by content filtering");
  const raw = message.content;
  const parsed = parseModelJson(raw, "Groq");
  const safeParsed = wasTruncated ? downgradeTruncatedAnalysis(parsed, "Groq") : parsed;
  const usage = body?.usage || {};
  return {
    ...safeParsed,
    providerModel: String(body?.model || model),
    finishReason: String(choice.finish_reason || "unknown"),
    promptTokens: Number.isFinite(Number(usage.prompt_tokens)) ? Number(usage.prompt_tokens) : null,
    completionTokens: Number.isFinite(Number(usage.completion_tokens)) ? Number(usage.completion_tokens) : null,
    reasoningTokens: null
  };
}

function historyPriceBounds(history) {
  let min = Infinity, max = 0;
  for (const tf of ["1h", "15m", "5m"]) {
    const item = history?.[tf];
    if (!item || !Array.isArray(item.rows)) continue;
    let previousClose = Number(item.basePrice);
    for (const row of item.rows) {
      const base = previousClose;
      const open = base * (1 + Number(row[1]) / 1000000);
      const high = base * (1 + Number(row[2]) / 1000000);
      const low = base * (1 + Number(row[3]) / 1000000);
      const close = base * (1 + Number(row[4]) / 1000000);
      if ([open, high, low, close].every(Number.isFinite) && low > 0 && high >= low) {
        min = Math.min(min, low);
        max = Math.max(max, high);
      }
      previousClose = close;
    }
  }
  return Number.isFinite(min) && max > 0 ? {min, max} : null;
}

function sanitizeNarrativePriceValues(text, floor, ceiling) {
  if (typeof text !== "string") return {text, mismatch:false};
  let mismatch = false;
  const normalizedDigits = value => value.replace(/[۰-۹٠-٩]/g, char => {
    const code = char.charCodeAt(0);
    return String(code >= 0x06f0 && code <= 0x06f9 ? code - 0x06f0 : code - 0x0660);
  });
  const sanitized = text.replace(/[0-9۰-۹٠-٩][0-9۰-۹٠-٩,٬،.]{3,}/g, token => {
    const numeric = Number(normalizedDigits(token).replace(/[٬,،]/g, ""));
    if (!Number.isFinite(numeric) || numeric < 1000) return token;
    if (numeric < floor || numeric > ceiling) {
      mismatch = true;
      return "قیمت خارج از داده مرجع";
    }
    return token;
  });
  return {text:sanitized, mismatch};
}

function validateProviderOverlays(provider, history, referencePrice = null) {
  if (provider?.status !== "ok") return provider;
  const bounds = historyPriceBounds(history);
  if (!bounds) return {...provider, overlays: []};
  const historicalFloor = bounds.min * 0.95, historicalCeiling = bounds.max * 1.05;
  // A broad historical envelope alone can admit stale/far-away levels. When
  // the app supplies a live anchor, apply tighter distance caps around it.
  const anchor = Number.isFinite(Number(referencePrice)) && Number(referencePrice) > 0 ? Number(referencePrice) : null;
  const lineFloor = anchor ? Math.max(historicalFloor, anchor * 0.96) : historicalFloor;
  const lineCeiling = anchor ? Math.min(historicalCeiling, anchor * 1.04) : historicalCeiling;
  const zoneFloor = anchor ? Math.max(historicalFloor, anchor * 0.94) : historicalFloor;
  const zoneCeiling = anchor ? Math.min(historicalCeiling, anchor * 1.06) : historicalCeiling;
  // Human-readable model prose must not smuggle in a second, stale market price.
  // Only numbers inside the submitted historical envelope are retained.
  let narrativePriceMismatch = false;
  const sanitizeText = value => {
    const result = sanitizeNarrativePriceValues(value, historicalFloor, historicalCeiling);
    narrativePriceMismatch ||= result.mismatch;
    return result.text;
  };
  const safeProvider = {
    ...provider,
    summary: sanitizeText(provider.summary || ""),
    observations: (provider.observations || []).map(sanitizeText),
    risks: (provider.risks || []).map(sanitizeText),
    invalidation: sanitizeText(provider.invalidation || ""),
    evidence: (provider.evidence || []).map(item => ({...item, explanation:sanitizeText(item.explanation || "")})),
    timeframeAnalysis: Object.fromEntries(Object.entries(provider.timeframeAnalysis || {}).map(([tf,item]) => [tf,{...item,evidence:(item.evidence || []).map(sanitizeText)}]))
  };
  const overlays = (provider.overlays || []).filter(item => item.type === "line"
    ? item.price >= lineFloor && item.price <= lineCeiling
    : item.low >= zoneFloor && item.high <= zoneCeiling);
  const rejectedItems = (provider.overlays || []).filter(item => !overlays.includes(item));
  const rejected = rejectedItems.length;
  const executionKinds = ["Entry", "SL", "TP1", "TP2", "TP3"];
  const executionRejected = rejectedItems.some(item => executionKinds.includes(item.kind));
  const side = provider.bias === "BUY" ? "bullish" : provider.bias === "SELL" ? "bearish" : "neutral";
  const hasValidOb = overlays.some(item => item.type === "zone" && item.kind === (provider.bias === "BUY" ? "Bullish OB" : "Bearish OB") && item.direction === side);
  const hasValidFvg = overlays.some(item => item.type === "zone" && ["FVG", provider.bias === "BUY" ? "Bullish FVG" : "Bearish FVG"].includes(item.kind) && item.direction === side);
  const hasValidRetest = overlays.some(item => item.type === "line" && item.direction === side &&
    (provider.bias === "BUY" ? ["Swing Low", "EQL"].includes(item.kind) : ["Swing High", "EQH"].includes(item.kind)));
  const hasValidPoi = hasValidOb || hasValidFvg || hasValidRetest;
  let finalBias = narrativePriceMismatch ? "WAIT" : provider.bias;
  let finalConfidence = narrativePriceMismatch ? 0 : provider.confidence;
  let finalOverlays = narrativePriceMismatch ? overlays.filter(item => !executionKinds.includes(item.kind)) : overlays;
  const levels = Object.fromEntries(executionKinds.map(kind => [kind, overlays.find(item => item.kind === kind)?.price]));
  const completePlan = executionKinds.every(kind => Number.isFinite(levels[kind]));
  const coherentPlan = provider.bias === "BUY"
    ? levels.SL < levels.Entry && levels.TP1 > levels.Entry && levels.TP2 > levels.TP1 && levels.TP3 > levels.TP2
    : provider.bias === "SELL"
      ? levels.SL > levels.Entry && levels.TP1 < levels.Entry && levels.TP2 < levels.TP1 && levels.TP3 < levels.TP2
      : true;
  // Re-check OB/FVG after the historical-price envelope filter. A plan whose
  // zones were rejected must not remain a BUY/SELL signal with an incomplete map.
  const invalidPlan = narrativePriceMismatch || ((provider.bias === "BUY" || provider.bias === "SELL") &&
    (executionRejected || !completePlan || !coherentPlan || !hasValidPoi));
  if (invalidPlan) {
    finalBias = "WAIT";
    finalConfidence = 0;
    finalOverlays = overlays.filter(item => !executionKinds.includes(item.kind));
  }
  const colored = finalOverlays.map(item => ({...item, color: item.kind === "Entry" ? "#46D6B3" : item.kind === "SL" ? "#F05D6C" : item.kind.startsWith("TP") ? "#22C99A" : item.direction === "bullish" ? "#22C99A" : item.direction === "bearish" ? "#F05D6C" : "#B58BE8"}));
  const extraRisks = [];
  if (narrativePriceMismatch) extraRisks.push("عدد قیمتی خارج از تاریخچه بازار در متن مدل شناسایی و حذف شد؛ تحلیل به WAIT تنزل یافت.");
  if (rejected > 0) extraRisks.push(`${rejected} سطح خارج از محدوده مجاز قیمت تاریخی/مرجع بود و برای جلوگیری از ترسیم قیمت نامعتبر حذف شد.`);
  if (invalidPlan && !narrativePriceMismatch) extraRisks.push(!hasValidPoi
    ? "پس از کنترل قیمت، هیچ POI معتبر از نوع OB، FVG یا بازآزمایی ساختاری باقی نماند؛ سیگنال به انتظار تبدیل شد."
    : "برنامه ورود/حدضرر/اهداف پس از کنترل محدوده قیمت کامل یا سازگار نبود؛ سیگنال به انتظار تبدیل شد.");
  return {
    ...safeProvider, bias: finalBias, confidence: finalConfidence, overlays: colored,
    contractStatus: narrativePriceMismatch ? "DEGRADED" : provider.contractStatus,
    weightsProvided: narrativePriceMismatch ? false : provider.weightsProvided,
    risks: [...(safeProvider.risks || []).slice(0, Math.max(0, 5-extraRisks.length)), ...extraRisks]
  };
}

function configuredModelList(provider, _env) {
  // The code-owned shortlist is authoritative. Old environment model lists
  // must not silently re-introduce retired/low-quality models or hide the
  // curated fallback after a temporary catalog outage.
  return [...(CURATED_MODEL_RANKING[provider] || [])];
}

// Fetch live catalogs server-side; provider API keys never leave the Worker.
async function fetchLiveModelCatalog(provider, env) {
  const key = PROVIDER_KEYS[provider];
  const apiKey = env[`${key}_API_KEY`];
  if (!apiKey) return { models: [], source: "not_configured", error: null };
  try {
    let models = [];
    if (provider === "gemini") {
      let pageToken = "";
      for (let page = 0; page < 3; page++) {
        const url = new URL("https://generativelanguage.googleapis.com/v1beta/models");
        url.searchParams.set("pageSize", "1000");
        if (pageToken) url.searchParams.set("pageToken", pageToken);
        const response = await fetchTimed(url.toString(), {headers:{"x-goog-api-key":apiKey}});
        const body = await readJsonResponse(response, "Gemini models");
        for (const item of body.models || []) {
          const modelId = String(item.name || "").replace(/^models\//, "");
          const nonTextOrSpecial = /(image|tts|transcrib|audio|speech|computer-use|deep-research|robotics|lyria|nano-banana|embedding|moderation)/i;
          if ((item.supportedGenerationMethods || []).includes("generateContent") &&
              /^(gemini|gemma)-/i.test(modelId) && !nonTextOrSpecial.test(modelId)) {
            models.push(modelId);
          }
        }
        pageToken = body.nextPageToken || "";
        if (!pageToken) break;
      }
    } else if (provider === "groq") {
      const response = await fetchTimed("https://api.groq.com/openai/v1/models", {headers:{Authorization:`Bearer ${apiKey}`}});
      const body = await readJsonResponse(response, "Groq models");
      models = (body.data || []).filter(item => item.active !== false && Number(item.context_window || 0) >= 8192 && !/(whisper|guard|embed|speech|transcri|moderation|tts)/i.test(item.id || "")).map(item => String(item.id));
    } else {
      const response = await fetchTimed("https://openrouter.ai/api/v1/models", {headers:{Authorization:`Bearer ${apiKey}`,"HTTP-Referer":"https://ai-crypto-analyst.app","X-Title":"AI Crypto Analyst"}});
      const body = await readJsonResponse(response, "OpenRouter models");
      models = (body.data || []).filter(item => {
        const input = item.architecture?.input_modalities || [];
        const output = item.architecture?.output_modalities || [];
        const pricing = item.pricing || {};
        const promptPrice = Number(pricing.prompt);
        const completionPrice = Number(pricing.completion);
        const isFree = String(item.id || "").endsWith(":free") || (promptPrice === 0 && completionPrice === 0);
        // Allow zero-cost OR low-cost models (USD/token), but require model-level
        // structured-output support. OpenRouter still enforces endpoint-level
        // support at request time via require_parameters.
        const enoughContext = Number(item.context_length || 0) >= 16384;
        // JSON-schema support is endpoint-specific. Models without it remain
        // eligible because the request path retries without response_format
        // and validates the complete V3 contract locally.
        return isFree && enoughContext && input.includes("text") && output.includes("text");
      }).map(item => String(item.id));
    }
    // Preserve the capability shortlist order; do not expose arbitrary catalog
    // entries. This makes discovery broad without silently trusting new models.
    models = (CURATED_MODEL_RANKING[provider] || []).filter(model => models.includes(model));
    return {models,source:"live_ranked_catalog",error:null,rankingVersion:MODEL_RANKING_VERSION};
  } catch (error) {
    return {models:configuredModelList(provider, env),source:"worker_fallback",error:safeError(error)};
  }
}

function requestedModels(provider, input, env, liveCatalog = null) {
  const available = liveCatalog?.[provider] ? liveCatalog[provider].models : configuredModelList(provider, env);
  const primaryRaw = input?.modelSelection?.[provider];
  const fallbackRaw = input?.fallbackSelection?.[provider];
  // User-selected primary/fallback come first; then retain the rest of the
  // ranked live catalog as automatic fallbacks. Never stop at two candidates.
  const values = [primaryRaw == null || primaryRaw === "" ? available[0] : primaryRaw, fallbackRaw, ...available];
  const models = [];
  for (const raw of values) {
    if (raw == null || raw === "") continue;
    const model = String(raw).trim();
    if (model.length > 140 || !/^[a-zA-Z0-9][a-zA-Z0-9._:/-]*$/.test(model)) {
      throw new Error(`Invalid ${provider} model identifier`);
    }
    if (!available.includes(model)) {
      throw new Error(`${provider} model is not in the current Worker candidate list or live provider catalog`);
    }
    if (!models.includes(model)) models.push(model);
  }
  if (models.length === 0) throw new Error(`No ${provider} model is configured`);
  // Bound sequential retries to keep worst-case latency and quota use predictable.
  return models.slice(0, 4);
}

async function runProviders(input, env) {
  const prompt = buildPrompt(input);
  const definitions = [
    ["gemini", callGemini],
    ["openrouter", callOpenRouter],
    ["groq", callGroq]
  ];
  const requested = Array.isArray(input?.selectedProviders)
    ? new Set(input.selectedProviders.filter(x => ["gemini","openrouter","groq"].includes(x)))
    : new Set(definitions.filter(([name]) => Boolean(env[`${PROVIDER_KEYS[name]}_API_KEY`])).map(([name]) => name));
  const liveCatalog = {};
  // Avoid an extra catalog request on every analysis when the selected IDs are
  // already in the local allow-list. Fetch live metadata only for newly selected IDs.
  const catalogNeeded = [...requested].filter(name => {
    const known = configuredModelList(name, env);
    const primary = input?.modelSelection?.[name];
    const fallback = input?.fallbackSelection?.[name];
    return [primary, fallback].some(value => value != null && value !== "" && !known.includes(String(value).trim()));
  });
  await Promise.all(catalogNeeded.map(async name => { liveCatalog[name] = await fetchLiveModelCatalog(name, env); }));
  const settled = await Promise.allSettled(definitions.map(async ([name, fn]) => {
    if (!requested.has(name)) return { skipped: true };
    const started = Date.now();
    try {
      if (!env[`${PROVIDER_KEYS[name]}_API_KEY`]) throw new Error(`${name} API key is not configured`);
      const models = requestedModels(name, input, env, liveCatalog);
      const failures = [];
      for (let modelIndex = 0; modelIndex < models.length; modelIndex++) {
        const model = models[modelIndex];
        try {
          const modelEnv = { ...env, [`${PROVIDER_KEYS[name]}_MODEL`]: model };
          const value = await fn(prompt, modelEnv);
          return { ...value, status: "ok", provider: name, providerModel: value.providerModel || model,
            attemptedModels: models.slice(0, modelIndex + 1), fallbackUsed: modelIndex > 0,
            responseTimeMs: Date.now() - started };
        } catch (error) {
          failures.push(`${model}: ${safeError(error)}`);
        }
      }
      throw new Error(failures.join(" || ") || `${name} models failed`);
    } catch (error) {
      throw Object.assign(new Error(safeError(error)), {
        providerName: name,
        responseTimeMs: Date.now() - started
      });
    }
  }));

  const results = {};
  for (let i = 0; i < definitions.length; i++) {
    const [name] = definitions[i];
    const item = settled[i];
    if (item.status === "fulfilled" && item.value?.skipped) {
      results[name] = { status: "not_selected", provider: name, bias: "WAIT", summary: "این ارائه‌دهنده برای این درخواست انتخاب نشده است.", observations: [], risks: [], confidence: 0, analyticalWeights: {trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20}, factorScores: {trend:0,marketStructure:0,liquidity:0,entryConfirmation:0,riskReward:0}, weightsProvided: false, overlays: [] };
    } else {
      results[name] = item.status === "fulfilled"
        ? item.value
        : {
            status: "error", provider: name, bias: "WAIT", summary: `فراخوانی ${name} ناموفق بود.`,
            observations: [], risks: [], confidence: 0, analyticalWeights: {trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20}, factorScores: {trend:0,marketStructure:0,liquidity:0,entryConfirmation:0,riskReward:0}, weightsProvided: false, overlays: [],
            error: safeError(item.reason), responseTimeMs: Number(item.reason?.responseTimeMs || 0)
          };
    }
    results[name] = validateProviderOverlays(results[name], input.marketHistory, input.referencePrice);
  }
  return results;
}

function overlaysMatch(a, b) {
  if (a.type !== b.type || a.kind !== b.kind || a.direction !== b.direction || a.timeframe !== b.timeframe) return false;
  if (a.type === "line") {
    const mid = (a.price + b.price) / 2;
    return mid > 0 && Math.abs(a.price - b.price) / mid <= 0.0015;
  }
  const overlap = Math.min(a.high, b.high) - Math.max(a.low, b.low);
  const span = Math.max(a.high, b.high) - Math.min(a.low, b.low);
  return span > 0 && overlap / span >= 0.5;
}

function makeConsensus(providers) {
  const names = ["gemini", "openrouter", "groq"];
  const valid = names.filter(name => providers[name]?.status === "ok" && providers[name]?.contractStatus === "VALID" && providers[name]?.weightsProvided === true);
  const conflicts = [];
  if (valid.length === 1) conflicts.push("فقط یک مدل دارای قرارداد کامل پاسخ داده است؛ این پاسخ نظر مستقل است و اجماع چندمدلی محسوب نمی‌شود.");
  if (valid.length === 0) conflicts.push("هیچ مدل AI پاسخ معتبر نداده است.");
  const votes = { BUY: 0, SELL: 0, WAIT: 0 };
  for (const name of valid) votes[normalizeSignal(providers[name].bias)]++;
  const majority = valid.length >= 2 && Math.max(votes.BUY, votes.SELL, votes.WAIT) >= 2
    ? Object.keys(votes).find(key => votes[key] >= 2) : "WAIT";
  if (valid.length >= 2 && majority === "WAIT") conflicts.push("بین مدل‌های پاسخ‌گو اجماع جهت‌دار وجود ندارد.");
  if (valid.length >= 2 && valid.length < 3) conflicts.push("حداقل یکی از ارائه‌دهندگان AI پاسخ نداده است.");
  const agreeing = valid.filter(name => normalizeSignal(providers[name].bias) === majority);
  const confidenceOk = agreeing.length >= 2 && agreeing.every(name => Number(providers[name].confidence) >= 55);
  // Directional consensus is deliberately identical to Flutter: at least two
  // complete, qualified provider contracts must agree. A lone model is never
  // promoted to a consensus decision.
  const decision = valid.length >= 2 && ["BUY", "SELL"].includes(majority) && confidenceOk ? majority : "WAIT";

  const aiOverlays = [];
  const baseName = agreeing[0];
  if (baseName) {
    for (const a of (providers[baseName].overlays || [])) {
      const matching = agreeing.slice(1).map(name => (providers[name].overlays || []).find(b => overlaysMatch(a, b))).filter(Boolean);
      if (matching.length < 1) continue;
      if (a.type === "line") {
        const price = ([a.price, ...matching.map(x => x.price)].reduce((sum, value) => sum + value, 0)) / (matching.length + 1);
        aiOverlays.push({...a, price, color: a.direction === "bullish" ? "#22C99A" : a.direction === "bearish" ? "#F05D6C" : "#B58BE8", agreement: "multi"});
      } else {
        const low = Math.max(a.low, ...matching.map(x => x.low));
        const high = Math.min(a.high, ...matching.map(x => x.high));
        if (high > low) aiOverlays.push({...a, low, high, color: a.direction === "bullish" ? "#22C99A" : a.direction === "bearish" ? "#F05D6C" : "#B58BE8", agreement: "multi"});
      }
      if (aiOverlays.length >= MAX_AI_OVERLAYS) break;
    }
  }
  if (aiOverlays.length === 0) conflicts.push("برای ترسیم تجمیعی منبع AI، دو مدل باید POI هم‌نوع و هم‌محدوده تأیید کنند.");
  return { decision, majority, votes, validProviders: valid, conflicts, aiOverlays };
}

async function readRequestBody(request) {
  const declared = Number(request.headers.get("Content-Length") || 0);
  if (declared > MAX_BODY_BYTES) throw new Error("Request body too large");

  const raw = await request.text();
  if (new TextEncoder().encode(raw).length > MAX_BODY_BYTES) {
    throw new Error("Request body too large");
  }

  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("Invalid JSON body");
  }
}

function constantTimeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) {
    return false;
  }
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function authorizedForProviderTest(request, env) {
  if (!env.GATEWAY_TOKEN) return false;
  const header = request.headers.get("Authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  return constantTimeEqual(token, env.GATEWAY_TOKEN);
}

async function applyRateLimit(request, env) {
  if (!env.RATE_LIMITER) {
    return { allowed: false, reason: "RATE_LIMITER binding is missing" };
  }

  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  try {
    const result = await env.RATE_LIMITER.limit({ key: ip });
    return { allowed: Boolean(result?.success), reason: null };
  } catch (error) {
    return { allowed: false, reason: "Rate limiter binding failed" };
  }
}

function normalizeAltFinsSymbol(raw) {
  const value = String(raw || "").trim().toUpperCase().replace(/[^A-Z0-9_]/g, "");
  if (!value) return "";
  // altFINS crypto screener uses the base ticker (BTC), not Binance's BTCUSDT.
  for (const quote of ["USDT", "USDC", "BUSD", "FDUSD", "USD", "BTC", "ETH"]) {
    if (value.endsWith(quote) && value.length > quote.length) return value.slice(0, -quote.length);
  }
  return value;
}

function altFinsInterval(raw) {
  const value = String(raw || "15m").trim().toLowerCase();
  const map = { "15m": "MINUTES15", "15min": "MINUTES15", "1h": "HOURLY", "60m": "HOURLY", "4h": "HOURS4", "12h": "HOURS12", "1d": "DAILY" };
  return map[value] || null;
}

async function altFinsFetch(path, env, options = {}) {
  if (!env.ALTFINS_API_KEY) throw new Error("ALTFINS_NOT_CONFIGURED");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ALTFINS_TIMEOUT_MS);
  try {
    return await fetch(`${ALTFINS_BASE}${path}`, {
      ...options,
      signal: controller.signal,
      headers: {
        Accept: "application/json",
        "X-API-KEY": env.ALTFINS_API_KEY,
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...(options.headers || {})
      }
    });
  } finally { clearTimeout(timer); }
}

async function readAltFinsJson(response) {
  const raw = await response.text();
  let body;
  try { body = raw ? JSON.parse(raw) : {}; }
  catch { throw new Error(`ALTFINS_INVALID_RESPONSE_HTTP_${response.status}`); }
  if (!response.ok) {
    const code = response.status === 401 ? "ALTFINS_UNAUTHORIZED" :
      response.status === 403 ? "ALTFINS_PLAN_RESTRICTED" :
      response.status === 429 ? "ALTFINS_LIMIT_REACHED" : `ALTFINS_HTTP_${response.status}`;
    const error = new Error(code);
    error.status = response.status;
    throw error;
  }
  return body;
}

async function getAltFinsQuota(env) {
  const response = await altFinsFetch("/monthly-available-permits", env, { method: "GET" });
  const body = await readAltFinsJson(response);
  return {
    availablePermits: Number.isFinite(Number(body.availablePermits)) ? Number(body.availablePermits) : null,
    monthlyAvailablePermits: Number.isFinite(Number(body.monthlyAvailablePermits)) ? Number(body.monthlyAvailablePermits) : null,
    monthlyAvailableAiTradeSetupPrompts: Number.isFinite(Number(body.monthlyAvailableAiTradeSetupPrompts))
      ? Number(body.monthlyAvailableAiTradeSetupPrompts) : null
  };
}

async function getAltFinsValidation(input, env) {
  const symbol = normalizeAltFinsSymbol(input.symbol);
  const interval = altFinsInterval(input.timeframe);
  if (!symbol || symbol.length > 20 || !interval) {
    return { status: 400, body: { ok: false, source: "altfins", status: "INVALID_INPUT", error: "A valid crypto symbol and timeframe (15m, 1h, 4h, 12h, 1d) are required" } };
  }
  const exchange = String(input.exchange || "BINANCE").toUpperCase();
  const allowedExchanges = new Set(["BINANCE", "BYBIT", "OKX", "COINBASE", "KRAKEN", "KUCOIN", "MEXC", "GATEIO"]);
  const safeExchange = allowedExchanges.has(exchange) ? exchange : "BINANCE";
  const tradingType = String(input.tradingType || "FUTURES").toUpperCase();
  const safeTradingType = ["SPOT", "FUTURES", "PERPETUAL", "FUTURES_OR_PERPETUAL", "ALL"].includes(tradingType) ? tradingType : "FUTURES";
  const cacheKey = new Request(`https://altfins-cache.local/v1/${encodeURIComponent(symbol)}/${interval}/${safeExchange}/${safeTradingType}`);
  const diagnostic = input.diagnostic === true;
  const cache = globalThis.caches?.default;
  if (cache && !diagnostic) {
    const cached = await cache.match(cacheKey);
    if (cached) {
      const data = await cached.json();
      return { status: 200, body: { ...data, cached: true } };
    }
  }
  const payload = {
    symbols: [symbol],
    timeInterval: interval,
    displayType: ["RSI14", "ADX", "MACD", "MACD_SIGNAL_LINE", "EMA9", "EMA50", "EMA200", "ATR", "VOLUME", "VOLUME_RELATIVE", "SHORT_TERM_TREND", "MEDIUM_TERM_TREND", "LONG_TERM_TREND", "SUPPORT", "RESISTANCE"]
  };
  const params = new URLSearchParams({ page: "0", size: "1", sort: "TIME,desc" });
  // These filters constrain the listing to the requested venue and instrument class.
  const bodyPayload = { ...payload, exchangeFilter: safeExchange, tradingTypeFilter: safeTradingType };
  try {
    const response = await altFinsFetch(`/screener-data/search-requests?${params}`, env, {
      method: "POST", body: JSON.stringify(bodyPayload)
    });
    const data = await readAltFinsJson(response);
    const rows = Array.isArray(data) ? data : Array.isArray(data.content) ? data.content :
      Array.isArray(data.items) ? data.items : [];
    const item = rows.find(row => String(row.symbol || "").toUpperCase() === symbol) || rows[0] || null;
    if (!item) {
      return { status: 200, body: { ok: true, source: "altfins", status: "NO_MATCH", symbol, timeframe: input.timeframe, refreshedAt: new Date().toISOString(), data: null, cached: false } };
    }
    // The official Screener API nests indicator values inside `additionalData`.
    // Older/alternate response shapes are also accepted for forward compatibility.
    const additional = item.additionalData || item.additional_data || {};
    // Diagnostic mode returns only support/resistance-related key names, types,
    // and bounded values. It never returns headers, API keys, or the full payload.
    const diagnosticKeys = diagnostic ? {
      itemKeys: Object.keys(item).filter(key => /support|resistance/i.test(key)),
      additionalDataKeys: Object.keys(additional).filter(key => /support|resistance/i.test(key)),
      supportCandidates: [],
      resistanceCandidates: []
    } : null;
    const safeDiagnosticValue = value => {
      if (value === null || value === undefined) return null;
      if (typeof value === "number" || typeof value === "boolean") return value;
      if (typeof value === "string") return value.slice(0, 160);
      try { return JSON.stringify(value).slice(0, 300); } catch (_) { return String(value).slice(0, 160); }
    };
    if (diagnostic) {
      for (const [key, value] of Object.entries({...item, ...additional})) {
        if (/support/i.test(key)) diagnosticKeys.supportCandidates.push({key, type: value === null ? "null" : Array.isArray(value) ? "array" : typeof value, value: safeDiagnosticValue(value)});
        if (/resistance/i.test(key)) diagnosticKeys.resistanceCandidates.push({key, type: value === null ? "null" : Array.isArray(value) ? "array" : typeof value, value: safeDiagnosticValue(value)});
      }
    }
    const metric = (...keys) => {
      for (const key of keys) {
        let value = item[key];
        if (value === undefined || value === null) value = additional[key];
        if (value === undefined || value === null) {
          const upper = String(key).toUpperCase();
          value = item[upper] ?? additional[upper];
        }
        if (value && typeof value === "object" && !Array.isArray(value)) {
          value = value.value ?? value.currentValue ?? value.numericValue ?? value.displayValue ?? null;
        }
        if (value !== undefined && value !== null && value !== "") return value;
      }
      return null;
    };
    // SUPPORT / RESISTANCE are nested objects (SUPPORT_1..6 / RESISTANCE_1..6),
    // not scalar metrics. Parse their formatted strings and select the nearest
    // valid level on the correct side of the current price.
    const parseAltFinsPrice = value => {
      if (typeof value === "number" && Number.isFinite(value)) return value;
      if (typeof value !== "string") return null;
      const cleaned = value.trim().replace(/,/g, "");
      if (!cleaned || cleaned === "-" || cleaned.toLowerCase() === "null") return null;
      const parsed = Number(cleaned);
      return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
    };
    const levelObject = (kind) => {
      const upper = kind.toUpperCase();
      const raw = item[upper] ?? item[kind.toLowerCase()] ?? additional[upper] ?? additional[kind.toLowerCase()];
      if (!raw || typeof raw !== "object" || Array.isArray(raw)) return {};
      return raw;
    };
    const collectLevels = kind => {
      const raw = levelObject(kind);
      const levels = [];
      for (let i = 1; i <= 6; i++) {
        const key = `${kind.toUpperCase()}_${i}`;
        const price = parseAltFinsPrice(raw[key] ?? raw[key.toLowerCase()]);
        if (price !== null) levels.push({ index: i, price });
      }
      return levels.sort((a, b) => a.price - b.price);
    };
    const lastPrice = parseAltFinsPrice(metric("lastPrice", "LAST_PRICE"));
    const supportLevels = collectLevels("support");
    const resistanceLevels = collectLevels("resistance");
    const nearestSupport = lastPrice === null ? null : supportLevels
      .filter(level => level.price <= lastPrice)
      .sort((a, b) => b.price - a.price)[0] || null;
    const nearestResistance = lastPrice === null ? null : resistanceLevels
      .filter(level => level.price >= lastPrice)
      .sort((a, b) => a.price - b.price)[0] || null;
    const normalizedData = {
      symbol: item.symbol || symbol,
      name: item.name || null,
      lastPrice: metric("lastPrice", "LAST_PRICE"),
      rsi14: metric("rsi14", "RSI14"),
      adx: metric("adx", "ADX"),
      macd: metric("macd", "MACD"),
      macdSignal: metric("macdSignalLine", "macdSignal", "MACD_SIGNAL_LINE"),
      ema9: metric("ema9", "EMA9"),
      ema50: metric("ema50", "EMA50"),
      ema200: metric("ema200", "EMA200"),
      atr: metric("atr", "ATR"),
      volume: metric("volume", "VOLUME"),
      relativeVolume: metric("volumeRelative", "relativeVolume", "VOLUME_RELATIVE"),
      shortTermTrend: metric("shortTermTrend", "SHORT_TERM_TREND"),
      mediumTermTrend: metric("mediumTermTrend", "MEDIUM_TERM_TREND"),
      longTermTrend: metric("longTermTrend", "LONG_TERM_TREND"),
      support: nearestSupport ? nearestSupport.price : null,
      resistance: nearestResistance ? nearestResistance.price : null,
      supportLevels: supportLevels.map(level => level.price),
      resistanceLevels: resistanceLevels.map(level => level.price)
    };
    const metricCount = Object.entries(normalizedData).filter(([key, value]) => key !== "symbol" && key !== "name" && value !== null).length;
    const normalized = {
      ok: metricCount > 0, source: "altfins", status: metricCount > 0 ? "AVAILABLE" : "DATA_EMPTY", symbol,
      timeframe: input.timeframe || "15m", interval,
      refreshedAt: new Date().toISOString(), cached: false,
      metricCount, data: normalizedData,
      ...(diagnostic ? { diagnostic: {
        responseContainer: Array.isArray(data) ? "array" : Array.isArray(data.content) ? "content[]" : Array.isArray(data.items) ? "items[]" : "unknown",
        additionalDataPresent: Boolean(item.additionalData || item.additional_data),
        supportResistanceKeys: diagnosticKeys,
        normalizedSupport: safeDiagnosticValue(normalizedData.support),
        normalizedResistance: safeDiagnosticValue(normalizedData.resistance),
        parsedSupportLevels: normalizedData.supportLevels,
        parsedResistanceLevels: normalizedData.resistanceLevels,
        selectedSupportIndex: nearestSupport?.index ?? null,
        selectedResistanceIndex: nearestResistance?.index ?? null,
        parsedLastPrice: lastPrice
      } } : {}),
      ...(metricCount === 0 ? { error: "ALT FINS returned an asset but no requested indicator values in additionalData", affectsTradeDecision: false } : {})
    };
    if (cache && !diagnostic) {
      const cacheResponse = new Response(JSON.stringify(normalized), { headers: { "Content-Type": "application/json", "Cache-Control": `public, max-age=${ALTFINS_CACHE_TTL_SECONDS}` } });
      await cache.put(cacheKey, cacheResponse);
    }
    return { status: 200, body: normalized };
  } catch (error) {
    const code = String(error?.message || "ALTFINS_UNAVAILABLE");
    const status = code === "ALTFINS_NOT_CONFIGURED" ? 503 :
      code === "ALTFINS_UNAUTHORIZED" ? 502 :
      code === "ALTFINS_PLAN_RESTRICTED" ? 200 :
      code === "ALTFINS_LIMIT_REACHED" ? 200 : 502;
    const state = code === "ALTFINS_NOT_CONFIGURED" ? "NOT_CONFIGURED" :
      code === "ALTFINS_UNAUTHORIZED" ? "INVALID_KEY" :
      code === "ALTFINS_PLAN_RESTRICTED" ? "PLAN_RESTRICTED" :
      code === "ALTFINS_LIMIT_REACHED" ? "LIMIT_REACHED" : "UNAVAILABLE";
    return { status, body: { ok: false, source: "altfins", status: state, symbol, timeframe: input.timeframe || "15m", error: code, affectsTradeDecision: false } };
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = getAllowedOrigin(request, env);

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          "Access-Control-Allow-Origin": origin,
          "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
          "Access-Control-Max-Age": "86400",
          "Vary": "Origin"
        }
      });
    }

    if (origin === "null") {
      return responseJson({ ok: false, error: "Origin not allowed" }, 403, origin);
    }

    if (url.pathname === "/health" && request.method === "GET") {
      return responseJson({
        ok: true,
        service: "AI Crypto Analyst Gateway",
        mode: "FREE_PROVIDERS",
        configured: {
          gemini: Boolean(env.GEMINI_API_KEY),
          openrouter: Boolean(env.OPENROUTER_API_KEY),
          groq: Boolean(env.GROQ_API_KEY),
          altfins: Boolean(env.ALTFINS_API_KEY),
          gateway: Boolean(env.GATEWAY_TOKEN),
          rateLimiter: Boolean(env.RATE_LIMITER)
        },
        models: {
          gemini: configuredModelList("gemini", env),
          openrouter: configuredModelList("openrouter", env),
          groq: configuredModelList("groq", env)
        },
        modelSelectionSupported: true,
        modelRankingVersion: MODEL_RANKING_VERSION,
        modelRankingNote: "Capability-based shortlist only; not a measured crypto-trading win-rate ranking."
      }, 200, origin);
    }

    if (url.pathname === "/models" && request.method === "GET") {
      const entries = await Promise.all(["gemini","openrouter","groq"].map(async name => [name, await fetchLiveModelCatalog(name, env)]));
      const providers = Object.fromEntries(entries.map(([name, catalog]) => [name, {
        configured: Boolean(env[`${PROVIDER_KEYS[name]}_API_KEY`]),
        source: catalog.source,
        error: catalog.error,
        models: catalog.models,
        modelPolicy: "free_or_low_cost_structured_text",
        maxAutoAttempts: 4
      }]));
      return responseJson({ ok: true, source: "live_provider_catalog", rankingVersion: MODEL_RANKING_VERSION, rankingNote: "Capability-based shortlist only; not a measured crypto-trading win-rate ranking.", refreshedAt: new Date().toISOString(), providers }, 200, origin);
    }

    if (url.pathname === "/altfins/quota" && request.method === "GET") {
      if (!env.ALTFINS_API_KEY) return responseJson({ ok: false, source: "altfins", status: "NOT_CONFIGURED" }, 200, origin);
      try {
        const quota = await getAltFinsQuota(env);
        return responseJson({ ok: true, source: "altfins", status: "AVAILABLE", checkedAt: new Date().toISOString(), quota }, 200, origin);
      } catch (error) {
        const code = String(error?.message || "ALTFINS_UNAVAILABLE");
        const state = code === "ALTFINS_UNAUTHORIZED" ? "INVALID_KEY" : code === "ALTFINS_PLAN_RESTRICTED" ? "PLAN_RESTRICTED" : code === "ALTFINS_LIMIT_REACHED" ? "LIMIT_REACHED" : "UNAVAILABLE";
        return responseJson({ ok: false, source: "altfins", status: state, error: code }, 200, origin);
      }
    }

    if (url.pathname === "/altfins/diagnostics" && request.method === "GET") {
      if (!env.ALTFINS_API_KEY) return responseJson({ ok: false, source: "altfins", status: "NOT_CONFIGURED" }, 200, origin);
      const rate = await applyRateLimit(request, env);
      if (!rate.allowed) return responseJson({ ok: false, source: "altfins", status: "RATE_LIMITED", error: rate.reason || "Rate limit exceeded" }, 200, origin);
      const result = await getAltFinsValidation({
        symbol: url.searchParams.get("symbol") || "BTCUSDT",
        timeframe: url.searchParams.get("timeframe") || "15m",
        exchange: url.searchParams.get("exchange") || "BINANCE",
        tradingType: url.searchParams.get("tradingType") || "FUTURES",
        diagnostic: true
      }, env);
      return responseJson(result.body, result.status, origin);
    }

    if (url.pathname === "/altfins/validation") {
      if (request.method !== "POST") return responseJson({ ok: false, error: "Method not allowed" }, 405, origin);
      if (!env.ALTFINS_API_KEY) return responseJson({ ok: false, source: "altfins", status: "NOT_CONFIGURED", affectsTradeDecision: false }, 200, origin);
      const rate = await applyRateLimit(request, env);
      if (!rate.allowed) return responseJson({ ok: false, source: "altfins", status: "RATE_LIMITED", error: rate.reason || "Rate limit exceeded", affectsTradeDecision: false }, 200, origin);
      try {
        const body = await readRequestBody(request);
        const result = await getAltFinsValidation(body || {}, env);
        return responseJson(result.body, result.status, origin);
      } catch (error) {
        const code = String(error?.message || "ALTFINS_UNAVAILABLE");
        const status = code === "Invalid JSON body" ? 400 : code === "Request body too large" ? 413 : 200;
        return responseJson({ ok: false, source: "altfins", status: "UNAVAILABLE", error: code, affectsTradeDecision: false }, status, origin);
      }
    }

    if (url.pathname === "/provider-test") {
      if (request.method !== "POST") {
        return responseJson({ ok: false, error: "Method not allowed" }, 405, origin);
      }
      if (!authorizedForProviderTest(request, env)) {
        return responseJson({ ok: false, error: "Unauthorized" }, 401, origin);
      }

      let testOptions = {};
      try { const rawOptions = await request.text(); if (rawOptions) testOptions = JSON.parse(rawOptions); }
      catch { return responseJson({ ok: false, error: "Invalid JSON body" }, 400, origin); }
      const testInput = {
        modelSelection: testOptions.modelSelection || {},
        fallbackSelection: testOptions.fallbackSelection || {},
        selectedProviders: testOptions.selectedProviders,
        exchange: "TEST",
        symbol: "BTCUSDT",
        technicalAnalysis: {
          signal: "WAIT",
          note: "Connectivity test only. Do not produce a trade signal."
        },
        marketHistory: {
          format: "delta OHLCV; price deltas in 0.01 bps; volume ratio x100",
          "1h": {timeStart:1700000000,intervalSeconds:3600,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:3600,0,10000,-10000,5000,100])},
          "15m": {timeStart:1700000000,intervalSeconds:900,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:900,0,10000,-10000,5000,100])},
          "5m": {timeStart:1700000000,intervalSeconds:300,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:300,0,10000,-10000,5000,100])}
        }
      };

      const providers = await runProviders(testInput, env);
      const successCount = Object.values(providers).filter(item => item.status === "ok").length;
      const ok = successCount >= 1;

      return responseJson({
        ok, successCount, requiredForDisplay: 1, requiredForConsensus: 2,
        test: "provider-connectivity", providers
      }, ok ? 200 : 502, origin);
    }

    if (url.pathname !== "/analyze") {
      return responseJson({ ok: false, error: "Not found" }, 404, origin);
    }

    if (request.method !== "POST") {
      return responseJson({ ok: false, error: "Method not allowed" }, 405, origin);
    }

    const rate = await applyRateLimit(request, env);
    if (!rate.allowed) {
      return responseJson({
        ok: false,
        error: rate.reason || "Rate limit exceeded",
        code: rate.reason ? "RATE_LIMITER_UNAVAILABLE" : "RATE_LIMITED"
      }, rate.reason ? 503 : 429, origin);
    }

    if (!env.GEMINI_API_KEY && !env.OPENROUTER_API_KEY && !env.GROQ_API_KEY) {
      return responseJson({
        ok: false,
        error: "No AI provider API key is configured (GEMINI_API_KEY, OPENROUTER_API_KEY, GROQ_API_KEY)"
      }, 503, origin);
    }

    try {
      const input = await readRequestBody(request);
      const marketHistory = input?.marketHistory;
      const validHistory = (item) => item && typeof item === "object" &&
        Number.isFinite(Number(item.timeStart)) && Number(item.timeStart) > 0 &&
        Number.isFinite(Number(item.intervalSeconds)) && Number(item.intervalSeconds) > 0 &&
        Number.isFinite(Number(item.basePrice)) && Number(item.basePrice) > 0 &&
        Number.isFinite(Number(item.baseVolumeMedian)) && Number(item.baseVolumeMedian) >= 0 &&
        Array.isArray(item.rows) && item.rows.length >= 50 && item.rows.every((row) =>
          Array.isArray(row) && row.length === 6 && row.every((value) => Number.isFinite(Number(value))) &&
          Number(row[0]) >= 0 && Number(row[2]) >= Math.max(Number(row[1]), Number(row[4])) &&
          Number(row[3]) <= Math.min(Number(row[1]), Number(row[4])) && Number(row[2]) >= Number(row[3]) && Number(row[5]) >= 0
        );

      if (
        !input ||
        typeof input !== "object" ||
        Array.isArray(input) ||
        typeof input.exchange !== "string" ||
        typeof input.symbol !== "string" ||
        !marketHistory || typeof marketHistory !== "object" ||
        !validHistory(marketHistory["1h"]) || !validHistory(marketHistory["15m"]) || !validHistory(marketHistory["5m"])
      ) {
        return responseJson({
          ok: false,
          error: "exchange, symbol and valid 1h/15m/5m marketHistory are required"
        }, 400, origin);
      }

      const referencePrice = Number(input.referencePrice);
      const lastClosed5mClose = Number(input.lastClosed5mClose);
      if (Number.isFinite(referencePrice) && referencePrice > 0 && Number.isFinite(lastClosed5mClose) && lastClosed5mClose > 0) {
        const gap = Math.abs(referencePrice - lastClosed5mClose) / lastClosed5mClose;
        if (gap > 0.025) return responseJson({ok:false,error:'Live reference price differs from the latest closed 5m close by more than 2.5%; analysis was blocked to prevent mixed-price snapshots.',code:'REFERENCE_PRICE_MISMATCH'}, 409, origin);
      }

      const providers = await runProviders({
        exchange: input.exchange.slice(0, 40),
        symbol: input.symbol.slice(0, 40),
        marketHistory,
        referencePrice: Number.isFinite(Number(input.referencePrice)) && Number(input.referencePrice) > 0 ? Number(input.referencePrice) : null,
        lastClosed5mClose: Number.isFinite(Number(input.lastClosed5mClose)) && Number(input.lastClosed5mClose) > 0 ? Number(input.lastClosed5mClose) : null,
        asOfUtc: typeof input.asOfUtc === 'string' ? input.asOfUtc.slice(0, 40) : null,
        snapshotId: typeof input.snapshotId === "string" ? input.snapshotId.slice(0, 100) : null,
        modelSelection: input.modelSelection && typeof input.modelSelection === "object" ? input.modelSelection : {},
        fallbackSelection: input.fallbackSelection && typeof input.fallbackSelection === "object" ? input.fallbackSelection : {},
        selectedProviders: input.selectedProviders
      }, env);
      const { gemini, openrouter, groq } = providers;
      const successfulProviders = Object.values(providers).filter(provider => provider.status === "ok").length;
      if (successfulProviders === 0) {
        return responseJson({
          ok: false, decision: "WAIT", providers, gemini, openrouter, groq,
          error: "All configured AI providers failed; no independent AI assessment is available"
        }, 502, origin);
      }

      const consensus = makeConsensus(providers);
      const partial = successfulProviders < 3;
      return responseJson({
        ok: true,
        decision: consensus.decision,
        consensus,
        conflicts: consensus.conflicts,
        providers,
        gemini,
        openrouter,
        groq,
        analysisMode: successfulProviders < 2 ? "SINGLE_PROVIDER_INDEPENDENT" : partial ? "PARTIAL_MULTI_PROVIDER" : "TRIPLE_PROVIDER",
        priceLevelsSource: "SOURCE_SELECTOR",
        aiOverlays: consensus.aiOverlays,
        snapshotId: typeof input.snapshotId === "string" ? input.snapshotId.slice(0, 100) : null,
        modelSelection: input.modelSelection || {},
        fallbackSelection: input.fallbackSelection || {},
        historyCounts: {
          "1h": marketHistory["1h"].rows.length,
          "15m": marketHistory["15m"].rows.length,
          "5m": marketHistory["5m"].rows.length
        }
      }, 200, origin);

    } catch (error) {
      const message = safeError(error);
      const status =
        message === "Request body too large" ? 413 :
        message === "Invalid JSON body" ? 400 : 502;

      return responseJson({
        ok: false,
        error: message,
        decision: "WAIT"
      }, status, origin);
    }
  }
};
