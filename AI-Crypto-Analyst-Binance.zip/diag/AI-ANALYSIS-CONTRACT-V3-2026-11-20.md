# AI Analysis Contract V3 — 2026-11-20

## Purpose
V3 replaces the minimal V2 response with a shared, mandatory, Persian-language market-analysis report for Gemini, OpenRouter and Groq. It does not claim calibrated trading probability.

## Required report
1. **Market regime:** trend/range/accumulation/distribution and volatility context.
2. **Multi-timeframe structure:** 1h context, 15m setup and 5m execution; BOS/CHOCH/MSS/displacement and protected swings where evidenced.
3. **Liquidity:** buy-side/sell-side liquidity, equal highs/lows, sweep and reclaim evidence.
4. **POI:** OB/Breaker/FVG or a directionally relevant swing/equal-level retest; one valid POI is enough, both OB and FVG are not required.
5. **Premium/Discount:** dealing range, equilibrium and current location; mark insufficient when a valid range cannot be derived.
6. **Volume/momentum/volatility:** candle-volume expansion, impulse and volatility using supplied OHLCV only.
7. **Scenarios:** bullish and bearish alternatives with activation and invalidation conditions.
8. **Execution:** entry quality, trigger, stop logic, targets and R multiples. BUY/SELL requires a coherent plan; otherwise WAIT.
9. **Data quality:** supplied coverage, stale/missing inputs and limitations.

Each section is `{status, findings}`. Status is one of `AVAILABLE`, `NOT_AVAILABLE`, `NOT_APPLICABLE`, `INSUFFICIENT_DATA`. Each finding is Persian. Missing order book, funding, open interest, delta, news and liquidation data must be disclosed as not supplied, never inferred from OHLCV.

## Shared supporting fields
- `timeframeAnalysis` for exactly `1h`, `15m`, `5m`.
- Structured evidence with timeframe, type, event, status and Persian explanation.
- Scenario invalidation.
- Persian summary, observations and risks.
- Analytical weights and evidence factor scores (not model reliability or win probability).
- Independent overlays and, only for a valid directional setup, Entry/SL/TP1-TP3.

## Qualification rules
- Worker marks a response `VALID` only when both the timeframe/evidence contract and all nine V3 sections validate.
- Missing or malformed V3 sections produce `DEGRADED`; the response cannot contribute to Hybrid votes.
- A truncated response is downgraded to WAIT and execution overlays are removed.
- Directional setup requires a valid OB OR FVG OR directionally relevant swing/equal-level retest, plus coherent execution prices.
- Historical envelope and reference-price checks remain mandatory.
- At least two qualified providers must agree before the aggregate decision can be BUY or SELL.

## Limitations
V3 is an OHLCV-only report unless additional feeds are actually supplied. It cannot truthfully report order-book imbalance, funding, open interest, liquidation clusters, news or exchange delta without those inputs. Model confidence is not a calibrated probability. A real performance ranking requires identical snapshots and forward-labelled outcomes; the current curated list is only a capability/availability shortlist.
