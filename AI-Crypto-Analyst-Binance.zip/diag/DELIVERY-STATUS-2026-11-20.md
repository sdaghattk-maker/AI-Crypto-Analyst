# Delivery status — 2026-11-20

## Implemented in this source package
- OpenRouter defaults to the known free Qwen model slug (account-level availability is checked through the authenticated live catalog) `qwen/qwen3.8-27b:free` and live catalog discovery no longer hides free text models merely because structured-output support is not universal across endpoints.
- OpenRouter retries without optional response_format/reasoning and without `require_parameters` after matching endpoint/parameter routing failures (400/404/422). Full local V3 validation remains mandatory.
- Contract V3 added to Worker schema, all-provider prompt, response normalization, Flutter model parsing and provider analysis cards.
- Nine required analysis sections: regime, structure, liquidity, POI, premium/discount, volume/momentum, scenarios, execution, data quality.
- Missing data must be declared; unsupported feeds are not inferred from OHLCV.
- BUY/SELL execution, POI, history envelope, price anchor, truncation and multi-provider consensus safeguards retained.
- 39/39 Node tests pass across AI Gateway and Binance Proxy; `node --check ai-gateway/worker.js` passes.

## Not verifiable in this environment
- Flutter/Dart SDK is not installed; `flutter analyze`, `flutter test` and APK build were not run.
- No user's OpenRouter/Gemini/Groq secrets are available; no live authenticated API call can be made.
- No Cloudflare deployment or GitHub push was performed.
- Free-model availability and quota depend on the user's OpenRouter account and current serving endpoints.

This is a tested source package, not a claim of live deployment or a verified installable APK. Run the repository's GitHub Actions workflow and a live provider diagnostic before calling it production-verified.
