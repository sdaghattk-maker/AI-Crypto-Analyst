# Targeted provider and V3 corrections — 2026-11-20

## OpenRouter model shortage
- Primary is `openrouter/free`, OpenRouter's documented dynamic free-model router.
- Authenticated catalog now discovers all eligible zero-cost text models with sufficient context, rather than intersecting the live catalog with four hard-coded IDs.
- Flutter appends discovered OpenRouter models after the preferred candidates; it no longer drops them.
- A routing/parameter incompatibility retry removes optional schema/reasoning controls; provider failures can fall through up to four candidate models.

## Groq price inconsistency
- Model prose prices are checked against the live ticker reference with a narrow 2.5% tolerance. A contradictory price such as 83,040 when the supplied reference is around 61,900 is sanitized, confidence is set to zero, execution levels are removed and the provider becomes ineligible for Hybrid.
- Gemini now uses the provider JSON Schema field for the complete V3 output and retries JSON-only mode only when the selected model rejects the schema.
- The default Groq model is `openai/gpt-oss-120b` for its documented strict JSON Schema support; Qwen remains fallback.

## V3 contract
- Buyer/seller strengths are normalized to 100 when the model has a small rounding mismatch.
- Empty findings are explicitly represented as INSUFFICIENT_DATA rather than causing a false schema failure.
- Missing required analysis sections remain invalid; degraded output cannot vote in Hybrid.

## Verification
- `node --check ai-gateway/worker.js`: passed.
- `node --test ai-gateway/tests/worker.test.mjs binance-proxy/tests/worker.test.mjs`: 42 passed, 0 failed.
- Flutter/Dart compile, live authenticated provider calls, Worker deployment and APK build were not possible in this environment and are not claimed as verified.
