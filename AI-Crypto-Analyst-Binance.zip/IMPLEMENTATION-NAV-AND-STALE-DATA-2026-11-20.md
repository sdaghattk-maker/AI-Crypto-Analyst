# Navigation and stale-data behavior — 2026-11-20

## Navigation
- Main navigation now has four destinations: Dashboard, Chart, AI Analysis (shown as «تحلیل هوشمند»), and Smart Connectivity.
- The standalone Market Sources destination was removed from the bottom navigation.
- Dashboard contains a dedicated entry to the combined Market Intelligence + altFINS screen. That screen is created only when the user opens it; its quota/cache/validation lifecycle no longer starts on application launch.
- There was no separate Reports destination in the source. Technical report, provider reports, model comparison, hybrid evaluation, and Smart Settings remain in the AI Analysis page.

## Lazy page initialization and API usage
- AppShell now lazily creates each of the four main pages on first visit and retains it afterward in the IndexedStack.
- On app launch, AnalysisController.restore() restores the local SharedPreferences snapshot only. It does not call market APIs or AI providers.
- Chart polling, AI model-catalog lookup, Smart Connectivity diagnostics, and altFINS page initialization are deferred until the relevant page is first opened.
- Opening/closing the app does not automatically execute Gemini, Groq, or OpenRouter analysis. AI execution remains user initiated from the AI Analysis page.

## Freshness and decision safety
- Technical freshness uses the existing 15-minute window.
- AI freshness uses its own 15-minute window and is also invalidated whenever its underlying technical snapshot is stale.
- Dashboard decision display now shows «تکنیکال نامعتبر», «AI نامعتبر», or both instead of displaying WAIT when required data is missing/stale.
- Cached technical/AI details remain visible as historical context, with explicit invalid labels and timestamps; they cannot produce a current BUY/SELL decision.
- Chart technical/AI overlays are suppressed when their source snapshot is stale. The selected source remains independent; no cross-source fallback was introduced.

## Validation
- Source-level checks performed for navigation destinations, lazy page creation, local-only restore, freshness gates, and chart overlay suppression.
- Flutter/Dart SDK is not installed in this environment; `flutter analyze`, Dart formatting/tests, Android build, and on-device UI verification could not be run.
