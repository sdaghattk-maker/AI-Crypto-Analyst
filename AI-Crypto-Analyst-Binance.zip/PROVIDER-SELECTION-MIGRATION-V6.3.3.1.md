# Provider Selection Migration — V6.3.3.1

## Root cause
The AI Analysis screen builds `selectedProviders` exclusively from persisted Flutter `SharedPreferences` values (`ai_provider_gemini`, `ai_provider_openrouter`, `ai_provider_groq`). The Worker marks any provider omitted from this list as `not_selected`; this status is produced before model selection or inference. Thus `not_selected` is not evidence of an invalid model ID or API key.

## Fix
- Added one-time SharedPreferences migration `ai_provider_selection_migration_v6331`.
- On first launch after this upgrade, enables Gemini, OpenRouter and Groq and persists the selection.
- Future user changes to provider switches remain respected.
- Default provider state is now all three enabled.
- AI Analysis shows the exact provider list that will be sent on the next run.
- Version bumped to `0.1.0+2`.

## Verification
- Full Node test suite: 151 passed, 0 failed.
- Worker syntax check passed.
- Flutter/Dart SDK is not installed in this build environment; `flutter analyze`, `flutter test`, and APK build were not run.
- No Cloudflare deployment or live provider request was performed.
