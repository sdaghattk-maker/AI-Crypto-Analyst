# Exact HTML Mirror — 2026-11-20

## Purpose
The standalone `index.html` is a strict viewer for the app's own exported analysis snapshot. It does not fetch market data, calculate indicators, normalize provider responses, or derive consensus.

## Changes
- Added `AnalysisController.buildExactExportSnapshot()` to export the exact in-memory `TechnicalReport.toJson()` and `AiConsensus.toJson()` objects used by Flutter.
- Included the same per-provider HybridEngine evaluations and final decision logic used by `DashboardScreen`.
- Included cached altFINS 1H/15M payloads, altFINS quota status, and explicit unsupported 5M status.
- Included snapshot identity, reference price, timestamps, stale flags, history counts and the exact candle history used by the app.
- Added a Dashboard action to share the JSON export.
- Replaced the previous independently calculating HTML dashboard with a strict JSON viewer. Every field present in the app export is recursively shown; no source value is recomputed or silently replaced.

## Exactness boundary
The HTML can only display the latest app state that was exported. It cannot silently read Flutter's private in-memory state from a separate browser tab. To update it, export a new JSON file from the app and import it into `index.html`. This is intentional: it preserves one source of truth and avoids divergent calculations.

## Validation
- HTML JavaScript syntax checked with Node.
- JSON schema gate requires `ai_crypto_analyst_exact_snapshot_v1`.
- Flutter/Dart SDK is not available in this environment; `flutter analyze`, `flutter test` and APK build remain unverified.
- No GitHub push, Worker deployment or live API test was performed.
- Centralized the dashboard's final hybrid decision in `HybridEngine.evaluateDashboard()`; both the visible Flutter dashboard and JSON exporter now call the same method, eliminating duplicated final-decision logic.
