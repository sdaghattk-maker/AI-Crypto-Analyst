# Groq normalization and AI price-plan validation repair — 2026-11-21

## Scope
Follow-up to V3 Data Normalizer repair. This change is limited to local source and tests; it does not deploy Cloudflare Workers, push GitHub, or build an APK.

## Groq nested response coverage
- Added a regression fixture matching a deeply wrapped Groq completion where the message content is JSON, the payload contains `data.result`, and `result` is itself a JSON string.
- Verified extraction of the complete 1H/15M/5M timeframe map, provider-declared buyer/seller percentages, all nine analysis sections, and preservation of the original raw HTTP response.
- Retained the existing fail-closed rule: separate timeframe branches are never stitched into a synthetic complete timeframe contract.

## Price and execution validation
Every directional provider plan is checked independently against the same submitted market snapshot:
- A valid live `referencePrice` and decoded 5M ATR are required for a directional execution plan.
- Entry must be within 1.5 ATR (or 1.5% of reference price, whichever is larger) of the live reference price.
- BUY entries cannot be materially above the live reference; SELL entries cannot be materially below it.
- Stop distance must be between 0.15 and 4 ATR.
- TP1/TP2/TP3 distances from Entry are capped at 5/8/12 ATR respectively, in addition to existing historical and volatility envelopes and minimum R-multiple checks.
- Entry must be within 1.5 ATR of an active candle-validated POI, and SL must be beyond the POI invalidation boundary with a 0.05 ATR buffer.
- Any failed check removes execution overlays and downgrades the provider direction to WAIT. No Technical Engine or peer-model price is used to repair a provider's plan.
- Structured `executionPriceValidation` status, ATR, anchor, distances and rejection reasons are returned to Flutter and shown in the model's validation panel.

## Regression coverage
- Added a positive Groq deeply nested JSON-string test for all three timeframes.
- Added rejection tests for stale but historically plausible Entry prices and an SL placed inside the only candle-validated POI.
- Updated BUY fixtures so the stop is beyond the validated OB and target distances meet the required R multiples.
- Existing split-branch, wrong-price narrative, invalid target, POI, evidence, and consensus tests remain in place.

## Verification boundary
- Node Worker tests and source mirror tests are run locally; results are recorded in the delivery README.
- Flutter/Dart tests are included but cannot be executed unless the Flutter/Dart SDK is available.
- No live provider requests, Worker deployment, GitHub push, or APK build is claimed.
