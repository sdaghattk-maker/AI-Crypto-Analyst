# AI Crypto Analyst — Curated Model Ranking

## Decision
The model picker and Worker now expose only a small, code-owned shortlist. Newly discovered catalog entries are not automatically selectable. The Worker independently rejects model IDs outside this shortlist.

## Provisional quality order
This is a capability-based starting order, not a claim of proven trading profitability. No model receives a win-rate or trading-accuracy guarantee.

1. **Gemini 3.8 Flash** — primary reasoning model. Google reports 61.4% on Vals Finance Agent v2 versus 59.0% for Gemini 3.7 Flash; its model card also reports gains on several multi-step reasoning/agent benchmarks.
2. **Qwen 3.8 27B** — strong secondary model. Its model card reports improvements over Qwen 3.6 27B on agentic and instruction-following tasks; these are largely vendor-reported and are not crypto-trading backtests.
3. **GPT-OSS 120B** — high-capacity fallback where available. OpenAI publishes stronger general reasoning results for 120B than 20B on several benchmarks; this is not evidence of better trading signals.
4. **Gemini 3.7 Flash** — Gemini fallback behind 3.8 Flash based on the published Finance Agent v2 and other benchmark comparisons.

## Provider picker policy
- Gemini: `gemini-3.8-flash` (primary), `gemini-3.7-flash` (fallback).
- OpenRouter: `qwen/qwen3.8-27b` only. The old free router and unverified/low-confidence catalog choices are hidden.
- Groq: `qwen/qwen3.8-27b` (primary), `openai/gpt-oss-120b` (fallback).
- Groq remains disabled by default as in the prior app settings; enabling it remains a user choice.

## Enforcement
- The UI intersects the live provider catalog with the curated ordered list.
- The Worker returns only curated IDs, preserving their order.
- The Worker rejects any model ID outside its own shortlist, even if a provider newly lists it.
- A provider's live catalog is used to verify availability, not to rank or auto-approve models.
- On temporary catalog failure, the code-owned shortlist remains the fallback; old Cloudflare `*_MODELS` variables cannot reintroduce removed models.

## What is deliberately not claimed
Public reasoning/finance-agent benchmarks are not a substitute for a same-snapshot crypto test. Final trading-specific ranks must be recalculated from at least 30–50 completed, identical market snapshots per model, scoring direction, Entry/SL/TP validity, zone accuracy, response validity, latency, and realized forward outcome. Model self-reported confidence is not used as a reliability score.

## Sources reviewed
- Google DeepMind Gemini 3.8 Flash model card (includes Vals Finance Agent v2 and Gemini 3.7 comparison): https://deepmind.google/models/model-cards/gemini-3-8-flash/
- Google Cloud Gemini 3.8 Flash model guide and model IDs: https://docs.cloud.google.com/gemini-enterprise-agent-platform/models/guides/gemini-3-8-flash
- Qwen3.8-27B model card: https://huggingface.co/Qwen/Qwen3.8-27B
- Groq supported model list (Qwen3.8-27B and GPT-OSS 120B availability): https://console.groq.com/docs/models
- OpenAI GPT-OSS published evaluations: https://openai.com/open-models/
