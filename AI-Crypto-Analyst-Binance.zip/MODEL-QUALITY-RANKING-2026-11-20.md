# Model selection and evidence policy — 2026-11-20

## What this list means
The Worker and UI model order is a **capability and live-availability shortlist**, not a proven BTC/ETH trading-accuracy ranking. General AI benchmarks, model vendor claims, and self-reported confidence are not evidence of profitable 5m/15m/1h crypto decisions.

## OpenRouter default
- Default selection: `openrouter/free`, OpenRouter’s free-model router, which dynamically chooses an available free endpoint compatible with the request. A direct free Qwen model remains the first named fallback.
- The live `/models` catalog now returns all eligible free text models with at least 16K context, not only a short hard-coded list. The Flutter settings screen preserves curated priority and appends newly discovered eligible models instead of hiding them.
- Free models can still be rate-limited. The Worker automatically falls through up to four candidates; a 429/empty provider response does not block trying the next model.
- JSON Schema support is endpoint-specific. The Worker first attempts strict structured output; on a compatible 400/404/422 routing/parameter error it retries without schema/reasoning restrictions and still validates the complete V3 contract locally.
- No paid model is silently chosen as the default. OpenRouter catalog discovery filters for zero-cost text models and does not add paid models to the free fallback list.
- Free model availability, rate limits, context, output caps and provider health can change. A free model can still fail due to account limits or provider availability.

## Gemini structured-output enforcement
- Gemini requests the complete V3 JSON Schema using `responseJsonSchema`; only models that explicitly reject the schema are retried in JSON mode, followed by the same strict local contract validation.

## Groq structured-output default
- Default selection: `openai/gpt-oss-120b`, a Groq model documented as supporting strict JSON Schema. `qwen/qwen3.8-27b` remains the fallback. This is a schema/capability choice, not a claim of higher trading accuracy.

## Evidence-based future ranking
For each model, retain identical timestamped snapshots and measure forward outcomes on a chronological holdout. Initial publication threshold: at least 50 completed independent observations per model; report sample size and confidence intervals. Track direction accuracy, calibration, MAE of projected levels, invalidation hit rate, target reach sequence, expectancy after fees/slippage, latency, truncation, schema validity and cost. Do not combine overlapping snapshots as independent samples. Do not rank models with fewer than the minimum observations.

## Safety
No provider's self-declared confidence is treated as win probability. Hybrid weights remain equal until a separate, out-of-sample calibration dataset justifies changes. A single model cannot issue aggregate BUY/SELL.
