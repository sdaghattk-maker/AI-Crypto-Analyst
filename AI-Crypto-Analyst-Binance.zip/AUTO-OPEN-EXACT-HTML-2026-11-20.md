# Automatic Exact HTML Mirror — 2026-11-20

## User flow
- The dashboard action is now **نمایش زنده و دقیق در Index HTML**.
- One tap builds the exact immutable snapshot from the app's current in-memory state and opens the bundled HTML mirror inside the app's WebView.
- Flutter injects the same JSON object directly into `window.loadSnapshotFromApp(...)` after the HTML asset finishes loading.
- No share sheet, manual file save, file picker, or second browser launch is required.
- The HTML remains independently usable: the manual JSON import remains available when opened outside the app.

## Data integrity
- The HTML still only renders the exact snapshot object; it does not recalculate technical indicators, AI decisions, hybrid votes, or altFINS values.
- The payload is built by `AnalysisController.buildExactExportSnapshot()` and the hybrid summary uses the same `HybridEngine.evaluateDashboard()` implementation as the app dashboard.
- The snapshot ID is visible for provenance. The displayed values are the snapshot captured when the button is tapped; later market updates require reopening the view from the dashboard.

## Files changed
- `lib/screens/dashboard.dart`
- `lib/screens/exact_snapshot_screen.dart` (new)
- `assets/index.html` (bundled HTML mirror)
- `index.html` (standalone copy)
- `pubspec.yaml`

## Verification boundary
- HTML JavaScript syntax and archive integrity checked.
- Flutter/Dart SDK unavailable in this environment; Flutter analyze and Android build were not run.
- Must verify the in-app WebView flow on Android after GitHub Actions builds the APK.
