AI CRYPTO ANALYST — TIMEFRAME NARRATIVE NORMALIZER FIX
Date: 2026-11-20

Root cause:
Provider findings could explicitly describe 1H / 15M / 5M structure in Persian or English prose, while the dashboard only rendered timeframeAnalysis maps. The previous normalizer only discovered structured timeframe objects and therefore incorrectly reported that no timeframe breakdown was provided.

Changes:
- Gateway now extracts explicit timeframe-labelled narrative from provider summary/analysis/observations and the structure section findings.
- Supports common Persian and English timeframe labels and direction/regime terms.
- Populates only fields explicitly supported by the corresponding timeframe text.
- Missing structure events, liquidity, buyer/seller strength, or evidence remain UNKNOWN/missing; they are not fabricated.
- Incomplete narrative extraction remains NORMALIZED/partial and cannot pass V3 validity or contribute to AI consensus.
- Dashboard now displays extracted partial timeframe findings and clearly labels them as non-consensus until the full contract is valid.
- Technical Engine data is not copied into provider results.

Validation:
- node --check ai-gateway/worker.js passed.
- node --test ai-gateway/tests/worker.test.mjs: 47 tests passed.
- Flutter analyze/build and live provider runtime tests were not run in this environment.
