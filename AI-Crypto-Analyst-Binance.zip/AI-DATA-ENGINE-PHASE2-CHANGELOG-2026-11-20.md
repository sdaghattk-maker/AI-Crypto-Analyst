# AI Data Engine — Phase 2

## Changes
- Removed forced `responseMimeType: application/json` from Gemini requests.
- Removed Groq strict JSON Schema enforcement. Gemini, Groq and OpenRouter may now return provider-native JSON or prose; parsing and validation happen locally.
- Added generic recursive fact extraction for provider-native nested JSON, including previously unknown model-specific fields.
- Added category normalization for market regime, market structure, liquidity, POIs, momentum/volume, scenarios, trade plans, risk/invalidation, fundamentals/sentiment and data quality.
- Added conservative section extraction for explicitly titled plain-text responses. Unlabeled prose remains available in the original raw response rather than being guessed into categories.
- Exposed `dataCategories` and `extractedFacts` in the Flutter result model and added category panels to the per-provider analysis UI.
- Kept raw provider response available, kept unknown fields in `extractedFacts`, and did not infer missing trade levels.
- Expanded provider response tests for native JSON, unfamiliar keys and titled prose.

## Validation
- `node --check ai-gateway/worker.js`: passed.
- `node --test ai-gateway/tests/worker.test.mjs binance-proxy/tests/worker.test.mjs`: 44 passed, 0 failed.
- ZIP integrity: verified after packaging.

## Not performed
- Flutter/Dart analyze, Android build, live Gemini/Groq/OpenRouter requests, or Cloudflare deployment. These require Flutter tooling and live provider credentials/deployment access.


## Follow-up fixes from 20 Nov 2026 screenshots

- Timeframe normalization now accepts provider casing/alias variations and preserves each valid field independently. Missing buyer/seller strength no longer blanks the timeframe's trend, structure, phase or liquidity; it still keeps the V3 contract out of full-valid status.
- Shared prompt now explicitly requires independent 1h/15m/5m OHLCV classification, buyer/seller candle-strength estimates, and a Persian evidence note per timeframe. `UNKNOWN` is reserved for fields/timeframes that genuinely cannot be assessed.
- V3 status is displayed as three distinct states: fully valid, normalized/visible but not Hybrid-qualified, and incomplete. No incomplete answer is promoted to a valid Hybrid vote.
- Nine comprehensive analysis sections are grouped into five visible cards. Supplementary extracted data is grouped into five deduplicated categories and collapsed by default.
- All paste-ready Worker text copies are byte-identical to `ai-gateway/worker.js`.
- Regression coverage added for timeframe alias/case normalization and field-level preservation.

## Verification

- `node --check ai-gateway/worker.js`: passed.
- `node --test ai-gateway/tests/worker.test.mjs`: 43/43 passed.
- `node --test test/chart_analyzer_export.test.mjs`: 3/3 passed.
- Flutter/Dart SDK is not installed in this environment; Flutter analyze/build and on-device visual verification were not run.

## Screenshot-driven follow-up — 20 Nov 2026

- Fixed supplementary extraction so the additional-data panel no longer duplicates the canonical V3 market regime, structure, liquidity, POI, momentum, scenario, trade-plan or risk sections.
- Supplementary categories now represent only explicitly identified external/provider feeds: order book/depth, derivatives (funding/OI), liquidations, on-chain/exchange flows, news/sentiment and provider-specific metrics.
- Numeric values are retained only when they belong to a recognized supplementary-feed field; generic scores, percentages and status labels are not presented as market data.
- UI copy now explains that supplementary facts are provider claims unless their source feed is actually connected, and displays the originating response path for traceability.
- Timeframe cards distinguish a missing timeframe object from an explicit UNKNOWN value. Missing data is no longer shown as if the model had assessed the market and found it unknown.
- Market structure now carries a separate `structureEvent` field (BOS/CHOCH/MSS with direction, NONE or UNKNOWN), in addition to directional structure state. Provider normalization accepts common case/key/value aliases and preserves each timeframe independently.
- Prompt definitions now distinguish BOS, CHOCH and MSS using closed candles and protected swings; wick-only liquidity sweeps cannot be labeled as a structure break. 1h context, 15m setup and 5m execution conflicts must be stated explicitly.
- Added regression tests for BOS/CHOCH normalization, omitted timeframe handling, supplementary category de-duplication and numeric external-feed values.

## Verification

- `node --check ai-gateway/worker.js`: passed.
- `node --test ai-gateway/tests/worker.test.mjs binance-proxy/tests/worker.test.mjs`: 47/47 passed.
- Flutter/Dart SDK remains unavailable in this environment; Flutter analyze/build and on-device UI verification are not claimed.
- Renamed the ambiguous OHLCV delta reconstruction seed from `basePrice` to `historyStartPrice`. It is the first candle's open, not the live market price; its value naturally differs across timeframes with different history start times. Legacy `basePrice` inputs remain accepted but are normalized before being shown to models.
- Provider prompts now explicitly prohibit comparing historyStartPrice across timeframes or against the live reference. Current-price consistency is evaluated using `referencePrice` versus `lastClosed5mClose` only.
- Added regression coverage for legacy and renamed history seeds, including a deliberately different history-start price with a consistent live reference/latest 5m close.
- Final regression counts after the historyStartPrice correction: AI Gateway + Binance Proxy 48/48; Chart Analyzer export/UI checks 3/3.
