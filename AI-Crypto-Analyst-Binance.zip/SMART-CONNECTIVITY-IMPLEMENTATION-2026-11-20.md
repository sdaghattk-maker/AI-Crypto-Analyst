# Smart Connectivity — implementation notes (2026-11-20)

## Implemented in this package
- A Smart Connectivity status card in AI Analysis, checked on screen entry and manually refreshable.
- Gateway reachability check via `/health`.
- Provider catalog/upstream reachability check via `/models` for Gemini, Groq and OpenRouter.
- altFINS quota/availability check via the existing Gateway endpoint; zero AI Trade Setup quota is shown as a plan limitation, not network failure.
- Failure classification distinguishes explicit auth/access/region messages, quota/rate limits, and transport/gateway failures. Generic network failure is not falsely labelled as ISP blocking.
- Existing routing is preserved: AI providers and altFINS through AI Gateway; Chart Analyzer via official direct WebView; Binance via its independent Binance Proxy.
- No provider keys, Gateway token, VPN credentials, or proxy secrets are embedded in the APK.
- No automatic direct-provider fallback is attempted. The app cannot safely call provider APIs directly without exposing provider credentials. Regional policy restrictions are not bypassed.

## Important scope boundary
This is a safe connectivity monitor and centralized routing policy, not a VPN and not a universal network tunnel. `/models` validates provider API reachability through the Worker and may fall back to the Worker's configured model list; such a fallback is reported as degraded/unknown rather than as a successful upstream check. Chart Analyzer and Binance are reported with their routing ownership; their live availability is not asserted by this diagnostic panel.

## Deployment
1. Deploy `ai-gateway/worker.js` to the existing AI Gateway Worker.
2. Keep `GEMINI_API_KEY`, `GROQ_API_KEY`, `OPENROUTER_API_KEY`, and `ALTFINS_API_KEY` as Cloudflare Worker Secrets.
3. Keep `AI_GATEWAY_BASE_URL` as the build-time GitHub Actions secret/variable as already configured.
4. Build and install the APK. Open AI Analysis; Smart Connectivity checks automatically. Use refresh for a fresh report.

## Validation limitation
This environment does not have Flutter or Dart SDK, so `flutter analyze`, Dart tests, Android Gradle build, and device runtime checks were not executed here. Node Worker tests are run separately and do not substitute for Flutter validation.
