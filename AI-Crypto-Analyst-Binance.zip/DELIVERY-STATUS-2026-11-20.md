# Delivery status — 2026-11-20

## Implemented in this source package
- OpenRouter defaults to the documented `openrouter/free` dynamic free-model router; direct free Qwen remains the fallback. Authenticated catalog discovery now returns eligible zero-cost text models beyond the short curated list, and Flutter no longer filters those discovered candidates out.
- OpenRouter retries without optional response_format/reasoning after matching endpoint/parameter routing failures (400/404/422), and automatically falls through the free candidate list after rate-limit/empty-response failures. Full local V3 validation remains mandatory.
- Gemini now requests the complete V3 JSON Schema through `responseJsonSchema`, with a bounded JSON-mode fallback only when a model explicitly rejects the schema.
- Groq defaults to `openai/gpt-oss-120b` for documented strict JSON Schema support, with Qwen retained as fallback.
- Groq/OpenRouter narrative prices are checked against the live reference anchor (±2.5%), not merely the broad historical envelope; contradictory market prices are sanitized and the provider is downgraded to WAIT/DEGRADED.
- V3 normalization tolerates harmless buyer/seller percentage rounding drift and safely represents empty findings as INSUFFICIENT_DATA while still rejecting missing sections.
- Contract V3 added to Worker schema, all-provider prompt, response normalization, Flutter model parsing and provider analysis cards.
- Nine required analysis sections: regime, structure, liquidity, POI, premium/discount, volume/momentum, scenarios, execution, data quality.
- Missing data must be declared; unsupported feeds are not inferred from OHLCV.
- BUY/SELL execution, POI, history envelope, price anchor, truncation and multi-provider consensus safeguards retained.
- 42/42 Node tests pass across AI Gateway and Binance Proxy; `node --check ai-gateway/worker.js` passes.

## Not verifiable in this environment
- Flutter/Dart SDK is not installed; `flutter analyze`, `flutter test` and APK build were not run.
- No user's OpenRouter/Gemini/Groq secrets are available; no live authenticated API call can be made.
- No Cloudflare deployment or GitHub push was performed.
- Flutter/Dart UI changes (dynamic OpenRouter list and connectivity source parsing) are source-reviewed but not compiled here.
- Free-model availability and quota depend on the user's OpenRouter account and current serving endpoints.

This is a tested source package, not a claim of live deployment or a verified installable APK. Run the repository's GitHub Actions workflow and a live provider diagnostic before calling it production-verified.
