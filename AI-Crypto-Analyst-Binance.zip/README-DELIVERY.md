# AI Crypto Analyst — Source Package

This package contains the screenshot-driven Market Structure, price-anchor labeling and supplementary-data corrections on top of the latest Phase 8 source baseline.

## Included corrections
- Supplementary data no longer repeats core V3 analysis or turns generic numbers/statuses into market facts.
- Only explicitly identified external/provider data families are shown in the supplementary panel, with response-path provenance and an unverified-claim notice.
- Missing timeframe fields are displayed as not provided, not as an AI finding of UNKNOWN.
- BOS/CHOCH/MSS events are separately represented from directional structure state, with closed-candle and protected-swing rules in the provider prompt.
- The ambiguous OHLCV reconstruction seed is now `historyStartPrice` (first candle open), not `basePrice`; legacy inputs are normalized. The AI is told not to compare it with live price or across timeframes.
- Current-price consistency remains based on `referencePrice` versus `lastClosed5mClose`.
- Existing independent-provider, POI, execution-level, historical-envelope and multi-provider consensus safeguards are preserved.

## Validation
- AI Gateway Worker syntax check: passed.
- AI Gateway + Binance Proxy automated tests: 48 passed, 0 failed.
- Flutter/Dart SDK is not available in the build environment. Flutter analyze, Android compilation, APK creation, live provider calls and Cloudflare deployment are not claimed as verified.

Read `DELIVERY-STATUS-2026-11-20.txt` for the full verification boundary before deployment.
