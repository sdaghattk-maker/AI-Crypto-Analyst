# AI Crypto Analyst — Current Source Package

This package is based on the verified V4 archive `AI-Crypto-Analyst-GROQ-PRICE-VALIDATION-REPAIR-FINAL-2026-11-21-V4.zip` (SHA256 `f059ee9d3ede5215cc70476537f7293090b1918e237c88156f6096132cf6dd5a`) and includes the timeframe narrative recovery repair described in `AI-TIMEFRAME-NARRATIVE-RECOVERY-REPAIR-2026-11-21.md`.

## Current source of truth
- Flutter app: `lib/`
- AI Gateway Worker: `ai-gateway/worker.js`
- Binance Proxy Worker: `binance-proxy/worker.js`
- The generic and legacy-named Gateway text snapshots are synchronized with `ai-gateway/worker.js`.
- `index.html` and `assets/index.html` are byte-identical.

## Main corrections in this package
- Compact quantized OHLCV history validation with explicit precision metadata and timestamp/interval alignment checks.
- Model response normalization with raw response retention, explicit truncation metadata, full normalization diagnostics, and confidence range validation. Full provider narrative is parsed for explicit per-timeframe trend declarations when structured timeframe fields are missing.
- Candle-backed validation for BOS/CHOCH/MSS, liquidity sweeps, OB/FVG and execution levels. Directional Entry/SL/TP plans are additionally checked against live reference price, 5m ATR, POI proximity, and the POI invalidation boundary; failed checks downgrade to WAIT and expose structured diagnostics in Flutter.
- Cross-timeframe semantic checks: directional AI plans must agree with 5m trend or a validated 5m reversal; fully opposing 1h/15m structure requires a validated higher-timeframe reversal.
- Independent Gemini/OpenRouter/Groq responses and a minimum two-model consensus.
- Consensus overlays require corroboration across eligible agreeing providers; partial retries cannot union single-model levels into the aggregate layer.
- Final Decision treats AI only as confirmation: Technical BUY/SELL and a matching two-model AI consensus are both required; otherwise WAIT.
- altFINS comparisons are timeframe-matched (15m with 15m, 1h with 1h), freshness-aware, and auxiliary only.
- AI-declared buyer/seller percentages are distinguished from the Technical Engine's independently calculated OHLCV estimate. Missing/invalid OHLCV strength is isolated to that sub-section and does not invalidate otherwise complete timeframe structure.
- Route-scoped rate limiting protects model catalog, altFINS quota/validation/diagnostics, authenticated provider connectivity tests, and analysis without sharing the same per-IP bucket.

## Validation
- JavaScript syntax checks: passed.
- Automated Node regression suite: **103 passed, 0 failed, 0 skipped, 0 todo**.
- HTML mirrors and Worker text snapshots: synchronized.
- Flutter/Dart SDK is not installed in this environment. Included Dart tests and Flutter source changes still require `dart format`, `flutter analyze`, Flutter tests, and Android build verification in Flutter CI or on a development machine.
- No live Gemini/OpenRouter/Groq or altFINS requests were made.
- No Cloudflare Worker deployment, GitHub push, or APK build was performed.

See `AI-POST-DATA-ENGINE-PIPELINE-AUDIT-2026-11-21.md` for the detailed stage-by-stage findings and verification boundary, and `AI-DATA-ENGINE-QUALITY-REPAIR-2026-11-21.md` for the original Data Engine repair.


Follow-up audit note (2026-11-21): Dashboard/Hybrid provider eligibility is unified; persisted factor maps are validated before voting; aggregate overlays require corroboration from any two agreeing providers; partial retries cannot mix identified Snapshot IDs or discard a previous successful answer on transport failure. Added Dart regression tests cover these cases, and mocked altFINS tests verify source timestamp freshness. The latest local Node suite passes 98 tests, including nested Groq extraction, live-price/ATR/POI execution validation, raw-text truncation, quantized-history bounds, and exact Worker/HTML mirror checks. Dart tests still require Flutter CI because the local environment has no Flutter/Dart SDK.


Follow-up repair (2026-11-21): Added a deeply nested Groq JSON-string regression test covering 1H/15M/5M, buyer/seller percentages, analysis sections, and raw response retention. Added stricter provider-local Entry/SL/TP validation against the live reference, 5m ATR, and active candle-validated POI. Flutter now carries and displays the execution-price validation report. See `AI-GROQ-PRICE-VALIDATION-REPAIR-2026-11-21.md`.


Follow-up repair (2026-11-21): Fixed loss of 1H/15M/5M trend information between the model's complete Persian/English response, timeframe normalization, and dashboard. Each timeframe now displays independently when available; narrative-only trends are visibly marked and are excluded from verified AI consensus until structured candle evidence passes. Tests cover long text beyond the 420-character summary, structured-plus-narrative partial results, all three providers, and protection against stitching separate Groq branches. Current local Node suite: 103 passed. Flutter/Dart tests, live provider calls, deployment, GitHub push, and APK build were not performed.
