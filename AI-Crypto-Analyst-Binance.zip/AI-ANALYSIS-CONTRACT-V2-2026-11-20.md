# Legacy V2 contract retired

The V2 response contract is retired and is not eligible for Hybrid decisions. Use `AI-ANALYSIS-CONTRACT-V3-2026-11-20.md` as the current required contract.
