# AI Data Engine validation and Index readability fix — 2026-11-21

## Scope

This update is based on `AI-Crypto-Analyst-INDEX-AI-DATA-ENGINE-READABLE-2026-11-20.zip`.
It changes AI-provider normalization, preserves confidence provenance through Flutter serialization, and updates both HTML entry points. It intentionally does not change Technical Engine signal-generation rules.

## Correctness changes

- Timeframe normalization now selects one coherent timeframe map (most complete, then shallowest) instead of merging 1H/15M/5M fields found in unrelated nested branches. Missing timeframes remain missing and make the contract ineligible for consensus. The selected JSON path and competing candidate paths are preserved as `timeframeProvenance`; equally ranked conflicting roots are flagged and cannot qualify the contract.
- Directional BOS / CHOCH / MSS values require an explicit direction attached to the event. An ambiguous MSS/CHOCH remains `UNKNOWN`; it is never silently converted to bullish.
- Final Worker validation now independently rechecks the complete Entry/SL/TP plan, 5m/directional metadata, ordering, and minimum TP1/TP2/TP3 risk multiples (1R/1.5R/2R). A plan that fails any of these checks is downgraded to WAIT and its execution overlays are removed.
- Buyer and seller values are preserved as reported. They are marked comparable complementary percentages only when both are valid 0–100 values and their total is within a small rounding tolerance of 100. Independent scores such as 70/60 remain 70/60, are marked `UNVERIFIED_INDEPENDENT_SCORES`, and cannot qualify the timeframe contract.
- Missing or invalid confidence is now `null` with `confidenceDeclared:false`; no synthetic 50% value is generated. Generic `score` fields are not mistaken for confidence. This provenance is carried through `AiModelResult`, exact snapshot export, and the app UI. Missing or sub-55% confidence is not an eligible directional vote in either AI consensus or the final Hybrid provider set.
- Deserialized provider records without an explicit status default to `unknown`, not `ok`, so malformed legacy records cannot be treated as successful providers.

## Index presentation changes

- Replaced the six-column cross-source table with independent source panels for Technical, Gemini, OpenRouter, Groq, and altFINS. The sources do not share identical schemas, so the UI no longer places semantically unrelated fields in the same row.
- Each provider panel retains its own normalized sections, timeframe data, risks, and raw model response. Technical and altFINS remain independent and are not used to fill missing AI fields.
- Contract statuses are shown distinctly (`VALID`, `NORMALIZED`, `PARTIAL`, `DEGRADED`, `INVALID`, or unknown) instead of collapsing all non-VALID states into one label.
- AI freshness is based on whether a provider actually returned a response and the app's stale flag, not merely whether an `ai` object exists.
- Mobile uses one-column source panels; no forced 650–720px minimum-width table or horizontal table scrolling remains.
- `index.html` and `assets/index.html` are kept byte-identical. Both app WebView and manual JSON import use the same rendering path.

## Regression coverage

Added Worker tests for ambiguous MSS, independent buyer/seller scores, missing confidence, and split timeframe branches. Updated existing assertions to verify source values are preserved rather than silently normalized.

## Validation performed

- `node --check ai-gateway/worker.js` — passed.
- `node --check index-script.js` — passed.
- Inline JavaScript extracted from `index.html` — syntax check passed.
- `index.html` and `assets/index.html` — byte-identical.
- `node --test ai-gateway/tests/worker.test.mjs binance-proxy/tests/worker.test.mjs test/chart_analyzer_export.test.mjs` — 60 tests passed.
- Added Flutter unit tests for confidence provenance and Hybrid vote eligibility; these could not be executed because Flutter/Dart SDK is unavailable.

## Not performed

- Flutter/Dart analyzer, Flutter build, and Android device/WebView test were not run because Flutter/Dart SDK is not available in this environment.
- Cloudflare Worker was not deployed. Live provider calls, VPN/network behavior, and production snapshot round-trip remain unverified.
