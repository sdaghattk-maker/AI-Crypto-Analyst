# Dashboard: Four Independent Buyer/Seller Strength Cards

## Change
Added a compact 2x2 strength panel to the existing dashboard, immediately after the four-source / three-timeframe market-structure matrix.

## Source mapping
- Technical: `TechnicalReport.buyerPower` and `TechnicalReport.sellerPower` from the deterministic technical engine.
- Gemini: `timeframeAnalysis.5m.buyerStrength` and `sellerStrength` from Gemini's own normalized provider response.
- OpenRouter: the same 5m fields from OpenRouter's own normalized response.
- Groq: the same 5m fields from Groq's own normalized response.

## Integrity rules
- AI sources are never averaged or substituted for one another.
- The displayed AI values are the model's normalized 5m buyer/seller strength fields; the dashboard does not derive a missing value from trend, confidence, or another provider.
- The pair is shown only when both values are numeric, within 0..100, and sum to 100.
- Missing, stale, or unavailable data is shown as unavailable, not as a fabricated 50/50 split.
- A provider whose 5m strength exists but whose complete analysis contract is partial is explicitly marked as partial.
- The section is labeled 5M because that is the app's execution timeframe.

## Validation
- Cloudflare Worker syntax check: passed.
- Gateway test suite: 48 passed.
- Binance proxy test suite: see package validation run.
- Flutter/Dart analyze and Android build were not run because Flutter/Dart SDK is not installed in the editing environment.
