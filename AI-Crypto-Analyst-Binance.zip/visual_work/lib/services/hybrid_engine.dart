import 'ai_service.dart';
import 'technical_engine.dart';

class HybridDecision {
  const HybridDecision({required this.provider, required this.decision, required this.score,
    required this.technicalScore, required this.aiScore, required this.technicalWeights,
    required this.aiWeights, required this.reasons, required this.calibration});
  final String provider, decision;
  final double score, technicalScore, aiScore;
  final Map<String,int> technicalWeights, aiWeights;
  final List<String> reasons;
  final String calibration;
}

class HybridEngine {
  static const keys = ['trend','marketStructure','liquidity','entryConfirmation','riskReward'];
  static const labels = {'trend':'روند','marketStructure':'ساختار بازار','liquidity':'نقدینگی','entryConfirmation':'تأیید ورود','riskReward':'ریسک به بازده'};

  Map<String,int> _normalize(Map<String,int> source) {
    final vals = keys.map((k) => (source[k] ?? 0).clamp(0,100).toInt()).toList();
    final sum = vals.fold<int>(0,(a,b)=>a+b);
    if (sum == 0) return {for(final k in keys) k:20};
    final out = <String,int>{};
    for(var i=0;i<keys.length;i++) { out[keys[i]] = (vals[i]*100/sum).round(); }
    final drift = 100-out.values.fold<int>(0,(a,b)=>a+b);
    out[keys.first] = (out[keys.first]!+drift).clamp(0,100).toInt();
    return out;
  }

  Map<String,int> _technicalWeights(TechnicalReport r) {
    final aligned = (r.bias1h == r.bias15m ? 25 : 10) + (r.bias15m == r.bias5m ? 20 : 8);
    final structure = (r.poiSummary.isNotEmpty ? 25 : 12) + (r.reasons.any((x)=>x.toLowerCase().contains('mss') || x.contains('ساختار')) ? 10 : 5);
    final liquidity = r.reasons.any((x)=>x.contains('نقدینگی') || x.toLowerCase().contains('sweep')) ? 65 : 35;
    final entry = r.state == SignalState.wait ? 20 : (r.score * .75).round().clamp(0,75).toInt();
    final rr = r.entry!=null && r.stopLoss!=null && r.tp1!=null ? 70 : 15;
    return _normalize({'trend':aligned,'marketStructure':structure,'liquidity':liquidity,'entryConfirmation':entry,'riskReward':rr});
  }

  Map<String,int> _technicalScores(TechnicalReport r) => {
    'trend': ((r.bias1h==r.bias15m?75:45)+(r.bias15m==r.bias5m?25:0)).clamp(0,100).toInt(),
    'marketStructure': r.poiSummary.isNotEmpty ? 75 : 35,
    'liquidity': r.reasons.any((x)=>x.contains('نقدینگی')||x.toLowerCase().contains('sweep')) ? 80 : 35,
    'entryConfirmation': r.state==SignalState.wait ? 25 : r.score.clamp(0,100).toInt(),
    'riskReward': r.entry!=null&&r.stopLoss!=null&&r.tp1!=null ? 75 : 20,
  };

  double _weighted(Map<String,int> weights, Map<String,int> scores) =>
    keys.fold<double>(0,(sum,k)=>sum+(weights[k]??0)*(scores[k]??0)/10000)*100;

  HybridDecision evaluate(TechnicalReport technical, AiModelResult ai) {
    final tw = _technicalWeights(technical);
    final aw = _normalize(ai.analyticalWeights);
    final ts = _weighted(tw,_technicalScores(technical));
    final ascore = _weighted(aw,ai.factorScores);
    final tDir = technical.state==SignalState.buy?1:technical.state==SignalState.sell?-1:0;
    final aDir = ai.bias=='BUY'?1:ai.bias=='SELL'?-1:0;
    final tStrength = ts*(technical.score.clamp(0,100)/100);
    final aStrength = ascore*(ai.confidence.clamp(0,100)/100);
    // Until sufficient out-of-sample records exist, engine-level reliability is neutral (50/50).
    final combined = (tDir*tStrength*0.5)+(aDir*aStrength*0.5);
    final conflict = tDir!=0 && aDir!=0 && tDir!=aDir;
    var decision = 'WAIT';
    if (ai.weightsProvided && !conflict && combined.abs()>=18 && combined!=0) decision = combined>0?'BUY':'SELL';
    final validPlan = ai.overlays.any((o)=>o['kind']=='Entry') && ai.overlays.any((o)=>o['kind']=='SL') && ai.overlays.any((o)=>o['kind']=='TP1');
    if (decision!='WAIT' && !validPlan) decision='WAIT';
    final reasons=<String>[];
    if (!ai.weightsProvided) reasons.add('این مدل وزن‌ها و امتیازهای معیارها را در پاسخ تولید نکرد؛ ترکیب معتبر صادر نشد.');
    reasons.add('سهم تکنیکال: ${tStrength.toStringAsFixed(1)} از ۱۰۰');
    reasons.add('سهم شواهد AI (${ai.model}): ${aStrength.toStringAsFixed(1)} از ۱۰۰');
    if(conflict) reasons.add('تعارض جهت بین تکنیکال و AI؛ تصمیم به WAIT محدود شد.');
    if(tDir==0||aDir==0) reasons.add('یکی از دو موتور خنثی است؛ سهم آن در امتیاز ترکیبی صفر لحاظ شد.');
    if(decision=='WAIT' && !conflict && combined.abs()<18) reasons.add('قدرت ترکیبی به حداقل آستانه تصمیم نرسید.');
    if(!validPlan && ai.bias!='WAIT') reasons.add('نقشه معامله AI کامل نیست؛ ورود ترکیبی صادر نشد.');
    return HybridDecision(provider:ai.model,decision:decision,score:combined,technicalScore:ts,aiScore:ascore,
      technicalWeights:tw,aiWeights:aw,reasons:reasons,calibration:'ضریب اعتماد عملکردی هنوز خنثی است؛ داده کافی برای کالیبراسیون خارج از نمونه ثبت نشده است.');
  }
}
