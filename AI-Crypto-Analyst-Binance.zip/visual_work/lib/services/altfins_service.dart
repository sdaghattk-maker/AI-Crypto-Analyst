import 'dart:convert';
import 'package:http/http.dart' as http;
import 'app_config.dart';

class AltFinsService {
  static const Duration _timeout = Duration(seconds: 18);
  Uri _uri(String path) => Uri.parse('${AppConfig.aiGatewayBaseUrl}$path');

  Future<Map<String, dynamic>> getQuota() async {
    final response = await http.get(_uri('/altfins/quota')).timeout(_timeout);
    return _decode(response);
  }

  Future<Map<String, dynamic>> validate({
    required String symbol,
    required String timeframe,
    required String exchange,
  }) async {
    if (timeframe == '5m') {
      return {'ok': false, 'source': 'altfins', 'status': 'UNSUPPORTED_TIMEFRAME', 'affectsTradeDecision': false};
    }
    final venue = _venue(exchange);
    final response = await http.post(
      _uri('/altfins/validation'),
      headers: const {'Content-Type': 'application/json'},
      body: jsonEncode({
        'symbol': symbol,
        'timeframe': timeframe,
        'exchange': venue,
        'tradingType': 'FUTURES',
      }),
    ).timeout(_timeout);
    return _decode(response);
  }

  String _venue(String exchange) {
    final value = exchange.toUpperCase();
    if (value.contains('BINANCE')) return 'BINANCE';
    if (value.contains('BYBIT')) return 'BYBIT';
    if (value.contains('OKX')) return 'OKX';
    if (value.contains('COINBASE')) return 'COINBASE';
    if (value.contains('KRAKEN')) return 'KRAKEN';
    if (value.contains('KUCOIN')) return 'KUCOIN';
    if (value.contains('MEXC')) return 'MEXC';
    if (value.contains('GATE')) return 'GATEIO';
    return 'BINANCE';
  }

  Map<String, dynamic> _decode(http.Response response) {
    dynamic decoded;
    try { decoded = jsonDecode(response.body); } catch (_) {
      return {'ok': false, 'status': 'INVALID_RESPONSE', 'error': 'پاسخ نامعتبر از Gateway', 'affectsTradeDecision': false};
    }
    if (decoded is! Map) return {'ok': false, 'status': 'INVALID_RESPONSE', 'affectsTradeDecision': false};
    final result = Map<String, dynamic>.from(decoded);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      result['ok'] = false;
      result['httpStatus'] = response.statusCode;
      result['affectsTradeDecision'] = false;
    }
    return result;
  }
}
