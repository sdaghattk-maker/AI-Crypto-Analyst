
# AI Crypto Analyst — multi-exchange / multi-timeframe

این نسخه بر پایه ZIP ارسالی کاربر توسعه داده شده است.

## آنچه در این نسخه پیاده‌سازی شده

### انتخاب صرافی و نمودار
- دریافت اولیه ۵۰۰ کندل و سپس به‌روزرسانی خودکار داده‌های اخیر هر ۵ ثانیه؛ در به‌روزرسانی‌های دوره‌ای فقط دو کندل آخر دریافت می‌شوند تا کندل جاری اصلاح و کندل جدید اضافه شود.
- به‌روزرسانی افزایشی نمودار، بدون پاک‌کردن داده‌ها و بدون بازنشانی زوم یا موقعیت دستی کاربر.
- کنترل لمسی: کشیدن یک انگشت برای جابه‌جایی، دو انگشت برای زوم، کشیدن محور قیمت برای مقیاس عمودی و دوبار لمس برای بازگشت به آخرین قیمت.
- انتخاب صرافی و نماد در `AppState` مشترک است؛ صفحه نمودار دیگر صرافی یا نماد ثابت ندارد.
- با تغییر صرافی یا نماد، درخواست قبلی بی‌اعتبار و داده‌های قبلی قیمت پاک می‌شوند.
- Binance از Worker موجود استفاده می‌کند:
  `https://hrs-binance-proxy.sdaghat-tk.workers.dev`
- Nobitex از API عمومی بازار استفاده می‌کند:
  - قیمت: `GET https://apiv2.nobitex.ir/market/stats`
  - کندل: `GET https://apiv2.nobitex.ir/market/udf/history`
- داده‌های نوبیتکس و بایننس با نام صرافی اشتباه نمایش داده نمی‌شوند.
- فقط کندل‌های بسته‌شده و OHLC معتبر به نمودار و موتور تحلیل می‌روند.

### مرحله 3 — Technical Engine
- دریافت 120 کندل بسته‌شده برای هرکدام از 1H، 15M و 5M.
- جهت 1H و 15M با EMA20/EMA50.
- RSI14 و ATR14 در 5M.
- محدوده 20 کندلی 15M به‌عنوان محدوده مرجع CRT.
- تشخیص sweep سقف/کف کوتاه‌مدت، شکست ساختار کوتاه‌مدت و کندل جابجایی.
- سنجش نسبی قدرت خریدار/فروشنده با موقعیت بسته‌شدن کندل و حجم در صورت وجود.
- سیگنال BUY/SELL فقط با هم‌جهتی 1H، عدم تضاد 15M، حداقل امتیاز، sweep یا MSS و displacement؛ در غیر این صورت WAIT.
- Entry از close کندل تأییدشده 5M؛ SL پشت high/low کندل با بافر 0.25 ATR؛ اهداف 1R، 2R و 3R.

**محدودیت مهم:** این نسخه موتور تکنیکال اولیه و قابل‌آزمایش است؛ هنوز تمام منطق ICT/CRT پیشرفته، FVG، CISD، SMT، order-flow و بک‌تست آماری در آن پیاده نشده است. امتیازها احتمال برد یا تضمین سود نیستند.

### مرحله 4 — Gemini + OpenRouter
- اپلیکیشن دارای کلاینت AI Gateway است و گزارش تکنیکال را به `/analyze` می‌فرستد.
- کد Cloudflare Worker در `ai-gateway/worker.js` قرار دارد.
- کلیدها داخل APK قرار نمی‌گیرند؛ فقط به‌صورت Worker Secret نگهداری می‌شوند.
- هماهنگ‌کننده فقط وقتی BUY/SELL می‌دهد که هر دو مدل با سیگنال موتور تکنیکال هم‌نظر باشند؛ در غیر این صورت WAIT.

## فعال‌سازی واقعی Gemini و OpenRouter

این بخش به کلیدهای API و استقرار Worker نیاز دارد؛ چون کلیدهای کاربر در این بسته وجود ندارند، اتصال زنده مدل‌ها هنوز فعال نشده است.

1. در Cloudflare یک Worker جدید بساز و محتوای `ai-gateway/worker.js` را Deploy کن.
2. در Worker بخش Settings → Variables and Secrets این موارد را به‌صورت **Secret** اضافه کن:
   - `GEMINI_API_KEY`
   - `OPENROUTER_API_KEY`
3. متغیرهای اختیاری:
   - `GEMINI_MODEL` (پیش‌فرض `gemini-3.8-flash`)
   - `OPENROUTER_MODEL` (پیش‌فرض `openrouter-flash`)
4. آدرس HTTPS Worker را در GitHub → Settings → Secrets and variables → Actions با نام زیر ذخیره کن:
   - `AI_GATEWAY_BASE_URL`
   - مقدار نمونه: `https://your-ai-gateway.your-subdomain.workers.dev`
5. Workflow را اجرا کن تا آدرس در APK قرار بگیرد.

تا قبل از انجام این مراحل، موتور تکنیکال کار می‌کند ولی صفحه AI صادقانه وضعیت «در انتظار تنظیم AI Gateway» را نشان می‌دهد.

## Build
Workflow در `.github/workflows/build-apk.yml`:
- Android platform را می‌سازد.
- مجوز INTERNET را اضافه می‌کند.
- `flutter analyze` اجرا می‌کند.
- APK Release می‌سازد و وجود مجوز INTERNET را داخل APK نهایی بررسی می‌کند.
- APK را با نام artifact `AI-Crypto-Analyst-APK` منتشر می‌کند.

## محدودیت‌ها و نکات
- هیچ سفارش خودکار یا اتصال به کیف پول/حساب کاربری وجود ندارد.
- API نوبیتکس برای جفت‌ارزهای USDT در دسترس بودن بازار را خودش تعیین می‌کند؛ اگر جفتی پشتیبانی نشود، برنامه خطا می‌دهد و داده بایننس را جایگزین نمی‌کند.
- این محیط Flutter SDK ندارد؛ بنابراین ساخت واقعی APK و تست زنده HTTP از اینجا انجام نشده است. کدها و ساختار ZIP بررسی ایستا شده‌اند و باید در GitHub Actions Build شوند.


## اصلاح هماهنگی Worker و اپلیکیشن (نسخه FIXED)

- اپلیکیشن اکنون گزارش را با کلید `technicalAnalysis` به مسیر `/analyze` می‌فرستد.
- Worker هر دو کلید `technicalAnalysis` و `technical` را برای سازگاری می‌پذیرد.
- پاسخ Worker هم ساختار `providers.gemini/openrouter` و هم کلیدهای تخت `gemini/openrouter` را برمی‌گرداند.
- کلاینت Flutter هر دو ساختار پاسخ را می‌خواند و زمان انتظار AI را تا ۷۵ ثانیه افزایش می‌دهد.
- مسیر `GET /health` فقط وجود Secretها را نشان می‌دهد و اعتبار واقعی آن‌ها را ثابت نمی‌کند.
- مسیر `POST /provider-test` اتصال واقعی هر دو مدل را آزمایش می‌کند و فقط با `Authorization: Bearer <GATEWAY_TOKEN>` قابل استفاده است.
- مسیر `/analyze` برای اپلیکیشن به رمز ثابت داخل APK وابسته نیست؛ چون هر رمز مشترکی که داخل APK قرار گیرد قابل استخراج است. در عوض باید در Cloudflare برای مسیر `/analyze` یک Rate Limiting Rule فعال شود (مثلاً محدودیت اولیه ۵ درخواست در هر دقیقه برای هر IP؛ متناسب با استفاده واقعی قابل تنظیم). این Rule باید قبل از عمومی‌کردن اپ فعال باشد.
- کلیدهای `GEMINI_API_KEY`, `OPENROUTER_API_KEY` و `GATEWAY_TOKEN` فقط در Cloudflare Worker Secrets باقی می‌مانند.

### آزمایش اتصال مدل‌ها

برای آزمایش از ابزار REST مانند Postman یا یک درخواست `curl` استفاده کنید:

`POST https://<worker-host>/provider-test`

Header:
`Authorization: Bearer <GATEWAY_TOKEN>`

Body:
`{}`

پاسخ موفق باید `ok: true` و وضعیت `ok` برای هر دو provider داشته باشد. هرگز مقدار Token یا API Key را در GitHub، APK یا پیام عمومی قرار ندهید.


## اصلاح اتصال OpenRouter (نسخه Binance-OPENROUTER-FIXED)

- قرارداد پاسخ Flutter با Worker فعلی هماهنگ شد: `providers.gemini` و `providers.openrouter`.
- نمایشگر تحلیل و داشبورد به‌جای DeepSeek نام OpenRouter را نشان می‌دهند.
- فایل Worker داخل آرشیو با نسخه تشخیصی تأییدشده Gemini Lite + OpenRouter جایگزین شد.
- هدرهای اختیاری `HTTP-Referer` و `X-Title` از درخواست OpenRouter حذف شده‌اند؛ حذف آن‌ها در تست قبلی باعث موفقیت هر دو Provider شد.
- Workflow ساخت APK همچنان از Secret به نام `AI_GATEWAY_BASE_URL` استفاده می‌کند و نیازی به تغییر ندارد.

## اصلاح سهمیه و اجرای مجدد مدل‌های ناموفق
- پاسخ هر provider برای Snapshot جاری به‌صورت مستقل ذخیره می‌شود.
- دکمه «تلاش مجدد فقط برای مدل‌های ناموفق» فقط providerهایی را اجرا می‌کند که وضعیت `error` دارند؛ `not_selected` به معنی ناموفق نیست و دوباره اجرا نمی‌شود.
- تلاش مجدد از همان کندل‌های ذخیره‌شده و همان `snapshotId` استفاده می‌کند و تحلیل تکنیکال/دریافت کندل را تکرار نمی‌کند.
- پاسخ جزئی جدید با پاسخ‌های موفق قبلی ادغام می‌شود. پاسخ `not_selected` هیچ‌وقت پاسخ قبلی را پاک نمی‌کند.
- اگر ارتباط کل Worker قطع شود، فقط مدل‌های انتخاب‌شده در همان درخواست به‌عنوان ناموفق ثبت می‌شوند و پاسخ‌های قبلی سایر مدل‌ها حفظ می‌شوند.
- اجرای کامل جدید Snapshot تازه می‌سازد؛ پاسخ‌های Snapshot قدیمی با پاسخ‌های بازار جدید مخلوط نمی‌شوند.

## Chart Analyzer AI (2026-11-19)

- Chart Analyzer AI remains an independent visual observer, launched in its own in-app WebView. It is not part of provider consensus or Hybrid.
- The app exports a clean chart image without Technical/AI overlays, then restores the overlays. The website handles its own analysis result.
- No undocumented API or private upload endpoint is used. Verify the upload flow on a real Android device because website upload controls and quotas may change.

## altFINS optional market validation (Basic/free-safe)

- Configure the Cloudflare Worker secret `ALTFINS_API_KEY`; never put this key in Flutter or a client request.
- `GET /altfins/quota` reads remaining permits/prompts from altFINS without spending an analysis credit.
- `POST /altfins/validation` accepts `{ "symbol":"BTCUSDT", "timeframe":"15m", "exchange":"BINANCE", "tradingType":"FUTURES" }`. Supported intervals: 15m, 1h, 4h, 12h, 1d. 5m is intentionally rejected before calling altFINS.
- Screener responses are cached for 15 minutes where Cloudflare Cache API is available. The endpoint returns a soft status (`PLAN_RESTRICTED`, `LIMIT_REACHED`, `UNAVAILABLE`, etc.) instead of changing a trade decision.
- Do not call AI Trade Setup generation on the Basic plan; it is plan-gated and can consume a separate prompt allowance. altFINS is optional context only, not a required gate for the 5m execution model.
- This phase adds and tests the Worker adapter. The app UI is not yet wired to display the returned altFINS context; deploy and live-key verification are still required.
