import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const chart = readFileSync(new URL('../assets/chart.html', import.meta.url), 'utf8');
const screen = readFileSync(new URL('../lib/screens/chart_analyzer_screen.dart', import.meta.url), 'utf8');
const chartScreen = readFileSync(new URL('../lib/screens/chart_screen.dart', import.meta.url), 'utf8');

test('Chart Analyzer export uses a high-resolution clean canvas and restores overlays/state', () => {
  assert.match(chart, /exportChartAnalyzerPng=function\(requestedCount,targetWidth,targetHeight,marketLabel\)/);
  assert.match(chart, /const w=Math\.max\(1200/);
  assert.match(chart, /const h=Math\.max\(700/);
  assert.match(chart, /tradeOverlays=\[\]/);
  assert.match(chart, /cleanExportMode=true/);
  assert.match(chart, /marketLabel/);
  assert.match(chart, /tradeOverlays=saved\.overlays/);
  assert.match(chart, /if\(candles\.length<50\)return ''/);
  assert.match(chart, /window\.getCandleCount=function\(\)/);
});

test('Chart Analyzer screen opens the official page in-app and auto-supplies the generated image', () => {
  assert.match(screen, /https:\/\/www\.chartanalyzerai\.com\/upload/);
  assert.match(screen, /setOnShowFileSelector/);
  assert.match(screen, /Uri\.file\(widget\.imageFile\.path\)/);
  assert.match(screen, /input\.click\(\)/);
});

test('Chart screen uses timeframe-specific candle targets and enforces 4 MB upload limit', () => {
  assert.match(chartScreen, /'1h' => 120/);
  assert.match(chartScreen, /'15m' => 160/);
  assert.match(chartScreen, /'5m' => 200/);
  assert.match(chartScreen, /4 \* 1024 \* 1024/);
  assert.match(chartScreen, /availableCount < targetCount/);
  assert.match(chartScreen, /safeSymbol/);
  assert.match(chartScreen, /ChartAnalyzerScreen\(/);
});
