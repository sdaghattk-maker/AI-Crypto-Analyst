# AI Data Engine — provider-native ingestion

## Decision
Gemini, Groq and OpenRouter are no longer required to emit the same rigid V3 JSON schema. Each provider receives an open-ended analysis instruction and may respond in its best supported format (JSON/prose/provider-native structured output). The gateway converts the response into the app's stable normalized envelope.

## Ingestion layers
1. **Raw response** — preserve the original provider response (bounded to 12,000 characters in the current API envelope) for inspection and future extraction improvements.
2. **Provider response parsing** — accept JSON objects, JSON embedded in fences/prose, and plain text. Recognize common aliases for direction, confidence, summary, observations, findings and risks.
3. **Canonical normalization** — map known fields to the current app response envelope; missing analytical sections are represented as `INSUFFICIENT_DATA`, not fabricated.
4. **Safety validation** — trade execution remains strict: BUY/SELL plans must have coherent Entry/SL/TP levels, a valid POI and prices consistent with the submitted market history/reference anchor. Invalid/incomplete execution is downgraded to WAIT while the analysis is retained.
5. **Hybrid eligibility** — a response without the complete evidence/weight contract is retained for display but is not automatically treated as a qualified Hybrid vote. This prevents a permissive parser from weakening decision safety.

## Provider behavior
- Gemini: JSON response mode is requested, but no rigid `responseJsonSchema` is imposed.
- OpenRouter: no universal `json_schema` constraint is imposed because free endpoints/models vary in support.
- Groq: no strict JSON schema is imposed; local normalization and safety checks remain authoritative.

## Limitations / next extension
The current normalizer preserves the complete raw response and maps common fields. Deep extraction of every provider-specific nested field into dedicated graphical categories (e.g. funding, OI, order book, news, liquidation, sentiment) should be added incrementally with explicit source/provenance metadata. The engine must never invent unavailable market feeds or infer executable prices from vague prose.
