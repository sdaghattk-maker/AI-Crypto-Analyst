import 'package:flutter/material.dart';
import '../models/app_state.dart';
import '../services/analysis_controller.dart';
import '../services/ai_service.dart';
import '../services/technical_engine.dart';
import '../services/hybrid_engine.dart';
import '../services/altfins_service.dart';
import '../services/smart_connectivity_service.dart';

class SmartConnectivityScreen extends StatefulWidget {
  const SmartConnectivityScreen({super.key});
  @override State<SmartConnectivityScreen> createState()=>_SmartConnectivityScreenState();
}
class _SmartConnectivityScreenState extends State<SmartConnectivityScreen> {
  final SmartConnectivityService _connectivity=SmartConnectivityService();
  ConnectivityReport? _connectivityReport;
  bool _connectivityLoading=false;
  String? _connectivityError;
  @override void initState(){
    super.initState();
    SmartConnectivityService.chartAnalyzerStatus.addListener(_onChartAnalyzerStatusChanged);
    _refreshConnectivity();
  }
  void _onChartAnalyzerStatusChanged(){
    final status=SmartConnectivityService.chartAnalyzerStatus.value;
    if(!mounted || status==null || _connectivityReport==null)return;
    setState(()=>_connectivityReport=_connectivityReport!.replaceItem(status));
  }
  @override void dispose(){
    SmartConnectivityService.chartAnalyzerStatus.removeListener(_onChartAnalyzerStatusChanged);
    _connectivity.dispose();
    super.dispose();
  }
  Future<void> _refreshConnectivity() async {
    if (_connectivityLoading) return;
    if (mounted) setState(() { _connectivityLoading = true; _connectivityError = null; });
    try {
      final report = await _connectivity.inspect();
      if (mounted) setState(() => _connectivityReport = report);
    } catch (e) {
      if (mounted) setState(() {
        _connectivityError = e.toString();
        if (_connectivityReport != null) _connectivityReport = _connectivityReport!.markStale(e.toString());
      });
    } finally {
      if (mounted) setState(() => _connectivityLoading = false);
    }
  }

  Widget _connectivityCard() {
    final report = _connectivityReport;
    IconData iconFor(LinkState state) => switch (state) {
      LinkState.available => Icons.check_circle,
      LinkState.degraded => Icons.warning_amber_rounded,
      LinkState.blocked => Icons.block,
      LinkState.authenticationFailed => Icons.key_off,
      LinkState.regionRestricted => Icons.public_off,
      LinkState.gatewayAccessDenied => Icons.lock_outline,
      LinkState.notConfigured => Icons.settings_outlined,
      LinkState.unknown => Icons.help_outline,
      LinkState.stale => Icons.history_toggle_off,
    };
    Color colorFor(LinkState state) => switch (state) {
      LinkState.available => const Color(0xFF46D6B3),
      LinkState.degraded => Colors.orangeAccent,
      LinkState.blocked => Colors.redAccent,
      LinkState.authenticationFailed => Colors.orangeAccent,
      LinkState.regionRestricted => Colors.redAccent,
      LinkState.gatewayAccessDenied => Colors.orangeAccent,
      LinkState.notConfigured => Colors.blueGrey,
      LinkState.unknown => Colors.white54,
      LinkState.stale => Colors.orangeAccent,
    };
    return Card(
      color: const Color(0xFF10182A),
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.alt_route, color: Color(0xFF8CE5CF)),
            const SizedBox(width: 8),
            const Expanded(child: Text('Smart Connectivity • وضعیت مسیرها', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
            IconButton(
              tooltip: 'بررسی دوباره اتصال‌ها',
              onPressed: _connectivityLoading ? null : _refreshConnectivity,
              icon: _connectivityLoading
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.refresh),
            ),
          ]),
          const Text('مسیر امن: AIها و altFINS از Gateway؛ Chart Analyzer از WebView رسمی؛ Binance از Proxy مستقل. کلیدها داخل APK قرار نمی‌گیرند.',
              style: TextStyle(fontSize: 10, color: Colors.white60)),
          if (_connectivityError != null) Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(_connectivityError!, style: const TextStyle(color: Colors.orangeAccent, fontSize: 11)),
          ),
          if (report == null && _connectivityLoading) const Padding(
            padding: EdgeInsets.symmetric(vertical: 10), child: LinearProgressIndicator(),
          ),
          if (report != null) ...[
            const SizedBox(height: 8),
            ...report.items.map((item) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(iconFor(item.state), size: 17, color: colorFor(item.state)),
                const SizedBox(width: 8),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(item.name, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                  Text(switch(item.state){
                    LinkState.available=>'در دسترس',
                    LinkState.degraded=>'اختلال موقت / کند',
                    LinkState.blocked=>'دسترسی توسط Provider رد شد',
                    LinkState.authenticationFailed=>'خطای احراز هویت Provider',
                    LinkState.regionRestricted=>'محدودیت منطقه‌ای صریح',
                    LinkState.gatewayAccessDenied=>'دسترسی به خود Gateway رد شد',
                    LinkState.notConfigured=>'تنظیم نشده',
                    LinkState.unknown=>'تأییدنشده',
                    LinkState.stale=>'اطلاعات قدیمی / نیازمند بررسی',
                  }, style: const TextStyle(fontSize: 9, color: Colors.white54)),
                  Text(item.detail, style: const TextStyle(fontSize: 10, color: Colors.white60)),
                ])),
                if (item.latencyMs != null) Text('${item.latencyMs}ms', style: const TextStyle(fontSize: 10, color: Colors.white38)),
              ]),
            )),
            Text('آخرین بررسی: ${report.checkedAt.toLocal().toString().substring(0, 16)}',
                style: const TextStyle(fontSize: 10, color: Colors.white38)),
          ],
          const SizedBox(height: 5),
          const Text('توجه: خطای Gateway به‌تنهایی اثبات فیلترینگ ISP نیست. VPN محدودیت مجوز یا سیاست منطقه‌ای ارائه‌دهنده را رفع نمی‌کند؛ برنامه مسیر جایگزین غیرمجاز ایجاد نمی‌کند.',
              style: TextStyle(fontSize: 10, color: Colors.orangeAccent)),
        ]),
      ),
    );
  }


  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Smart Connectivity',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
    const SizedBox(height:6),
    const Text('مدیریت و پایش مسیرهای ارتباطی سرویس‌ها؛ بدون تغییر مسیر امن یا قراردادن کلیدها در APK.',style:TextStyle(color:Colors.white60,fontSize:12)),
    const SizedBox(height:12),_connectivityCard(),
  ]);
}

class MarketSourcesScreen extends StatefulWidget {
  const MarketSourcesScreen({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  @override State<MarketSourcesScreen> createState()=>_MarketSourcesScreenState();
}
class _MarketSourcesScreenState extends State<MarketSourcesScreen> {
  final AltFinsService altFins=AltFinsService();
  final HybridEngine hybridEngine=HybridEngine();
  bool _altFinsLoading=false;
  Map<String,dynamic>? _altFinsQuota;
  Map<String,Map<String,dynamic>> _altFinsValidation={};
  String? _altFinsError;
  DateTime? _altFinsCheckedAt;
  String get _altFinsContextKey => '${widget.state.exchange.toUpperCase()}_${widget.state.symbol.toUpperCase()}';
  String _loadedAltFinsContextKey='';
  AiConsensus? get consensus {
    final value=widget.analysis.consensus;
    if(widget.analysis.isStale || widget.analysis.isAiStale) return null;
    return value!=null && value.snapshotId!=null && value.snapshotId==widget.analysis.snapshotId ? value : null;
  }
  @override void initState(){super.initState();widget.state.addListener(_onMarketContextChanged);_refreshAltFinsQuota();_loadAltFinsCache();_refreshAltFinsValidation(forceRefresh:false);}
  @override void dispose(){widget.state.removeListener(_onMarketContextChanged);super.dispose();}
  void _onMarketContextChanged(){final key=_altFinsContextKey;if(key==_loadedAltFinsContextKey)return;_loadedAltFinsContextKey=key;if(mounted)setState(()=>_altFinsValidation={});_loadAltFinsCache();}
  Future<void> _refreshAltFinsQuota() async {
    try {
      final result=await altFins.getQuota();
      if(!mounted)return;
      setState((){_altFinsQuota=result;_altFinsError=null;_altFinsCheckedAt=DateTime.now();});
    } catch(e) {
      if(!mounted)return;
      setState(()=>_altFinsError='دریافت سهمیه altFINS ناموفق بود: $e');
    }
  }

  Future<void> _loadAltFinsCache() async {
    final symbol=widget.state.symbol, exchange=widget.state.exchange;
    _loadedAltFinsContextKey='${exchange.toUpperCase()}_${symbol.toUpperCase()}';
    try {
      final results=await Future.wait([
        altFins.loadCached(symbol:symbol,timeframe:'15m',exchange:exchange),
        altFins.loadCached(symbol:symbol,timeframe:'1h',exchange:exchange),
      ]);
      if(!mounted || widget.state.symbol!=symbol || widget.state.exchange!=exchange)return;
      setState(() {
        _altFinsValidation={
          if(results[0]!=null)'15m':results[0]!,
          if(results[1]!=null)'1h':results[1]!,
        };
        _altFinsCheckedAt=DateTime.now();
      });
    } catch (_) { /* Cache is optional; network/analysis must remain usable. */ }
  }

  Future<void> _refreshAltFinsValidation({bool forceRefresh=true}) async {
    if(_altFinsLoading)return;
    final symbol=widget.state.symbol, exchange=widget.state.exchange;
    setState(()=>_altFinsLoading=true);
    try {
      final results=await Future.wait([
        altFins.validateSmart(symbol:symbol,timeframe:'15m',exchange:exchange,forceRefresh:forceRefresh),
        altFins.validateSmart(symbol:symbol,timeframe:'1h',exchange:exchange,forceRefresh:forceRefresh),
      ]);
      if(!mounted || widget.state.symbol!=symbol || widget.state.exchange!=exchange)return;
      setState((){
        _altFinsValidation={'15m':results[0],'1h':results[1]};
        _altFinsCheckedAt=DateTime.now();
        final failed=results.any((r)=>r['ok']!=true || r['status']!='AVAILABLE');
        _altFinsError=failed?'بروزرسانی کامل نبود؛ داده قبلی فقط برای نمایش و با وضعیت منقضی نگهداری شده است.':null;
      });
    } catch(e) {
      if(mounted)setState(()=>_altFinsError='اعتبارسنجی altFINS در دسترس نیست: $e');
    } finally { if(mounted)setState(()=>_altFinsLoading=false); }
  }

  String _altValue(dynamic value) {
    if(value==null)return '—';
    if(value is num)return value.toStringAsFixed(value.abs()>=100?2:4);
    return value.toString();
  }

  Widget _altFinsCard() {
    final quota=_altFinsQuota?['quota'];
    final monthly=quota is Map ? quota['monthlyAvailablePermits'] : null;
    final aiPrompts=quota is Map ? quota['monthlyAvailableAiTradeSetupPrompts'] : null;
    final quotaStatus='${_altFinsQuota?['status']??'در انتظار بررسی'}';
    return Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[const Icon(Icons.query_stats,color:Color(0xFF8CE5CF)),const SizedBox(width:8),const Expanded(child:Text('اعتبارسنجی کمکی altFINS',style:TextStyle(fontWeight:FontWeight.bold,fontSize:16))),Text(quotaStatus,style:TextStyle(fontSize:11,color:quotaStatus=='AVAILABLE'?const Color(0xFF46D6B3):Colors.orangeAccent))]),
      const SizedBox(height:6),
      Text('سهمیه ماهانه: ${monthly??'—'} درخواست • AI Trade Setup: ${aiPrompts??'—'}',style:const TextStyle(fontSize:11,color:Colors.white70)),
      const SizedBox(height:8),
      SizedBox(width:double.infinity,child:OutlinedButton.icon(onPressed:_altFinsLoading?null:()=>_refreshAltFinsValidation(forceRefresh:true),icon:_altFinsLoading?const SizedBox(width:15,height:15,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.sync,size:17),label:Text(_altFinsLoading?'در حال دریافت داده‌ها...':'به‌روزرسانی اعتبارسنجی 15M و 1H'))),
      if(_altFinsValidation.isEmpty)const Text('هنوز داده اعتبارسنجی دریافت نشده است.',style:TextStyle(fontSize:11,color:Colors.white54)),
      ...['15m','1h'].where(_altFinsValidation.containsKey).map((tf){
        final rawResult = _altFinsValidation[tf];
        final r = rawResult == null ? <String, dynamic>{} : Map<String, dynamic>.from(rawResult);
        final rawCache = r['_cache'];
        final cache = rawCache is Map ? Map<String, dynamic>.from(rawCache) : <String, dynamic>{};
        final fresh=cache['fresh']==true && r['ok']==true && r['status']=='AVAILABLE';
        final rawData=r['data'] is Map?r['data']:r['_previousData'];
        final data=rawData is Map?Map<String,dynamic>.from(rawData):<String,dynamic>{};
        final st=fresh?'AVAILABLE':(data.isNotEmpty?'STALE • فقط نمایش':'${r['status']??'UNAVAILABLE'}');
        return Padding(padding:const EdgeInsets.only(top:8),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('$tf • $st',style:TextStyle(fontWeight:FontWeight.bold,color:st=='AVAILABLE'?const Color(0xFF46D6B3):Colors.orangeAccent)),
          if(data.isNotEmpty)Wrap(spacing:12,runSpacing:5,children:[
            Text('RSI ${_altValue(data['rsi14'])}'),Text('ADX ${_altValue(data['adx'])}'),Text('MACD ${_altValue(data['macd'])}'),
            Text('EMA9 ${_altValue(data['ema9'])}'),Text('EMA50 ${_altValue(data['ema50'])}'),Text('EMA200 ${_altValue(data['ema200'])}'),
            Text('RVOL ${_altValue(data['relativeVolume'])}'),Text('Trend ${_altValue(data['shortTermTrend'])}'),
            Text('Support ${_altValue(data['support'])}'),Text('Resistance ${_altValue(data['resistance'])}'),
          ].map((w)=>DefaultTextStyle(style:const TextStyle(fontSize:10,color:Colors.white70),child:w)).toList()),
          if(!fresh)Text(data.isNotEmpty?'این داده منقضی است و در تحلیل/هم‌سنجی استفاده نمی‌شود.':'${r['error']??'داده تازه در دسترس نیست.'}',style:const TextStyle(fontSize:10,color:Colors.orangeAccent)),
          if(cache['fetchedAt']!=null)Text('دریافت: ${cache['fetchedAt']} • اعتبار: ${fresh? 'معتبر':'پایان‌یافته'}',style:const TextStyle(fontSize:9,color:Colors.white38)),
        ]));
      }),
      if(_altFinsCheckedAt!=null)Text('آخرین بررسی: ${_altFinsCheckedAt!.toLocal().toString().substring(0,16)}',style:const TextStyle(fontSize:10,color:Colors.white38)),
      if(_altFinsError!=null)Text(_altFinsError!,style:const TextStyle(fontSize:10,color:Colors.orangeAccent)),
      const Text('altFINS در این نسخه روی SPOT هم‌نوع با داده‌های بازار برنامه فیلتر می‌شود؛ فقط اعتبارسنجی کمکی است و در تصمیم Technical، AI یا Hybrid دخالت نمی‌کند. تایم‌فریم 5M پشتیبانی نمی‌شود.',style:TextStyle(fontSize:10,color:Colors.white54)),
    ])));
  }

  String _directionLabel(String value) {
    switch(value.toUpperCase()) { case 'BUY': case 'BULLISH': return 'صعودی'; case 'SELL': case 'BEARISH': return 'نزولی'; default: return 'خنثی/نامشخص'; }
  }

  String _altInterpretation(Map<String,dynamic> d) {
    final parts=<String>[];
    final trend='${d['shortTermTrend']??''}'.toUpperCase();
    if(trend.contains('BULL')||trend.contains('UP')) parts.add('روند کوتاه‌مدت صعودی');
    else if(trend.contains('BEAR')||trend.contains('DOWN')) parts.add('روند کوتاه‌مدت نزولی');
    final rsi=num.tryParse('${d['rsi14']??''}');
    if(rsi!=null) parts.add(rsi>=70?'RSI در اشباع خرید':rsi<=30?'RSI در اشباع فروش':rsi>=55?'مومنتوم متمایل به خریدار':rsi<=45?'مومنتوم متمایل به فروشنده':'RSI خنثی');
    final adx=num.tryParse('${d['adx']??''}');
    if(adx!=null) parts.add(adx>=25?'قدرت روند مناسب':'قدرت روند ضعیف/محدود');
    final macd=num.tryParse('${d['macd']??''}');
    if(macd!=null) parts.add(macd>0?'MACD مثبت':macd<0?'MACD منفی':'MACD نزدیک صفر');
    final e9=num.tryParse('${d['ema9']??''}'), e50=num.tryParse('${d['ema50']??''}'), e200=num.tryParse('${d['ema200']??''}');
    if(e9!=null&&e50!=null&&e200!=null) parts.add(e9>e50&&e50>e200?'چیدمان EMA صعودی':e9<e50&&e50<e200?'چیدمان EMA نزولی':'چیدمان EMA مختلط');
    return parts.isEmpty?'داده کافی برای تفسیر موجود نیست':parts.join(' • ');
  }

  String _altDirection(Map<String,dynamic> d) {
    var score=0;
    final trend='${d['shortTermTrend']??''}'.toUpperCase();
    if(trend.contains('BULL')||trend.contains('UP')) score+=2;
    if(trend.contains('BEAR')||trend.contains('DOWN')) score-=2;
    final rsi=num.tryParse('${d['rsi14']??''}'); if(rsi!=null){if(rsi>=55&&rsi<70)score++;if(rsi<=45&&rsi>30)score--;}
    final macd=num.tryParse('${d['macd']??''}'); if(macd!=null){if(macd>0)score++;if(macd<0)score--;}
    final a=num.tryParse('${d['ema9']??''}'),b=num.tryParse('${d['ema50']??''}'),c=num.tryParse('${d['ema200']??''}');
    if(a!=null&&b!=null&&c!=null){if(a>b&&b>c)score+=2;if(a<b&&b<c)score-=2;}
    return score>=2?'BUY':score<=-2?'SELL':'WAIT';
  }

  String _alignment(String a,String b) {
    if(a=='WAIT'||b=='WAIT'||a.isEmpty||b.isEmpty)return 'قابل‌مقایسه نیست';
    return a==b?'هم‌راستا':'ناهم‌راستا';
  }

  String _technicalTimeframeDirection(TechnicalReport? report,String timeframe) {
    if(report==null || widget.analysis.isStale) return '';
    final bias=timeframe=='15m'?report.bias15m:report.bias1h;
    return bias==TradeBias.bullish?'BUY':bias==TradeBias.bearish?'SELL':'WAIT';
  }

  String _aiTimeframeDirection(AiModelResult provider,String timeframe) {
    if(widget.analysis.isStale || widget.analysis.isAiStale || provider.status!='ok') return '';
    final voteMeta=provider.timeframeVoteEligibility[timeframe];
    if(voteMeta is! Map || voteMeta['eligible']!=true) return '';
    final raw=provider.timeframeAnalysis[timeframe];
    if(raw is! Map || raw['provided']!=true) return '';
    switch('${raw['trend']??'UNKNOWN'}'.toUpperCase()) {
      case 'BULLISH': return 'BUY';
      case 'BEARISH': return 'SELL';
      case 'RANGE':
      case 'TRANSITION': return 'WAIT';
      default: return '';
    }
  }

  String _aiTimeframeConsensus(AiConsensus? value,String timeframe) {
    if(value==null) return '';
    final counts=<String,int>{'BUY':0,'SELL':0,'WAIT':0};
    for(final provider in [value.gemini,value.openrouter,value.groq]) {
      final direction=_aiTimeframeDirection(provider,timeframe);
      if(direction.isNotEmpty) counts[direction]=(counts[direction]??0)+1;
    }
    final ranked=counts.entries.where((entry)=>entry.value>0).toList()
      ..sort((a,b)=>b.value.compareTo(a.value));
    if(ranked.isEmpty || ranked.first.value<2 ||
        (ranked.length>1 && ranked.first.value==ranked[1].value)) return '';
    return ranked.first.key;
  }

  Widget _marketIntelCard(dynamic report, AiConsensus? c) {
    final rows=<Widget>[];
    for(final tf in ['15m','1h']) {
      final r=_altFinsValidation[tf]; if(r==null || r['usableForAnalysis']!=true) continue;
      final rawData = r['data'];
      final data = rawData is Map ? Map<String, dynamic>.from(rawData) : <String, dynamic>{};
      if(data.isEmpty) continue;
      final alt=_altDirection(data);
      final technicalReport = report is TechnicalReport ? report : null;
      final technical=_technicalTimeframeDirection(technicalReport,tf);
      final aiTf=_aiTimeframeConsensus(c,tf);
      Widget alignLine(String name,String direction)=>Padding(padding:const EdgeInsets.only(top:3),child:Row(children:[Expanded(child:Text(name,style:const TextStyle(fontSize:10,color:Colors.white60))),Text(_alignment(alt,direction),style:TextStyle(fontSize:10,fontWeight:FontWeight.bold,color:_alignment(alt,direction)=='هم‌راستا'?const Color(0xFF46D6B3):_alignment(alt,direction)=='ناهم‌راستا'?Colors.orangeAccent:Colors.white54))]));
      rows.add(Container(margin:const EdgeInsets.only(top:8),padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFF0D1726),borderRadius:BorderRadius.circular(10)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Row(children:[Expanded(child:Text('altFINS SPOT • ${tf.toUpperCase()}',style:const TextStyle(fontWeight:FontWeight.bold))),Text(_directionLabel(alt),style:TextStyle(fontWeight:FontWeight.bold,color:alt=='BUY'?const Color(0xFF46D6B3):alt=='SELL'?const Color(0xFFF06470):Colors.amber))]),
        const SizedBox(height:5),Text(_altInterpretation(data),style:const TextStyle(fontSize:11,color:Colors.white70,height:1.45)),
        const SizedBox(height:6),const Text('هم‌سنجی هم‌تایم‌فریم',style:TextStyle(fontSize:10,fontWeight:FontWeight.bold,color:Colors.white54)),
        alignLine('Technical ${tf.toUpperCase()}',technical),
        if(c!=null) ...[
          alignLine('اجماع AI ${tf.toUpperCase()}',aiTf),
          alignLine('Gemini ${tf.toUpperCase()}',_aiTimeframeDirection(c.gemini,tf)),
          alignLine('OpenRouter ${tf.toUpperCase()}',_aiTimeframeDirection(c.openrouter,tf)),
          alignLine('Groq ${tf.toUpperCase()}',_aiTimeframeDirection(c.groq,tf)),
        ],
      ])));
    }
    return Card(child:Padding(padding:const EdgeInsets.all(13),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Row(children:[Icon(Icons.insights,color:Color(0xFF8CE5CF)),SizedBox(width:7),Expanded(child:Text('Market Intelligence • تفسیر و هم‌سنجی',style:TextStyle(fontWeight:FontWeight.bold,fontSize:15)))]),
      const SizedBox(height:5),
      const Text('مقایسه هر تایم‌فریم فقط با داده همان تایم‌فریم انجام می‌شود؛ مدل ناقص، شواهد تأییدنشده یا Snapshot قدیمی در اجماع وارد نمی‌شود. altFINS صرفاً منبع کمکی است و در تصمیم نهایی دخالت ندارد.',style:TextStyle(fontSize:10,color:Colors.white54,height:1.4)),
      if(rows.isEmpty)const Padding(padding:EdgeInsets.only(top:8),child:Text('پس از دریافت داده تازه 15M و 1H، تفسیر و هم‌سنجی اینجا نمایش داده می‌شود.',style:TextStyle(fontSize:11,color:Colors.white54))) else ...rows,
    ])));
  }


  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:Listenable.merge([widget.state,widget.analysis]),
    builder:(context,_)=>ListView(padding:const EdgeInsets.all(18),children:[
      const Text('Market Intelligence و altFINS',style:TextStyle(fontSize:23,fontWeight:FontWeight.bold)),
      const SizedBox(height:6),
      Text('${widget.state.symbol} • ${widget.state.exchange}',style:const TextStyle(color:Colors.white60)),
      const SizedBox(height:12),
      _altFinsCard(),
      _marketIntelCard(widget.analysis.report,consensus),
    ]),
  );
}
