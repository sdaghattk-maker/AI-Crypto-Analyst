
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import '../services/analysis_controller.dart';
import '../services/ai_service.dart';
import '../services/hybrid_engine.dart';

class AiAnalysisScreen extends StatefulWidget{
  const AiAnalysisScreen({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  @override State<AiAnalysisScreen> createState()=>_AiAnalysisScreenState();
}
class _AiAnalysisScreenState extends State<AiAnalysisScreen>{
  final AiService ai=AiService();
  final HybridEngine hybridEngine=HybridEngine();
  bool aiLoading=false;
  String status='برای شروع، ابتدا تحلیل تکنیکال سه تایم‌فریم اجرا می‌شود.';
  String? error;
  final Map<String, TextEditingController> _modelControllers = {
    'gemini': TextEditingController(text: 'gemini-3.8-flash'),
    'openrouter': TextEditingController(text: 'qwen/qwen3.8-27b:free'),
    'groq': TextEditingController(text: 'openai/gpt-oss-120b'),
  };
  final Map<String, TextEditingController> _fallbackControllers = {
    'gemini': TextEditingController(text: 'gemini-3.7-flash'),
    'openrouter': TextEditingController(text: 'qwen/qwen3.8-27b:free'),
    'groq': TextEditingController(text: 'qwen/qwen3.8-27b'),
  };
  final Map<String, bool> _providerEnabled = {'gemini': true, 'openrouter': true, 'groq': true};
  bool _settingsLoaded = false;
  final Map<String,List<String>> _availableModels = {};
  String? _catalogError;
  bool _catalogLoading = false;
  AiConsensus? get consensus {
    final value = widget.analysis.consensus;
    // Only this exact snapshot may participate in current decisions or retries.
    return value != null && value.snapshotId != null &&
            value.snapshotId == widget.analysis.snapshotId ? value : null;
  }

  AiConsensus? get displayConsensus => consensus ?? widget.analysis.latestHistoricalConsensus;
  bool get showingHistoricalConsensus => consensus == null && displayConsensus != null;

  AiModelResult? _displayProviderResult(String provider) {
    final active = consensus;
    final activeResult = switch (provider) {
      'gemini' => active?.gemini,
      'openrouter' => active?.openrouter,
      'groq' => active?.groq,
      _ => null,
    };
    if (activeResult != null && activeResult.status != 'not_selected' && activeResult.status != 'error') return activeResult;
    return widget.analysis.historicalProviderResult(provider) ?? activeResult;
  }

  bool _providerResultIsHistorical(String provider) {
    final active = consensus;
    final activeResult = switch (provider) {
      'gemini' => active?.gemini,
      'openrouter' => active?.openrouter,
      'groq' => active?.groq,
      _ => null,
    };
    if (activeResult != null && activeResult.status != 'not_selected' && activeResult.status != 'error') return false;
    return widget.analysis.historicalProviderResult(provider) != null;
  }

  @override void initState(){ super.initState(); _initializeSettingsAndCatalog(); }
  Future<void> _initializeSettingsAndCatalog() async {
    await _loadAiSettings();
    if (mounted) await _loadModelCatalog();
  }
  @override void dispose(){ for(final c in _modelControllers.values){c.dispose();} for(final c in _fallbackControllers.values){c.dispose();} super.dispose(); }
  Future<void> _loadAiSettings() async {
    final prefs=await SharedPreferences.getInstance();
    // One-time migration: earlier builds may have persisted only Groq as
    // enabled. Enable all independent providers once on this upgrade; after
    // migration, explicit user switch changes are preserved.
    const migrationKey = 'ai_provider_selection_migration_v6331';
    if (prefs.getBool(migrationKey) != true) {
      for (final key in _modelControllers.keys) {
        await prefs.setBool('ai_provider_$key', true);
      }
      await prefs.setBool(migrationKey, true);
    }
    if(!mounted)return;
    setState((){
      for(final key in _modelControllers.keys){
        _modelControllers[key]!.text=prefs.getString('ai_model_$key')??_modelControllers[key]!.text;
        _fallbackControllers[key]!.text=prefs.getString('ai_fallback_model_$key')??_fallbackControllers[key]!.text;
        _providerEnabled[key]=prefs.getBool('ai_provider_$key')??true;
      }
      _settingsLoaded=true;
    });
  }
  // The Worker is the single source of truth for live account-eligible models.
  // Preserve its capability-ranked order; a Flutter-side static shortlist can
  // hide newly released models or models available only to this provider key.
  List<String> _rankedModelsFor(String provider, List<String> live) {
    return List<String>.unmodifiable(<String>{
      for (final model in live)
        if (model.trim().isNotEmpty) model.trim(),
    });
  }

  Future<void> _loadModelCatalog() async {
    if (_catalogLoading) return;
    setState(() => _catalogLoading = true);
    try {
      final models = await ai.fetchModelCatalog();
      if (!mounted) return;
      setState(() {
        for (final key in ['gemini','openrouter','groq']) {
          _availableModels[key] = _rankedModelsFor(key, models[key] ?? const <String>[]);
          // Keep saved selection if it still exists; otherwise choose a valid live model.
          final list = _availableModels[key]!;
          if (list.isNotEmpty && !list.contains(_modelControllers[key]!.text)) {
            _modelControllers[key]!.text = list.first;
          }
          if (list.isNotEmpty && (!list.contains(_fallbackControllers[key]!.text) || _fallbackControllers[key]!.text == _modelControllers[key]!.text)) {
            _fallbackControllers[key]!.text = list.firstWhere((m) => m != _modelControllers[key]!.text, orElse: () => list.first);
          }
        }
        _catalogError = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _catalogError = e.toString());
    } finally {
      if (mounted) setState(() => _catalogLoading = false);
    }
  }
  Future<void> _saveAiSettings() async {
    final prefs=await SharedPreferences.getInstance();
    for(final key in _modelControllers.keys){
      final model=_modelControllers[key]!.text.trim();
      if(model.isNotEmpty) await prefs.setString('ai_model_$key',model);
      final fallback=_fallbackControllers[key]!.text.trim();
      if(fallback.isNotEmpty) await prefs.setString('ai_fallback_model_$key',fallback);
      await prefs.setBool('ai_provider_$key',_providerEnabled[key]??false);
    }
  }

  List<String> get _failedProviders {
    final current = consensus;
    if (current == null) return const [];
    final results = <String, AiModelResult>{
      'gemini': current.gemini,
      'openrouter': current.openrouter,
      'groq': current.groq,
    };
    return results.entries
        .where((e) => (_providerEnabled[e.key] ?? false) &&
            e.value.status != 'not_selected' && !aiModelIsConsensusEligible(e.value))
        .map((e) => e.key)
        .toList();
  }

  Future<void> _runAiProviders(List<String> providers, {required String label}) async {
    final report = widget.analysis.report;
    if (report == null || widget.analysis.snapshotId == null ||
        widget.analysis.latestReferencePrice == null ||
        widget.analysis.latestReferencePrice! <= 0 ||
        widget.analysis.history1h.isEmpty || widget.analysis.history15m.isEmpty ||
        widget.analysis.history5m.isEmpty) {
      if (mounted) setState(() { aiLoading = false; error = 'Snapshot معتبر شامل قیمت مرجع و تاریخچه کندل در دسترس نیست؛ ابتدا تحلیل کامل و تازه را اجرا کنید.'; });
      return;
    }
    // Never retry a disabled provider or call a provider that already succeeded
    // for this exact snapshot. This protects quotas and preserves good answers.
    final current = consensus;
    final currentResults = current == null ? <String, AiModelResult>{} : <String, AiModelResult>{
      'gemini': current.gemini, 'openrouter': current.openrouter, 'groq': current.groq,
    };
    final eligibleProviders = providers.where((provider) =>
      (_providerEnabled[provider] ?? false) &&
      !aiModelIsConsensusEligible(currentResults[provider] ??
        const AiModelResult(model: 'unknown', status: 'not_selected'))).toList();
    if (eligibleProviders.isEmpty) {
      if (mounted) setState(() { aiLoading = false; status = 'مدل فعالِ نیازمند اجرا وجود ندارد؛ نتایج قبلی حفظ شدند و درخواست تکراری ارسال نشد.'; });
      return;
    }
    final requestedExchange = widget.state.exchange;
    final requestedSymbol = widget.state.symbol;
    final snapshot = widget.analysis.snapshotId;
    final generation = widget.analysis.requestGeneration;
    // Freeze the complete request payload before the first await.
    final snapshotHistory1h = widget.analysis.history1h;
    final snapshotHistory15m = widget.analysis.history15m;
    final snapshotHistory5m = widget.analysis.history5m;
    final snapshotReferencePrice = widget.analysis.latestReferencePrice!;
    setState(() { aiLoading = true; error = null; status = '$label: ${eligibleProviders.join(', ')}'; });
    widget.analysis.setProvidersRunning(eligibleProviders);
    try {
      await _saveAiSettings();
      if (widget.state.exchange != requestedExchange ||
          widget.state.symbol != requestedSymbol ||
          widget.analysis.snapshotId != snapshot ||
          widget.analysis.requestGeneration != generation ||
          widget.analysis.report != report) {
        if (mounted) setState(() { aiLoading = false; status = 'Snapshot یا نسل درخواست پیش از ارسال تغییر کرد؛ درخواست قدیمی ارسال نشد.'; });
        return;
      }
      final result = await ai.analyze(
        exchange: requestedExchange,
        symbol: requestedSymbol,
        history1h: snapshotHistory1h,
        history15m: snapshotHistory15m,
        history5m: snapshotHistory5m,
        modelSelection: {for (final e in _modelControllers.entries) e.key: e.value.text.trim()},
        fallbackSelection: {for (final e in _fallbackControllers.entries) e.key: e.value.text.trim()},
        selectedProviders: eligibleProviders,
        snapshotId: snapshot,
        referencePrice: snapshotReferencePrice,
      );
      if (!mounted) return;
      if (widget.state.exchange != requestedExchange || widget.state.symbol != requestedSymbol ||
          widget.analysis.snapshotId != snapshot ||
          widget.analysis.requestGeneration != generation || widget.analysis.report != report) {
        setState(() { aiLoading = false; status = 'پاسخ دیررس به علت تغییر نماد، تایم‌فریم یا Snapshot کنار گذاشته شد.'; });
        return;
      }
      final saved = await widget.analysis.saveConsensus(result, mergeSameSnapshot: true);
      if (!mounted) return;
      if (!saved) {
        setState(() { aiLoading = false; status = 'پاسخ دریافت شد اما Snapshot تغییر کرده بود؛ پاسخ قدیمی ذخیره نشد.'; });
        return;
      }
      final stillFailed = _failedProviders;
      setState(() {
        aiLoading = false;
        status = stillFailed.isEmpty
            ? 'مدل‌های فعال و اجراشده برای همین Snapshot پاسخ معتبر دارند.'
            : 'پاسخ‌ها ذخیره شد؛ هنوز بدون پاسخ معتبر: ${stillFailed.join(', ')}. فقط همین مدل‌های فعال را دوباره اجرا کنید.';
      });
    } catch (e) {
      if (!mounted) return;
      final failure = AiConsensus(
        gemini: eligibleProviders.contains('gemini') ? AiModelResult(model: 'Gemini', status: 'error', error: e.toString()) : const AiModelResult(model: 'Gemini', status: 'not_selected'),
        openrouter: eligibleProviders.contains('openrouter') ? AiModelResult(model: 'OpenRouter', status: 'error', error: e.toString()) : const AiModelResult(model: 'OpenRouter', status: 'not_selected'),
        groq: eligibleProviders.contains('groq') ? AiModelResult(model: 'Groq', status: 'error', error: e.toString()) : const AiModelResult(model: 'Groq', status: 'not_selected'),
        decision: 'WAIT', conflicts: [e.toString()], snapshotId: snapshot,
      );
      if (widget.analysis.requestGeneration == generation && widget.analysis.snapshotId == snapshot) {
        await widget.analysis.saveConsensus(failure, mergeSameSnapshot: true);
      }
      if (!mounted) return;
      setState(() {
        aiLoading = false;
        error = e.toString();
        status = 'ارتباط ناموفق بود؛ پاسخ‌های موفق قبلی حفظ شدند. فقط مدل‌های فعال و ناموفق قابل تلاش مجدد هستند.';
      });
    }
  }

  Future<void> _retryFailedOnly() async {
    final failed = _failedProviders;
    if (failed.isEmpty) return;
    const owner = 'ai-retry';
    if (!widget.analysis.acquireWorkflow(owner)) {
      if (mounted) setState(() => status = 'تحلیل دیگری در حال اجراست؛ پس از پایان آن دوباره تلاش کنید.');
      return;
    }
    try {
      await _runAiProviders(failed, label: 'تلاش مجدد فقط برای مدل‌های ناموفق و فعال');
    } finally {
      widget.analysis.releaseWorkflow(owner);
    }
  }

  Future<void> _runFullAnalysis() async {
    const owner = 'ai-full-analysis';
    if (!widget.analysis.acquireWorkflow(owner)) {
      if (mounted) setState(() => status = 'تحلیل دیگری از داشبورد یا صفحه هوشمند در حال اجراست؛ از ارسال درخواست موازی جلوگیری شد.');
      return;
    }
    try {
      await _saveAiSettings();
      final selectedProviders = _providerEnabled.entries
          .where((e) => e.value).map((e) => e.key).toList();
      // Technical refresh is independent from AI provider selection. Even
      // with all providers disabled, refresh the market/technical snapshot and
      // preserve prior AI answers as historical display-only results.
      if (mounted) setState(() { aiLoading = true; error = null; status = 'در حال اجرای موتور تکنیکال...'; });
      final completed = await widget.analysis.run(lockAlreadyHeld: true);
      if (!mounted) return;
      if (!completed) {
        setState(() { aiLoading = false; error = widget.analysis.error ?? 'تحلیل جدید تکمیل نشد؛ تحلیل قبلی حفظ شده است.'; status = 'درخواست AI ارسال نشد.'; });
        return;
      }
      if (widget.analysis.report == null) {
        setState(() { aiLoading = false; error = 'تحلیل تکنیکال انجام نشد.'; status = 'تحلیل AI متوقف شد.'; });
        return;
      }
      if (selectedProviders.isEmpty) {
        if (mounted) setState(() {
          aiLoading = false;
          error = null;
          status = 'تحلیل تکنیکال تازه شد؛ هر سه مدل AI غیرفعال‌اند، هیچ درخواست AI ارسال نشد و نتایج قبلی در تاریخچه حفظ شدند.';
        });
        return;
      }
      if (!ai.isConfigured) {
        setState(() { aiLoading = false; status = 'موتور تکنیکال آماده است؛ اتصال AI Gateway در انتظار تنظیم است.'; });
        return;
      }
      await _runAiProviders(selectedProviders, label: 'ارسال Snapshot تازه به مدل‌های فعال');
    } finally {
      if (mounted) setState(() => aiLoading = false);
      widget.analysis.releaseWorkflow(owner);
    }
  }

  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:Listenable.merge([widget.state,widget.analysis]),
    builder:(context,_){
      final report=widget.analysis.report;
      return ListView(padding:const EdgeInsets.all(18),children:[
        const SizedBox(height:8),
        const Text('گزارش تحلیل AI',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        Text('${widget.state.symbol} • ${widget.state.exchange}',style:const TextStyle(color:Colors.white60)),
        const SizedBox(height:8),
        if(widget.analysis.report!=null) Card(child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[
          Icon(widget.analysis.isStale?Icons.warning_amber_rounded:Icons.check_circle_outline,
            color:widget.analysis.isStale?Colors.orangeAccent:const Color(0xFF46D6B3)),
          const SizedBox(width:8),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(widget.analysis.isStale?'تحلیل ذخیره‌شده قدیمی است':'آخرین تحلیل ذخیره و بازیابی شده',style:const TextStyle(fontWeight:FontWeight.bold)),
            Text('زمان تحلیل: ${widget.analysis.technicalAt?.toLocal().toString().substring(0,16) ?? '—'}',style:const TextStyle(fontSize:11,color:Colors.white60)),
            if(widget.analysis.technicalAt!=null) Text('سن تحلیل: ${_age(widget.analysis.technicalAt!)}',style:const TextStyle(fontSize:11,color:Colors.white60)),
            if(widget.analysis.aiAt!=null) Text('پاسخ AI: ${widget.analysis.aiAt!.toLocal().toString().substring(0,16)} • ${widget.analysis.isAiStale ? 'قدیمی' : 'تازه'}',style:TextStyle(fontSize:11,color:widget.analysis.isAiStale?Colors.orangeAccent:Colors.white60)),
            Text('تاریخچه کندل بسته‌شده: 1H ${widget.analysis.historyCount1h} • 15M ${widget.analysis.historyCount15m} • 5M ${widget.analysis.historyCount5m}',style:const TextStyle(fontSize:11,color:Colors.white60)),
          ])),
          Text(widget.analysis.isStale?'قدیمی':'تازه',style:TextStyle(color:widget.analysis.isStale?Colors.orangeAccent:const Color(0xFF46D6B3))),
        ]))),
        const SizedBox(height:14),
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('اجرای تحلیل کامل',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),
          const Text('کندل‌های بسته‌شده 1H، 15M و 5M پس از ذخیره در یک Snapshot ثابت، مستقل برای هر مدل ارسال می‌شوند. پاسخ هر مدل جداگانه نگهداری می‌شود. تحلیل تکنیکال مستقل باقی می‌ماند و منبع رسم چارت طبق انتخاب شما فقط تکنیکال یا AI است.'),
          const SizedBox(height:10),
          SizedBox(width:double.infinity,child:FilledButton.icon(
            onPressed:widget.analysis.workflowBusy?null:_runFullAnalysis,
            icon:widget.analysis.workflowBusy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.psychology),
            label:Text(widget.analysis.workflowBusy?'در حال تحلیل...':'اجرای تحلیل با مدل‌های انتخاب‌شده'),
          )),
          if (_failedProviders.isNotEmpty) ...[
            const SizedBox(height:8),
            SizedBox(width:double.infinity,child:OutlinedButton.icon(
              onPressed:widget.analysis.workflowBusy?null:_retryFailedOnly,
              icon:const Icon(Icons.replay),
              label:Text('تلاش مجدد فقط برای ${_failedProviders.length} مدل ناموفق'),
            )),
            const Padding(padding:EdgeInsets.only(top:4),child:Text('پاسخ‌های موفق قبلی حفظ می‌شوند و دوباره درخواست نمی‌خورند؛ فقط مدل‌های ناموفق برای همان Snapshot اجرا می‌شوند.',style:TextStyle(fontSize:10,color:Colors.white54))),
          ],
          const SizedBox(height:8),
          Text(status,style:const TextStyle(color:Colors.white70,fontSize:12)),
          Text('ارائه‌دهنده‌های انتخاب‌شده: ${_providerEnabled.entries.where((e)=>e.value).map((e)=>e.key.toUpperCase()).join('، ').isEmpty ? 'هیچ‌کدام' : _providerEnabled.entries.where((e)=>e.value).map((e)=>e.key.toUpperCase()).join('، ')}',style:const TextStyle(color:Color(0xFF8CE5CF),fontSize:11,fontWeight:FontWeight.w600)),
          Text('وضعیت: Gemini ${_providerEnabled['gemini'] == true ? widget.analysis.providerExecutionStatus['gemini'] : 'غیرفعال (نتیجه حفظ شده)'} • OpenRouter ${_providerEnabled['openrouter'] == true ? widget.analysis.providerExecutionStatus['openrouter'] : 'غیرفعال (نتیجه حفظ شده)'} • Groq ${_providerEnabled['groq'] == true ? widget.analysis.providerExecutionStatus['groq'] : 'غیرفعال (نتیجه حفظ شده)'}',style:const TextStyle(color:Colors.white38,fontSize:10)),
          if(widget.analysis.restoring) const Padding(padding:EdgeInsets.only(top:6),child:LinearProgressIndicator()),
          if(error!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(error!,style:const TextStyle(color:Colors.orangeAccent))),
        ]))),
        if(report!=null)...[
          _section('گزارش فنی مبنا'),
          Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('سیگنال تکنیکال: ${report.state.toString().split('.').last.toUpperCase()}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
            Text('سوگیری 1H: ${report.bias1h.toString().split('.').last} | 15M: ${report.bias15m.toString().split('.').last} | 5M: ${report.bias5m.toString().split('.').last}'),
            const SizedBox(height:8),
            Text(report.powerAvailable?'برآورد فشار کندلی OHLCV خریدار ${report.buyerPower}% • فروشنده ${report.sellerPower}%':'داده حجم معتبر برای برآورد فشار خریدار/فروشنده کافی نیست.'),
            if(report.entry!=null)Text('Entry ${_p(report.entry)} | SL ${_p(report.stopLoss)} | TP ${_p(report.tp1)} / ${_p(report.tp2)} / ${_p(report.tp3)}'),
            ...report.reasons.map((x)=>Text('• $x')),
            if(report.poiSummary.isNotEmpty)const Padding(padding:EdgeInsets.only(top:10),child:Text('ساختار و نواحی مهم بازار',style:TextStyle(fontWeight:FontWeight.bold))),
            ...report.poiSummary.map((x)=>Text('• $x',style:const TextStyle(color:Color(0xFF8CE5CF)))),
            ...report.warnings.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent))),
          ]))),
        ],
        _section('وضعیت مدل‌ها'),
        if (showingHistoricalConsensus) Card(color:const Color(0xFF332A19),child:const Padding(padding:EdgeInsets.all(10),child:Text('نتایج زیر متعلق به تحلیل قبلی هستند؛ برای تصمیم و اجماع Snapshot فعلی استفاده نمی‌شوند.',style:TextStyle(color:Colors.orangeAccent,fontSize:12)))),
        _modelCard('Gemini','تحلیل مستقل تاریخچه 1H/15M/5M و سناریوها${_providerResultIsHistorical('gemini') ? ' • آخرین نتیجه معتبر قبلی' : ''}',_displayProviderResult('gemini')),
        _modelCard('OpenRouter','تحلیل مستقل همان Snapshot${_providerResultIsHistorical('openrouter') ? ' • آخرین نتیجه معتبر قبلی' : ''}',_displayProviderResult('openrouter')),
        _modelCard('Groq','تحلیل مستقل همان Snapshot${_providerResultIsHistorical('groq') ? ' • آخرین نتیجه معتبر قبلی' : ''}',_displayProviderResult('groq')),
        if(report!=null && consensus!=null && !widget.analysis.isStale && !widget.analysis.isAiStale)...[
          _section('ارزیابی تأییدی هر مدل در کنار تکنیکال'),
          const Padding(padding:EdgeInsets.only(bottom:8),child:Text('هر مدل امتیاز عوامل را مستقل گزارش می‌کند؛ برای جلوگیری از اتکا به وزن‌های خوداظهاری، وزن عوامل AI در این کارت فعلاً برابر است. این امتیازها تشخیصی‌اند؛ تصمیم نهایی فقط با جهت معتبر تکنیکال و اجماع حداقل دو مدل هم‌جهت صادر می‌شود.',style:TextStyle(fontSize:11,color:Colors.white60))),
          _hybridCard(hybridEngine.evaluate(report,consensus!.gemini)),
          _hybridCard(hybridEngine.evaluate(report,consensus!.openrouter)),
          _hybridCard(hybridEngine.evaluate(report,consensus!.groq)),
        ],
        if(report!=null && consensus!=null && (widget.analysis.isStale || widget.analysis.isAiStale))
          const Padding(padding:EdgeInsets.only(top:8),child:Text('تحلیل تکنیکال یا AI قدیمی است؛ ارزیابی تأییدی برای تصمیم جدید نمایش داده نمی‌شود.',style:TextStyle(fontSize:11,color:Colors.orangeAccent))),
        if(displayConsensus?.snapshotId!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text('شناسه Snapshot: ${displayConsensus!.snapshotId}',style:const TextStyle(fontSize:10,color:Colors.white38))),
        if(displayConsensus!=null)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(showingHistoricalConsensus?'اجماع تحلیل قبلی (صرفاً جهت مشاهده)':'اجماع مستقل مدل‌های هوش مصنوعی',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
          const SizedBox(height:8),
          Text(displayConsensus!.decision.toUpperCase(),style:TextStyle(fontSize:24,fontWeight:FontWeight.bold,color:displayConsensus!.decision.toUpperCase()=='WAIT'?Colors.amber:const Color(0xFF46D6B3))),
          ...displayConsensus!.conflicts.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent))),
        ]))),
        if(!ai.isConfigured)Card(child:Padding(padding:const EdgeInsets.all(14),child:const Text(
          'اتصال AI Gateway فعال نیست: آدرس Worker باید در GitHub Actions با Secret به نام AI_GATEWAY_BASE_URL تنظیم شود و کلیدهای Gemini، Groq و OpenRouter فقط به‌صورت Secret در Cloudflare نگهداری شوند. کلید API نباید داخل APK قرار گیرد.',
          style:TextStyle(color:Colors.amber),
        ))),
        const SizedBox(height:12),
        const Text('سیاست تحلیل: هر ارائه‌دهنده AI مستقل از موتور تکنیکال و سایر مدل‌ها تصمیم می‌گیرد. خروجی، جهت، دلایل و سطوح هر مدل جداگانه نمایش داده می‌شود؛ نتیجه اجماع صرفاً یک نمای کمکی است و تصمیم مستقل هیچ مدلی را تغییر نمی‌دهد. منبع رسم نمودار فقط از انتخاب شما پیروی می‌کند.'),
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Row(children:[Icon(Icons.tune,color:Color(0xFF8CE5CF)),SizedBox(width:8),Text('تنظیمات هوشمند',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold))]),
          const SizedBox(height:8),
          const Text('انتخاب ارائه‌دهنده‌ها و مدل اصلی/جایگزین. این بخش در انتهای صفحه تحلیل AI نگهداری می‌شود.',style:TextStyle(fontSize:11,color:Colors.white60)),
          if(!_settingsLoaded) const LinearProgressIndicator(),
          ..._modelControllers.entries.map((entry)=>_modelSetting(entry.key,entry.value,_fallbackControllers[entry.key]!)),
          if(_catalogError!=null) Padding(padding:const EdgeInsets.only(top:4),child:Text('فهرست مدل‌ها دریافت نشد؛ شناسه را دستی وارد کنید. $_catalogError',style:const TextStyle(fontSize:11,color:Colors.orangeAccent))),
          Align(alignment:Alignment.centerLeft,child:TextButton.icon(onPressed:_catalogLoading?null:_loadModelCatalog,icon:_catalogLoading?const SizedBox(width:16,height:16,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.refresh,size:16),label:Text(_catalogLoading?'در حال دریافت مدل‌های فعال...':'به‌روزرسانی زنده فهرست مدل‌ها'))),
        ]))),
      ]);
    },
  );

  Widget _modelSetting(String key,TextEditingController controller,TextEditingController fallbackController){
    final labels={'gemini':'Google Gemini','openrouter':'OpenRouter','groq':'Groq'};
    final models=_availableModels[key]??const <String>[];
    final enabled=_providerEnabled[key]??false;
    final rankedNames=models.asMap().entries.map((e)=>'${e.key+1}) ${e.value}').join('  ←  ');
    Widget modelDropdown(String value, String label, ValueChanged<String?> onChanged) =>
      Directionality(textDirection:TextDirection.rtl,child:DropdownButtonFormField<String>(
        value:models.contains(value)?value:null,
        isExpanded:true,
        decoration:InputDecoration(labelText:label,isDense:true,border:const OutlineInputBorder(),floatingLabelBehavior:FloatingLabelBehavior.always),
        items:models.map((m)=>DropdownMenuItem<String>(value:m,child:Directionality(textDirection:TextDirection.ltr,child:Align(alignment:Alignment.centerLeft,child:Text(m,textAlign:TextAlign.left,maxLines:1,softWrap:false,overflow:TextOverflow.ellipsis,style:const TextStyle(fontFamily:'monospace',fontSize:12)))))).toList(),
        selectedItemBuilder:(context)=>models.map((m)=>Align(alignment:Alignment.centerLeft,child:Directionality(textDirection:TextDirection.ltr,child:Text(m,textDirection:TextDirection.ltr,textAlign:TextAlign.left,maxLines:1,overflow:TextOverflow.ellipsis,softWrap:false,style:const TextStyle(fontFamily:'monospace',fontSize:12))))).toList(),
        onChanged:enabled?onChanged:null,
      ));
    InputDecoration idDecoration(String label,String hint)=>InputDecoration(labelText:label,hintText:hint,isDense:true,border:const OutlineInputBorder(),floatingLabelBehavior:FloatingLabelBehavior.always,alignLabelWithHint:true);
    return Card(color:const Color(0xFF10182A),child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      SwitchListTile(contentPadding:EdgeInsets.zero,dense:true,title:Text(labels[key]??key),value:enabled,onChanged:(v)=>setState(()=>_providerEnabled[key]=v)),
      if(models.isNotEmpty) Padding(padding:const EdgeInsets.only(bottom:8),child:Text('اولویت انتخاب بر اساس قابلیت عمومی (نه دقت معاملاتی اثبات‌شده): $rankedNames',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:10,color:Colors.white60))),
      if(models.isNotEmpty) modelDropdown(controller.text,'انتخاب مدل فعال اصلی',(v){if(v!=null)setState(()=>controller.text=v);}),
      const SizedBox(height:10),
      Directionality(textDirection:TextDirection.ltr,child:TextField(controller:controller,enabled:enabled,textDirection:TextDirection.ltr,textAlign:TextAlign.left,textAlignVertical:TextAlignVertical.center,style:const TextStyle(fontFamily:'monospace',fontSize:13),decoration:idDecoration('مدل اصلی (شناسه دقیق)','provider/model-id'))),
      const SizedBox(height:10),
      if(models.isNotEmpty) modelDropdown(fallbackController.text,'انتخاب مدل جایگزین فعال',(v){if(v!=null)setState(()=>fallbackController.text=v);}),
      const SizedBox(height:10),
      Directionality(textDirection:TextDirection.ltr,child:TextField(controller:fallbackController,enabled:enabled,textDirection:TextDirection.ltr,textAlign:TextAlign.left,textAlignVertical:TextAlignVertical.center,style:const TextStyle(fontFamily:'monospace',fontSize:13),decoration:idDecoration('مدل جایگزین (شناسه دقیق)','provider/fallback-model'))),
    ])));
  }
  Widget _section(String s)=>Padding(padding:const EdgeInsets.only(top:18,bottom:8),child:Text(s,style:const TextStyle(fontSize:16,fontWeight:FontWeight.bold)));
  Widget _hybridCard(HybridDecision d){
    final color=d.decision=='BUY'?const Color(0xFF28C99A):d.decision=='SELL'?const Color(0xFFF06470):const Color(0xFFE7B84E);
    String weights(Map<String,int> values)=>values.entries.map((e)=>'${HybridEngine.labels[e.key]??e.key} ${e.value}%').join('  •  ');
    return Card(color:const Color(0xFF111A2B),child:Padding(padding:const EdgeInsets.all(13),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Expanded(child:Text('تکنیکال + ${d.provider}',style:const TextStyle(fontWeight:FontWeight.bold))),Text(d.decision,style:TextStyle(fontSize:19,fontWeight:FontWeight.bold,color:color))]),
      Text('امتیاز مقایسه‌ای: ${d.score.toStringAsFixed(1)} | شواهد تکنیکال: ${d.technicalScore.toStringAsFixed(1)} | شواهد AI: ${d.aiScore.toStringAsFixed(1)}',style:const TextStyle(fontSize:11,color:Colors.white70)),
      const SizedBox(height:7),const Text('وزن‌های تکنیکال',style:TextStyle(fontWeight:FontWeight.bold,fontSize:11)),
      Text(weights(d.technicalWeights),style:const TextStyle(fontSize:10,color:Colors.white60,height:1.5)),
      const SizedBox(height:5),const Text('وزن‌های برابر AI (موقت)',style:TextStyle(fontWeight:FontWeight.bold,fontSize:11)),
      Text(weights(d.aiWeights),style:const TextStyle(fontSize:10,color:Colors.white60,height:1.5)),
      ...d.reasons.map((x)=>Text('• $x',style:const TextStyle(fontSize:11,color:Colors.orangeAccent))),
      Text(d.calibration,style:const TextStyle(fontSize:10,color:Colors.white38)),
    ])));
  }

  Widget _modelCard(String name,String role,AiModelResult? result){
    final bias=((result?.marketBias ?? result?.bias)??'').toUpperCase();
    final Color tone=bias=='BUY'?const Color(0xFF28C99A):bias=='SELL'?const Color(0xFFF06470):const Color(0xFFE7B84E);
    final String direction=bias=='BUY'?'خرید':bias=='SELL'?'فروش':bias=='WAIT'?'انتظار':'نامشخص';
    final String statusLabel=result?.status=='ok'?'پاسخ دریافت شد':result?.status=='error'?'خطا':result?.status=='not_selected'?'انتخاب نشده':(result?.status??'در انتظار');
    final overlays=result?.overlays??const <Map<String,dynamic>>[];
    String overlayName(dynamic value){
      const names={'Swing High':'سقف نوسانی','Swing Low':'کف نوسانی','FVG':'شکاف ارزش منصفانه','Bullish FVG':'FVG صعودی','Bearish FVG':'FVG نزولی','Bullish OB':'اوردر بلاک صعودی','Bearish OB':'اوردر بلاک نزولی','EQH':'سقف‌های برابر','EQL':'کف‌های برابر','BOS+':'شکست ساختار صعودی','BOS-':'شکست ساختار نزولی','CRT-H':'سقف CRT','CRT-L':'کف CRT','EQ':'تعادل'};
      return names[value?.toString()]??value?.toString()??'ناحیه';
    }
    Widget panel(String title,IconData icon,List<Widget> children,{Color color=Colors.white70}){
      if(children.isEmpty)return const SizedBox.shrink();
      return Container(margin:const EdgeInsets.only(top:10),padding:const EdgeInsets.all(11),decoration:BoxDecoration(color:const Color(0xFF0B1422),borderRadius:BorderRadius.circular(11),border:Border.all(color:color.withOpacity(.20))),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Row(children:[Icon(icon,size:17,color:color),const SizedBox(width:7),Text(title,style:TextStyle(fontWeight:FontWeight.bold,color:color,fontSize:13))]),
        const SizedBox(height:8),...children,
      ]));
    }
    List<Widget> bulletItems(List<String> items)=>items.map((x)=>Padding(padding:const EdgeInsets.only(bottom:6),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[const Padding(padding:EdgeInsets.only(top:5),child:Icon(Icons.circle,size:5,color:Colors.white54)),const SizedBox(width:8),Expanded(child:Text(x,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:12,height:1.45,color:Color(0xE0FFFFFF))))]))).toList();
    final structure=overlays.where((o){final k='${o['kind']??''}'.toLowerCase();return k.contains('bos')||k.contains('swing')||k.contains('eqh')||k.contains('eql')||k.contains('crt')||k=='eq';}).toList();
    final zones=overlays.where((o){final k='${o['kind']??''}'.toLowerCase();return k.contains('fvg')||k.contains('ob')||k.contains('order');}).toList();
    final other=overlays.where((o)=>!structure.contains(o)&&!zones.contains(o)&&!const {'Entry','SL','TP1','TP2','TP3'}.contains(o['kind'])).toList();
    Widget overlayChips(List<Map<String,dynamic>> values){
      if(values.isEmpty)return const SizedBox.shrink();
      return Wrap(spacing:6,runSpacing:6,children:values.map((o){
        final kind=overlayName(o['kind']);final tf=(o['timeframe']??'').toString().toUpperCase();final price=o['price'];final low=o['low'];final high=o['high'];
        final value=price is num?'${price.toStringAsFixed(2)}':(low is num&&high is num?'${low.toStringAsFixed(2)} – ${high.toStringAsFixed(2)}':'');
        final status='${o['status']??'UNSPECIFIED'}';
        final statusFa=({'ACTIVE':'فعال','MITIGATED':'مصرف‌شده','INVALIDATED':'باطل‌شده','PENDING':'در انتظار','UNSPECIFIED':'وضعیت نامشخص'})[status]??'وضعیت نامشخص';
        final timestamp=o['timestamp'];
        final timeLabel=timestamp is num ? DateTime.fromMillisecondsSinceEpoch((timestamp*1000).round()).toLocal().toString().substring(5,16) : '';
        final dir='${o['direction']??''}';final c=status=='MITIGATED'||status=='INVALIDATED'?const Color(0xFF9AA4B2):dir=='bullish'?const Color(0xFF28C99A):dir=='bearish'?const Color(0xFFF06470):const Color(0xFF8DA8C8);
        return Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:6),decoration:BoxDecoration(color:c.withOpacity(.10),borderRadius:BorderRadius.circular(8),border:Border.all(color:c.withOpacity(.25))),child:Text('$kind ${tf.isEmpty?'':'• $tf'} ${value.isEmpty?'':'• $value'} • $statusFa ${timeLabel.isEmpty?'':'• $timeLabel'}',textDirection:TextDirection.rtl,style:TextStyle(fontSize:10,color:c,fontWeight:FontWeight.w600)));
      }).toList());
    }
    return Card(color:const Color(0xFF111A2B),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Row(children:[const Icon(Icons.memory,size:20),const SizedBox(width:8),Expanded(child:Text(name,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16))),
        Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),decoration:BoxDecoration(color:(result?.status=='error'?Colors.redAccent:Colors.tealAccent).withOpacity(.13),borderRadius:BorderRadius.circular(20)),child:Text(statusLabel,style:TextStyle(fontSize:10,color:result?.status=='error'?Colors.redAccent:Colors.tealAccent)))
      ]),
      const SizedBox(height:10),
      if((result?.marketBias ?? result?.bias)!=null && result?.status!='error')Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:tone.withOpacity(.10),border:Border.all(color:tone.withOpacity(.35)),borderRadius:BorderRadius.circular(12)),child:Column(children:[
        Row(children:[Container(width:42,height:42,decoration:BoxDecoration(color:tone.withOpacity(.18),shape:BoxShape.circle),child:Icon(bias=='BUY'?Icons.trending_up:bias=='SELL'?Icons.trending_down:Icons.pause_circle_outline,color:tone,size:25)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(direction,style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:tone)),const Text('تصمیم مستقل این مدل',style:TextStyle(fontSize:10,color:Colors.white60))])),Text(result!.confidenceDeclared&&result!.confidence!=null?'${result!.confidence}%':'—',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold,color:tone))]),
        if(result.confidenceDeclared&&result.confidence!=null) ...[const SizedBox(height:9),ClipRRect(borderRadius:BorderRadius.circular(8),child:LinearProgressIndicator(value:result.confidence!/100,minHeight:8,backgroundColor:Colors.white10,color:tone))],const SizedBox(height:3),Align(alignment:Alignment.centerLeft,child:Text(result.confidenceDeclared?'درصد اطمینان اعلام‌شده توسط مدل':'مدل اطمینان عددی اعلام نکرده است',style:const TextStyle(fontSize:10,color:Colors.white54)))
      ])) else Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Text(result?.status=='error'?'این مدل در این اجرا پاسخ معتبر نداد. کد: ${result?.errorCode??'نامشخص'} | مدل‌های امتحان‌شده: ${result?.attemptedModels.join('، ')??'نامشخص'} | ${result?.error??''}':role,style:const TextStyle(color:Colors.white70,fontSize:12))),
      if(overlays.isNotEmpty) ...[
        const SizedBox(height:10),
        Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFF0B1422),borderRadius:BorderRadius.circular(12),border:Border.all(color:Colors.white12)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Row(children:[Icon(Icons.candlestick_chart_rounded,size:17,color:Color(0xFF8CE5CF)),SizedBox(width:7),Text('نقشه تصویری سطوح استخراج‌شده',style:TextStyle(fontSize:12,fontWeight:FontWeight.bold,color:Color(0xFF8CE5CF)))]),
          const SizedBox(height:7),
          SizedBox(height:158,width:double.infinity,child:CustomPaint(painter:_AiOverlayMapPainter(overlays))),
          const Text('نمای شماتیک قیمت‌ها و نواحی اعلام‌شده توسط همین مدل؛ نه نمودار قیمت زنده.',style:TextStyle(fontSize:9,color:Colors.white38)),
        ])),
      ],
      if(result?.contractVersion==3 || result?.contractStatus=='DEGRADED' || result?.contractStatus=='NORMALIZED') ...[
        panel('اعتبار قالب تحلیل',Icons.verified_outlined,[
          Text(
            result?.directionalVoteEligible == true
              ? 'جهت بازار از تایم‌فریم بالاتر با شواهد مستقل تأیید شده است؛ نقص عامل یا تایم‌فریم دیگر، این رأی را حذف نمی‌کند.'
              : result?.contractStatus=='VALID'
                  ? 'قالب V3 کامل است؛ اما عامل‌های لازم برای رأی جهت بازار هنوز تأیید نشده‌اند.'
                  : result?.contractStatus=='NORMALIZED'
                      ? 'بخشی از عوامل ناقص یا نامعتبرند؛ وضعیت هر عامل مستقل در ادامه نمایش داده می‌شود.'
                      : 'ساختار کلی قرارداد V3 ناقص است؛ وضعیت عوامل معتبر به‌صورت مستقل حفظ می‌شود.',
            textDirection:TextDirection.rtl,
            style:TextStyle(fontSize:11,color:result?.directionalVoteEligible==true?Colors.tealAccent:Colors.orangeAccent)),
        ],color:result?.directionalVoteEligible==true?Colors.tealAccent:Colors.orangeAccent),
      ],
      if(result!=null && result.status=='ok') panel('صلاحیت رأی و برنامه معاملاتی',Icons.fact_check_outlined,[
        Text(result.directionalVoteEligible ? 'رأی جهت بازار: معتبر (${result.marketBias ?? result.bias ?? '—'})' : 'رأی جهت بازار: غیرمعتبر یا تأییدنشده',textDirection:TextDirection.rtl,style:TextStyle(fontSize:11,color:result.directionalVoteEligible?Colors.tealAccent:Colors.orangeAccent,fontWeight:FontWeight.bold)),
        if((result.directionalVoteReason??'').isNotEmpty) Text(result.directionalVoteReason!,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:10,color:Colors.white70)),
        const SizedBox(height:5),
        Text(aiModelHasValidExecutionPlan(result) ? 'برنامه معاملاتی: معتبر و قابل ارزیابی' : 'برنامه معاملاتی: ناقص یا فاقد اعتبار اجرایی؛ این موضوع رأی جهت بازار را حذف نمی‌کند.',textDirection:TextDirection.rtl,style:TextStyle(fontSize:10,color:aiModelHasValidExecutionPlan(result)?Colors.tealAccent:Colors.orangeAccent)),
      ],color:result.directionalVoteEligible?Colors.tealAccent:Colors.orangeAccent),
      if(result?.analysisSections.isNotEmpty==true) ...[
        const SizedBox(height:4),
        ...<String, List<String>>{
          'رژیم بازار و ساختار چندتایم‌فریمی':['regime','structure'],
          'نقدینگی و نقاط علاقه':['liquidity','poi'],
          'تعادل، حجم و مومنتوم':['premiumDiscount','volumeMomentum'],
          'سناریوها و اجرای معامله':['scenarios','execution'],
          'کیفیت داده و محدودیت‌ها':['dataQuality'],
        }.entries.map((group){
          final children=<Widget>[];
          for(final key in group.value){
            final section=result!.analysisSections[key];
            if(section is! Map)continue;
            final state='${section['status']??'INSUFFICIENT_DATA'}';
            final findings=section['findings'] is List ? (section['findings'] as List).map((x)=>x.toString()).where((x)=>x.trim().isNotEmpty).toList() : <String>[];
            final label=({'regime':'رژیم بازار','structure':'ساختار بازار','liquidity':'نقدینگی','poi':'نواحی مهم','premiumDiscount':'Premium / Discount','volumeMomentum':'حجم و مومنتوم','scenarios':'سناریوها','execution':'اجرای معامله','dataQuality':'کیفیت داده'})[key]??key;
            final stateLabel=state=='AVAILABLE'?'قابل ارزیابی':state=='NOT_AVAILABLE'?'داده ارائه نشده':state=='NOT_APPLICABLE'?'نامرتبط':state=='INVALID'?'نامعتبر':state=='NOT_CONFIRMED'?'تأیید نشد':'داده ناکافی';
            final factorMeta=result!.analysisSectionStatus[key];
            final factorReasonCode=factorMeta is Map ? factorMeta['reason']?.toString() : null;
            final factorReason=({'AVAILABLE_REQUIRES_FINDING':'بخش AVAILABLE باید حداقل یک یافته داشته باشد.','FINDINGS_FIELD_MISSING':'فیلد یافته‌ها در پاسخ وجود ندارد.','FINDINGS_SHAPE_INVALID':'ساختار یافته‌های این عامل معتبر نیست.','SECTION_STATUS_MISSING_OR_UNSUPPORTED':'وضعیت این عامل ارائه نشده یا پشتیبانی نمی‌شود.'})[factorReasonCode] ?? factorReasonCode;
            children.add(Padding(padding:const EdgeInsets.only(bottom:7),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
              Text('$label • $stateLabel',textDirection:TextDirection.rtl,style:TextStyle(fontSize:10,color:state=='AVAILABLE'?Colors.tealAccent:state=='INVALID'?Colors.redAccent:Colors.orangeAccent,fontWeight:FontWeight.bold)),
              if(factorReason!=null&&factorReason.isNotEmpty) Text('علت: $factorReason',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:9,color:Colors.orangeAccent)),
              ...findings.take(2).map((x)=>Padding(padding:const EdgeInsets.only(top:3),child:Text('• $x',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:11,height:1.45,color:Colors.white70)))),
            ])));
          }
          return panel(group.key,Icons.analytics_outlined,children,color:const Color(0xFF8DA8C8));
        }),
      ],
      if(result?.factorEvidenceValidation.isNotEmpty==true) panel('اعتبار مستقل عوامل شواهد',Icons.rule_folder_outlined,[
        Text('امتیاز عوامل AI: ${result!.factorScoresStatus=='PROVIDED'?'ارائه‌شده توسط مدل':'ارائه نشده؛ هیچ امتیاز جایگزینی ساخته نشده است.'}',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:10,color:Colors.white70)),
        ...result!.factorEvidenceValidation.entries.map((entry){
          final status='${entry.value}';
          final label=({'trend':'روند','marketStructure':'ساختار بازار','liquidity':'نقدینگی','poi':'نواحی POI','premiumDiscount':'Premium/Discount','volumeMomentum':'حجم و مومنتوم','scenarios':'سناریوها','execution':'اجرا','dataQuality':'کیفیت داده'})[entry.key]??entry.key;
          final good=status=='VALIDATED'||status=='AVAILABLE';
          return Padding(padding:const EdgeInsets.only(bottom:4),child:Text('$label: $status',textDirection:TextDirection.rtl,style:TextStyle(fontSize:10,color:good?Colors.tealAccent:Colors.orangeAccent)));
        }),
      ],color:const Color(0xFF8DA8C8)),
      if(result?.timeframeAnalysis.isNotEmpty==true)panel('تحلیل ساختاریافته تایم‌فریم‌ها',Icons.stacked_line_chart,[
        ...['1h','15m','5m'].where((tf)=>result!.timeframeAnalysis[tf] is Map).map((tf){
          final item=Map<String,dynamic>.from(result!.timeframeAnalysis[tf] as Map);
          final voteMeta=result!.timeframeVoteEligibility[tf] is Map ? Map<String,dynamic>.from(result!.timeframeVoteEligibility[tf] as Map) : const <String,dynamic>{};
          final tfFactors=result!.timeframeFactorEvidenceValidation[tf] is Map ? Map<String,dynamic>.from(result!.timeframeFactorEvidenceValidation[tf] as Map) : const <String,dynamic>{};
          final voteEligible=voteMeta['eligible']==true;
          final voteReason=voteMeta['reason']?.toString()??'وضعیت رأی این تایم‌فریم از Worker دریافت نشده است.';
          if(item['provided']==false){
            return Padding(padding:const EdgeInsets.only(bottom:7),child:Text('$tf  •  اطلاعات ساختاری این تایم‌فریم در پاسخ مدل ثبت نشده است؛ این وضعیت به معنی خنثی یا نامشخص بودن واقعی بازار نیست.',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:10,color:Colors.orangeAccent,height:1.5)));
          }
          String show(dynamic v){if(v==null||v.toString().isEmpty||v.toString()=='UNKNOWN')return 'در پاسخ مشخص نشده';return switch(v.toString()){ 'BUY_SIDE_SWEEP'=>'جاروب نقدینگی خرید','SELL_SIDE_SWEEP'=>'جاروب نقدینگی فروش','BUY_SIDE_LIQUIDITY_POOL'=>'استخر نقدینگی خرید','SELL_SIDE_LIQUIDITY_POOL'=>'استخر نقدینگی فروش','BOTH_SWEEPS'=>'جاروب هر دو سمت','BOTH_POOLS'=>'استخر هر دو سمت','NONE'=>'رویداد جاروب مشاهده نشد',_=>v.toString()};}
          final line='$tf  |  روند: ${show(item['trend'])}  |  ساختار: ${show(item['structure'])}  |  رویداد: ${show(item['structureEvent'])}  |  فاز: ${show(item['phase'])}  |  درصد اعلامی مدل، خریدار: ${item['buyerStrength']??'—'}٪  |  فروشنده: ${item['sellerStrength']??'—'}٪  |  نقدینگی: ${show(item['liquidity'])}';
          final evidence=item['evidence'] is List ? (item['evidence'] as List).map((x)=>x.toString()).where((x)=>x.trim().isNotEmpty).toList() : <String>[];
          return Padding(padding:const EdgeInsets.only(bottom:7),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
            Text(line,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:10,color:Colors.white70,height:1.5)),
            Text('رأی مستقل این تایم‌فریم: ${voteEligible?'معتبر':'غیرمعتبر'} • $voteReason',textDirection:TextDirection.rtl,style:TextStyle(fontSize:9,color:voteEligible?Colors.tealAccent:Colors.orangeAccent,height:1.4)),
            Text('اعتبار ساختار: ${tfFactors['marketStructure']??'نامشخص'} • اعتبار نقدینگی: ${tfFactors['liquidity']??'نامشخص'}',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:9,color:Colors.white54)),
            ...evidence.take(2).map((x)=>Padding(padding:const EdgeInsets.only(top:2,right:8),child:Text('شاهد: $x',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:9,color:Colors.white54,height:1.4)))),
          ]));
        })
      ],color:const Color(0xFF82B7FF)),
      if((result?.invalidation??'').isNotEmpty)panel('شرط ابطال سناریو',Icons.gpp_bad_outlined,[Text(result!.invalidation!,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:12,color:Colors.orangeAccent))],color:Colors.orangeAccent),
      panel('شواهد ساختاریافته',Icons.fact_check_outlined,bulletItems((result?.evidence??const []).map((e)=>'${e['timeframe']??''} • ${e['event']??''} • ${e['status']??''}: ${e['explanation']??''}').toList()),color:const Color(0xFF8CE5CF)),
      if((result?.summary??'').isNotEmpty)panel('خلاصه سناریوی بازار',Icons.subject,[Text(result!.summary!,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:13,height:1.6,color:Colors.white))],color:const Color(0xFF82B7FF)),
      panel('شواهد و مشاهدات',Icons.fact_check_outlined,bulletItems(result?.observations??const []),color:const Color(0xFF8CE5CF)),
      panel('ریسک‌ها و موارد احتیاط',Icons.warning_amber_rounded,bulletItems(result?.risks??const []),color:Colors.orangeAccent),
      if(structure.isNotEmpty)panel('ساختار بازار و نقدینگی',Icons.account_tree_outlined,[overlayChips(structure)],color:const Color(0xFFB5A0FF)),
      if(zones.isNotEmpty)panel('نواحی عرضه و تقاضا',Icons.layers_outlined,[overlayChips(zones)],color:const Color(0xFF8CE5CF)),
      if(overlays.any((o)=>const {'Entry','SL','TP1','TP2','TP3'}.contains(o['kind'])))panel('نقشه معامله مستقل این مدل',Icons.track_changes,[
        Wrap(spacing:7,runSpacing:7,children:overlays.where((o)=>const {'Entry','SL','TP1','TP2','TP3'}.contains(o['kind'])).map((o){
          final kind='${o['kind']}';final price=o['price'];final label=kind=='Entry'?'ورود':kind=='SL'?'حد ضرر':kind.replaceFirst('TP','هدف ');
          final c=kind=='Entry'?const Color(0xFF46D6B3):kind=='SL'?const Color(0xFFF06470):const Color(0xFF28C99A);
          return Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:8),decoration:BoxDecoration(color:c.withOpacity(.10),borderRadius:BorderRadius.circular(9),border:Border.all(color:c.withOpacity(.35))),child:Text('$label: ${price is num?price.toStringAsFixed(2):'—'}',style:TextStyle(color:c,fontSize:12,fontWeight:FontWeight.bold)));
        }).toList())
      ],color:const Color(0xFF46D6B3)),
      if(other.isNotEmpty)panel('سایر سطوح مستقل مدل',Icons.place_outlined,[overlayChips(other)],color:const Color(0xFF8DA8C8)),
      if((result?.error??'').isNotEmpty && result?.status!='error')Padding(padding:const EdgeInsets.only(top:10),child:Text('هشدار ارائه‌دهنده: ${result!.error}',style:const TextStyle(color:Colors.orangeAccent,fontSize:12))),
      const Divider(height:22,color:Colors.white12),
      Wrap(spacing:12,runSpacing:6,children:[
        if((result?.providerModel??'').isNotEmpty)Text('مدل: ${result!.providerModel}',style:const TextStyle(fontSize:10,color:Colors.white54)),
        if(result?.responseTimeMs!=null)Text('زمان پاسخ: ${(result!.responseTimeMs!/1000).toStringAsFixed(1)} ثانیه',style:const TextStyle(fontSize:10,color:Colors.white54)),
        if(result?.fallbackUsed==true)const Text('مدل جایگزین فعال شد',style:TextStyle(fontSize:10,color:Colors.orangeAccent)),
      ]),
      if(result?.dataCategories.isNotEmpty==true) ...[
        const SizedBox(height:4),
        Theme(data:Theme.of(context).copyWith(dividerColor:Colors.transparent),child:ExpansionTile(tilePadding:EdgeInsets.zero,childrenPadding:EdgeInsets.zero,title:const Text('داده‌های تکمیلی خارج از تحلیل اصلی',style:TextStyle(fontSize:12,color:Colors.white70,fontWeight:FontWeight.bold)),subtitle:const Text('فقط اطلاعات اضافه‌ای که مدل جداگانه ذکر کرده؛ ادعای مدل است و لزوماً فید زنده یا تأییدشده نیست.',style:TextStyle(fontSize:10,color:Colors.white38)),children:[
        ...<String, List<String>>{
          'دفتر سفارش و عمق بازار': ['orderBook'],
          'مشتقات • Funding / Open Interest': ['derivatives'],
          'لیکوییدیشن‌ها': ['liquidations'],
          'داده‌های آن‌چین و جریان صرافی': ['onChain'],
          'اخبار و احساسات بازار': ['newsSentiment'],
          'شاخص‌های اختصاصی ارائه‌دهنده': ['providerSpecific'],
        }.entries.map((group){
          final items=<Map>[];
          for(final key in group.value){
            final raw=result!.dataCategories[key];
            if(raw is List){for(final item in raw.whereType<Map>()){final value='${item['text']??''}'.trim();if(value.isNotEmpty && !items.any((x)=>'${x['text']}'.toLowerCase()==value.toLowerCase()))items.add(item);}}
          }
          if(items.isEmpty)return const SizedBox.shrink();
          return panel(group.key,Icons.auto_awesome,[
            ...items.take(5).map((item){
              final value='${item['text']??''}';
              final path='${item['sourcePath']??'مسیر نامشخص'}';
              return Padding(padding:const EdgeInsets.only(bottom:7),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
                Text('• $value',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:11,height:1.5,color:Colors.white70)),
                Text('مسیر ثبت‌شده در پاسخ مدل: $path',textDirection:TextDirection.ltr,style:const TextStyle(fontSize:9,color:Colors.white38)),
              ]));
            }),
            if(items.length>5)Text('${items.length-5} مورد دیگر در پاسخ مدل ثبت شده است.',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:10,color:Colors.white38)),
          ],color:const Color(0xFF8DA8C8));
        }),
      ])),
      ],
      if(result?.normalization.isNotEmpty==true) ...[
        const SizedBox(height:6),
        Theme(data:Theme.of(context).copyWith(dividerColor:Colors.transparent),child:ExpansionTile(tilePadding:EdgeInsets.zero,childrenPadding:const EdgeInsets.only(bottom:8),title:const Text('گزارش تبدیل و اعتبارسنجی پاسخ',style:TextStyle(fontSize:12,color:Colors.white60)),subtitle:const Text('وضعیت نرمال‌سازی و علت ناقص بودن احتمالی برنامه',style:TextStyle(fontSize:10,color:Colors.white38)),children:[
          ..._normalizationLines({...result!.normalization, 'executionPriceValidation':result!.executionPriceValidation}).map((line)=>Padding(padding:const EdgeInsets.symmetric(vertical:3),child:Text('• $line',textDirection:TextDirection.rtl,style:const TextStyle(fontSize:10,color:Colors.white70,height:1.45)))),
        ])),
      ],
      if((result?.rawText??'').isNotEmpty)Theme(data:Theme.of(context).copyWith(dividerColor:Colors.transparent),child:ExpansionTile(tilePadding:EdgeInsets.zero,childrenPadding:const EdgeInsets.only(bottom:8),title:const Text('متن اصلی پاسخ مدل',style:TextStyle(fontSize:12,color:Colors.white60)),subtitle:Text(result!.rawTextTruncated?'نمایش بخشی از متن؛ طول اصلی: ${result!.rawTextOriginalLength??'نامشخص'} نویسه':'برای مشاهده جزئیات خام باز کنید',style:const TextStyle(fontSize:10,color:Colors.white38)),children:[Container(width:double.infinity,padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFF090F1B),borderRadius:BorderRadius.circular(8)),child:SelectableText(result!.rawText!,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:11,height:1.5)))])),
      if((result?.rawProviderResponse??'').isNotEmpty)Theme(data:Theme.of(context).copyWith(dividerColor:Colors.transparent),child:ExpansionTile(tilePadding:EdgeInsets.zero,childrenPadding:const EdgeInsets.only(bottom:8),title:const Text('پاسخ خام HTTP ارائه‌دهنده',style:TextStyle(fontSize:12,color:Colors.white60)),subtitle:Text(result!.rawProviderResponseTruncated?'نمایش ۱۰۰٬۰۰۰ نویسه اول؛ پاسخ اصلی طولانی‌تر بوده است (${result!.rawProviderResponseOriginalLength??'نامشخص'} نویسه)':'بدنه خام پاسخ دریافتی از سرویس، پیش از استخراج و نرمال‌سازی',style:const TextStyle(fontSize:10,color:Colors.white38)),children:[Container(width:double.infinity,padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFF090F1B),borderRadius:BorderRadius.circular(8)),child:SelectableText(result!.rawProviderResponse!,textDirection:TextDirection.ltr,style:const TextStyle(fontSize:10,height:1.4)))])),
    ])));
  }
  List<String> _normalizationLines(Map<String, dynamic> data) {
    final lines=<String>[];
    final source='${data['sourceFormat']??'نامشخص'}';
    lines.add('قالب ورودی: $source');
    if(data['partial']==true) lines.add('ساختار تحلیل ناقص تشخیص داده شده است.');
    if(data['tradePlanIncomplete']==true) {
      lines.add('برنامه معاملاتی ناقص است؛ تصمیم باید WAIT باشد.');
      final missing=data['missingTradeFields'];
      if(missing is List && missing.isNotEmpty) lines.add('موارد مفقود: ${missing.join('، ')}');
    }
    if(data['tradePlanInconsistent']==true) lines.add('ناسازگاری در ترتیب یا جهت Entry/SL/TP تشخیص داده شده است.');
    if(data['executionWithoutDirection']==true) lines.add('سطوح اجرایی بدون جهت BUY/SELL دریافت شده‌اند.');
    final recovered=data['timeframeNarrativeRecovered'];
    if(recovered is List && recovered.isNotEmpty) {
      final recoveredText=recovered.join('، ');
      lines.add('روند تایم‌فریم‌ها از متن کامل گزارش بازیابی شد: $recoveredText. این بازیابی به‌تنهایی تأیید کندلی BOS/CHOCH نیست.');
    }
    final narrativeOnly=data['timeframeNarrativeOnly'];
    if(narrativeOnly is List && narrativeOnly.isNotEmpty) {
      final narrativeOnlyText=narrativeOnly.join('، ');
      lines.add('تایم‌فریم‌های صرفاً متنی و غیرقابل‌رأی در اجماع: $narrativeOnlyText.');
    }
    final priceValidation=data['executionPriceValidation'];
    if(priceValidation is Map && priceValidation.isNotEmpty) {
      final status='${priceValidation['status']??'UNKNOWN'}';
      lines.add(status=='VALIDATED'?'قیمت Entry/SL/TP با قیمت مرجع، ATR و POI کندل‌محور تأیید شد.':status=='NOT_APPLICABLE'?'مدل سیگنال جهت‌دار صادر نکرده است؛ اعتبارسنجی سطوح ورود لازم نبود.':'اعتبارسنجی قیمت Entry/SL/TP کامل یا موفق نیست؛ سیگنال جهت‌دار به WAIT تبدیل شده است.');
      final reasons=priceValidation['reasons'];
      if(reasons is List) lines.addAll(reasons.map((reason)=>'علت کنترل قیمت: $reason'));
    }
    if(data['providerCompletionTruncated']==true) lines.add('خود ارائه‌دهنده پاسخ را به‌دلیل رسیدن به سقف تولید قطع کرده است؛ تحلیل اجرایی به WAIT تنزل یافته است.');
    if(data['rawTextTruncated']==true) lines.add('متن استخراج‌شده کامل نیست؛ طول اصلی: ${data['rawTextOriginalLength']??'نامشخص'} نویسه.');
    if(data['rawProviderResponseTruncated']==true) lines.add('بدنه خام HTTP کامل نیست؛ طول اصلی: ${data['rawProviderResponseOriginalLength']??'نامشخص'} نویسه.');
    if(lines.length==1) lines.add('مورد خاصی از ناقص بودن یا ناسازگاری ثبت نشده است.');
    return lines;
  }

  String _p(double? x)=>x==null?'—':x.toStringAsFixed(2);
  String _age(DateTime value){final d=DateTime.now().difference(value);if(d.inDays>0)return '${d.inDays} روز و ${d.inHours%24} ساعت';if(d.inHours>0)return '${d.inHours} ساعت و ${d.inMinutes%60} دقیقه';return '${d.inMinutes} دقیقه';}
}


class _AiOverlayMapPainter extends CustomPainter {
  _AiOverlayMapPainter(this.overlays);
  final List<Map<String, dynamic>> overlays;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF09111E);
    canvas.drawRRect(RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(9)), bg);
    final values = <double>[];
    for (final o in overlays) {
      final p = (o['price'] as num?)?.toDouble();
      final lo = (o['low'] as num?)?.toDouble();
      final hi = (o['high'] as num?)?.toDouble();
      if (p != null && p > 0) values.add(p);
      if (lo != null && lo > 0) values.add(lo);
      if (hi != null && hi > 0) values.add(hi);
    }
    if (values.isEmpty) return;
    var minP = values.reduce((a,b)=>a<b?a:b);
    var maxP = values.reduce((a,b)=>a>b?a:b);
    if ((maxP-minP).abs() < 1e-9) { minP *= .995; maxP *= 1.005; }
    final pad = (maxP-minP)*.12;
    minP -= pad; maxP += pad;
    const left = 10.0, right = 10.0, top = 10.0, bottom = 10.0;
    final plotH = size.height-top-bottom;
    double y(double price) => top + (maxP-price)/(maxP-minP)*plotH;
    final grid = Paint()..color = Colors.white.withOpacity(.07)..strokeWidth=1;
    for (var i=0;i<=4;i++) {
      final yy=top+plotH*i/4;
      canvas.drawLine(Offset(left,yy),Offset(size.width-right,yy),grid);
    }
    Color colorFor(Map<String,dynamic> o) {
      final kind='${o['kind']??''}'.toUpperCase();
      final direction='${o['direction']??''}'.toLowerCase();
      if (kind=='SL') return const Color(0xFFF06470);
      if (kind=='ENTRY') return const Color(0xFF58CDB2);
      if (kind.startsWith('TP')) return const Color(0xFF35C995);
      if (direction=='bullish' || kind.contains('BULL')) return const Color(0xFF35C995);
      if (direction=='bearish' || kind.contains('BEAR')) return const Color(0xFFF06470);
      return const Color(0xFFB49AF4);
    }
    for (final o in overlays.where((x)=>x['type']=='zone')) {
      final lo=(o['low'] as num?)?.toDouble(), hi=(o['high'] as num?)?.toDouble();
      if (lo==null||hi==null||hi<=lo) continue;
      final c=colorFor(o);
      final rect=Rect.fromLTRB(left,y(hi),size.width-right,y(lo));
      canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(3)),Paint()..color=c.withOpacity(.20));
      canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(3)),Paint()..color=c.withOpacity(.75)..style=PaintingStyle.stroke..strokeWidth=1);
      _label(canvas,'${o['kind']??'ZONE'}',Offset(size.width-right-5,(rect.top+rect.bottom)/2),c,align:TextAlign.right);
    }
    for (final o in overlays.where((x)=>x['type']=='line')) {
      final p=(o['price'] as num?)?.toDouble();
      if (p==null||p<=0) continue;
      final yy=y(p), c=colorFor(o);
      final paint=Paint()..color=c..strokeWidth=1.4;
      canvas.drawLine(Offset(left,yy),Offset(size.width-right,yy),paint);
      _label(canvas,'${o['kind']??'LEVEL'}  ${p.toStringAsFixed(2)}',Offset(size.width-right-4,yy-2),c,align:TextAlign.right);
    }
  }

  void _label(Canvas canvas,String text,Offset point,Color color,{TextAlign align=TextAlign.left}) {
    final tp=TextPainter(text:TextSpan(text:text,style:TextStyle(color:color,fontSize:8.5,fontWeight:FontWeight.w700,backgroundColor:const Color(0xCC09111E))),textDirection:TextDirection.ltr,textAlign:align,maxLines:1)..layout(maxWidth:120);
    tp.paint(canvas,Offset((point.dx-tp.width).clamp(2.0,10000.0), (point.dy-tp.height/2).clamp(1.0,10000.0)));
  }

  @override
  bool shouldRepaint(covariant _AiOverlayMapPainter oldDelegate) => oldDelegate.overlays != overlays;
}
