
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import '../services/analysis_controller.dart';
import '../services/ai_service.dart';

class AiAnalysisScreen extends StatefulWidget{
  const AiAnalysisScreen({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  @override State<AiAnalysisScreen> createState()=>_AiAnalysisScreenState();
}
class _AiAnalysisScreenState extends State<AiAnalysisScreen>{
  final AiService ai=AiService();
  bool aiLoading=false;
  String status='برای شروع، ابتدا تحلیل تکنیکال سه تایم‌فریم اجرا می‌شود.';
  String? error;
  final Map<String, TextEditingController> _modelControllers = {
    'gemini': TextEditingController(text: 'gemini-3.5-flash-lite'),
    'openrouter': TextEditingController(text: 'openrouter/free'),
    'groq': TextEditingController(text: 'openai/gpt-oss-120b'),
  };
  final Map<String, TextEditingController> _fallbackControllers = {
    'gemini': TextEditingController(text: 'gemini-3.8-flash'),
    'openrouter': TextEditingController(text: 'inclusionai/ling-3.2-flash:free'),
    'groq': TextEditingController(text: 'openai/gpt-oss-20b'),
  };
  final Map<String, bool> _providerEnabled = {'gemini': true, 'openrouter': true, 'groq': false};
  bool _settingsLoaded = false;
  final Map<String,List<String>> _availableModels = {};
  String? _catalogError;
  bool _catalogLoading = false;
  AiConsensus? get consensus => widget.analysis.consensus;

  @override void initState(){ super.initState(); _initializeSettingsAndCatalog(); }
  Future<void> _initializeSettingsAndCatalog() async {
    await _loadAiSettings();
    if (mounted) await _loadModelCatalog();
  }
  @override void dispose(){ for(final c in _modelControllers.values){c.dispose();} for(final c in _fallbackControllers.values){c.dispose();} super.dispose(); }
  Future<void> _loadAiSettings() async {
    final prefs=await SharedPreferences.getInstance();
    if(!mounted)return;
    setState((){
      for(final key in _modelControllers.keys){
        _modelControllers[key]!.text=prefs.getString('ai_model_$key')??_modelControllers[key]!.text;
        _fallbackControllers[key]!.text=prefs.getString('ai_fallback_model_$key')??_fallbackControllers[key]!.text;
        _providerEnabled[key]=prefs.getBool('ai_provider_$key')??(_providerEnabled[key]??true);
      }
      _settingsLoaded=true;
    });
  }
  Future<void> _loadModelCatalog() async {
    if (_catalogLoading) return;
    setState(() => _catalogLoading = true);
    try {
      final models = await ai.fetchModelCatalog();
      if (!mounted) return;
      setState(() {
        for (final key in ['gemini','openrouter','groq']) {
          _availableModels[key] = models[key] ?? const <String>[];
          // Keep saved selection if it still exists; otherwise choose a valid live model.
          final list = _availableModels[key]!;
          if (list.isNotEmpty && !list.contains(_modelControllers[key]!.text)) {
            _modelControllers[key]!.text = list.first;
          }
          if (list.isNotEmpty && !list.contains(_fallbackControllers[key]!.text)) {
            _fallbackControllers[key]!.text = list.length > 1 ? list[1] : list.first;
          }
        }
        _catalogError = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _catalogError = e.toString());
    } finally {
      if (mounted) setState(() => _catalogLoading = false);
    }
  }
  Future<void> _saveAiSettings() async {
    final prefs=await SharedPreferences.getInstance();
    for(final key in _modelControllers.keys){
      final model=_modelControllers[key]!.text.trim();
      if(model.isNotEmpty) await prefs.setString('ai_model_$key',model);
      final fallback=_fallbackControllers[key]!.text.trim();
      if(fallback.isNotEmpty) await prefs.setString('ai_fallback_model_$key',fallback);
      await prefs.setBool('ai_provider_$key',_providerEnabled[key]??false);
    }
  }

  Future<void> _runFullAnalysis() async{
    final requestedExchange=widget.state.exchange;
    final requestedSymbol=widget.state.symbol;
    setState(() {
      aiLoading=true; error=null; status='در حال اجرای موتور تکنیکال...';
    });
    final completed = await widget.analysis.run();
    if(!mounted)return;
    if(!completed){
      setState(() { aiLoading=false; error=widget.analysis.error??'تحلیل جدید تکمیل نشد؛ تحلیل قبلی حفظ شده است.'; status='درخواست AI ارسال نشد تا تحلیل قدیمی به‌اشتباه دوباره پردازش نشود.'; });
      return;
    }
    final report=widget.analysis.report;
    if(report==null){
      setState(() {
        aiLoading=false; error=widget.analysis.error??'تحلیل تکنیکال انجام نشد.'; status='تحلیل AI متوقف شد.';
      });
      return;
    }
    if(!ai.isConfigured){
      setState(() {
        aiLoading=false; status='موتور تکنیکال آماده است؛ اتصال AI Gateway در انتظار تنظیم است.';
      });
      return;
    }
    await _saveAiSettings();
    final selectedProviders=_providerEnabled.entries.where((e)=>e.value).map((e)=>e.key).toList();
    if(selectedProviders.isEmpty){setState((){aiLoading=false;error='حداقل یک ارائه‌دهنده را انتخاب کنید.';});return;}
    final selectedModels={for(final e in _modelControllers.entries)e.key:e.value.text.trim()};
    final selectedFallbacks={for(final e in _fallbackControllers.entries)e.key:e.value.text.trim()};
    setState(() { status='ارسال Snapshot ذخیره‌شده کندل‌ها به مدل‌های انتخاب‌شده به‌صورت مستقل...'; });
    try{
      final result=await ai.analyze(
        exchange:requestedExchange, symbol:requestedSymbol,
        history1h:widget.analysis.history1h,
        history15m:widget.analysis.history15m,
        history5m:widget.analysis.history5m,
        modelSelection:selectedModels,
        fallbackSelection:selectedFallbacks,
        selectedProviders:selectedProviders,
        snapshotId:widget.analysis.snapshotId,
      );
      if(!mounted)return;
      if(widget.state.exchange!=requestedExchange || widget.state.symbol!=requestedSymbol || widget.analysis.report!=report){
        setState(() { aiLoading=false; status='بازار هنگام تحلیل تغییر کرد؛ نتیجه قبلی کنار گذاشته شد.'; });
        return;
      }
      await widget.analysis.saveConsensus(result);
      if(!mounted)return;
      setState(() {
        aiLoading=false; status='پاسخ مدل‌ها دریافت و ذخیره شد.';
      });
    }catch(e){
      if(!mounted)return;
      setState(() {
        aiLoading=false; error=e.toString(); status='ارتباط با AI Gateway ناموفق بود.';
      });
    }
  }

  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:Listenable.merge([widget.state,widget.analysis]),
    builder:(context,_){
      final report=widget.analysis.report;
      return ListView(padding:const EdgeInsets.all(18),children:[
        const SizedBox(height:8),
        const Text('گزارش تحلیل AI',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        Text('${widget.state.symbol} • ${widget.state.exchange}',style:const TextStyle(color:Colors.white60)),
        const SizedBox(height:8),
        if(widget.analysis.report!=null) Card(child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[
          Icon(widget.analysis.isStale?Icons.warning_amber_rounded:Icons.check_circle_outline,
            color:widget.analysis.isStale?Colors.orangeAccent:const Color(0xFF46D6B3)),
          const SizedBox(width:8),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(widget.analysis.isStale?'تحلیل ذخیره‌شده قدیمی است':'آخرین تحلیل ذخیره و بازیابی شده',style:const TextStyle(fontWeight:FontWeight.bold)),
            Text('زمان تحلیل: ${widget.analysis.technicalAt?.toLocal().toString().substring(0,16) ?? '—'}',style:const TextStyle(fontSize:11,color:Colors.white60)),
            if(widget.analysis.technicalAt!=null) Text('سن تحلیل: ${_age(widget.analysis.technicalAt!)}',style:const TextStyle(fontSize:11,color:Colors.white60)),
            if(widget.analysis.aiAt!=null) Text('پاسخ AI: ${widget.analysis.aiAt!.toLocal().toString().substring(0,16)} • ${widget.analysis.isAiStale ? 'قدیمی' : 'تازه'}',style:TextStyle(fontSize:11,color:widget.analysis.isAiStale?Colors.orangeAccent:Colors.white60)),
            Text('تاریخچه کندل بسته‌شده: 1H ${widget.analysis.historyCount1h} • 15M ${widget.analysis.historyCount15m} • 5M ${widget.analysis.historyCount5m}',style:const TextStyle(fontSize:11,color:Colors.white60)),
          ])),
          Text(widget.analysis.isStale?'قدیمی':'تازه',style:TextStyle(color:widget.analysis.isStale?Colors.orangeAccent:const Color(0xFF46D6B3))),
        ]))),
        const SizedBox(height:14),
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('اجرای تحلیل کامل',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),
          const Text('کندل‌های بسته‌شده 1H، 15M و 5M پس از ذخیره در یک Snapshot ثابت، مستقل برای هر مدل ارسال می‌شوند. پاسخ هر مدل جداگانه نگهداری می‌شود. تحلیل تکنیکال مستقل باقی می‌ماند و منبع رسم چارت طبق انتخاب شما فقط تکنیکال یا AI است.'),
          const SizedBox(height:10),
          if(!_settingsLoaded) const LinearProgressIndicator(),
          ..._modelControllers.entries.map((entry)=>_modelSetting(entry.key,entry.value,_fallbackControllers[entry.key]!)),
          if(_catalogError!=null) Padding(padding:const EdgeInsets.only(top:4),child:Text('فهرست مدل‌ها دریافت نشد؛ شناسه را دستی وارد کنید. $_catalogError',style:const TextStyle(fontSize:11,color:Colors.orangeAccent))),
          Align(alignment:Alignment.centerLeft,child:TextButton.icon(onPressed:_catalogLoading?null:_loadModelCatalog,icon:_catalogLoading?const SizedBox(width:16,height:16,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.refresh,size:16),label:Text(_catalogLoading?'در حال دریافت مدل‌های فعال...':'به‌روزرسانی زنده فهرست مدل‌ها'))),
          const SizedBox(height:12),
          SizedBox(width:double.infinity,child:FilledButton.icon(
            onPressed:aiLoading?null:_runFullAnalysis,
            icon:aiLoading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.psychology),
            label:Text(aiLoading?'در حال تحلیل...':'اجرای تحلیل با مدل‌های انتخاب‌شده'),
          )),
          const SizedBox(height:8),
          Text(status,style:const TextStyle(color:Colors.white70,fontSize:12)),
          if(widget.analysis.restoring) const Padding(padding:EdgeInsets.only(top:6),child:LinearProgressIndicator()),
          if(error!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(error!,style:const TextStyle(color:Colors.orangeAccent))),
        ]))),
        if(report!=null)...[
          _section('گزارش فنی مبنا'),
          Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('سیگنال تکنیکال: ${report.state.name.toUpperCase()}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
            Text('سوگیری 1H: ${report.bias1h.name} | 15M: ${report.bias15m.name} | 5M: ${report.bias5m.name}'),
            const SizedBox(height:8),
            Text('برآورد قدرت کندلی خریدار ${report.buyerPower}% • فروشنده ${report.sellerPower}%'),
            if(report.entry!=null)Text('Entry ${_p(report.entry)} | SL ${_p(report.stopLoss)} | TP ${_p(report.tp1)} / ${_p(report.tp2)} / ${_p(report.tp3)}'),
            ...report.reasons.map((x)=>Text('• $x')),
            if(report.poiSummary.isNotEmpty)const Padding(padding:EdgeInsets.only(top:10),child:Text('ساختار و نواحی مهم بازار',style:TextStyle(fontWeight:FontWeight.bold))),
            ...report.poiSummary.map((x)=>Text('• $x',style:const TextStyle(color:Color(0xFF8CE5CF)))),
            ...report.warnings.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent))),
          ]))),
        ],
        _section('وضعیت مدل‌ها'),
        _modelCard('Gemini','تحلیل مستقل تاریخچه 1H/15M/5M و سناریوها',consensus?.gemini),
        _modelCard('OpenRouter','تحلیل مستقل همان Snapshot',consensus?.openrouter),
        _modelCard('Groq','تحلیل مستقل همان Snapshot',consensus?.groq),
        if(consensus?.snapshotId!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text('شناسه Snapshot: ${consensus!.snapshotId}',style:const TextStyle(fontSize:10,color:Colors.white38))),
        if(consensus!=null)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('اجماع مستقل مدل‌های هوش مصنوعی',style:TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
          const SizedBox(height:8),
          Text(consensus!.decision.toUpperCase(),style:TextStyle(fontSize:24,fontWeight:FontWeight.bold,color:consensus!.decision.toUpperCase()=='WAIT'?Colors.amber:const Color(0xFF46D6B3))),
          ...consensus!.conflicts.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent))),
        ]))),
        if(!ai.isConfigured)Card(child:Padding(padding:const EdgeInsets.all(14),child:const Text(
          'اتصال AI Gateway فعال نیست: آدرس Worker باید در GitHub Actions با Secret به نام AI_GATEWAY_BASE_URL تنظیم شود و کلیدهای Gemini، Groq و OpenRouter فقط به‌صورت Secret در Cloudflare نگهداری شوند. کلید API نباید داخل APK قرار گیرد.',
          style:TextStyle(color:Colors.amber),
        ))),
        const SizedBox(height:12),
        const Text('سیاست تحلیل: هر ارائه‌دهنده AI مستقل از موتور تکنیکال و سایر مدل‌ها تصمیم می‌گیرد. خروجی، جهت، دلایل و سطوح هر مدل جداگانه نمایش داده می‌شود؛ نتیجه اجماع صرفاً یک نمای کمکی است و تصمیم مستقل هیچ مدلی را تغییر نمی‌دهد. منبع رسم نمودار فقط از انتخاب شما پیروی می‌کند.'),
      ]);
    },
  );

  Widget _modelSetting(String key,TextEditingController controller,TextEditingController fallbackController){
    final labels={'gemini':'Google Gemini','openrouter':'OpenRouter','groq':'Groq'};
    final models=_availableModels[key]??const <String>[];
    final enabled=_providerEnabled[key]??false;
    Widget modelDropdown(String value, String label, ValueChanged<String?> onChanged) =>
      Directionality(textDirection:TextDirection.rtl,child:DropdownButtonFormField<String>(
        value:models.contains(value)?value:null,
        isExpanded:true,
        decoration:InputDecoration(labelText:label,isDense:true,border:const OutlineInputBorder(),floatingLabelBehavior:FloatingLabelBehavior.always),
        items:models.map((m)=>DropdownMenuItem<String>(value:m,child:Directionality(textDirection:TextDirection.ltr,child:Align(alignment:Alignment.centerLeft,child:Text(m,textAlign:TextAlign.left,maxLines:1,softWrap:false,overflow:TextOverflow.ellipsis,style:const TextStyle(fontFamily:'monospace',fontSize:12)))))).toList(),
        selectedItemBuilder:(context)=>models.map((m)=>Align(alignment:Alignment.centerLeft,child:Directionality(textDirection:TextDirection.ltr,child:Text(m,textDirection:TextDirection.ltr,textAlign:TextAlign.left,maxLines:1,overflow:TextOverflow.ellipsis,softWrap:false,style:const TextStyle(fontFamily:'monospace',fontSize:12))))).toList(),
        onChanged:enabled?onChanged:null,
      ));
    InputDecoration idDecoration(String label,String hint)=>InputDecoration(labelText:label,hintText:hint,isDense:true,border:const OutlineInputBorder(),floatingLabelBehavior:FloatingLabelBehavior.always,alignLabelWithHint:true);
    return Card(color:const Color(0xFF10182A),child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      SwitchListTile(contentPadding:EdgeInsets.zero,dense:true,title:Text(labels[key]??key),value:enabled,onChanged:(v)=>setState(()=>_providerEnabled[key]=v)),
      if(models.isNotEmpty) modelDropdown(controller.text,'انتخاب مدل فعال اصلی',(v){if(v!=null)setState(()=>controller.text=v);}),
      const SizedBox(height:10),
      Directionality(textDirection:TextDirection.ltr,child:TextField(controller:controller,enabled:enabled,textDirection:TextDirection.ltr,textAlign:TextAlign.left,textAlignVertical:TextAlignVertical.center,style:const TextStyle(fontFamily:'monospace',fontSize:13),decoration:idDecoration('مدل اصلی (شناسه دقیق)','provider/model-id'))),
      const SizedBox(height:10),
      if(models.isNotEmpty) modelDropdown(fallbackController.text,'انتخاب مدل جایگزین فعال',(v){if(v!=null)setState(()=>fallbackController.text=v);}),
      const SizedBox(height:10),
      Directionality(textDirection:TextDirection.ltr,child:TextField(controller:fallbackController,enabled:enabled,textDirection:TextDirection.ltr,textAlign:TextAlign.left,textAlignVertical:TextAlignVertical.center,style:const TextStyle(fontFamily:'monospace',fontSize:13),decoration:idDecoration('مدل جایگزین (شناسه دقیق)','provider/fallback-model'))),
    ])));
  }
  Widget _section(String s)=>Padding(padding:const EdgeInsets.only(top:18,bottom:8),child:Text(s,style:const TextStyle(fontSize:16,fontWeight:FontWeight.bold)));
  Widget _modelCard(String name,String role,AiModelResult? result){
    final bias=(result?.bias??'').toUpperCase();
    final Color tone=bias=='BUY'?const Color(0xFF28C99A):bias=='SELL'?const Color(0xFFF06470):const Color(0xFFE7B84E);
    final String direction=bias=='BUY'?'خرید':bias=='SELL'?'فروش':bias=='WAIT'?'انتظار':'نامشخص';
    final String statusLabel=result?.status=='ok'?'پاسخ دریافت شد':result?.status=='error'?'خطا':result?.status=='not_selected'?'انتخاب نشده':(result?.status??'در انتظار');
    final overlays=result?.overlays??const <Map<String,dynamic>>[];
    String overlayName(dynamic value){
      const names={'Swing High':'سقف نوسانی','Swing Low':'کف نوسانی','FVG':'شکاف ارزش منصفانه','Bullish FVG':'FVG صعودی','Bearish FVG':'FVG نزولی','Bullish OB':'اوردر بلاک صعودی','Bearish OB':'اوردر بلاک نزولی','EQH':'سقف‌های برابر','EQL':'کف‌های برابر','BOS+':'شکست ساختار صعودی','BOS-':'شکست ساختار نزولی','CRT-H':'سقف CRT','CRT-L':'کف CRT','EQ':'تعادل'};
      return names[value?.toString()]??value?.toString()??'ناحیه';
    }
    Widget panel(String title,IconData icon,List<Widget> children,{Color color=Colors.white70}){
      if(children.isEmpty)return const SizedBox.shrink();
      return Container(margin:const EdgeInsets.only(top:10),padding:const EdgeInsets.all(11),decoration:BoxDecoration(color:const Color(0xFF0B1422),borderRadius:BorderRadius.circular(11),border:Border.all(color:color.withOpacity(.20))),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Row(children:[Icon(icon,size:17,color:color),const SizedBox(width:7),Text(title,style:TextStyle(fontWeight:FontWeight.bold,color:color,fontSize:13))]),
        const SizedBox(height:8),...children,
      ]));
    }
    List<Widget> bulletItems(List<String> items)=>items.map((x)=>Padding(padding:const EdgeInsets.only(bottom:6),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[const Padding(padding:EdgeInsets.only(top:5),child:Icon(Icons.circle,size:5,color:Colors.white54)),const SizedBox(width:8),Expanded(child:Text(x,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:12,height:1.45,color:Colors.white.withOpacity(.88))))]))).toList();
    final structure=overlays.where((o){final k='${o['kind']??''}'.toLowerCase();return k.contains('bos')||k.contains('swing')||k.contains('eqh')||k.contains('eql')||k.contains('crt')||k=='eq';}).toList();
    final zones=overlays.where((o){final k='${o['kind']??''}'.toLowerCase();return k.contains('fvg')||k.contains('ob')||k.contains('order');}).toList();
    final other=overlays.where((o)=>!structure.contains(o)&&!zones.contains(o)).toList();
    Widget overlayChips(List<Map<String,dynamic>> values){
      if(values.isEmpty)return const SizedBox.shrink();
      return Wrap(spacing:6,runSpacing:6,children:values.map((o){
        final kind=overlayName(o['kind']);final tf=(o['timeframe']??'').toString().toUpperCase();final price=o['price'];final low=o['low'];final high=o['high'];
        final value=price is num?'${price.toStringAsFixed(2)}':(low is num&&high is num?'${low.toStringAsFixed(2)} – ${high.toStringAsFixed(2)}':'');
        final dir='${o['direction']??''}';final c=dir=='bullish'?const Color(0xFF28C99A):dir=='bearish'?const Color(0xFFF06470):const Color(0xFF8DA8C8);
        return Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:6),decoration:BoxDecoration(color:c.withOpacity(.10),borderRadius:BorderRadius.circular(8),border:Border.all(color:c.withOpacity(.25))),child:Text('$kind ${tf.isEmpty?'':'• $tf'} ${value.isEmpty?'':'• $value'}',style:TextStyle(fontSize:10,color:c,fontWeight:FontWeight.w600)));
      }).toList());
    }
    return Card(color:const Color(0xFF111A2B),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Row(children:[const Icon(Icons.memory,size:20),const SizedBox(width:8),Expanded(child:Text(name,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16))),
        Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),decoration:BoxDecoration(color:(result?.status=='error'?Colors.redAccent:Colors.tealAccent).withOpacity(.13),borderRadius:BorderRadius.circular(20)),child:Text(statusLabel,style:TextStyle(fontSize:10,color:result?.status=='error'?Colors.redAccent:Colors.tealAccent)))
      ]),
      const SizedBox(height:10),
      if(result?.bias!=null)Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:tone.withOpacity(.10),border:Border.all(color:tone.withOpacity(.35)),borderRadius:BorderRadius.circular(12)),child:Column(children:[
        Row(children:[Container(width:42,height:42,decoration:BoxDecoration(color:tone.withOpacity(.18),shape:BoxShape.circle),child:Icon(bias=='BUY'?Icons.trending_up:bias=='SELL'?Icons.trending_down:Icons.pause_circle_outline,color:tone,size:25)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(direction,style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:tone)),const Text('تصمیم مستقل این مدل',style:TextStyle(fontSize:10,color:Colors.white60))])),Text('${result!.confidence}%',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold,color:tone))]),
        const SizedBox(height:9),ClipRRect(borderRadius:BorderRadius.circular(8),child:LinearProgressIndicator(value:result.confidence/100,minHeight:8,backgroundColor:Colors.white10,color:tone)),const SizedBox(height:3),const Align(alignment:Alignment.centerLeft,child:Text('درصد اطمینان اعلام‌شده توسط مدل',style:TextStyle(fontSize:10,color:Colors.white54)))
      ])) else Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Text(result?.status=='error'?'این مدل در این اجرا پاسخ معتبر نداد. ${result?.error??''}':role,style:const TextStyle(color:Colors.white70,fontSize:12))),
      if((result?.summary??'').isNotEmpty)panel('خلاصه سناریوی بازار',Icons.subject,[Text(result!.summary!,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:13,height:1.6,color:Colors.white))],color:const Color(0xFF82B7FF)),
      panel('شواهد و مشاهدات',Icons.fact_check_outlined,bulletItems(result?.observations??const []),color:const Color(0xFF8CE5CF)),
      panel('ریسک‌ها و موارد احتیاط',Icons.warning_amber_rounded,bulletItems(result?.risks??const []),color:Colors.orangeAccent),
      if(structure.isNotEmpty)panel('ساختار بازار و نقدینگی',Icons.account_tree_outlined,[overlayChips(structure)],color:const Color(0xFFB5A0FF)),
      if(zones.isNotEmpty)panel('نواحی عرضه و تقاضا',Icons.layers_outlined,[overlayChips(zones)],color:const Color(0xFF8CE5CF)),
      if(other.isNotEmpty)panel('سایر نواحی شناسایی‌شده',Icons.place_outlined,[overlayChips(other)],color:const Color(0xFF8DA8C8)),
      if((result?.error??'').isNotEmpty && result?.status!='error')Padding(padding:const EdgeInsets.only(top:10),child:Text('هشدار ارائه‌دهنده: ${result!.error}',style:const TextStyle(color:Colors.orangeAccent,fontSize:12))),
      const Divider(height:22,color:Colors.white12),
      Wrap(spacing:12,runSpacing:6,children:[
        if((result?.providerModel??'').isNotEmpty)Text('مدل: ${result!.providerModel}',style:const TextStyle(fontSize:10,color:Colors.white54)),
        if(result?.responseTimeMs!=null)Text('زمان پاسخ: ${(result!.responseTimeMs!/1000).toStringAsFixed(1)} ثانیه',style:const TextStyle(fontSize:10,color:Colors.white54)),
        if(result?.fallbackUsed==true)const Text('مدل جایگزین فعال شد',style:TextStyle(fontSize:10,color:Colors.orangeAccent)),
      ]),
      if((result?.rawText??'').isNotEmpty)Theme(data:Theme.of(context).copyWith(dividerColor:Colors.transparent),child:ExpansionTile(tilePadding:EdgeInsets.zero,childrenPadding:const EdgeInsets.only(bottom:8),title:const Text('متن اصلی پاسخ مدل',style:TextStyle(fontSize:12,color:Colors.white60)),subtitle:const Text('برای مشاهده جزئیات خام باز کنید',style:TextStyle(fontSize:10,color:Colors.white38)),children:[Container(width:double.infinity,padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFF090F1B),borderRadius:BorderRadius.circular(8)),child:SelectableText(result!.rawText!,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:11,height:1.5)))])),
    ])));
  }
  String _p(double? x)=>x==null?'—':x.toStringAsFixed(2);
  String _age(DateTime value){final d=DateTime.now().difference(value);if(d.inDays>0)return '${d.inDays} روز و ${d.inHours%24} ساعت';if(d.inHours>0)return '${d.inHours} ساعت و ${d.inMinutes%60} دقیقه';return '${d.inMinutes} دقیقه';}
}
