import 'dart:io';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import '../services/smart_connectivity_service.dart';

/// Opens the official Chart Analyzer upload page inside the app.
/// When its file input is requested, the generated chart image is supplied
/// directly instead of opening the Android gallery/file picker.
class ChartAnalyzerScreen extends StatefulWidget {
  const ChartAnalyzerScreen({
    super.key,
    required this.imageFile,
    required this.symbol,
    required this.timeframe,
    required this.candleCount,
  });

  final File imageFile;
  final String symbol;
  final String timeframe;
  final int candleCount;

  @override
  State<ChartAnalyzerScreen> createState() => _ChartAnalyzerScreenState();
}

class _ChartAnalyzerScreenState extends State<ChartAnalyzerScreen> {
  late final WebViewController _controller;
  bool _ready = false;
  bool _imageAttached = false;
  bool _attachRequested = false;
  bool _uploadSupported = false;
  int _progress = 0;
  DateTime? _pageStartedAt;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0B1020))
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (url) {
          _pageStartedAt = DateTime.now();
          SmartConnectivityService.reportChartAnalyzerStatus(
            LinkState.degraded, 'صفحه رسمی Chart Analyzer در حال بارگذاری است.');
          if (mounted) setState(() { _ready = false; _progress = 0; });
        },
        onProgress: (value) {
          if (mounted) setState(() => _progress = value);
        },
        onPageFinished: (url) {
          final host = Uri.tryParse(url)?.host.toLowerCase() ?? '';
          if (host == 'chartanalyzerai.com' || host.endsWith('.chartanalyzerai.com')) {
            final latency = _pageStartedAt == null ? null : DateTime.now().difference(_pageStartedAt!).inMilliseconds;
            // Page reachability is not proof that the external AI service or
            // its inference backend is healthy. Keep it degraded until a real
            // service-level signal exists; never paint a page load green or imply a failure.
            SmartConnectivityService.reportChartAnalyzerStatus(
              LinkState.unknown, 'PAGE_LOADED: صفحه رسمی در WebView باز شد؛ سلامت سرویس AI و اجرای تحلیل از این رویداد قابل تأیید نیست.', latencyMs: latency);
          }
          if (!mounted) return;
          setState(() { _ready = true; _progress = 100; _error = null; });
          if (_attachRequested) _triggerFileInput();
        },
        onHttpError: (error) {
          final statusCode = error.response?.statusCode;
          if (mounted) setState(() => _error = 'پاسخ HTTP صفحه Chart Analyzer ناموفق بود${statusCode == null ? '' : ' ( $statusCode )'}؛ بارگذاری صفحه به معنی سلامت سرویس نیست.');
          SmartConnectivityService.reportChartAnalyzerStatus(
            LinkState.degraded, 'HTTP_ERROR: پاسخ HTTP صفحه Chart Analyzer ناموفق بود${statusCode == null ? '' : '؛ کد $statusCode'}.');
        },
        onWebResourceError: (error) {
          if (error.isForMainFrame == true) {
            SmartConnectivityService.reportChartAnalyzerStatus(
              LinkState.degraded, 'بارگذاری صفحه اصلی Chart Analyzer ناموفق بود: ${error.description}');
            if (mounted) setState(() => _error = 'بارگذاری صفحه Chart Analyzer ناموفق بود: ${error.description}');
          }
        },
      ));
    _configureAndroidUpload();
    _controller.loadRequest(Uri.parse('https://www.chartanalyzerai.com/upload'));
  }

  Future<void> _configureAndroidUpload() async {
    if (_controller.platform is! AndroidWebViewController) {
      if (mounted) setState(() => _error = 'ارسال خودکار فایل در این نسخه فقط روی Android پشتیبانی می‌شود.');
      return;
    }
    final android = _controller.platform as AndroidWebViewController;
    try {
      await android.setAllowFileAccess(true);
      await android.setAllowContentAccess(true);
      await android.setOnShowFileSelector((params) async {
        if (!mounted || !await widget.imageFile.exists()) return <String>[];
        final acceptsImage = params.acceptTypes.isEmpty || params.acceptTypes.any(
          (type) => type.contains('image') || type.contains('png') || type.contains('jpeg'),
        );
        if (!acceptsImage || params.mode == FileSelectorMode.save) return <String>[];
        if (mounted) setState(() => _imageAttached = true);
        // Android WebView expects file/content URI strings, not XFile objects.
        return <String>[Uri.file(widget.imageFile.path).toString()];
      });
      if (mounted) setState(() => _uploadSupported = true);
      SmartConnectivityService.reportChartAnalyzerStatus(
        LinkState.unknown, 'UPLOAD_READY: امکان اتصال تصویر به فرم WebView آماده است؛ پاسخ‌گویی موتور AI هنوز آزمایش نشده است.');
    } catch (e) {
      if (mounted) setState(() => _error = 'آماده‌سازی ارسال تصویر در WebView ناموفق بود: $e');
    }
  }

  Future<void> _triggerFileInput() async {
    if (!_ready || !_uploadSupported) return;
    try {
      final result = await _controller.runJavaScriptReturningResult('''
        (function(){
          const input = document.querySelector('input[type="file"]');
          if (!input) return 'NO_FILE_INPUT';
          input.click();
          return 'FILE_INPUT_OPENED';
        })();
      ''');
      if (result.toString().contains('NO_FILE_INPUT')) {
        if (mounted) setState(() => _error = 'فرم انتخاب تصویر در صفحه پیدا نشد؛ صفحه را تازه‌سازی کنید.');
      } else {
        if (mounted) setState(() { _attachRequested = false; _error = null; });
      }
    } catch (e) {
      if (mounted) setState(() => _error = 'اتصال تصویر آماده به فرم ناموفق بود: $e');
    }
  }

  Future<void> _attachImage() async {
    if (!_ready) return;
    setState(() { _attachRequested = true; _error = null; _imageAttached = false; });
    await _triggerFileInput();
  }

  Future<bool> _handleBack() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (!didPop && await _handleBack() && context.mounted) Navigator.of(context).pop();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0B1020),
        appBar: AppBar(
          backgroundColor: const Color(0xFF111A2B),
          title: const Text('Chart Analyzer AI'),
          actions: [
            IconButton(
              tooltip: 'بارگذاری تصویر آماده',
              onPressed: _ready && _uploadSupported ? _attachImage : null,
              icon: const Icon(Icons.add_photo_alternate_outlined, color: Color(0xFF8CE5CF)),
            ),
            IconButton(tooltip: 'بازنشانی صفحه', onPressed: () => _controller.reload(), icon: const Icon(Icons.refresh)),
          ],
        ),
        body: Column(children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            color: const Color(0xFF13263A),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${widget.symbol} • ${widget.timeframe.toUpperCase()} • ${widget.candleCount} کندل', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
              const SizedBox(height: 3),
              Text(_imageAttached ? 'تصویر نمودار به فرم سایت ضمیمه شد؛ اکنون Analyze Chart را بزنید.' : 'تصویر تمیز 1600×900 آماده است؛ برای ضمیمه‌کردن، دکمه تصویر را بزنید.', style: const TextStyle(color: Colors.white70, fontSize: 11)),
            ]),
          ),
          if (_progress < 100) LinearProgressIndicator(value: _progress == 0 ? null : _progress / 100, minHeight: 2),
          if (_error != null) Container(width: double.infinity, padding: const EdgeInsets.all(9), color: const Color(0xFF49252B), child: Text(_error!, style: const TextStyle(color: Colors.white, fontSize: 11))),
          Expanded(child: WebViewWidget(controller: _controller)),
        ]),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _ready && _uploadSupported ? _attachImage : null,
          backgroundColor: const Color(0xFF46D6B3),
          foregroundColor: const Color(0xFF07111C),
          icon: const Icon(Icons.upload_file_rounded),
          label: const Text('ضمیمه تصویر آماده'),
        ),
      ),
    );
  }
}
