import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// Opens the exact HTML mirror inside the app and injects the already-built
/// immutable app snapshot. No file picker, JSON save, or manual import needed.
class ExactSnapshotScreen extends StatefulWidget {
  const ExactSnapshotScreen({super.key, required this.snapshot});
  final Map<String, dynamic> snapshot;

  @override
  State<ExactSnapshotScreen> createState() => _ExactSnapshotScreenState();
}

class _ExactSnapshotScreenState extends State<ExactSnapshotScreen> {
  late final WebViewController _controller;
  bool _pageReady = false;
  bool _dataLoaded = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF080D18))
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) {
          _pageReady = true;
          _injectSnapshot();
        },
        onWebResourceError: (error) {
          if (error.isForMainFrame == true && mounted) {
            setState(() => _error = error.description);
          }
        },
      ));
    _loadPage();
  }

  Future<void> _loadPage() async {
    try {
      await _controller.loadFlutterAsset('assets/index.html');
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _injectSnapshot() async {
    if (!_pageReady || _dataLoaded) return;
    try {
      final payload = jsonEncode(widget.snapshot);
      await _controller.runJavaScript('window.loadSnapshotFromApp($payload);');
      if (mounted) setState(() => _dataLoaded = true);
    } catch (e) {
      if (mounted) setState(() => _error = 'انتقال داده به صفحه ناموفق بود: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('گزارش دقیق منابع بازار'),
        actions: [
          IconButton(
            tooltip: 'بارگذاری مجدد همین Snapshot',
            onPressed: () async {
              setState(() { _dataLoaded = false; _error = null; });
              await _injectSnapshot();
            },
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (!_dataLoaded && _error == null)
            const ColoredBox(
              color: Color(0xFF080D18),
              child: Center(child: CircularProgressIndicator()),
            ),
          if (_error != null)
            ColoredBox(
              color: const Color(0xFF080D18),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.error_outline, color: Colors.orangeAccent, size: 34),
                      const SizedBox(height: 12),
                      const Text('نمایش گزارش انجام نشد', style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                      const SizedBox(height: 14),
                      FilledButton(onPressed: _loadPage, child: const Text('تلاش دوباره')),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
