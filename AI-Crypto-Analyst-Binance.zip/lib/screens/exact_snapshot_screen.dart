import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// Displays the exact immutable snapshot exported by the app.
/// JavaScript render success is acknowledged separately from script execution.
class ExactSnapshotScreen extends StatefulWidget {
  const ExactSnapshotScreen({super.key, required this.snapshot});
  final Map<String, dynamic> snapshot;

  @override
  State<ExactSnapshotScreen> createState() => _ExactSnapshotScreenState();
}

class _ExactSnapshotScreenState extends State<ExactSnapshotScreen> {
  late final WebViewController _controller;
  bool _pageReady = false;
  bool _dataLoaded = false;
  bool _injecting = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF080D18))
      ..addJavaScriptChannel(
        'IndexBridge',
        onMessageReceived: (message) {
          try {
            final event = jsonDecode(message.message) as Map<String, dynamic>;
            if (!mounted) return;
            if (event['state'] == 'success') {
              setState(() {
                _dataLoaded = true;
                _error = null;
              });
            } else if (event['state'] == 'error') {
              setState(() {
                _dataLoaded = false;
                _error = 'خطای نمایش گزارش: ${event['message'] ?? 'نامشخص'}';
              });
            }
          } catch (e) {
            if (mounted) setState(() => _error = 'گزارش خطای صفحه قابل خواندن نبود: $e');
          }
        },
      )
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) {
          _pageReady = true;
          _injectSnapshot();
        },
        onWebResourceError: (error) {
          if (error.isForMainFrame == true && mounted) {
            setState(() {
              _dataLoaded = false;
              _error = 'بارگذاری صفحه گزارش ناموفق بود: ${error.description}';
            });
          }
        },
      ));
    _loadPage();
  }

  @override
  void didUpdateWidget(covariant ExactSnapshotScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(oldWidget.snapshot, widget.snapshot)) {
      _dataLoaded = false;
      _error = null;
      _injectSnapshot();
    }
  }

  Future<void> _loadPage() async {
    try {
      _pageReady = false;
      await _controller.loadFlutterAsset('assets/index.html');
    } catch (e) {
      if (mounted) setState(() => _error = 'بازکردن صفحه گزارش ناموفق بود: $e');
    }
  }

  Future<void> _injectSnapshot() async {
    if (!_pageReady || _injecting) return;
    _injecting = true;
    try {
      final payload = jsonEncode(widget.snapshot);
      final result = await _controller.runJavaScriptReturningResult(
        'window.loadSnapshotFromApp($payload);',
      );
      final succeeded = result == true || result.toString() == 'true';
      if (!succeeded) {
        throw StateError('صفحه داده را دریافت کرد اما رندر گزارش را تأیید نکرد.');
      }
      if (mounted) setState(() {
        _dataLoaded = true;
        _error = null;
      });
    } catch (e) {
      if (mounted) setState(() {
        _dataLoaded = false;
        _error = 'انتقال یا نمایش داده در Index ناموفق بود: $e';
      });
    } finally {
      _injecting = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('گزارش تحلیلی منابع بازار'),
        actions: [
          IconButton(
            tooltip: 'بارگذاری مجدد همین Snapshot',
            onPressed: () async {
              setState(() { _dataLoaded = false; _error = null; });
              if (!_pageReady) {
                await _loadPage();
              } else {
                await _injectSnapshot();
              }
            },
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (!_dataLoaded && _error == null)
            const ColoredBox(
              color: Color(0xFF080D18),
              child: Center(child: CircularProgressIndicator()),
            ),
          if (_error != null)
            ColoredBox(
              color: const Color(0xFF080D18),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.error_outline, color: Colors.orangeAccent, size: 34),
                      const SizedBox(height: 12),
                      const Text('نمایش گزارش انجام نشد', style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                      const SizedBox(height: 14),
                      FilledButton(onPressed: _loadPage, child: const Text('تلاش دوباره')),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
