
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'models/app_state.dart';
import 'services/analysis_controller.dart';
import 'screens/dashboard.dart';
import 'screens/chart_screen.dart';
import 'screens/ai_analysis.dart';
import 'screens/connectivity_and_sources.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Keep a useful in-app diagnostic instead of Flutter's opaque grey ErrorWidget.
  FlutterError.onError = (details) {
    FlutterError.presentError(details);
    debugPrint('APP_WIDGET_ERROR: ${details.exceptionAsString()}\n${details.stack ?? ''}');
  };
  ui.PlatformDispatcher.instance.onError = (error, stack) {
    debugPrint('APP_ASYNC_ERROR: $error\n$stack');
    return true;
  };
  ErrorWidget.builder = (details) {
    final message = details.exceptionAsString();
    debugPrint('APP_ERROR_WIDGET: $message\n${details.stack ?? ''}');
    return Directionality(
      textDirection: TextDirection.rtl,
      child: ColoredBox(
        color: const Color(0xFF0B1020),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF251D2A),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.orangeAccent.withOpacity(.5)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.warning_amber_rounded, color: Colors.orangeAccent, size: 30),
                  const SizedBox(height: 8),
                  const Text('خطا در نمایش این بخش', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(message.length > 220 ? '${message.substring(0, 220)}…' : message,
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white70, fontSize: 11)),
                  const SizedBox(height: 8),
                  const Text('می‌توانید از نوار پایین به بخش‌های دیگر بروید.', style: TextStyle(color: Colors.white60, fontSize: 11)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  };
  final state=AppState();
  final analysis=AnalysisController(state);
  state.addListener(analysis.onStateChanged);
  analysis.restore();
  runApp(CryptoAnalystApp(state:state,analysis:analysis));
}

class CryptoAnalystApp extends StatelessWidget {
  const CryptoAnalystApp({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;

  @override
  Widget build(BuildContext context) {
    const bg=Color(0xFF0B1020);
    return MaterialApp(
      debugShowCheckedModeBanner:false,title:'AI Crypto Analyst',
      // The app UI is Persian-first. Keep the whole Flutter widget tree RTL;
      // Flutter's bidi algorithm will still render Latin symbols and numbers correctly.
      builder:(context,child)=>Directionality(
        textDirection:TextDirection.rtl,
        child:child??const SizedBox.shrink(),
      ),
      theme:ThemeData(
        brightness:Brightness.dark,scaffoldBackgroundColor:bg,
        colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF46D6B3),brightness:Brightness.dark,surface:const Color(0xFF151D31)),
        useMaterial3:true,
        cardTheme:CardThemeData(color:const Color(0xFF151D31),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18))),
      ),
      home:AppShell(state:state,analysis:analysis),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  @override State<AppShell> createState()=>_AppShellState();
}
class _AppShellState extends State<AppShell>{
  int index=0;
  final List<Widget?> _pages=List<Widget?>.filled(4,null);

  Widget _createPage(int pageIndex) {
    switch(pageIndex) {
      case 0: return DashboardScreen(state:widget.state,analysis:widget.analysis);
      case 1: return ChartScreen(state:widget.state,analysis:widget.analysis);
      case 2: return AiAnalysisScreen(state:widget.state,analysis:widget.analysis);
      default: return const SmartConnectivityScreen();
    }
  }

  @override
  Widget build(BuildContext context)=>Scaffold(
    body:SafeArea(child:IndexedStack(index:index,children:List<Widget>.generate(4,(i){
      // Create each feature only on first visit. Hidden pages must not start
      // chart polling, model-catalog requests, or source diagnostics at app launch.
      _pages[i] ??= i==index ? _createPage(i) : null;
      return _pages[i] ?? const SizedBox.shrink();
    }))),
    bottomNavigationBar:NavigationBar(
      selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'داشبورد'),
        NavigationDestination(icon:Icon(Icons.candlestick_chart_outlined),selectedIcon:Icon(Icons.candlestick_chart),label:'نمودار'),
        NavigationDestination(icon:Icon(Icons.psychology_outlined),selectedIcon:Icon(Icons.psychology),label:'تحلیل هوشمند'),
        NavigationDestination(icon:Icon(Icons.hub_outlined),selectedIcon:Icon(Icons.hub),label:'اتصال هوشمند'),
      ],
    ),
  );
}
