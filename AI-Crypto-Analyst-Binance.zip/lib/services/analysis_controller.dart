import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import 'ai_service.dart';
import 'market_api.dart';
import 'technical_engine.dart';
import 'altfins_service.dart';
import 'hybrid_engine.dart';

class AnalysisController extends ChangeNotifier {
  AnalysisController(this.appState)
      : _lastExchange = appState.exchange,
        _lastSymbol = appState.symbol;
  final AppState appState;
  final MarketApi api = MarketApi();
  final TechnicalEngine engine = TechnicalEngine();

  bool loading = false;
  bool restoring = true;
  String status = 'در حال بازیابی آخرین تحلیل ذخیره‌شده...';
  String? error;
  TechnicalReport? report;
  AiConsensus? consensus;
  DateTime? technicalAt;
  DateTime? aiAt;
  List<MarketCandle> history1h = const [];
  List<MarketCandle> history15m = const [];
  List<MarketCandle> history5m = const [];
  int historyCount1h = 0, historyCount15m = 0, historyCount5m = 0;
  String? snapshotId;
  double? latestReferencePrice;
  String _lastExchange;
  String _lastSymbol;
  int _requestId = 0;

  String get cacheKey => 'analysis_cache_${appState.exchange}_${appState.symbol}';
  bool get isStale => technicalAt == null ||
      DateTime.now().difference(technicalAt!) > const Duration(minutes: 15);
  bool get isAiStale => aiAt == null ||
      DateTime.now().difference(aiAt!) > const Duration(minutes: 15);

  Future<void> restore() async {
    final requestedExchange = appState.exchange;
    final requestedSymbol = appState.symbol;
    restoring = true;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('analysis_cache_${requestedExchange}_$requestedSymbol');
      if (requestedExchange != appState.exchange || requestedSymbol != appState.symbol) return;
      if (raw != null) {
        final decoded = jsonDecode(raw);
        if (decoded is Map) {
          final map = Map<String, dynamic>.from(decoded);
          if (map['report'] is Map) {
            report = TechnicalReport.fromJson(Map<String, dynamic>.from(map['report']));
            technicalAt = DateTime.tryParse('${map['technicalAt'] ?? ''}');
            historyCount1h = (map['historyCount1h'] as num?)?.toInt() ?? 0;
            historyCount15m = (map['historyCount15m'] as num?)?.toInt() ?? 0;
            historyCount5m = (map['historyCount5m'] as num?)?.toInt() ?? 0;
            snapshotId = map['snapshotId']?.toString();
            latestReferencePrice = (map['referencePrice'] as num?)?.toDouble();
            history1h = _restoreCandles(map['snapshot1h']);
            history15m = _restoreCandles(map['snapshot15m']);
            history5m = _restoreCandles(map['snapshot5m']);
            // Older caches did not persist the ticker anchor. Also reject a
            // corrupted/stale anchor that is inconsistent with the saved 5m close.
            final restoredPrice = latestReferencePrice;
            final lastClosed5m = history5m.isEmpty ? null : history5m.last.close;
            if (restoredPrice == null || !restoredPrice.isFinite || restoredPrice <= 0 ||
                lastClosed5m == null || lastClosed5m <= 0 ||
                (restoredPrice - lastClosed5m).abs() / lastClosed5m > 0.025) {
              latestReferencePrice = null;
            }
            // Invalidate pre-Persian / pre-independent-plan AI cache while preserving
            // the technical report and its saved market snapshot.
            if (map['aiSchemaVersion'] == 2 && map['consensus'] is Map) {
              final restoredConsensus = AiConsensus.fromJson(Map<String, dynamic>.from(map['consensus']));
              // A cached AI answer is active only when it belongs to the exact
              // technical snapshot restored above. Never mix generations.
              if (latestReferencePrice != null && snapshotId != null &&
                  restoredConsensus.snapshotId == snapshotId) {
                consensus = restoredConsensus;
                aiAt = DateTime.tryParse('${map['aiAt'] ?? ''}');
              } else {
                consensus = null;
                aiAt = null;
              }
            } else {
              consensus = null;
              aiAt = null;
            }
            status = 'آخرین تحلیل ذخیره‌شده بازیابی شد؛ ${isStale ? 'قدیمی' : 'تازه'}.';
          }
        }
      } else {
        status = 'هنوز تحلیلی برای این نماد ذخیره نشده است.';
      }
    } catch (e) {
      error = 'بازیابی تحلیل ذخیره‌شده ناموفق بود: $e';
      status = 'خطا در بازیابی تحلیل قبلی.';
    } finally {
      restoring = false;
      notifyListeners();
    }
  }

  Future<void> _persist({String? exchange, String? symbol}) async {
    if (report == null || technicalAt == null) return;
    final targetExchange = exchange ?? appState.exchange;
    final targetSymbol = symbol ?? appState.symbol;
    final prefs = await SharedPreferences.getInstance();
    if (targetExchange != appState.exchange || targetSymbol != appState.symbol) return;
    final data = <String, dynamic>{
      'exchange': targetExchange,
      'symbol': targetSymbol,
      'technicalAt': technicalAt!.toIso8601String(),
      'historyCount1h': historyCount1h,
      'historyCount15m': historyCount15m,
      'historyCount5m': historyCount5m,
      'snapshotId': snapshotId,
      'referencePrice': latestReferencePrice,
      'snapshot1h': history1h.map((c)=>c.toJson()).toList(),
      'snapshot15m': history15m.map((c)=>c.toJson()).toList(),
      'snapshot5m': history5m.map((c)=>c.toJson()).toList(),
      'aiAt': aiAt?.toIso8601String(),
      'aiSchemaVersion': 2,
      'report': report!.toJson(),
      'consensus': consensus?.toJson(),
    };
    await prefs.setString('analysis_cache_${targetExchange}_$targetSymbol', jsonEncode(data));
  }

  List<MarketCandle> _restoreCandles(dynamic raw) {
    if(raw is! List)return const [];
    final out=<MarketCandle>[];
    for(final item in raw){if(item is Map){try{out.add(MarketCandle.fromJson(Map<String,dynamic>.from(item)));}catch(_){}}}
    return List.unmodifiable(out);
  }


  /// Builds a read-only export from the exact in-memory objects used by the app.
  /// The HTML monitor must render this payload verbatim and must never recalculate.
  Future<Map<String, dynamic>> buildExactExportSnapshot() async {
    final decisionState = HybridEngine().evaluateDashboard(
      technical: report,
      consensus: consensus,
      technicalStale: isStale,
      aiStale: isAiStale,
    );
    final technicalStale = decisionState.technicalInvalid;
    final aiStale = decisionState.aiInvalid;
    final hybridResults = <String, dynamic>{
      for (final entry in decisionState.providerResults.entries)
        entry.key: {
          'provider': entry.value.provider,
          'decision': entry.value.decision,
          'score': entry.value.score,
          'technicalScore': entry.value.technicalScore,
          'aiScore': entry.value.aiScore,
          'technicalWeights': entry.value.technicalWeights,
          'aiWeights': entry.value.aiWeights,
          'reasons': entry.value.reasons,
          'calibration': entry.value.calibration,
        },
    };

    final alt = AltFinsService();
    final cachedAlt = await Future.wait([
      alt.loadCached(symbol: appState.symbol, timeframe: '1h', exchange: appState.exchange),
      alt.loadCached(symbol: appState.symbol, timeframe: '15m', exchange: appState.exchange),
      alt.getQuota().catchError((_) => <String, dynamic>{
        'ok': false, 'source': 'altfins', 'status': 'UNAVAILABLE',
      }),
    ]);

    return <String, dynamic>{
      'schema': 'ai_crypto_analyst_exact_snapshot_v1',
      'exportedAt': DateTime.now().toUtc().toIso8601String(),
      'identity': {
        'exchange': appState.exchange,
        'symbol': appState.symbol,
        'snapshotId': snapshotId,
        'referencePrice': latestReferencePrice,
        'technicalAt': technicalAt?.toUtc().toIso8601String(),
        'aiAt': aiAt?.toUtc().toIso8601String(),
        'technicalStale': technicalStale,
        'aiStale': aiStale,
        'historyCount1h': historyCount1h,
        'historyCount15m': historyCount15m,
        'historyCount5m': historyCount5m,
      },
      'technical': report?.toJson(),
      'ai': consensus?.toJson(),
      'hybrid': {
        'decision': decisionState.decision,
        'validProviderCount': decisionState.validProviders.length,
        'buyVotes': decisionState.buyVotes,
        'sellVotes': decisionState.sellVotes,
        'providerResults': hybridResults,
      },
      'altfins': {
        'quota': cachedAlt[2],
        'timeframes': {
          '1h': cachedAlt[0] ?? {
            'ok': false, 'source': 'altfins', 'status': 'NOT_FETCHED',
          },
          '15m': cachedAlt[1] ?? {
            'ok': false, 'source': 'altfins', 'status': 'NOT_FETCHED',
          },
          '5m': {
            'ok': false, 'source': 'altfins',
            'status': 'UNSUPPORTED_TIMEFRAME',
            'affectsTradeDecision': false,
          },
        },
      },
      'marketSnapshot': {
        '1h': history1h.map((c) => c.toJson()).toList(),
        '15m': history15m.map((c) => c.toJson()).toList(),
        '5m': history5m.map((c) => c.toJson()).toList(),
      },
    };
  }

  Future<bool> saveConsensus(AiConsensus value, {bool mergeSameSnapshot = true}) async {
    // Reject late provider responses if a newer market snapshot has replaced
    // the one this request analyzed. This is the final write-side guard.
    if (snapshotId == null || value.snapshotId == null || value.snapshotId != snapshotId) {
      return false;
    }
    final sameSnapshot = consensus != null &&
        consensus!.snapshotId != null &&
        consensus!.snapshotId == value.snapshotId;
    consensus = mergeSameSnapshot && sameSnapshot
        ? consensus!.mergePartial(value)
        : value;
    aiAt = DateTime.now();
    await _persist();
    notifyListeners();
    return true;
  }

  Future<void> onStateChanged() async {
    if (_lastExchange == appState.exchange && _lastSymbol == appState.symbol) return;
    _lastExchange = appState.exchange;
    _lastSymbol = appState.symbol;
    _requestId++;
    loading = false;
    report = null;
    consensus = null;
    technicalAt = null;
    aiAt = null;
    history1h = const [];
    history15m = const [];
    history5m = const [];
    historyCount1h = historyCount15m = historyCount5m = 0;
    snapshotId = null;
    latestReferencePrice = null;
    error = null;
    status = 'در حال بازیابی تحلیل ذخیره‌شده برای نماد جدید...';
    notifyListeners();
    await restore();
  }

  List<MarketCandle> _closedHistory(List<MarketCandle> candles, int intervalSeconds, int targetCount) {
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final closed = candles.where((c) => c.time + intervalSeconds <= now).toList()
      ..sort((a,b)=>a.time.compareTo(b.time));
    return List.unmodifiable(closed.length > targetCount
        ? closed.sublist(closed.length-targetCount) : closed);
  }


  void _validateFreshCandles(List<MarketCandle> candles, int intervalSeconds, String label) {
    if (candles.isEmpty) throw MarketApiException('تاریخچه $label خالی است.');
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final latest = candles.last;
    final age = now - (latest.time + intervalSeconds);
    // Never run a new analysis from a cache that is more than 2.5 candles old.
    if (age > intervalSeconds * 2.5) {
      throw MarketApiException('داده $label قدیمی است (${(age / 60).round()} دقیقه). دریافت تازه از صرافی ناموفق بود؛ تحلیل با داده قدیمی اجرا نشد.');
    }
  }

  Future<bool> run() async {
    final id = ++_requestId;
    loading = true;
    error = null;
    status = 'دریافت داده‌های 1H، 15M و 5M...';
    notifyListeners();
    final exchange = appState.exchange, symbol = appState.symbol;
    try {
      final responses = await Future.wait<Object>([
        api.getKlines(exchange: exchange, symbol: symbol, interval: '1h', limit: 1001, refreshInterval: const Duration(seconds: 15)),
        api.getKlines(exchange: exchange, symbol: symbol, interval: '15m', limit: 1501, refreshInterval: const Duration(seconds: 15)),
        api.getKlines(exchange: exchange, symbol: symbol, interval: '5m', limit: 2001, refreshInterval: const Duration(seconds: 15)),
        api.getPrice(exchange: exchange, symbol: symbol),
      ]);
      if (id != _requestId) return false;
      final candles1h = responses[0] as List<MarketCandle>;
      final candles15m = responses[1] as List<MarketCandle>;
      final candles5m = responses[2] as List<MarketCandle>;
      final referencePrice = responses[3] as double;
      _validateFreshCandles(candles1h, 3600, '1H');
      _validateFreshCandles(candles15m, 900, '15M');
      _validateFreshCandles(candles5m, 300, '5M');
      final lastClosed5m = _closedHistory(candles5m, 300, 2).last;
      final priceGap = (referencePrice - lastClosed5m.close).abs() / lastClosed5m.close;
      if (priceGap > 0.025) {
        throw MarketApiException('قیمت لحظه‌ای با آخرین کندل بسته‌شده 5M بیش از ۲٫۵٪ اختلاف دارد؛ برای جلوگیری از تحلیل با داده ناسازگار، اجرا متوقف شد.');
      }
      status = 'محاسبه روند، ساختار، نقدینگی و قدرت خریدار/فروشنده...';
      notifyListeners();
      final result = engine.analyze(h1: candles1h, m15: candles15m, m5: candles5m);
      if (id != _requestId) return false;
      // The AI receives the same completed candles used by the technical engine;
      // the still-forming candle is excluded to avoid a moving/inconsistent snapshot.
      history1h = _closedHistory(candles1h, 3600, 1000);
      history15m = _closedHistory(candles15m, 900, 1500);
      history5m = _closedHistory(candles5m, 300, 2000);
      historyCount1h = history1h.length;
      historyCount15m = history15m.length;
      historyCount5m = history5m.length;
      snapshotId = '${exchange}_${symbol}_${DateTime.now().toUtc().microsecondsSinceEpoch}_${history1h.last.time}_${history15m.last.time}_${history5m.last.time}';
      latestReferencePrice = referencePrice;
      report = result;
      // A successful technical refresh creates a new immutable snapshot.
      // Previous AI outputs are invalidated from the active cache and must not be
      // shown, merged into Hybrid, or retried against this new snapshot.
      consensus = null;
      aiAt = null;
      technicalAt = DateTime.now();
      final historyShort = historyCount1h < 1000 || historyCount15m < 1500 || historyCount5m < 2000;
      status = historyShort
          ? 'تحلیل با تاریخچه کمتر از هدف تکمیل شد: 1H=$historyCount1h/1000، 15M=$historyCount15m/1500، 5M=$historyCount5m/2000. صفحه‌بندی پروکسی را بررسی کنید.'
          : 'تحلیل تکمیل و ذخیره شد؛ کندل بسته‌شده: 1H=$historyCount1h، 15M=$historyCount15m، 5M=$historyCount5m.';
      await _persist(exchange: exchange, symbol: symbol);
      return true;
    } catch (e) {
      if (id != _requestId) return false;
      error = e.toString();
      status = 'تحلیل کامل نشد؛ آخرین تحلیل ذخیره‌شده حفظ شده است.';
      return false;
    } finally {
      if (id == _requestId) {
        loading = false;
        notifyListeners();
      }
    }
  }
}
