import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import 'ai_service.dart';
import 'market_api.dart';
import 'technical_engine.dart';
import 'altfins_service.dart';
import 'hybrid_engine.dart';

class AnalysisController extends ChangeNotifier {
  AnalysisController(this.appState)
      : _lastExchange = appState.exchange,
        _lastSymbol = appState.symbol,
        _lastTimeframe = appState.timeframe;
  final AppState appState;
  final MarketApi api = MarketApi();
  final TechnicalEngine engine = TechnicalEngine();

  bool loading = false;
  bool restoring = true;
  String status = 'در حال بازیابی آخرین تحلیل ذخیره‌شده...';
  String? error;
  TechnicalReport? report;
  AiConsensus? consensus;
  DateTime? technicalAt;
  DateTime? aiAt;
  List<MarketCandle> history1h = const [];
  List<MarketCandle> history15m = const [];
  List<MarketCandle> history5m = const [];
  int historyCount1h = 0, historyCount15m = 0, historyCount5m = 0;
  String? snapshotId;
  double? latestReferencePrice;
  String _lastExchange;
  String _lastSymbol;
  int _requestId = 0;
  int _requestGeneration = 0;
  int _restoreGeneration = 0;
  String _lastTimeframe;

  // A single app-wide workflow lock shared by Dashboard and AI Analysis.
  bool workflowBusy = false;
  String? workflowOwner;
  final Map<String, String> providerExecutionStatus = {
    'gemini': 'idle', 'openrouter': 'idle', 'groq': 'idle',
  };

  // Keep the last successful AI snapshots separate from the active snapshot.
  // Historical results are display-only and are never fed into current consensus.
  final Map<String, AiConsensus> historicalAiResults = <String, AiConsensus>{};
  final Map<String, DateTime> historicalAiTimes = <String, DateTime>{};
  List<String> get _historicalSnapshotIdsNewestFirst {
    final ids = historicalAiResults.keys.toList();
    ids.sort((a, b) =>
      (historicalAiTimes[b] ?? DateTime.fromMillisecondsSinceEpoch(0))
        .compareTo(historicalAiTimes[a] ?? DateTime.fromMillisecondsSinceEpoch(0)));
    return ids;
  }

  AiConsensus? get latestHistoricalConsensus => _historicalSnapshotIdsNewestFirst.isEmpty
      ? null : historicalAiResults[_historicalSnapshotIdsNewestFirst.first];
  DateTime? get latestHistoricalAiAt => _historicalSnapshotIdsNewestFirst.isEmpty
      ? null : historicalAiTimes[_historicalSnapshotIdsNewestFirst.first];

  AiModelResult? historicalProviderResult(String provider) {
    AiModelResult? fallback;
    for (final id in _historicalSnapshotIdsNewestFirst) {
      final item = historicalAiResults[id]!;
      final result = switch (provider) {
        'gemini' => item.gemini,
        'openrouter' => item.openrouter,
        'groq' => item.groq,
        _ => null,
      };
      if (result == null || result.status == 'not_selected' || result.status == 'error') continue;
      if (result.status == 'ok') return result;
      fallback ??= result;
    }
    return fallback;
  }

  int get requestGeneration => _requestGeneration;

  bool acquireWorkflow(String owner) {
    if (workflowBusy) return false;
    workflowBusy = true;
    workflowOwner = owner;
    notifyListeners();
    return true;
  }

  void releaseWorkflow(String owner) {
    if (!workflowBusy || workflowOwner != owner) return;
    workflowBusy = false;
    workflowOwner = null;
    notifyListeners();
  }

  void setProvidersRunning(Iterable<String> providers) {
    for (final provider in providers) {
      if (providerExecutionStatus.containsKey(provider)) {
        providerExecutionStatus[provider] = 'running';
      }
    }
    notifyListeners();
  }

  void updateProviderStatuses(AiConsensus value) {
    providerExecutionStatus['gemini'] = _providerStatus(value.gemini.status);
    providerExecutionStatus['openrouter'] = _providerStatus(value.openrouter.status);
    providerExecutionStatus['groq'] = _providerStatus(value.groq.status);
    notifyListeners();
  }

  String _providerStatus(String status) {
    if (status == 'ok') return 'success';
    if (status == 'error') return 'failed';
    if (status == 'incomplete') return 'incomplete';
    if (status == 'not_selected') return 'idle';
    return 'pending';
  }


  String get cacheKey => 'analysis_cache_${appState.exchange}_${appState.symbol}';
  bool get isStale => technicalAt == null ||
      DateTime.now().difference(technicalAt!) > const Duration(minutes: 15);
  bool get isAiStale => aiAt == null ||
      DateTime.now().difference(aiAt!) > const Duration(minutes: 15);

  Future<void> restore() async {
    final requestedExchange = appState.exchange;
    final requestedSymbol = appState.symbol;
    final restoreGeneration = ++_restoreGeneration;
    restoring = true;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('analysis_cache_${requestedExchange}_$requestedSymbol');
      if (restoreGeneration != _restoreGeneration ||
          requestedExchange != appState.exchange || requestedSymbol != appState.symbol) return;
      historicalAiResults.clear();
      historicalAiTimes.clear();
      providerExecutionStatus.updateAll((key, value) => 'idle');
      if (raw != null) {
        final decoded = jsonDecode(raw);
        if (decoded is Map) {
          final map = Map<String, dynamic>.from(decoded);
          if (map['aiHistory'] is Map) {
            final history = Map<String, dynamic>.from(map['aiHistory']);
            for (final entry in history.entries) {
              if (entry.value is Map) {
                final item = Map<String, dynamic>.from(entry.value as Map);
                if (item['consensus'] is Map) {
                  try {
                    historicalAiResults[entry.key] = AiConsensus.fromJson(
                      Map<String, dynamic>.from(item['consensus'] as Map));
                    final at = DateTime.tryParse('${item['aiAt'] ?? ''}');
                    if (at != null) historicalAiTimes[entry.key] = at;
                  } catch (_) {}
                }
              }
            }
          }
          if (map['report'] is Map) {
            report = TechnicalReport.fromJson(Map<String, dynamic>.from(map['report']));
            technicalAt = DateTime.tryParse('${map['technicalAt'] ?? ''}');
            historyCount1h = (map['historyCount1h'] as num?)?.toInt() ?? 0;
            historyCount15m = (map['historyCount15m'] as num?)?.toInt() ?? 0;
            historyCount5m = (map['historyCount5m'] as num?)?.toInt() ?? 0;
            snapshotId = map['snapshotId']?.toString();
            latestReferencePrice = (map['referencePrice'] as num?)?.toDouble();
            history1h = _restoreCandles(map['snapshot1h']);
            history15m = _restoreCandles(map['snapshot15m']);
            history5m = _restoreCandles(map['snapshot5m']);
            // Older caches did not persist the ticker anchor. Also reject a
            // corrupted/stale anchor that is inconsistent with the saved 5m close.
            final restoredPrice = latestReferencePrice;
            final lastClosed5m = history5m.isEmpty ? null : history5m.last.close;
            if (restoredPrice == null || !restoredPrice.isFinite || restoredPrice <= 0 ||
                lastClosed5m == null || lastClosed5m <= 0 ||
                (restoredPrice - lastClosed5m).abs() / lastClosed5m > 0.025) {
              latestReferencePrice = null;
            }
            // Invalidate pre-Persian / pre-independent-plan AI cache while preserving
            // the technical report and its saved market snapshot.
            if (map['consensus'] is Map) {
              final restoredConsensus = AiConsensus.fromJson(Map<String, dynamic>.from(map['consensus']));
              final restoredAiAt = DateTime.tryParse('${map['aiAt'] ?? ''}');
              // Only the new fingerprint schema may be promoted to active AI.
              // Older active answers are migrated into display-only history.
              final isCurrentSnapshot = map['aiSchemaVersion'] == 3 &&
                  latestReferencePrice != null && snapshotId != null &&
                  restoredConsensus.snapshotId == snapshotId &&
                  snapshotId!.startsWith('snap2_');
              if (isCurrentSnapshot) {
                consensus = restoredConsensus;
                aiAt = restoredAiAt;
              } else {
                consensus = null;
                aiAt = null;
                final oldSnapshotId = restoredConsensus.snapshotId;
                if (oldSnapshotId != null) {
                  historicalAiResults.putIfAbsent(oldSnapshotId, () => restoredConsensus);
                  if (restoredAiAt != null) {
                    historicalAiTimes.putIfAbsent(oldSnapshotId, () => restoredAiAt);
                  }
                }
              }
            } else {
              consensus = null;
              aiAt = null;
            }
            if (consensus != null && consensus!.snapshotId != null) {
              historicalAiResults[consensus!.snapshotId!] = consensus!;
              if (aiAt != null) historicalAiTimes[consensus!.snapshotId!] = aiAt!;
              updateProviderStatuses(consensus!);
            }
            status = 'آخرین تحلیل ذخیره‌شده بازیابی شد؛ ${isStale ? 'قدیمی' : 'تازه'}.';
          }
        }
      } else {
        status = 'هنوز تحلیلی برای این نماد ذخیره نشده است.';
      }
    } catch (e) {
      if (restoreGeneration == _restoreGeneration &&
          requestedExchange == appState.exchange && requestedSymbol == appState.symbol) {
        error = 'بازیابی تحلیل ذخیره‌شده ناموفق بود: $e';
        status = 'خطا در بازیابی تحلیل قبلی.';
      }
    } finally {
      // A slower restore for a previously selected market must not finish the
      // newer market's loading state or publish stale cache data.
      if (restoreGeneration == _restoreGeneration &&
          requestedExchange == appState.exchange && requestedSymbol == appState.symbol) {
        restoring = false;
        notifyListeners();
      }
    }
  }

  Future<void> _persist({String? exchange, String? symbol}) async {
    if (report == null || technicalAt == null) return;
    final targetExchange = exchange ?? appState.exchange;
    final targetSymbol = symbol ?? appState.symbol;
    final prefs = await SharedPreferences.getInstance();
    if (targetExchange != appState.exchange || targetSymbol != appState.symbol) return;
    final data = <String, dynamic>{
      'exchange': targetExchange,
      'symbol': targetSymbol,
      'technicalAt': technicalAt!.toIso8601String(),
      'historyCount1h': historyCount1h,
      'historyCount15m': historyCount15m,
      'historyCount5m': historyCount5m,
      'snapshotId': snapshotId,
      'referencePrice': latestReferencePrice,
      'snapshot1h': history1h.map((c)=>c.toJson()).toList(),
      'snapshot15m': history15m.map((c)=>c.toJson()).toList(),
      'snapshot5m': history5m.map((c)=>c.toJson()).toList(),
      'aiAt': aiAt?.toIso8601String(),
      'aiSchemaVersion': 3,
      'report': report!.toJson(),
      'consensus': consensus?.toJson(),
      'aiHistory': {
        for (final entry in historicalAiResults.entries)
          entry.key: {
            'consensus': entry.value.toJson(),
            'aiAt': historicalAiTimes[entry.key]?.toIso8601String(),
          },
      },
    };
    await prefs.setString('analysis_cache_${targetExchange}_$targetSymbol', jsonEncode(data));
  }

  List<MarketCandle> _restoreCandles(dynamic raw) {
    if(raw is! List)return const [];
    final out=<MarketCandle>[];
    for(final item in raw){if(item is Map){try{out.add(MarketCandle.fromJson(Map<String,dynamic>.from(item)));}catch(_){}}}
    return List.unmodifiable(out);
  }


  /// Builds a read-only export from the exact in-memory objects used by the app.
  /// The HTML monitor must render this payload verbatim and must never recalculate.
  Future<Map<String, dynamic>> buildExactExportSnapshot() async {
    final decisionState = HybridEngine().evaluateDashboard(
      technical: report,
      consensus: consensus,
      technicalStale: isStale,
      aiStale: isAiStale,
    );
    final technicalStale = decisionState.technicalInvalid;
    final aiStale = decisionState.aiInvalid;
    final hybridResults = <String, dynamic>{
      for (final entry in decisionState.providerResults.entries)
        entry.key: {
          'provider': entry.value.provider,
          'decision': entry.value.decision,
          'score': entry.value.score,
          'technicalScore': entry.value.technicalScore,
          'aiScore': entry.value.aiScore,
          'technicalWeights': entry.value.technicalWeights,
          'aiWeights': entry.value.aiWeights,
          'reasons': entry.value.reasons,
          'calibration': entry.value.calibration,
        },
    };

    final alt = AltFinsService();
    final cachedAlt = await Future.wait([
      alt.loadCached(symbol: appState.symbol, timeframe: '1h', exchange: appState.exchange),
      alt.loadCached(symbol: appState.symbol, timeframe: '15m', exchange: appState.exchange),
      alt.getQuota().catchError((_) => <String, dynamic>{
        'ok': false, 'source': 'altfins', 'status': 'UNAVAILABLE',
      }),
    ]);

    return <String, dynamic>{
      'schema': 'ai_crypto_analyst_exact_snapshot_v1',
      'exportedAt': DateTime.now().toUtc().toIso8601String(),
      'identity': {
        'exchange': appState.exchange,
        'symbol': appState.symbol,
        'marketType': 'SPOT',
        'snapshotId': snapshotId,
        'referencePrice': latestReferencePrice,
        'technicalAt': technicalAt?.toUtc().toIso8601String(),
        'aiAt': aiAt?.toUtc().toIso8601String(),
        'technicalStale': technicalStale,
        'aiStale': aiStale,
        'historyCount1h': historyCount1h,
        'historyCount15m': historyCount15m,
        'historyCount5m': historyCount5m,
      },
      'technical': report?.toJson(),
      'ai': consensus?.toJson(),
      'hybrid': {
        'decision': decisionState.decision,
        'validProviderCount': decisionState.validProviders.length,
        'technicalPlanInvalid': decisionState.technicalPlanInvalid,
        'buyVotes': decisionState.buyVotes,
        'sellVotes': decisionState.sellVotes,
        'providerResults': hybridResults,
      },
      'altfins': {
        'quota': cachedAlt[2],
        'timeframes': {
          '1h': cachedAlt[0] ?? {
            'ok': false, 'source': 'altfins', 'status': 'NOT_FETCHED',
          },
          '15m': cachedAlt[1] ?? {
            'ok': false, 'source': 'altfins', 'status': 'NOT_FETCHED',
          },
          '5m': {
            'ok': false, 'source': 'altfins',
            'status': 'UNSUPPORTED_TIMEFRAME',
            'affectsTradeDecision': false,
          },
        },
      },
      'marketSnapshot': {
        '1h': history1h.map((c) => c.toJson()).toList(),
        '15m': history15m.map((c) => c.toJson()).toList(),
        '5m': history5m.map((c) => c.toJson()).toList(),
      },
    };
  }

  Future<bool> saveConsensus(AiConsensus value, {bool mergeSameSnapshot = true}) async {
    // Reject late provider responses if a newer market snapshot has replaced
    // the one this request analyzed. This is the final write-side guard.
    if (snapshotId == null || value.snapshotId == null || value.snapshotId != snapshotId) {
      return false;
    }
    final sameSnapshot = consensus != null &&
        consensus!.snapshotId != null &&
        consensus!.snapshotId == value.snapshotId;
    consensus = mergeSameSnapshot && sameSnapshot
        ? consensus!.mergePartial(value)
        : value;
    aiAt = DateTime.now();
    historicalAiResults[value.snapshotId!] = consensus!;
    historicalAiTimes[value.snapshotId!] = aiAt!;
    // Bound local history to the ten most recent immutable snapshots.
    while (historicalAiResults.length > 10) {
      final oldest = historicalAiResults.keys.first;
      historicalAiResults.remove(oldest);
      historicalAiTimes.remove(oldest);
    }
    updateProviderStatuses(consensus!);
    await _persist();
    notifyListeners();
    return true;
  }

  Future<void> onStateChanged() async {
    final marketChanged = _lastExchange != appState.exchange || _lastSymbol != appState.symbol;
    final timeframeChanged = _lastTimeframe != appState.timeframe;
    if (!marketChanged && !timeframeChanged) return;
    _lastExchange = appState.exchange;
    _lastSymbol = appState.symbol;
    _lastTimeframe = appState.timeframe;
    _requestGeneration++;
    if (!marketChanged) {
      // A timeframe switch invalidates in-flight responses without discarding
      // the market snapshot or any stored provider result.
      providerExecutionStatus.updateAll((key, value) => value == 'running' ? 'idle' : value);
      notifyListeners();
      return;
    }
    providerExecutionStatus.updateAll((key, value) => 'idle');
    _restoreGeneration++; // invalidate every restore belonging to the old market
    restoring = true;
    _requestId++;
    loading = false;
    report = null;
    consensus = null;
    technicalAt = null;
    aiAt = null;
    history1h = const [];
    history15m = const [];
    history5m = const [];
    historyCount1h = historyCount15m = historyCount5m = 0;
    snapshotId = null;
    latestReferencePrice = null;
    error = null;
    status = 'در حال بازیابی تحلیل ذخیره‌شده برای نماد جدید...';
    notifyListeners();
    await restore();
  }

  /// Deterministic identity for the exact closed OHLCV inputs plus a
  /// deliberately quantized live-price anchor. The anchor uses 0.1% buckets
  /// relative to the latest closed 5m close: ticker noise inside a bucket does
  /// not trigger another paid AI request, while a material move does.
  static String buildSnapshotId({
    required String exchange,
    required String symbol,
    required List<MarketCandle> history1h,
    required List<MarketCandle> history15m,
    required List<MarketCandle> history5m,
    required double referencePrice,
  }) {
    if (history1h.isEmpty || history15m.isEmpty || history5m.isEmpty ||
        !referencePrice.isFinite || referencePrice <= 0) {
      throw ArgumentError('Snapshot requires valid closed candle histories and reference price.');
    }
    final last5mClose = history5m.last.close;
    if (!last5mClose.isFinite || last5mClose <= 0) {
      throw ArgumentError('Snapshot requires a valid latest closed 5m close.');
    }
    final priceBucketPermille = ((referencePrice / last5mClose - 1) * 1000).round();
    final buffer = StringBuffer()
      ..write('v2|')..write(exchange)..write('|')..write(symbol)
      ..write('|SPOT|anchorPermille=')..write(priceBucketPermille);
    void appendHistory(String timeframe, List<MarketCandle> candles) {
      buffer.write('|$timeframe:${candles.length}');
      for (final candle in candles) {
        buffer
          ..write(';')..write(candle.time)
          ..write(',')..write(candle.open.toStringAsPrecision(17))
          ..write(',')..write(candle.high.toStringAsPrecision(17))
          ..write(',')..write(candle.low.toStringAsPrecision(17))
          ..write(',')..write(candle.close.toStringAsPrecision(17))
          ..write(',')..write(candle.volume.toStringAsPrecision(17));
      }
    }
    appendHistory('1h', history1h);
    appendHistory('15m', history15m);
    appendHistory('5m', history5m);

    // Two independent 32-bit rolling hashes avoid a new package dependency.
    // The canonical input above is deterministic across app launches.
    var hashA = 2166136261;
    var hashB = 5381;
    for (final unit in buffer.toString().codeUnits) {
      hashA = ((hashA ^ unit) * 16777619) & 0xFFFFFFFF;
      hashB = ((hashB * 33) ^ unit) & 0xFFFFFFFF;
    }
    return 'snap2_${hashA.toRadixString(16).padLeft(8, '0')}${hashB.toRadixString(16).padLeft(8, '0')}';
  }

  List<MarketCandle> _closedHistory(List<MarketCandle> candles, int intervalSeconds, int targetCount) {
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final closed = candles.where((c) => c.time + intervalSeconds <= now).toList()
      ..sort((a,b)=>a.time.compareTo(b.time));
    return List.unmodifiable(closed.length > targetCount
        ? closed.sublist(closed.length-targetCount) : closed);
  }


  void _validateFreshCandles(List<MarketCandle> candles, int intervalSeconds, String label) {
    final closed = _closedHistory(candles, intervalSeconds, candles.length);
    if (closed.length < 50) {
      throw MarketApiException('تاریخچه بسته‌شده $label کافی نیست؛ حداقل ۵۰ کندل معتبر لازم است.');
    }
    for (var i = 0; i < closed.length; i++) {
      final candle = closed[i];
      if (candle.time <= 0 || candle.time % intervalSeconds != 0) {
        throw MarketApiException('زمان شروع کندل $label با مرز تایم‌فریم هماهنگ نیست (ردیف ${i + 1}).');
      }
      final values = [candle.open, candle.high, candle.low, candle.close, candle.volume];
      if (values.any((value) => !value.isFinite) ||
          candle.open <= 0 || candle.high <= 0 || candle.low <= 0 ||
          candle.close <= 0 || candle.volume < 0 ||
          candle.high < candle.open || candle.high < candle.close ||
          candle.low > candle.open || candle.low > candle.close ||
          candle.high < candle.low) {
        throw MarketApiException('کندل نامعتبر در تاریخچه $label شناسایی شد (ردیف ${i + 1}).');
      }
      if (i > 0) {
        final delta = candle.time - closed[i - 1].time;
        if (delta != intervalSeconds) {
          final reason = delta <= 0 ? 'کندل تکراری یا نامرتب' : 'شکاف زمانی در تاریخچه';
          throw MarketApiException('$reason $label شناسایی شد؛ تحلیل با داده ناقص اجرا نشد.');
        }
      }
    }
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final latest = closed.last;
    final age = now - (latest.time + intervalSeconds);
    if (age < -intervalSeconds || age > intervalSeconds * 1.5) {
      throw MarketApiException('تازگی داده $label قابل قبول نیست (${(age / 60).round()} دقیقه از بسته‌شدن آخرین کندل). دریافت تازه از صرافی ناموفق بود؛ تحلیل با داده قدیمی اجرا نشد.');
    }
  }

  Future<bool> run({bool lockAlreadyHeld = false}) async {
    const owner = 'dashboard-refresh';
    var ownsLock = false;
    if (!lockAlreadyHeld) {
      ownsLock = acquireWorkflow(owner);
      if (!ownsLock) return false;
    } else if (!workflowBusy) {
      return false;
    }
    final id = ++_requestId;
    final generation = _requestGeneration;
    loading = true;
    error = null;
    status = 'دریافت داده‌های 1H، 15M و 5M...';
    notifyListeners();
    final exchange = appState.exchange, symbol = appState.symbol;
    try {
      final responses = await Future.wait<Object>([
        api.getKlines(exchange: exchange, symbol: symbol, interval: '1h', limit: 1001, refreshInterval: const Duration(seconds: 15)),
        api.getKlines(exchange: exchange, symbol: symbol, interval: '15m', limit: 1501, refreshInterval: const Duration(seconds: 15)),
        api.getKlines(exchange: exchange, symbol: symbol, interval: '5m', limit: 2001, refreshInterval: const Duration(seconds: 15)),
        api.getPrice(exchange: exchange, symbol: symbol),
      ]);
      if (id != _requestId || generation != _requestGeneration) return false;
      final candles1h = responses[0] as List<MarketCandle>;
      final candles15m = responses[1] as List<MarketCandle>;
      final candles5m = responses[2] as List<MarketCandle>;
      final referencePrice = responses[3] as double;
      _validateFreshCandles(candles1h, 3600, '1H');
      _validateFreshCandles(candles15m, 900, '15M');
      _validateFreshCandles(candles5m, 300, '5M');
      final lastClosed5m = _closedHistory(candles5m, 300, 2).last;
      final priceGap = (referencePrice - lastClosed5m.close).abs() / lastClosed5m.close;
      if (priceGap > 0.025) {
        throw MarketApiException('قیمت لحظه‌ای با آخرین کندل بسته‌شده 5M بیش از ۲٫۵٪ اختلاف دارد؛ برای جلوگیری از تحلیل با داده ناسازگار، اجرا متوقف شد.');
      }
      status = 'محاسبه روند، ساختار، نقدینگی و قدرت خریدار/فروشنده...';
      notifyListeners();
      // Freeze one identical closed-candle set for both the technical engine
      // and AI. This also applies the same history limits to both consumers.
      history1h = _closedHistory(candles1h, 3600, 1000);
      history15m = _closedHistory(candles15m, 900, 1500);
      history5m = _closedHistory(candles5m, 300, 2000);
      historyCount1h = history1h.length;
      historyCount15m = history15m.length;
      historyCount5m = history5m.length;
      final result = engine.analyze(h1: history1h, m15: history15m, m5: history5m);
      if (id != _requestId || generation != _requestGeneration) return false;
      final previousConsensus = consensus;
      final previousAiAt = aiAt;
      // Identity covers every closed OHLCV value and a 0.1% reference-price
      // bucket. Small ticker fluctuations no longer create duplicate AI work.
      final nextSnapshotId = buildSnapshotId(
        exchange: exchange, symbol: symbol, history1h: history1h,
        history15m: history15m, history5m: history5m, referencePrice: referencePrice,
      );
      snapshotId = nextSnapshotId;
      latestReferencePrice = referencePrice;
      report = result;
      if (previousConsensus != null && previousConsensus.snapshotId != null) {
        if (previousConsensus.snapshotId == nextSnapshotId) {
          // Same immutable market input: keep successful model outputs active.
          consensus = previousConsensus;
          aiAt = previousAiAt;
        } else {
          historicalAiResults[previousConsensus.snapshotId!] = previousConsensus;
          if (previousAiAt != null) historicalAiTimes[previousConsensus.snapshotId!] = previousAiAt;
          while (historicalAiResults.length > 10) {
            final oldest = historicalAiResults.keys.first;
            historicalAiResults.remove(oldest);
            historicalAiTimes.remove(oldest);
          }
          consensus = null;
          aiAt = null;
        }
      } else {
        consensus = null;
        aiAt = null;
      }
      providerExecutionStatus.updateAll((key, value) => 'idle');
      if (consensus != null) updateProviderStatuses(consensus!);
      technicalAt = DateTime.now();
      final historyShort = historyCount1h < 1000 || historyCount15m < 1500 || historyCount5m < 2000;
      status = historyShort
          ? 'تحلیل با تاریخچه کمتر از هدف تکمیل شد: 1H=$historyCount1h/1000، 15M=$historyCount15m/1500، 5M=$historyCount5m/2000. صفحه‌بندی پروکسی را بررسی کنید.'
          : 'تحلیل تکمیل و ذخیره شد؛ کندل بسته‌شده: 1H=$historyCount1h، 15M=$historyCount15m، 5M=$historyCount5m.';
      await _persist(exchange: exchange, symbol: symbol);
      return true;
    } catch (e) {
      if (id != _requestId || generation != _requestGeneration) return false;
      error = e.toString();
      status = 'تحلیل کامل نشد؛ آخرین تحلیل ذخیره‌شده حفظ شده است.';
      return false;
    } finally {
      if (id == _requestId) {
        loading = false;
        notifyListeners();
      }
      if (ownsLock) releaseWorkflow(owner);
    }
  }
}
