import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'app_config.dart';

enum LinkState { available, degraded, blocked, notConfigured, unknown }

class LinkCheck {
  const LinkCheck(this.name, this.state, this.detail, {this.latencyMs});
  final String name;
  final LinkState state;
  final String detail;
  final int? latencyMs;
  Map<String, dynamic> toJson() => {
    'name': name, 'state': state.name, 'detail': detail, 'latencyMs': latencyMs,
  };
}

class ConnectivityReport {
  const ConnectivityReport({required this.checkedAt, required this.items});
  final DateTime checkedAt;
  final List<LinkCheck> items;
  bool get gatewayReady => items.any((x) => x.name == 'AI Gateway' && x.state == LinkState.available);
  Map<String, dynamic> toJson() => {
    'checkedAt': checkedAt.toIso8601String(),
    'items': items.map((x) => x.toJson()).toList(),
  };
}

/// Safe routing policy: provider credentials remain in Cloudflare.
/// The app never attempts direct provider calls or bypasses regional restrictions.
class SmartConnectivityService {
  final http.Client _client;
  SmartConnectivityService({http.Client? client}) : _client = client ?? http.Client();

  Future<ConnectivityReport> inspect() async {
    final results = <LinkCheck>[];
    final base = AppConfig.aiGatewayBaseUrl.replaceFirst(RegExp(r'/+$'), '');
    if (!base.startsWith('https://') || base.contains('YOUR_')) {
      results.add(const LinkCheck('AI Gateway', LinkState.notConfigured, 'آدرس HTTPS در تنظیمات Build تعریف نشده است.'));
      return ConnectivityReport(checkedAt: DateTime.now(), items: results);
    }

    final health = await _getJson('$base/health');
    if (health.ok && health.body?['ok'] == true) {
      results.add(LinkCheck('AI Gateway', LinkState.available, 'Gateway پاسخ‌گو است؛ کلیدها فقط سمت Worker نگهداری می‌شوند.', latencyMs: health.ms));
      final providers = health.body?['configured'];
      for (final p in ['gemini', 'groq', 'openrouter']) {
        final configured = providers is Map && providers[p] == true;
        results.add(LinkCheck(
          p == 'openrouter' ? 'OpenRouter' : p[0].toUpperCase() + p.substring(1),
          configured ? LinkState.unknown : LinkState.notConfigured,
          configured ? 'کلید سمت Worker تنظیم شده؛ بررسی دسترسی upstream جداگانه لازم است.' : 'کلید API در Worker تنظیم نشده است.',
        ));
      }
    } else {
      final classification = _classify(health.status, health.error);
      results.add(LinkCheck('AI Gateway', classification.$1, classification.$2, latencyMs: health.ms));
      for (final p in ['Gemini', 'Groq', 'OpenRouter']) {
        results.add(LinkCheck(p, LinkState.unknown, 'به‌دلیل در دسترس نبودن Gateway امکان بررسی upstream وجود ندارد.'));
      }
    }

    final providerHealth = await _postJson('$base/providers/health', {
      'selectedProviders': ['gemini', 'groq', 'openrouter'],
      'forceProbe': true,
    });
    if (providerHealth.ok && providerHealth.body?['providers'] is Map) {
      final map = providerHealth.body!['providers'] as Map;
      for (final key in ['gemini', 'groq', 'openrouter']) {
        final data = map[key];
        if (data is! Map) continue;
        final name = key == 'openrouter' ? 'OpenRouter' : key[0].toUpperCase() + key.substring(1);
        final state = '${data['status'] ?? 'UNAVAILABLE'}';
        final code = '${data['errorCode'] ?? ''}';
        final latency = data['latencyMs'] is num ? (data['latencyMs'] as num).round() : null;
        final attempts = data['attempts'] is List ? (data['attempts'] as List) : const [];
        final failedAttempt = attempts.whereType<Map>().cast<Map>().firstWhere(
          (x) => x['errorCode'] != null || x['error'] != null,
          orElse: () => const {},
        );
        final httpStatus = failedAttempt['httpStatus'];
        final upstreamError = (failedAttempt['error'] ?? data['error'] ?? '').toString();
        final retryAt = data['retryAt']?.toString();
        final selectedModel = data['selectedModel']?.toString() ?? '';
        final fallbackModel = data['fallbackModel']?.toString() ?? '';
        final attemptedModels = data['attemptedModels'] is List
            ? (data['attemptedModels'] as List).map((x) => x.toString()).where((x) => x.isNotEmpty).join(' ← ')
            : '';
        final diagnostic = [
          if (code.isNotEmpty) code,
          if (httpStatus != null) 'HTTP $httpStatus',
          if (upstreamError.isNotEmpty) upstreamError,
          if (retryAt != null && retryAt.isNotEmpty) 'آزمون بعدی: $retryAt',
        ].join(' • ');
        final modelTrace = [
          if (selectedModel.isNotEmpty) 'مدل انتخاب‌شده: $selectedModel',
          if (fallbackModel.isNotEmpty) 'جایگزین: $fallbackModel (فهرست زنده؛ هنوز Probe نشده)',
          if (attemptedModels.isNotEmpty) 'مدل‌های آزمایش‌شده: $attemptedModels',
        ].join(' • ');
        final detail = state == 'READY'
            ? 'مدل متنی واجدشرایط با آزمون واقعی پاسخ‌گویی تأیید شد.${modelTrace.isEmpty ? '' : ' $modelTrace'}'
            : state == 'DEGRADED' && data['routable'] == true
                ? 'مدل پاسخ‌گو است اما تأخیر آن بالاست؛ برای تحلیل قابل استفاده است.${modelTrace.isEmpty ? '' : ' $modelTrace'}'
                : 'مدل فعلاً قابل استفاده نیست${modelTrace.isEmpty ? '' : ' • $modelTrace'}${diagnostic.isEmpty ? '' : ': $diagnostic'}';
        final linkState = data['routable'] == true
            ? (state == 'READY' ? LinkState.available : LinkState.degraded)
            : (code == 'NOT_CONFIGURED' ? LinkState.notConfigured : state == 'DEGRADED' ? LinkState.degraded : LinkState.blocked);
        _replace(results, LinkCheck(name, linkState, detail, latencyMs: latency));
      }
    } else {
      for (final name in ['Gemini', 'Groq', 'OpenRouter']) {
        _replace(results, LinkCheck(name, LinkState.unknown, 'آزمون واقعی پاسخ‌گویی مدل دریافت نشد؛ وضعیت مدل تأیید نشده است.'));
      }
    }

    // altFINS quota and market validation are owned by the separate Market Sources
    // screen, avoiding a duplicate quota request from the connectivity monitor.

    // Chart Analyzer remains the official direct WebView flow. A lightweight
    // HEAD probe can be rejected by the website, so it is deliberately not used
    // to claim service availability.
    results.add(const LinkCheck('Chart Analyzer AI', LinkState.unknown, 'مسیر رسمی WebView مستقیم است؛ تست واقعی بارگذاری صفحه در خود WebView انجام می‌شود.'));
    results.add(const LinkCheck('Binance Proxy', LinkState.unknown, 'مسیر مستقل حفظ شده؛ این بررسی آن را تغییر یا جایگزین نمی‌کند.'));
    return ConnectivityReport(checkedAt: DateTime.now(), items: results);
  }

  void _replace(List<LinkCheck> list, LinkCheck item) {
    final index = list.indexWhere((x) => x.name == item.name);
    if (index >= 0) list[index] = item; else list.add(item);
  }

  (LinkState, String) _classify(int? status, String error) {
    final e = error.toLowerCase();
    if (status == 401 || status == 403 || e.contains('unauthorized') || e.contains('forbidden') || e.contains('region') || e.contains('location not supported') || e.contains('country')) {
      return (LinkState.blocked, 'ارائه‌دهنده خطای دسترسی/منطقه‌ای داده است؛ علت دقیق را فقط با پیام رسمی upstream می‌توان تعیین کرد.');
    }
    if (status == 429 || e.contains('rate limit') || e.contains('quota')) {
      return (LinkState.degraded, 'محدودیت نرخ یا سهمیه؛ این خطا مسدودسازی شبکه نیست.');
    }
    if (error.contains('SocketException') || error.contains('Failed host lookup') || error.contains('timed out') || status == 502 || status == 503) {
      return (LinkState.degraded, 'خطای شبکه یا مسیر Gateway؛ بین فیلترینگ ISP و اختلال موقت بدون شواهد بیشتر نمی‌توان قطعی تفکیک کرد.');
    }
    return (LinkState.unknown, error.isEmpty ? 'وضعیت نامشخص است.' : error);
  }

  Future<_Probe> _postJson(String url, Map<String, dynamic> body) async {
    final watch = Stopwatch()..start();
    try {
      final response = await _client.post(Uri.parse(url), headers: const {'Content-Type':'application/json','Accept':'application/json'}, body: jsonEncode(body)).timeout(const Duration(seconds: 40));
      watch.stop();
      final decoded = jsonDecode(response.body);
      if (decoded is Map) return _Probe(response.statusCode >= 200 && response.statusCode < 300, Map<String,dynamic>.from(decoded), response.statusCode, '', watch.elapsedMilliseconds);
      return _Probe(false, null, response.statusCode, 'پاسخ JSON معتبر نیست.', watch.elapsedMilliseconds);
    } on TimeoutException {
      return _Probe(false, null, null, 'Connection timed out', watch.elapsedMilliseconds);
    } catch (e) {
      return _Probe(false, null, null, e.toString(), watch.elapsedMilliseconds);
    }
  }

  Future<_Probe> _getJson(String url) async {
    final watch = Stopwatch()..start();
    try {
      final response = await _client.get(Uri.parse(url), headers: const {'Accept': 'application/json'}).timeout(const Duration(seconds: 12));
      watch.stop();
      final decoded = jsonDecode(response.body);
      if (decoded is Map) return _Probe(response.statusCode >= 200 && response.statusCode < 300, Map<String, dynamic>.from(decoded), response.statusCode, '', watch.elapsedMilliseconds);
      return _Probe(false, null, response.statusCode, 'پاسخ JSON معتبر نیست.', watch.elapsedMilliseconds);
    } on TimeoutException {
      return _Probe(false, null, null, 'Connection timed out', watch.elapsedMilliseconds);
    } catch (e) {
      return _Probe(false, null, null, e.toString(), watch.elapsedMilliseconds);
    }
  }

  void dispose() => _client.close();
}

class _Probe {
  const _Probe(this.ok, this.body, this.status, this.error, this.ms);
  final bool ok;
  final Map<String, dynamic>? body;
  final int? status;
  final String error;
  final int ms;
}
