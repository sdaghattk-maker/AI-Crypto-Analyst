import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'app_config.dart';

enum LinkState { available, degraded, blocked, authenticationFailed, regionRestricted, gatewayAccessDenied, notConfigured, unknown, stale }

class LinkCheck {
  const LinkCheck(this.name, this.state, this.detail, {this.latencyMs, this.checkedAt});
  final String name;
  final LinkState state;
  final String detail;
  final int? latencyMs;
  final DateTime? checkedAt;
  Map<String, dynamic> toJson() => {
    'name': name, 'state': state.name, 'detail': detail, 'latencyMs': latencyMs,
    if (checkedAt != null) 'checkedAt': checkedAt!.toIso8601String(),
  };
}

class ConnectivityReport {
  const ConnectivityReport({required this.checkedAt, required this.items});
  final DateTime checkedAt;
  final List<LinkCheck> items;
  bool get gatewayReady => items.any((x) => x.name == 'AI Gateway' && x.state == LinkState.available);
  Map<String, dynamic> toJson() => {
    'checkedAt': checkedAt.toIso8601String(),
    'items': items.map((x) => x.toJson()).toList(),
  };
  ConnectivityReport markStale(String reason) => ConnectivityReport(
    checkedAt: checkedAt,
    items: items.map((item) => LinkCheck(
      item.name, LinkState.stale,
      'آخرین وضعیت ثبت‌شده: ${item.state.name}؛ بررسی جدید ناموفق بود: $reason',
      latencyMs: item.latencyMs, checkedAt: item.checkedAt,
    )).toList(),
  );
  ConnectivityReport replaceItem(LinkCheck replacement) => ConnectivityReport(
    checkedAt: checkedAt,
    items: [for (final item in items) if (item.name != replacement.name) item, replacement],
  );
}

/// Safe routing policy: provider credentials remain in Cloudflare.
/// The app never attempts direct provider calls or bypasses regional restrictions.
class SmartConnectivityService {
  final http.Client _client;
  SmartConnectivityService({http.Client? client}) : _client = client ?? http.Client();

  static final ValueNotifier<LinkCheck?> chartAnalyzerStatus = ValueNotifier<LinkCheck?>(null);

  static void reportChartAnalyzerStatus(LinkState state, String detail, {int? latencyMs}) {
    chartAnalyzerStatus.value = LinkCheck('Chart Analyzer AI', state, detail,
      latencyMs: latencyMs, checkedAt: DateTime.now());
  }

  Future<ConnectivityReport> inspect() async {
    final results = <LinkCheck>[];
    final base = AppConfig.aiGatewayBaseUrl.replaceFirst(RegExp(r'/+$'), '');
    final configured = base.startsWith('https://') && !base.contains('YOUR_');
    final healthFuture = configured
        ? _getJson('$base/health', timeout: const Duration(seconds: 12))
        : Future.value(const _Probe(false, null, null, 'آدرس Gateway تنظیم نشده است.', 0));
    final providerFuture = configured
        ? _postJson('$base/providers/health', {
            'selectedProviders': ['gemini', 'groq', 'openrouter'],
            'forceProbe': true,
          }, timeout: AppConfig.providerHealthTimeout)
        : Future.value(const _Probe(false, null, null, 'Gateway تنظیم نشده است.', 0));
    final binanceFuture = _getJson(
      '${AppConfig.binanceWorkerBaseUrl.replaceFirst(RegExp(r'/+$'), '')}/?endpoint=price&symbol=BTCUSDT',
      timeout: const Duration(seconds: 10),
    );
    final checks = await Future.wait([healthFuture, providerFuture, binanceFuture]);
    final health = checks[0], providerHealth = checks[1], binance = checks[2];

    if (!configured) {
      results.add(const LinkCheck('AI Gateway', LinkState.notConfigured, 'آدرس HTTPS در تنظیمات Build تعریف نشده است.'));
    } else if (health.ok && health.body?['ok'] == true) {
      results.add(LinkCheck('AI Gateway', LinkState.available,
        'Gateway پاسخ‌گو است؛ این بررسی فقط سلامت Worker را تأیید می‌کند، نه وضعیت Providerها.', latencyMs: health.ms, checkedAt: DateTime.now()));
    } else {
      final classification = _classify(health.status, health.error);
      results.add(LinkCheck('AI Gateway', classification.$1, classification.$2, latencyMs: health.ms, checkedAt: DateTime.now()));
    }

    if (providerHealth.ok && providerHealth.body?['providers'] is Map) {
      final map = providerHealth.body!['providers'] as Map;
      for (final key in ['gemini', 'groq', 'openrouter']) {
        final data = map[key];
        if (data is! Map) {
          _replace(results, LinkCheck(_providerName(key), LinkState.unknown, 'پاسخ Health برای این Provider موجود نیست.'));
          continue;
        }
        final name = _providerName(key);
        final state = '${data['status'] ?? 'UNAVAILABLE'}';
        final code = '${data['errorCode'] ?? ''}';
        final latency = data['latencyMs'] is num ? (data['latencyMs'] as num).round() : null;
        final attempts = data['attempts'] is List ? (data['attempts'] as List) : const [];
        final failedAttempt = attempts.whereType<Map>().cast<Map>().firstWhere(
          (x) => x['errorCode'] != null || x['error'] != null,
          orElse: () => const {},
        );
        final httpStatus = failedAttempt['httpStatus'];
        final upstreamError = (failedAttempt['error'] ?? data['error'] ?? '').toString();
        final retryAt = data['retryAt']?.toString();
        final selectedModel = data['selectedModel']?.toString() ?? '';
        final fallbackModel = data['fallbackModel']?.toString() ?? '';
        final attemptedModels = data['attemptedModels'] is List
            ? (data['attemptedModels'] as List).map((x) => x.toString()).where((x) => x.isNotEmpty).join(' ← ')
            : '';
        final diagnostic = [
          if (code.isNotEmpty) code,
          if (httpStatus != null) 'HTTP $httpStatus',
          if (upstreamError.isNotEmpty) upstreamError,
          if (retryAt != null && retryAt.isNotEmpty) 'آزمون بعدی: $retryAt',
        ].join(' • ');
        final modelTrace = [
          if (selectedModel.isNotEmpty) 'مدل انتخاب‌شده: $selectedModel',
          if (fallbackModel.isNotEmpty) 'جایگزین: $fallbackModel (کاتالوگ زنده؛ هنوز Probe نشده)',
          if (attemptedModels.isNotEmpty) 'مدل‌های آزمایش‌شده: $attemptedModels',
        ].join(' • ');
        final transientProbeFailure = const {
          'EMPTY_RESPONSE', 'TIMEOUT_OR_NETWORK', 'UPSTREAM_ERROR', 'RATE_LIMITED',
          'MANUAL_PROBE_THROTTLED', 'CIRCUIT_OPEN', 'CIRCUIT_HALF_OPEN_PROBE_IN_PROGRESS',
          'HEALTH_BUDGET_EXHAUSTED',
        }.contains(code);
        final failureExplanation = switch (code) {
          'EMPTY_RESPONSE' => 'Provider با HTTP موفق پاسخ داده اما متن قابل استفاده تولید نکرد؛ این وضعیت به‌تنهایی خطای دسترسی نیست.',
          'TIMEOUT_OR_NETWORK' => 'مهلت آزمون واقعی تمام شد یا ارتباط upstream قطع شد؛ وضعیت موقت است.',
          'UPSTREAM_ERROR' => 'سرویس upstream خطای موقت داده است؛ این نتیجه اثبات مسدودسازی شبکه نیست.',
          'RATE_LIMITED' => 'محدودیت نرخ/سهمیه گزارش شد؛ تعویض مدل لزوماً آن را برطرف نمی‌کند.',
          'ACCESS_DENIED' => 'درخواست از طرف خود Provider با خطای دسترسی رد شده است.',
          'AUTHENTICATION_FAILED' => 'Provider کلید/احراز هویت را نپذیرفته است؛ مقدار کلید نمایش داده نمی‌شود.',
          'REGION_RESTRICTED' => 'خود Provider صریحاً محدودیت جغرافیایی/منطقه‌ای گزارش کرده است.',
          'MODEL_UNAVAILABLE' => 'مدل در کاتالوگ یا سرویس فعلی در دسترس نیست؛ این خطا به معنی مسدودسازی حساب نیست.',
          'HEALTH_BUDGET_EXHAUSTED' => 'بودجه زمانی بررسی سلامت تمام شد؛ نتیجه قطعی برای این مدل ثبت نشده است.',
          _ => 'آزمون واقعی مدل موفق نشد.'
        };
        final detail = data['routable'] == true
            ? 'مدل متنی با درخواست واقعی پاسخ داد.${modelTrace.isEmpty ? '' : ' $modelTrace'}'
            : '$failureExplanation${modelTrace.isEmpty ? '' : ' • $modelTrace'}${diagnostic.isEmpty ? '' : ' • $diagnostic'}';
        final linkState = data['routable'] == true
            ? (state == 'READY' ? LinkState.available : LinkState.degraded)
            : code == 'NOT_CONFIGURED' ? LinkState.notConfigured
            : code == 'REGION_RESTRICTED' ? LinkState.regionRestricted
            : code == 'ACCESS_DENIED' ? LinkState.blocked
            : code == 'AUTHENTICATION_FAILED' ? LinkState.authenticationFailed
            : transientProbeFailure || const {'MODEL_CATALOG_UNAVAILABLE','NO_ELIGIBLE_MODEL','CIRCUIT_STATE_UNAVAILABLE','PROVIDER_REQUEST_FAILED','INVALID_RESPONSE_OR_REQUEST','MODEL_UNAVAILABLE'}.contains(code) || state == 'DEGRADED'
                ? LinkState.degraded
                : LinkState.unknown;
        _replace(results, LinkCheck(name, linkState, detail, latencyMs: latency, checkedAt: DateTime.now()));
      }
    } else {
      final detail = providerHealth.error.isNotEmpty
          ? 'آزمون upstream از مسیر Gateway دریافت نشد: ${providerHealth.error}'
          : 'آزمون واقعی پاسخ‌گویی مدل دریافت نشد؛ وضعیت Provider تأیید نشده است.';
      for (final name in ['Gemini', 'Groq', 'OpenRouter']) {
        _replace(results, LinkCheck(name, LinkState.unknown, detail, latencyMs: providerHealth.ms, checkedAt: DateTime.now()));
      }
    }

    final proxyData = binance.body?['data'];
    final proxyPrice = proxyData is Map ? double.tryParse('${proxyData['price'] ?? proxyData['lastPrice'] ?? ''}') : null;
    if (binance.ok && binance.body?['ok'] == true && proxyPrice != null && proxyPrice > 0) {
      results.add(LinkCheck('Binance Proxy', LinkState.available,
        'Proxy مستقل با دریافت قیمت واقعی BTCUSDT پاسخ داد.', latencyMs: binance.ms, checkedAt: DateTime.now()));
    } else {
      final detail = binance.error.isNotEmpty ? 'درخواست قیمت آزمایشی از Proxy ناموفق بود: ${binance.error}'
          : 'پاسخ Proxy فاقد قیمت معتبر بود (HTTP ${binance.status ?? 'نامشخص'}).';
      results.add(LinkCheck('Binance Proxy', binance.status == 429 || binance.status == 503 || binance.status == null
          ? LinkState.degraded : LinkState.unknown, detail, latencyMs: binance.ms, checkedAt: DateTime.now()));
    }

    final chartStatus = chartAnalyzerStatus.value;
    if (chartStatus == null) {
      results.add(const LinkCheck('Chart Analyzer AI', LinkState.unknown,
        'هنوز از داخل WebView رسمی بررسی نشده است؛ پس از بارگذاری صفحه وضعیت واقعی ثبت می‌شود.'));
    } else if (DateTime.now().difference(chartStatus.checkedAt ?? DateTime.fromMillisecondsSinceEpoch(0)) > const Duration(minutes: 15)) {
      results.add(LinkCheck('Chart Analyzer AI', LinkState.stale,
        'آخرین نتیجه WebView بیش از ۱۵ دقیقه قدمت دارد؛ صفحه را دوباره باز کنید.', latencyMs: chartStatus.latencyMs, checkedAt: chartStatus.checkedAt));
    } else {
      results.add(chartStatus);
    }
    return ConnectivityReport(checkedAt: DateTime.now(), items: results);
  }

  String _providerName(String key) => key == 'openrouter' ? 'OpenRouter' : key[0].toUpperCase() + key.substring(1);

  void _replace(List<LinkCheck> list, LinkCheck item) {
    final index = list.indexWhere((x) => x.name == item.name);
    if (index >= 0) list[index] = item; else list.add(item);
  }

  (LinkState, String) _classify(int? status, String error) {
    if (status == 401 || status == 403) {
      return (LinkState.gatewayAccessDenied, 'خود AI Gateway درخواست را رد کرده است؛ این پاسخ به‌تنهایی خطای دسترسی یا محدودیت منطقه‌ای Providerها را ثابت نمی‌کند.');
    }
    final e = error.toLowerCase();
    if (status == 429 || e.contains('rate limit') || e.contains('quota')) {
      return (LinkState.degraded, 'Gateway محدودیت نرخ گزارش کرده است؛ این خطا مسدودسازی Provider نیست.');
    }
    if (error.contains('SocketException') || error.contains('Failed host lookup') || error.contains('timed out') || status == 502 || status == 503) {
      return (LinkState.degraded, 'خطای شبکه یا مسیر Gateway؛ بدون پاسخ upstream نمی‌توان درباره محدودیت Provider نتیجه گرفت.');
    }
    return (LinkState.unknown, error.isEmpty ? 'وضعیت نامشخص است.' : error);
  }

  Future<_Probe> _postJson(String url, Map<String, dynamic> body, {Duration timeout = const Duration(seconds: 38)}) async {
    final watch = Stopwatch()..start();
    try {
      final response = await _client.post(Uri.parse(url), headers: const {'Content-Type':'application/json','Accept':'application/json'}, body: jsonEncode(body)).timeout(timeout);
      watch.stop();
      final decoded = jsonDecode(response.body);
      if (decoded is Map) return _Probe(response.statusCode >= 200 && response.statusCode < 300, Map<String,dynamic>.from(decoded), response.statusCode, '', watch.elapsedMilliseconds);
      return _Probe(false, null, response.statusCode, 'پاسخ JSON معتبر نیست.', watch.elapsedMilliseconds);
    } on TimeoutException {
      return _Probe(false, null, null, 'Connection timed out', watch.elapsedMilliseconds);
    } catch (e) {
      return _Probe(false, null, null, e.toString(), watch.elapsedMilliseconds);
    }
  }

  Future<_Probe> _getJson(String url, {Duration timeout = const Duration(seconds: 12)}) async {
    final watch = Stopwatch()..start();
    try {
      final response = await _client.get(Uri.parse(url), headers: const {'Accept': 'application/json'}).timeout(timeout);
      watch.stop();
      final decoded = jsonDecode(response.body);
      if (decoded is Map) return _Probe(response.statusCode >= 200 && response.statusCode < 300, Map<String, dynamic>.from(decoded), response.statusCode, '', watch.elapsedMilliseconds);
      return _Probe(false, null, response.statusCode, 'پاسخ JSON معتبر نیست.', watch.elapsedMilliseconds);
    } on TimeoutException {
      return _Probe(false, null, null, 'Connection timed out', watch.elapsedMilliseconds);
    } catch (e) {
      return _Probe(false, null, null, e.toString(), watch.elapsedMilliseconds);
    }
  }

  void dispose() => _client.close();
}

class _Probe {
  const _Probe(this.ok, this.body, this.status, this.error, this.ms);
  final bool ok;
  final Map<String, dynamic>? body;
  final int? status;
  final String error;
  final int ms;
}
