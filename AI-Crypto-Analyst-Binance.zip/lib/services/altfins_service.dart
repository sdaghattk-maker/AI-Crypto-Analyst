import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'app_config.dart';

/// Free-plan-safe altFINS adapter with persistent, freshness-enforced cache.
/// Cached stale values are display-only and are never marked usable for analysis.
class AltFinsService {
  AltFinsService({http.Client? client}) : _client = client;
  final http.Client? _client;

  static const Duration _timeout = Duration(seconds: 18);
  static const Duration _fifteenMinuteTtl = Duration(minutes: 15);
  static const Duration _oneHourTtl = Duration(minutes: 60);
  static final Map<String, Future<Map<String, dynamic>>> _inFlight = {};

  Uri _uri(String path) => Uri.parse('${AppConfig.aiGatewayBaseUrl}$path');

  Future<Map<String, dynamic>> getQuota() async {
    final response = await (_client?.get(_uri('/altfins/quota')) ?? http.get(_uri('/altfins/quota'))).timeout(_timeout);
    return _decode(response);
  }

  Duration _ttl(String timeframe) => timeframe == '15m' ? _fifteenMinuteTtl : _oneHourTtl;

  String _cacheKey({required String symbol, required String timeframe, required String exchange}) {
    final normalizedSymbol = symbol.trim().toUpperCase();
    final normalizedExchange = exchange.trim().toUpperCase();
    return 'altfins_cache_v3_SPOT_${normalizedExchange}_${normalizedSymbol}_$timeframe';
  }

  Future<Map<String, dynamic>?> loadCached({
    required String symbol,
    required String timeframe,
    required String exchange,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_cacheKey(symbol: symbol, timeframe: timeframe, exchange: exchange));
    if (raw == null || raw.isEmpty) return null;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map) return null;
      final saved = Map<String, dynamic>.from(decoded);
      final fetchedAt = DateTime.tryParse('${saved['_cachedAt'] ?? ''}')?.toUtc();
      final payload = saved['payload'];
      if (fetchedAt == null || payload is! Map) return null;
      final age = DateTime.now().toUtc().difference(fetchedAt);
      final fresh = !age.isNegative && age < _ttl(timeframe);
      final result = Map<String, dynamic>.from(payload);
      result['_cache'] = {
        'fetchedAt': fetchedAt.toIso8601String(),
        'fresh': fresh,
        'ageSeconds': age.inSeconds < 0 ? 0 : age.inSeconds,
        'ttlSeconds': _ttl(timeframe).inSeconds,
        'source': 'persistent',
      };
      // Explicitly gate any downstream consumer on this flag.
      result['usableForAnalysis'] = fresh && result['ok'] == true && result['status'] == 'AVAILABLE';
      return result;
    } catch (_) {
      return null;
    }
  }

  Future<Map<String, dynamic>> validateSmart({
    required String symbol,
    required String timeframe,
    required String exchange,
    bool forceRefresh = false,
  }) async {
    final cached = await loadCached(symbol: symbol, timeframe: timeframe, exchange: exchange);
    if (!forceRefresh && cached != null && cached['_cache'] is Map &&
        (cached['_cache'] as Map)['fresh'] == true) {
      return cached;
    }

    final key = _cacheKey(symbol: symbol, timeframe: timeframe, exchange: exchange);
    final existing = _inFlight[key];
    if (existing != null) return existing;

    final future = _fetchAndPersist(symbol: symbol, timeframe: timeframe, exchange: exchange, oldCache: cached);
    _inFlight[key] = future;
    try {
      return await future;
    } finally {
      if (identical(_inFlight[key], future)) _inFlight.remove(key);
    }
  }

  Future<Map<String, dynamic>> _fetchAndPersist({
    required String symbol,
    required String timeframe,
    required String exchange,
    required Map<String, dynamic>? oldCache,
  }) async {
    try {
      final fresh = await validate(symbol: symbol, timeframe: timeframe, exchange: exchange);
      final isSuccess = fresh['ok'] == true && fresh['status'] == 'AVAILABLE' &&
          fresh['data'] is Map && (fresh['data'] as Map).isNotEmpty;
      if (!isSuccess) {
        return _withFailureAndOldCache(fresh, oldCache);
      }
      // Never manufacture freshness from the local clock when the Gateway
      // omits its retrieval timestamp. The source timestamp is mandatory.
      final upstreamAt = DateTime.tryParse('${fresh['refreshedAt'] ?? ''}')?.toUtc();
      if (upstreamAt == null) {
        return _withFailureAndOldCache({
          'ok': false, 'source': 'altfins', 'status': 'INVALID_RESPONSE',
          'error': 'زمان به‌روزرسانی منبع altFINS در پاسخ وجود ندارد؛ داده تازه تأیید نشد.',
          'affectsTradeDecision': false,
        }, oldCache);
      }
      final now = DateTime.now().toUtc();
      final age = now.difference(upstreamAt);
      if (age.isNegative || age >= _ttl(timeframe)) {
        return _withFailureAndOldCache({
          'ok': false, 'source': 'altfins', 'status': 'STALE_RESPONSE',
          'error': 'پاسخ altFINS خارج از بازه تازگی مجاز است؛ داده برای هم‌سنجی استفاده نشد.',
          'affectsTradeDecision': false,
        }, oldCache);
      }
      final prefs = await SharedPreferences.getInstance();
      final key = _cacheKey(symbol: symbol, timeframe: timeframe, exchange: exchange);
      await prefs.setString(key, jsonEncode({'_cachedAt': upstreamAt.toIso8601String(), 'payload': fresh}));
      final result = Map<String, dynamic>.from(fresh);
      result['_cache'] = {
        'fetchedAt': upstreamAt.toIso8601String(),
        'fresh': !DateTime.now().toUtc().difference(upstreamAt).isNegative && DateTime.now().toUtc().difference(upstreamAt) < _ttl(timeframe),
        'ageSeconds': DateTime.now().toUtc().difference(upstreamAt).inSeconds.clamp(0, 1 << 30),
        'ttlSeconds': _ttl(timeframe).inSeconds,
        'source': 'network',
      };
      result['usableForAnalysis'] = (result['_cache'] as Map)['fresh'] == true;
      return result;
    } catch (e) {
      return _withFailureAndOldCache(
        {'ok': false, 'source': 'altfins', 'status': 'UNAVAILABLE', 'error': e.toString(), 'affectsTradeDecision': false},
        oldCache,
      );
    }
  }

  Map<String, dynamic> _withFailureAndOldCache(Map<String, dynamic> failure, Map<String, dynamic>? oldCache) {
    final result = Map<String, dynamic>.from(failure);
    result['usableForAnalysis'] = false;
    result['_refreshFailed'] = true;
    if (oldCache != null) {
      // Never mutate the cached object shared with the caller/persistent layer.
      final previousCache = oldCache['_cache'];
      final safeCache = previousCache is Map
          ? Map<String, dynamic>.from(previousCache)
          : <String, dynamic>{};
      safeCache['fresh'] = false;
      result['_previousData'] = oldCache['data'] is Map
          ? Map<String, dynamic>.from(oldCache['data'] as Map)
          : oldCache['data'];
      result['_previousCache'] = Map<String, dynamic>.from(safeCache);
      result['_cache'] = safeCache;
      result['_previousStatus'] = oldCache['status'];
    }
    return result;
  }

  Future<Map<String, dynamic>> validate({
    required String symbol,
    required String timeframe,
    required String exchange,
  }) async {
    if (timeframe == '5m') {
      return {'ok': false, 'source': 'altfins', 'status': 'UNSUPPORTED_TIMEFRAME', 'affectsTradeDecision': false};
    }
    final venue = _venue(exchange);
    if (venue == null) {
      return {'ok': false, 'source': 'altfins', 'status': 'UNSUPPORTED_EXCHANGE', 'exchange': exchange, 'marketType': 'SPOT', 'affectsTradeDecision': false, 'error': 'altFINS برای این صرافی پشتیبانی نمی‌شود؛ داده Binance جایگزین نمی‌شود.'};
    }
    final response = await (_client?.post(
      _uri('/altfins/validation'),
      headers: const {'Content-Type': 'application/json'},
      body: jsonEncode({'symbol': symbol, 'timeframe': timeframe, 'exchange': venue, 'tradingType': 'SPOT'}),
    ) ?? http.post(
      _uri('/altfins/validation'),
      headers: const {'Content-Type': 'application/json'},
      body: jsonEncode({'symbol': symbol, 'timeframe': timeframe, 'exchange': venue, 'tradingType': 'SPOT'}),
    )).timeout(_timeout);
    return _decode(response);
  }

  String? _venue(String exchange) {
    final value = exchange.toUpperCase();
    if (value.contains('BINANCE')) return 'BINANCE';
    if (value.contains('BYBIT')) return 'BYBIT';
    if (value.contains('OKX')) return 'OKX';
    if (value.contains('COINBASE')) return 'COINBASE';
    if (value.contains('KRAKEN')) return 'KRAKEN';
    if (value.contains('KUCOIN')) return 'KUCOIN';
    if (value.contains('MEXC')) return 'MEXC';
    if (value.contains('GATE')) return 'GATEIO';
    return null;
  }

  Map<String, dynamic> _decode(http.Response response) {
    dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } catch (_) {
      return {'ok': false, 'status': 'INVALID_RESPONSE', 'error': 'پاسخ نامعتبر از Gateway', 'affectsTradeDecision': false};
    }
    if (decoded is! Map) return {'ok': false, 'status': 'INVALID_RESPONSE', 'affectsTradeDecision': false};
    final result = Map<String, dynamic>.from(decoded);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      result['ok'] = false;
      result['httpStatus'] = response.statusCode;
      result['affectsTradeDecision'] = false;
    }
    return result;
  }
}
