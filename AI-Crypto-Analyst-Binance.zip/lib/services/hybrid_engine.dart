import 'ai_service.dart';
import 'technical_engine.dart';

class HybridDecision {
  const HybridDecision({required this.provider, required this.decision, required this.score,
    required this.technicalScore, required this.aiScore, required this.technicalWeights,
    required this.aiWeights, required this.reasons, required this.calibration});
  final String provider, decision;
  final double score, technicalScore, aiScore;
  final Map<String,int> technicalWeights, aiWeights;
  final List<String> reasons;
  final String calibration;
}

class HybridDashboardSnapshot {
  const HybridDashboardSnapshot({
    required this.providers,
    required this.validProviders,
    required this.providerResults,
    required this.hybridVotes,
    required this.buyVotes,
    required this.sellVotes,
    required this.technicalInvalid,
    required this.technicalPlanInvalid,
    required this.aiInvalid,
    required this.decision,
  });
  final List<AiModelResult> providers;
  final List<AiModelResult> validProviders;
  final Map<String, HybridDecision> providerResults;
  final List<String> hybridVotes;
  final int buyVotes;
  final int sellVotes;
  final bool technicalInvalid;
  final bool technicalPlanInvalid;
  final bool aiInvalid;
  final String decision;
}

class HybridEngine {
  static const keys = ['trend','marketStructure','liquidity','entryConfirmation','riskReward'];

  bool _technicalHasValidExecutionPlan(TechnicalReport report) {
    if (report.state == SignalState.wait) return true;
    final entry = report.entry, stop = report.stopLoss;
    final tp1 = report.tp1, tp2 = report.tp2, tp3 = report.tp3;
    final levels = [entry, stop, tp1, tp2, tp3];
    if (levels.any((value) => value == null || !value.isFinite || value <= 0)) return false;
    final e = entry!, sl = stop!, t1 = tp1!, t2 = tp2!, t3 = tp3!;
    final risk = (e - sl).abs();
    if (risk <= 0) return false;
    if (report.state == SignalState.buy) {
      return sl < e && t1 > e && t2 > t1 && t3 > t2 &&
          (t1 - e) / risk >= 1 && (t2 - e) / risk >= 1.5 && (t3 - e) / risk >= 2;
    }
    return sl > e && t1 < e && t2 < t1 && t3 < t2 &&
        (e - t1) / risk >= 1 && (e - t2) / risk >= 1.5 && (e - t3) / risk >= 2;
  }
  static const labels = {'trend':'روند','marketStructure':'ساختار بازار','liquidity':'نقدینگی','entryConfirmation':'تأیید ورود','riskReward':'ریسک به بازده'};

  Map<String,int> _normalize(Map<String,int> source) {
    final vals = keys.map((k) => (source[k] ?? 0).clamp(0,100).toInt()).toList();
    final sum = vals.fold<int>(0,(a,b)=>a+b);
    if (sum == 0) return {for(final k in keys) k:20};
    final exact = vals.map((value) => value * 100 / sum).toList();
    final allocated = exact.map((value) => value.floor()).toList();
    var remaining = 100 - allocated.fold<int>(0, (a,b) => a+b);
    final order = List<int>.generate(keys.length, (i) => i)
      ..sort((a,b) => (exact[b] - allocated[b]).compareTo(exact[a] - allocated[a]));
    for (var i = 0; i < remaining; i++) {
      allocated[order[i % order.length]]++;
    }
    return {for(var i=0;i<keys.length;i++) keys[i]:allocated[i]};
  }

  Map<String,int> _technicalWeights(TechnicalReport r) {
    final aligned = (r.bias1h == r.bias15m ? 25 : 10) + (r.bias15m == r.bias5m ? 20 : 8);
    final structure = (r.poiSummary.isNotEmpty ? 25 : 12) + (r.reasons.any((x)=>x.toLowerCase().contains('mss') || x.contains('ساختار')) ? 10 : 5);
    final liquidity = r.reasons.any((x)=>x.contains('نقدینگی') || x.toLowerCase().contains('sweep')) ? 65 : 35;
    final entry = r.state == SignalState.wait ? 20 : (r.score * .75).round().clamp(0,75).toInt();
    final rr = r.entry!=null && r.stopLoss!=null && r.tp1!=null ? 70 : 15;
    return _normalize({'trend':aligned,'marketStructure':structure,'liquidity':liquidity,'entryConfirmation':entry,'riskReward':rr});
  }

  Map<String,int> _technicalScores(TechnicalReport r) => {
    'trend': ((r.bias1h==r.bias15m?75:45)+(r.bias15m==r.bias5m?25:0)).clamp(0,100).toInt(),
    'marketStructure': r.poiSummary.isNotEmpty ? 75 : 35,
    'liquidity': r.reasons.any((x)=>x.contains('نقدینگی')||x.toLowerCase().contains('sweep')) ? 80 : 35,
    'entryConfirmation': r.state==SignalState.wait ? 25 : r.score.clamp(0,100).toInt(),
    'riskReward': r.entry!=null&&r.stopLoss!=null&&r.tp1!=null ? 75 : 20,
  };

  double _weighted(Map<String,int> weights, Map<String,int> scores) =>
    keys.fold<double>(0,(sum,k)=>sum+(weights[k]??0)*(scores[k]??0)/10000)*100;


  /// Single source of truth for the dashboard's final decision and its export.
  /// Both Flutter UI and the HTML snapshot exporter call this exact method.
  HybridDashboardSnapshot evaluateDashboard({
    required TechnicalReport? technical,
    required AiConsensus? consensus,
    required bool technicalStale,
    required bool aiStale,
  }) {
    final providers = consensus == null
        ? <AiModelResult>[]
        : [consensus.gemini, consensus.openrouter, consensus.groq];
    final valid = providers.where(aiModelIsConsensusEligible).toList();
    final technicalInvalid = technicalStale || technical == null;
    final technicalPlanInvalid = technical != null && !_technicalHasValidExecutionPlan(technical);
    // An AI response tied to an expired technical snapshot is invalid too.
    final aiInvalid = aiStale || technicalStale || consensus == null;
    final results = <String, HybridDecision>{};
    final votes = <String>[];
    if (technical != null) {
      for (final provider in valid) {
        final result = evaluate(technical, provider);
        results[provider.model.toLowerCase()] = result;
        if (result.decision == 'BUY' || result.decision == 'SELL') votes.add(result.decision);
      }
    }
    final buyVotes = votes.where((v) => v == 'BUY').length;
    final sellVotes = votes.where((v) => v == 'SELL').length;
    final technicalDirection = technical?.state == SignalState.buy ? 'BUY'
        : technical?.state == SignalState.sell ? 'SELL' : 'WAIT';
    final aiDirection = consensus?.decision.toUpperCase() ?? 'WAIT';
    final aiAgreeing = valid.where((provider) => provider.bias?.toUpperCase() == aiDirection).length;
    final invalidSources = <String>[
      if (technicalInvalid) 'تکنیکال',
      if (aiInvalid) 'AI',
    ];
    // AI is a confirmation layer, never an independent trigger. The final
    // decision requires a directional technical setup AND a two-model AI
    // consensus in exactly the same direction. Neutral technical state,
    // missing consensus, or any directional disagreement must remain WAIT.
    final decision = invalidSources.isNotEmpty
        ? '${invalidSources.join(' / ')} نامعتبر'
        : (technicalPlanInvalid || valid.length < 2 || aiAgreeing < 2 ||
            !['BUY', 'SELL'].contains(technicalDirection) ||
            !['BUY', 'SELL'].contains(aiDirection) ||
            technicalDirection != aiDirection)
            ? 'WAIT' : technicalDirection;
    return HybridDashboardSnapshot(
      providers: providers,
      validProviders: valid,
      providerResults: results,
      hybridVotes: votes,
      buyVotes: buyVotes,
      sellVotes: sellVotes,
      technicalInvalid: technicalInvalid,
      technicalPlanInvalid: technicalPlanInvalid,
      aiInvalid: aiInvalid,
      decision: decision,
    );
  }

  HybridDecision evaluate(TechnicalReport technical, AiModelResult ai) {
    final tw = _technicalWeights(technical);
    // Until forward-tested calibration exists, model-authored importance weights
    // are not trusted as reliability weights. Use equal factor weights.
    final aw = {for (final k in keys) k: 20};
    final ts = _weighted(tw,_technicalScores(technical));
    final ascore = _weighted(aw,ai.factorScores);
    final tDir = technical.state==SignalState.buy?1:technical.state==SignalState.sell?-1:0;
    final aiBias = ai.bias?.toUpperCase();
    final aDir = aiBias=='BUY'?1:aiBias=='SELL'?-1:0;
    final tStrength = ts*(technical.score.clamp(0,100)/100);
    // Confidence is model self-assessment, not a calibrated probability.
    // Keep the evidence score visible but do not multiply it by that claim.
    final aStrength = ascore;
    // Until sufficient out-of-sample records exist, engine-level reliability is neutral (50/50).
    final combined = (tDir*tStrength*0.5)+(aDir*aStrength*0.5);
    final conflict = tDir!=0 && aDir!=0 && tDir!=aDir;
    final validPlan = aiModelHasValidExecutionPlan(ai);
    final providerEligible = aiModelIsConsensusEligible(ai);
    var decision = 'WAIT';
    final directionMatches = tDir != 0 && tDir == aDir;
    if (providerEligible && !conflict && directionMatches) decision = tDir > 0 ? 'BUY' : 'SELL';
    final reasons=<String>[];
    if (ai.status != 'ok' || ai.contractStatus != 'VALID' || ai.evidenceStatus != 'VALIDATED') {
      reasons.add('پاسخ این مدل از نظر وضعیت، قرارداد V3 یا شواهد بازار واجد شرایط تصمیم ترکیبی نیست.');
    }
    if (!ai.weightsProvided) reasons.add('این مدل امتیازهای معیارها را ارائه نکرده است.');
    if (!ai.confidenceDeclared || ai.confidence == null || ai.confidence! < 55) reasons.add('اطمینان عددی معتبر و حداقل ۵۵٪ از این مدل دریافت نشده است.');
    reasons.add('سهم تکنیکال: ${tStrength.toStringAsFixed(1)} از ۱۰۰');
    reasons.add('امتیاز شواهد AI (${ai.model}): ${aStrength.toStringAsFixed(1)} از ۱۰۰');
    if(conflict) reasons.add('تعارض جهت بین تکنیکال و AI؛ تصمیم به WAIT محدود شد.');
    if(tDir==0||aDir==0) reasons.add('موتور تکنیکال یا مدل AI جهت معاملاتی ندارد؛ AI به‌تنهایی محرک ورود نیست.');
    if(!validPlan && aiBias!='WAIT') reasons.add('نقشه معامله AI کامل یا از نظر R/R معتبر نیست؛ ورود ترکیبی صادر نشد.');
    return HybridDecision(provider:ai.model,decision:decision,score:combined,technicalScore:ts,aiScore:ascore,
      technicalWeights:tw,aiWeights:aw,reasons:reasons,calibration:'این امتیاز فقط تشخیصی است و تصمیم نهایی را تعیین نمی‌کند؛ وزن عوامل AI برابر است و اعتمادبه‌نفس مدل احتمال کالیبره‌شده نیست.');
  }
}
