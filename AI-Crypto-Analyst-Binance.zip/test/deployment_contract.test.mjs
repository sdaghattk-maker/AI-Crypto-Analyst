import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const read = path => readFile(new URL(`../${path}`, import.meta.url));
const sha = value => createHash('sha256').update(value).digest('hex');

test('all AI Gateway deployable text mirrors exactly match the canonical Worker source', async () => {
  const canonical = await read('ai-gateway/worker.js');
  for (const path of ['AI-GATEWAY-WORKER.txt','ai-gateway/AI-GATEWAY-WORKER.txt','PHASE7.7-AI-GATEWAY-WORKER.txt','PHASE7.8-AI-GATEWAY-WORKER.txt']) {
    const mirror = await read(path);
    assert.deepEqual(mirror, canonical, `${path} must be byte-identical to ai-gateway/worker.js`);
  }
  assert.equal(sha(canonical), '9fee2e41746d56783cde36d83271ca9638c2f14a24b9e35ece10487624c69425');
});

test('deployment instructions use canonical Worker source and preserve existing identities and bindings', async () => {
  const deployment = (await read('PHASE7.8-DEPLOYMENT.txt')).toString('utf8');
  const wrangler = (await read('ai-gateway/wrangler.toml')).toString('utf8');
  const config = (await read('lib/services/app_config.dart')).toString('utf8');
  assert.match(deployment, /Canonical source:\s+ai-gateway\/worker\.js/);
  assert.match(deployment, /existing Worker named hrs-ai-crypto-gateway/);
  assert.match(deployment, /PROVIDER_CIRCUIT_BREAKER/);
  assert.match(deployment, /RATE_LIMITER/);
  assert.match(deployment, /Keep the separate Binance Proxy Worker named hrs-binance-proxy/);
  assert.match(wrangler, /name\s*=\s*"hrs-ai-crypto-gateway"/);
  assert.match(config, /https:\/\/hrs-ai-crypto-gateway\.sdaghat-tk\.workers\.dev/);
  assert.match(config, /https:\/\/hrs-binance-proxy\.sdaghat-tk\.workers\.dev/);
  assert.doesNotMatch(deployment, /Replace ONLY the AI Gateway Worker source with PHASE7\.8-AI-GATEWAY-WORKER\.txt/);
});
