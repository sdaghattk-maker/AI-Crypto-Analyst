import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

test("Flutter migrates persisted provider switches once so Gemini, OpenRouter and Groq are selected after upgrade", () => {
  const source = readFileSync(new URL("../lib/screens/ai_analysis.dart", import.meta.url), "utf8");
  assert.match(source, /ai_provider_selection_migration_v6331/);
  assert.match(source, /await prefs\.setBool\('ai_provider_\$key', true\)/);
  assert.match(source, /_providerEnabled = \{'gemini': true, 'openrouter': true, 'groq': true\}/);
  const service = readFileSync(new URL("../lib/services/ai_service.dart", import.meta.url), "utf8");
  assert.match(service, /'selectedProviders': selectedProviders/);
  assert.match(source, /ارائه‌دهنده‌های انتخاب‌شده/);
});


test('Flutter preserves per-provider health failures and accepts four verified auto candidates', () => {
  const service = readFileSync(new URL('../lib/services/ai_service.dart', import.meta.url), 'utf8');
  assert.match(service, /take\(4\)\.toList\(\)/);
  assert.match(service, /final healthFailed = <String, AiModelResult>\{\}/);
  assert.match(service, /healthFailed\['gemini'\] \?\?/);
  assert.match(service, /healthFailed\['openrouter'\] \?\?/);
  assert.match(service, /healthFailed\['groq'\] \?\?/);
  assert.match(service, /if \(routableProviders\.isEmpty\)[\s\S]*?healthFailed\['gemini'\]/);
});


test('AI Gateway default URL remains the user-confirmed workers.dev domain', () => {
  const config = readFileSync(new URL('../lib/services/app_config.dart', import.meta.url), 'utf8');
  assert.match(config, /https:\/\/hrs-ai-crypto-gateway\.sdaghat-tk\.workers\.dev/);
  assert.doesNotMatch(config, /hrs-ai-crypto-gateway\.sdaghat-tk\.workers\.de(?:['\"]|\s)/);
});
