import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const html = await readFile(new URL('../assets/index.html', import.meta.url), 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)?.[1];
assert.ok(script, 'inline Index script exists');

function boot() {
  const elements = new Map();
  const messages = [];
  const make = id => ({
    id, innerHTML: '', textContent: '', value: '', listeners: {},
    classList: { add() {}, remove() {}, toggle() {} },
    addEventListener(name, cb) { this.listeners[name] = cb; },
  });
  const document = {
    body: { classList: { add() {} } },
    getElementById(id) { if (!elements.has(id)) elements.set(id, make(id)); return elements.get(id); },
    querySelector(selector) { return selector === '.sub' ? make('sub') : null; },
  };
  const window = {
    IndexBridge: { postMessage(value) { messages.push(JSON.parse(value)); } },
    addEventListener() {},
  };
  vm.runInNewContext(script, { document, window, JSON, String, Object, Array, Math, Error });
  return { window, elements, messages };
}

test('Index renders a full provider snapshot with rawText, missing fields and all sources', () => {
  const { window, elements, messages } = boot();
  const provider = { status: 'ok', contractStatus: 'VALID', evidenceStatus: 'VALIDATED', bias: 'BUY', summary: 'صعودی', rawText: 'گزارش کامل فارسی', rawTextTruncated: false, rawProviderResponse: '{"ok":true}', timeframeAnalysis: { '1h': { trend: 'BULLISH' }, '15m': { trend: 'NEUTRAL' }, '5m': { trend: 'BULLISH' } } };
  const snapshot = {
    schema: 'ai_crypto_analyst_exact_snapshot_v1', exportedAt: '2026-11-21T10:00:00Z',
    identity: { symbol: 'BTCUSDT', exchange: 'BINANCE', marketType: 'SPOT', snapshotId: 'snap-1', referencePrice: 90000, historyCount1h: 100, historyCount15m: 100, historyCount5m: 100 },
    technical: { signal: 'buy', bias1h: 'bullish', bias15m: 'neutral', bias5m: 'bullish', entry: 89900, stopLoss: 89500, tp1: 90500 },
    ai: { gemini: provider, openrouter: { ...provider, rawText: 'پاسخ دوم' }, groq: { status: 'failed', error: 'timeout' }, decision: 'WAIT', conflicts: ['technical_ai_conflict'], dataQuality: { status: 'OK' } },
    hybrid: { decision: 'WAIT', validProviderCount: 1, technicalPlanInvalid: false },
    altfins: { quota: { status: 'AVAILABLE' }, timeframes: { '1h': { status: 'OK', trend: 'BULLISH' }, '15m': { status: 'NOT_FETCHED' } } },
  };
  assert.equal(window.loadSnapshotFromApp(snapshot), true);
  assert.equal(elements.get('content').classList.add instanceof Function, true);
  assert.match(elements.get('sourceCards').innerHTML, /Gemini/);
  assert.match(elements.get('sourceCards').innerHTML, /متن خام مدل/);
  assert.match(elements.get('sourceCards').innerHTML, /گزارش کامل فارسی/);
  assert.match(elements.get('timeframes').innerHTML, /۱ ساعت/);
  assert.match(elements.get('hybridView').innerHTML, /انتظار/);
  assert.equal(messages.at(-1).state, 'success');
});

test('Index rejects an unsupported schema and reports a render error to Flutter', () => {
  const { window, elements, messages } = boot();
  assert.equal(window.loadSnapshotFromApp({ schema: 'wrong' }), false);
  assert.equal(messages.at(-1).state, 'error');
  assert.match(elements.get('renderError').textContent, /قالب Snapshot معتبر نیست/);
});
