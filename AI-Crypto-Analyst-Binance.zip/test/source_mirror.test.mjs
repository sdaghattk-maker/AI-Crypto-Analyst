import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

test('both distributable AI Gateway Worker snapshots exactly mirror worker.js', async () => {
  const source = await read('ai-gateway/worker.js');
  const rootSnapshot = await read('AI-GATEWAY-WORKER.txt');
  const gatewaySnapshot = await read('ai-gateway/AI-GATEWAY-WORKER.txt');
  assert.equal(rootSnapshot, source);
  assert.equal(gatewaySnapshot, source);
});

test('the Android asset HTML index exactly mirrors the root HTML index', async () => {
  assert.equal(await read('assets/index.html'), await read('index.html'));
});

test('AI buyer/seller percentages are labeled as model-declared, not technical OHLCV estimates', async () => {
  const screen = await read('lib/screens/ai_analysis.dart');
  const dashboard = await read('lib/screens/dashboard.dart');
  assert.match(screen, /درصد اعلامی مدل، خریدار/);
  assert.doesNotMatch(screen, /فشار تخمینی OHLCV خریدار/);
  assert.match(dashboard, /درصدهای AI مقادیر اعلام‌شده توسط خود مدل‌اند/);
});

test('current package documentation does not claim the quantized candle transport is lossless', async () => {
  const readme = await read('README-DELIVERY.md');
  const repair = await read('AI-DATA-ENGINE-QUALITY-REPAIR-2026-11-21.md');
  assert.doesNotMatch(readme, /Lossless OHLCV/i);
  assert.doesNotMatch(repair, /lossless delta-OHLCV|lossless candle history/i);
  assert.match(repair, /not lossless/i);
});
