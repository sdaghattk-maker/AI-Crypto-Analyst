import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

test('both distributable AI Gateway Worker snapshots exactly mirror worker.js', async () => {
  const source = await read('ai-gateway/worker.js');
  const rootSnapshot = await read('AI-GATEWAY-WORKER.txt');
  const gatewaySnapshot = await read('ai-gateway/AI-GATEWAY-WORKER.txt');
  assert.equal(rootSnapshot, source);
  assert.equal(gatewaySnapshot, source);
});

test('the Android asset HTML index exactly mirrors the root HTML index', async () => {
  assert.equal(await read('assets/index.html'), await read('index.html'));
});

test('AI buyer/seller percentages are labeled as model-declared, not technical OHLCV estimates', async () => {
  const screen = await read('lib/screens/ai_analysis.dart');
  const dashboard = await read('lib/screens/dashboard.dart');
  assert.match(screen, /درصد اعلامی مدل، خریدار/);
  assert.doesNotMatch(screen, /فشار تخمینی OHLCV خریدار/);
  assert.match(dashboard, /درصدهای AI مقادیر اعلام‌شده توسط خود مدل‌اند/);
});

test('current package documentation does not claim the quantized candle transport is lossless', async () => {
  const readme = await read('README-DELIVERY.md');
  const repair = await read('AI-DATA-ENGINE-QUALITY-REPAIR-2026-11-21.md');
  assert.doesNotMatch(readme, /Lossless OHLCV/i);
  assert.doesNotMatch(repair, /lossless delta-OHLCV|lossless candle history/i);
  assert.match(repair, /not lossless/i);
});


test('dashboard displays available AI timeframe data independently from the full-contract consensus gate', async () => {
  const dashboard = await read('lib/screens/dashboard.dart');
  assert.match(dashboard, /Render each provider's available timeframe independently/);
  assert.match(dashboard, /provider\.contractStatus != 'VALID' \|\| provider\.evidenceStatus != 'VALIDATED'/);
  assert.match(dashboard, /frame\['narrativeOnly'\] == true/);
  assert.match(dashboard, /روند استخراج‌شده از متن گزارش/);
});

test('timeframe narrative extraction reads complete raw answer and Persian hourly/minute aliases', async () => {
  const worker = await read('ai-gateway/worker.js');
  assert.match(worker, /'key_points','rawText'/);
  assert.match(worker, /ساعتی\|یک\[‌\\s-\]\*ساعته/);
  assert.match(worker, /same-provider narrative may fill a missing timeframe/i);
});

test('Index has no undefined provider alias in rawText rendering and uses each provider own truncation flag', async () => {
  const html = await read('assets/index.html');
  assert.doesNotMatch(html, /summary\.textContent\s*=\s*p\.rawTextTruncated/);
  assert.match(html, /p\.rawTextTruncated/);
  assert.match(html, /window\.loadSnapshotFromApp=function\(snapshot\)\{try\{render\(snapshot\)/);
});

test('Index renders readable timeframe, source and audit sections without flattening internal paths', async () => {
  const html = await read('assets/index.html');
  assert.match(html, /id="timeframes"/);
  assert.match(html, /تحلیل تایم‌فریم‌ها/);
  assert.match(html, /تحلیل تکنیکال/);
  assert.match(html, /Gemini/);
  assert.match(html, /OpenRouter/);
  assert.match(html, /Groq/);
  assert.match(html, /altFINS/);
  assert.match(html, /id="audit"/);
  assert.doesNotMatch(html, /function flatten\(/);
});

test('Index reports render success and failure to Flutter and preserves raw model responses', async () => {
  const html = await read('assets/index.html');
  const flutter = await read('lib/screens/exact_snapshot_screen.dart');
  assert.match(html, /IndexBridge\.postMessage/);
  assert.match(html, /report\('success'/);
  assert.match(html, /report\('error'/);
  assert.match(html, /p\.rawText/);
  assert.match(html, /p\.rawProviderResponse/);
  assert.match(flutter, /addJavaScriptChannel\(/);
  assert.match(flutter, /runJavaScriptReturningResult\(/);
  assert.match(flutter, /صفحه داده را دریافت کرد اما رندر گزارش را تأیید نکرد/);
});

test('root index is byte-identical to Android asset and stale duplicate script is removed', async () => {
  assert.equal(await read('assets/index.html'), await read('index.html'));
  await assert.rejects(read('index-script.js'));
});
