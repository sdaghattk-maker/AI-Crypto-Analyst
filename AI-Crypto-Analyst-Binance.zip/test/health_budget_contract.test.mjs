import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

test('Worker health probes have one bounded total budget with bounded catalog and per-model probes', async () => {
  const worker = await read('ai-gateway/worker.js');
  assert.match(worker, /HEALTH_CHECK_BUDGET_MS\s*=\s*32000/);
  assert.match(worker, /HEALTH_CATALOG_TIMEOUT_MS\s*=\s*6000/);
  assert.match(worker, /HEALTH_PROBE_TIMEOUT_MS\s*=\s*5500/);
  assert.match(worker, /HEALTH_MAX_CANDIDATES\s*=\s*4/);
  assert.match(worker, /deadlineAt\s*=\s*startedAt\s*\+\s*HEALTH_CHECK_BUDGET_MS/);
  assert.match(worker, /maxPages:1/);
  assert.match(worker, /durationMs:Date\.now\(\)-startedAt,budgetMs:HEALTH_CHECK_BUDGET_MS/);
});

test('full analysis shares one 82-second deadline across catalog, model fallbacks and optional retries', async () => {
  const worker = await read('ai-gateway/worker.js');
  assert.match(worker, /ANALYSIS_TOTAL_BUDGET_MS\s*=\s*82000/);
  assert.match(worker, /ANALYSIS_CATALOG_TIMEOUT_MS\s*=\s*7000/);
  assert.match(worker, /analysisDeadlineAt\s*=\s*Date\.now\(\)\s*\+\s*ANALYSIS_TOTAL_BUDGET_MS/);
  assert.match(worker, /AI_REQUEST_DEADLINE_MS\s*:\s*modelDeadlineAt/);
  assert.match(worker, /deadlineAt\s*=\s*null/);
  assert.match(worker, /deadlineAt\s*-\s*Date\.now\(\)/);
  assert.match(worker, /fetchProvider\(endpoint,[\s\S]*?AI_REQUEST_DEADLINE_MS/);
});

test('Flutter health transport timeout exceeds the Worker budget with a bounded margin', async () => {
  const config = await read('lib/services/app_config.dart');
  const ai = await read('lib/services/ai_service.dart');
  const connectivity = await read('lib/services/smart_connectivity_service.dart');
  assert.match(config, /providerHealthTimeout\s*=\s*Duration\(seconds:\s*38\)/);
  assert.match(ai, /\.timeout\(AppConfig\.providerHealthTimeout\)/);
  assert.match(connectivity, /timeout: AppConfig\.providerHealthTimeout/);
  assert.match(connectivity, /\.timeout\(timeout\)/);
  assert.doesNotMatch(ai, /providers\/health[\s\S]{0,600}Duration\(seconds:\s*40\)/);
});

test('Durable Object circuit acquire/success/failure operations share the Health and Analysis deadlines', async () => {
  const worker = await read('ai-gateway/worker.js');
  assert.match(worker, /export async function circuitRequest[\s\S]*?deadlineAt - Date\.now\(\)/);
  assert.match(worker, /CIRCUIT_STORE_TIMEOUT/);
  assert.match(worker, /acquireProviderCircuit\(env,circuitKey,\{forceProbe:input\?\.forceProbe === true,deadlineAt\}\)/);
  assert.match(worker, /recordProviderCircuitSuccess\(env,circuitKey,\{deadlineAt\}\)/);
  assert.match(worker, /recordProviderCircuitFailure\(env,circuitKey,[^\n]+\{deadlineAt\}\)/);
});
