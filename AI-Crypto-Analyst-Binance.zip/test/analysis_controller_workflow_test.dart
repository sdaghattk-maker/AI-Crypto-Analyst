import 'package:flutter_test/flutter_test.dart';
import 'package:ai_crypto_analyst/models/app_state.dart';
import 'package:ai_crypto_analyst/services/analysis_controller.dart';
import 'package:ai_crypto_analyst/services/ai_service.dart';
import 'package:ai_crypto_analyst/services/market_api.dart';

void main() {
  group('AnalysisController shared workflow coordination', () {
    late AppState state;
    late AnalysisController controller;

    setUp(() {
      state = AppState();
      controller = AnalysisController(state);
    });

    tearDown(() {
      controller.dispose();
      state.dispose();
    });

    test('only one workflow owner can hold the app-wide lock', () {
      expect(controller.acquireWorkflow('dashboard-refresh'), isTrue);
      expect(controller.workflowBusy, isTrue);
      expect(controller.acquireWorkflow('ai-full-analysis'), isFalse);
      expect(controller.workflowOwner, 'dashboard-refresh');
      controller.releaseWorkflow('ai-full-analysis');
      expect(controller.workflowBusy, isTrue);
      controller.releaseWorkflow('dashboard-refresh');
      expect(controller.workflowBusy, isFalse);
      expect(controller.acquireWorkflow('ai-full-analysis'), isTrue);
    });

    test('provider execution states are centralized and independent', () {
      controller.setProvidersRunning(['gemini', 'groq']);
      expect(controller.providerExecutionStatus['gemini'], 'running');
      expect(controller.providerExecutionStatus['groq'], 'running');
      expect(controller.providerExecutionStatus['openrouter'], 'idle');

      const response = AiConsensus(
        gemini: AiModelResult(model: 'Gemini', status: 'ok'),
        openrouter: AiModelResult(model: 'OpenRouter', status: 'not_selected'),
        groq: AiModelResult(model: 'Groq', status: 'error'),
        decision: 'WAIT', conflicts: [], snapshotId: 'snapshot-1',
      );
      controller.updateProviderStatuses(response);
      expect(controller.providerExecutionStatus['gemini'], 'success');
      expect(controller.providerExecutionStatus['openrouter'], 'idle');
      expect(controller.providerExecutionStatus['groq'], 'failed');
    });


    test('historical successful provider result remains retrievable after a later snapshot', () {
      controller.historicalAiResults['snapshot-old'] = const AiConsensus(
        gemini: AiModelResult(model: 'Gemini', status: 'ok'),
        openrouter: AiModelResult(model: 'OpenRouter', status: 'not_selected'),
        groq: AiModelResult(model: 'Groq', status: 'error'),
        decision: 'WAIT', conflicts: [], snapshotId: 'snapshot-old',
      );
      controller.historicalAiTimes['snapshot-old'] = DateTime.utc(2026, 11, 21);
      expect(controller.historicalProviderResult('gemini')?.status, 'ok');
      expect(controller.historicalProviderResult('openrouter'), isNull);
      expect(controller.historicalProviderResult('groq'), isNull);
    });

    test('timeframe changes advance request generation and invalidate late work', () async {
      expect(controller.requestGeneration, 0);
      state.selectTimeframe('15m');
      await controller.onStateChanged();
      expect(controller.requestGeneration, 1);
      expect(controller.snapshotId, isNull);
    });

    test('snapshot fingerprint is stable inside the 0.1 percent reference-price bucket', () {
      const h1 = [MarketCandle(time: 3600, open: 100, high: 102, low: 99, close: 101, volume: 12)];
      const m15 = [MarketCandle(time: 900, open: 100, high: 102, low: 99, close: 101, volume: 8)];
      const m5 = [MarketCandle(time: 300, open: 100, high: 102, low: 99, close: 100, volume: 4)];
      final first = AnalysisController.buildSnapshotId(
        exchange: 'Binance', symbol: 'BTCUSDT', history1h: h1, history15m: m15, history5m: m5, referencePrice: 100.01);
      final sameBucket = AnalysisController.buildSnapshotId(
        exchange: 'Binance', symbol: 'BTCUSDT', history1h: h1, history15m: m15, history5m: m5, referencePrice: 100.04);
      final nextBucket = AnalysisController.buildSnapshotId(
        exchange: 'Binance', symbol: 'BTCUSDT', history1h: h1, history15m: m15, history5m: m5, referencePrice: 100.06);
      expect(first, sameBucket);
      expect(first, isNot(nextBucket));
    });

    test('snapshot fingerprint changes when any closed OHLCV input changes', () {
      const h1 = [MarketCandle(time: 3600, open: 100, high: 102, low: 99, close: 101, volume: 12)];
      const m15 = [MarketCandle(time: 900, open: 100, high: 102, low: 99, close: 101, volume: 8)];
      const m5 = [MarketCandle(time: 300, open: 100, high: 102, low: 99, close: 100, volume: 4)];
      const changedVolume = [MarketCandle(time: 300, open: 100, high: 102, low: 99, close: 100, volume: 4.01)];
      final original = AnalysisController.buildSnapshotId(
        exchange: 'Binance', symbol: 'BTCUSDT', history1h: h1, history15m: m15, history5m: m5, referencePrice: 100);
      final changed = AnalysisController.buildSnapshotId(
        exchange: 'Binance', symbol: 'BTCUSDT', history1h: h1, history15m: m15, history5m: changedVolume, referencePrice: 100);
      expect(original, isNot(changed));
    });
  });
}
