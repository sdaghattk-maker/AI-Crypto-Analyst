import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:ai_crypto_analyst/services/smart_connectivity_service.dart';

void main() {
  setUp(() { SmartConnectivityService.chartAnalyzerStatus.value = null; });

  Future<ConnectivityReport> inspectProvider(Map<String, dynamic> provider) async {
    final client = MockClient((request) async {
      if (request.url.host == 'hrs-binance-proxy.sdaghat-tk.workers.dev') {
        return http.Response(jsonEncode({'ok':true,'data':{'symbol':'BTCUSDT','price':'65000.00'}}), 200);
      }
      if (request.url.path.endsWith('/health')) {
        return http.Response(jsonEncode({
          'ok': true,
          'configured': {
            'gemini': true,
            'groq': true,
            'openrouter': true,
          },
        }), 200);
      }
      if (request.url.path.endsWith('/providers/health')) {
        return http.Response(jsonEncode({
          'ok': true,
          'providers': {
            'gemini': provider,
            'groq': {'status': 'UNAVAILABLE', 'errorCode': 'NOT_CONFIGURED'},
            'openrouter': {'status': 'UNAVAILABLE', 'errorCode': 'NOT_CONFIGURED'},
          },
        }), 200);
      }
      return http.Response('{}', 404);
    });
    final service = SmartConnectivityService(client: client);
    try {
      return await service.inspect();
    } finally {
      service.dispose();
    }
  }

  LinkState geminiState(ConnectivityReport report) =>
      report.items.firstWhere((item) => item.name == 'Gemini').state;

  test('unknown provider diagnostic is not mislabeled as access blocked', () async {
    final report = await inspectProvider({
      'status': 'UNAVAILABLE',
      'routable': false,
      'errorCode': 'INVALID_RESPONSE_OR_REQUEST',
    });
    expect(geminiState(report), LinkState.degraded);
  });

  test('provider access, authentication, region and model errors remain distinct', () async {
    final access = await inspectProvider({'status':'UNAVAILABLE','routable':false,'errorCode':'ACCESS_DENIED'});
    final auth = await inspectProvider({'status':'UNAVAILABLE','routable':false,'errorCode':'AUTHENTICATION_FAILED'});
    final region = await inspectProvider({'status':'UNAVAILABLE','routable':false,'errorCode':'REGION_RESTRICTED'});
    final model = await inspectProvider({'status':'UNAVAILABLE','routable':false,'errorCode':'MODEL_UNAVAILABLE'});
    expect(geminiState(access), LinkState.blocked);
    expect(geminiState(auth), LinkState.authenticationFailed);
    expect(geminiState(region), LinkState.regionRestricted);
    expect(geminiState(model), LinkState.degraded);
  });

  test('transient empty response remains degraded, not blocked', () async {
    final report = await inspectProvider({
      'status': 'UNAVAILABLE',
      'routable': false,
      'errorCode': 'EMPTY_RESPONSE',
    });
    expect(geminiState(report), LinkState.degraded);
  });

  test('Gateway HTTP 403 is not propagated as an upstream Provider block', () async {
    SmartConnectivityService.chartAnalyzerStatus.value = null;
    final client = MockClient((request) async {
      if (request.url.path.endsWith('/health')) return http.Response('{"error":"forbidden"}', 403);
      if (request.url.path.endsWith('/providers/health')) return http.Response('{"error":"forbidden"}', 403);
      if (request.url.host == 'hrs-binance-proxy.sdaghat-tk.workers.dev') return http.Response('{"ok":true,"data":{"price":"65000"}}', 200);
      return http.Response('{}', 404);
    });
    final service = SmartConnectivityService(client: client);
    try {
      final report = await service.inspect();
      expect(report.items.firstWhere((item)=>item.name=='AI Gateway').state, LinkState.gatewayAccessDenied);
      expect(geminiState(report), LinkState.unknown);
    } finally { service.dispose(); }
  });

  test('Binance Proxy is available only after a real valid price response', () async {
    final report = await inspectProvider({'status':'READY','routable':true});
    expect(report.items.firstWhere((item)=>item.name=='Binance Proxy').state, LinkState.available);
  });

  test('Chart Analyzer WebView result is shared with Smart Connectivity', () async {
    SmartConnectivityService.reportChartAnalyzerStatus(LinkState.available, 'صفحه WebView بارگذاری شد.', latencyMs: 850);
    final report = await inspectProvider({'status':'READY','routable':true});
    final chart = report.items.firstWhere((item)=>item.name=='Chart Analyzer AI');
    expect(chart.state, LinkState.available);
    expect(chart.latencyMs, 850);
  });

  test('failed refresh changes old available states to STALE and preserves their prior state in detail', () {
    final report = ConnectivityReport(checkedAt: DateTime.utc(2026, 11, 23), items: const [
      LinkCheck('AI Gateway', LinkState.available, 'Gateway پاسخ‌گو بود.'),
      LinkCheck('Binance Proxy', LinkState.available, 'قیمت دریافت شد.'),
    ]);
    final stale = report.markStale('Connection timed out');
    expect(stale.items.every((item)=>item.state==LinkState.stale), isTrue);
    expect(stale.items.first.detail, contains('available'));
    expect(stale.items.first.detail, contains('Connection timed out'));
  });

  test('a real inference probe remains available only when routable', () async {
    final report = await inspectProvider({
      'status': 'READY',
      'routable': true,
      'errorCode': null,
    });
    expect(geminiState(report), LinkState.available);
  });
}
