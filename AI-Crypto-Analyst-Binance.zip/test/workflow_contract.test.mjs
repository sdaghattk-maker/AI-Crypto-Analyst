import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const controller = await readFile(new URL('../lib/services/analysis_controller.dart', import.meta.url), 'utf8');
const aiScreen = await readFile(new URL('../lib/screens/ai_analysis.dart', import.meta.url), 'utf8');
const dashboard = await readFile(new URL('../lib/screens/dashboard.dart', import.meta.url), 'utf8');
const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

test('Dashboard and AI screen share the AnalysisController workflow lock', () => {
  assert.match(controller, /bool acquireWorkflow\(String owner\)/);
  assert.match(controller, /if \(workflowBusy\) return false;/);
  assert.match(controller, /Future<bool> run\(\{bool lockAlreadyHeld = false\}\)/);
  assert.match(aiScreen, /const owner = 'ai-full-analysis';[\s\S]*?acquireWorkflow\(owner\)/);
  assert.match(aiScreen, /const owner = 'ai-retry';[\s\S]*?acquireWorkflow\(owner\)/);
  assert.match(dashboard, /analysis\.workflowBusy \? null : analysis\.run/);
});

test('Disabling all AI providers still refreshes technical analysis without sending AI requests', () => {
  const technicalRun = aiScreen.indexOf('widget.analysis.run(lockAlreadyHeld: true)');
  const disabledGuard = aiScreen.indexOf('if (selectedProviders.isEmpty)', technicalRun);
  assert.ok(technicalRun >= 0 && disabledGuard > technicalRun);
  assert.match(aiScreen.slice(disabledGuard, disabledGuard + 700), /هیچ درخواست AI ارسال نشد/);
  assert.match(aiScreen, /selectedProviders: eligibleProviders/);
});

test('Historical AI results are persisted separately and never substituted into current consensus', () => {
  assert.match(controller, /'aiHistory':/);
  assert.match(controller, /'aiSchemaVersion': 3/);
  assert.match(controller, /snapshotId!\.startsWith\('snap2_'\)/);
  assert.match(controller, /historicalAiResults\[entry.key\] = AiConsensus\.fromJson/);
  assert.match(controller, /consensus = null;/);
  assert.match(aiScreen, /displayConsensus => consensus \?\? widget\.analysis\.latestHistoricalConsensus/);
  assert.match(aiScreen, /صرفاً جهت مشاهده/);
  assert.match(aiScreen, /historicalProviderResult\(provider\)/);
  assert.match(controller, /AiModelResult\? historicalProviderResult\(String provider\)/);
});

test('AI requests are guarded by snapshot and request generation and retry only active failed providers', () => {
  assert.match(controller, /int get requestGeneration => _requestGeneration/);
  assert.match(aiScreen, /widget\.analysis\.requestGeneration != generation/);
  assert.match(aiScreen, /\(_providerEnabled\[e\.key\] \?\? false\)/);
  assert.match(aiScreen, /selectedProviders: eligibleProviders/);
});

test('Snapshot identity fingerprints every closed OHLCV candle and a quantized price anchor', () => {
  assert.match(controller, /static String buildSnapshotId\(/);
  assert.match(controller, /candle\.open\.toStringAsPrecision\(17\)/);
  assert.match(controller, /candle\.high\.toStringAsPrecision\(17\)/);
  assert.match(controller, /candle\.low\.toStringAsPrecision\(17\)/);
  assert.match(controller, /candle\.close\.toStringAsPrecision\(17\)/);
  assert.match(controller, /candle\.volume\.toStringAsPrecision\(17\)/);
  assert.match(controller, /priceBucketPermille/);
  assert.match(controller, /buildSnapshotId\(/);
  assert.match(aiScreen, /!aiModelIsConsensusEligible\(currentResults\[provider\]/);
});

test('Market restore generations prevent a previous symbol cache from winning a race', () => {
  assert.match(controller, /final restoreGeneration = \+\+_restoreGeneration/);
  assert.match(controller, /restoreGeneration != _restoreGeneration/);
  assert.match(controller, /requestedExchange != appState\.exchange \|\| requestedSymbol != appState\.symbol/);
  assert.match(controller, /_restoreGeneration\+\+; \/\/ invalidate every restore belonging to the old market/);
  assert.match(controller, /analysis_cache_\$\{targetExchange\}_\$targetSymbol/);
});


test('Technical Engine and AI consume the same frozen closed-candle arrays', () => {
  assert.match(controller, /history1h = _closedHistory\(candles1h, 3600, 1000\);[\s\S]*?history15m = _closedHistory\(candles15m, 900, 1500\);[\s\S]*?history5m = _closedHistory\(candles5m, 300, 2000\);[\s\S]*?engine\.analyze\(h1: history1h, m15: history15m, m5: history5m\)/);
  assert.match(aiScreen, /history1h: snapshotHistory1h,[\s\S]*?history15m: snapshotHistory15m,[\s\S]*?history5m: snapshotHistory5m/);
});


test('Worker is the single source of truth for AI directional vote eligibility; Flutter keeps trade-plan checks separate', async () => {
  const aiService = await read('lib/services/ai_service.dart');
  const hybrid = await read('lib/services/hybrid_engine.dart');
  const worker = await read('ai-gateway/worker.js');
  assert.match(worker, /directionalVoteEligible = provider\.status === "ok"[\s\S]*?marketDirectionSupported/);
  assert.match(worker, /timeframeFactorEvidenceValidation/);
  assert.match(worker, /executionEvidenceValid/);
  assert.match(worker, /tradePlanEligible: !invalidPlan && directional/);
  assert.match(worker, /voteEligibleProviders: eligible/);
  assert.match(aiService, /directionalVoteEligible: raw\['directionalVoteEligible'\] == true/);
  assert.match(aiService, /return provider\.directionalVoteEligible/);
  assert.match(aiService, /return provider\.tradePlanEligible/);
  assert.match(hybrid, /aiModelHasValidExecutionPlan\(provider\)/);
  assert.match(hybrid, /!aiPlanEligible/);
});

test('HTTP 400 history validation diagnostics are surfaced per timeframe in Persian', async () => {
  const aiService = await read('lib/services/ai_service.dart');
  assert.match(aiService, /_formatHistoryQualityDiagnostic\(dynamic raw\)/);
  assert.match(aiService, /final timeframes = raw\['timeframes'\]/);
  assert.match(aiService, /for \(final key in const \['1h', '15m', '5m'\]\)/);
  assert.match(aiService, /check\['reason'\]/);
  assert.match(aiService, /check\['candleCount'\]/);
  assert.match(aiService, /check\['index'\]/);
  assert.match(aiService, /response\.statusCode == 400 && decoded is Map/);
  assert.match(aiService, /_formatHistoryQualityDiagnostic\(decoded\['dataQuality'\]\)/);
});

test('Candle cache normalization rejects contradictory duplicate timestamps instead of overwriting', async () => {
  const marketApi = await read('lib/services/market_api.dart');
  assert.match(marketApi, /on MarketApiDataIntegrityException\s*\{[\s\S]*?rethrow;/);
  assert.match(marketApi, /final existing = unique\[candle\.time\]/);
  assert.match(marketApi, /final identical = existing\.open == candle\.open/);
  assert.match(marketApi, /if \(!identical\)\s*\{[\s\S]*?throw MarketApiDataIntegrityException/);
  assert.doesNotMatch(marketApi, /final unique=<int,MarketCandle>\{for\(final c in list\)c\.time:c\}/);
});

test('AI Gateway request contract carries exchange, symbol and all three separately encoded histories', async () => {
  const aiService = await read('lib/services/ai_service.dart');
  assert.match(aiService, /'exchange': exchange/);
  assert.match(aiService, /'symbol': symbol/);
  assert.match(aiService, /'marketHistory':\s*\{[\s\S]*?'1h': _encodeHistoryWindow\(history1h, 3600\)[\s\S]*?'15m': _encodeHistoryWindow\(history15m, 900\)[\s\S]*?'5m': _encodeHistoryWindow\(history5m, 300\)/);
  assert.match(aiService, /'encodingMetadata':/);
  assert.match(aiService, /'snapshotId': stableSnapshotId/);
});


test('AI provider payload is bounded to the latest 50 contiguous candles per timeframe', async () => {
  const aiService = await readFile(new URL('../lib/services/ai_service.dart', import.meta.url), 'utf8');
  assert.match(aiService, /encodeAiMarketHistoryWindow[\s\S]*?maxCandles = 50/);
  assert.match(aiService, /_encodeHistoryWindow\(history1h, 3600\)[\s\S]*?_encodeHistoryWindow\(history15m, 900\)[\s\S]*?_encodeHistoryWindow\(history5m, 300\)/);
  assert.match(aiService, /sourceCandleCount/);
  assert.match(aiService, /MOST_RECENT_CONTIGUOUS_CLOSED_CANDLES/);
});


test('provider quota failures preserve errorCode and attempted model diagnostics in Flutter', async () => {
  const service = await read('lib/services/ai_service.dart');
  const screen = await read('lib/screens/ai_analysis.dart');
  assert.match(service, /errorCode: raw\['errorCode'\]\?\.toString\(\)/);
  assert.match(service, /'errorCode': errorCode/);
  assert.match(screen, /result\?\.errorCode/);
  assert.match(screen, /result\?\.attemptedModels\.join/);
});

test('model discovery sends only the exact health-probed live candidate sequence to analysis', async () => {
  const service = await readFile(new URL('../lib/services/ai_service.dart', import.meta.url), 'utf8');
  const worker = await readFile(new URL('../ai-gateway/worker.js', import.meta.url), 'utf8');
  assert.match(service, /verifiedModelCandidates/);
  assert.match(service, /'modelCandidates': verifiedModelCandidates/);
  assert.match(worker, /input\?\.modelCandidates/);
  assert.match(worker, /fallbackModel:eligibleCandidates\[1\] \\|\| null/);
  assert.match(worker, /const circuitKey = `\$\{name\}:auto`/);
});

test('Flutter preserves the full Worker-ranked live model catalog instead of filtering Gemini/Groq through stale local rankings', async () => {
  const screen = await readFile(new URL('../lib/screens/ai_analysis.dart', import.meta.url), 'utf8');
  assert.match(screen, /List<String> _rankedModelsFor\(String provider, List<String> live\)/);
  assert.match(screen, /List<String>\.unmodifiable/);
  assert.doesNotMatch(screen, /const ranking = <String, List<String>>/);
});
