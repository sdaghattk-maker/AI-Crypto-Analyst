import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const controller = await readFile(new URL('../lib/services/analysis_controller.dart', import.meta.url), 'utf8');
const aiScreen = await readFile(new URL('../lib/screens/ai_analysis.dart', import.meta.url), 'utf8');
const dashboard = await readFile(new URL('../lib/screens/dashboard.dart', import.meta.url), 'utf8');

test('Dashboard and AI screen share the AnalysisController workflow lock', () => {
  assert.match(controller, /bool acquireWorkflow\(String owner\)/);
  assert.match(controller, /if \(workflowBusy\) return false;/);
  assert.match(controller, /Future<bool> run\(\{bool lockAlreadyHeld = false\}\)/);
  assert.match(aiScreen, /const owner = 'ai-full-analysis';[\s\S]*?acquireWorkflow\(owner\)/);
  assert.match(aiScreen, /const owner = 'ai-retry';[\s\S]*?acquireWorkflow\(owner\)/);
  assert.match(dashboard, /analysis\.workflowBusy \? null : analysis\.run/);
});

test('Disabling all AI providers still refreshes technical analysis without sending AI requests', () => {
  const technicalRun = aiScreen.indexOf('widget.analysis.run(lockAlreadyHeld: true)');
  const disabledGuard = aiScreen.indexOf('if (selectedProviders.isEmpty)', technicalRun);
  assert.ok(technicalRun >= 0 && disabledGuard > technicalRun);
  assert.match(aiScreen.slice(disabledGuard, disabledGuard + 700), /هیچ درخواست AI ارسال نشد/);
  assert.match(aiScreen, /selectedProviders: eligibleProviders/);
});

test('Historical AI results are persisted separately and never substituted into current consensus', () => {
  assert.match(controller, /'aiHistory':/);
  assert.match(controller, /'aiSchemaVersion': 3/);
  assert.match(controller, /snapshotId!\.startsWith\('snap2_'\)/);
  assert.match(controller, /historicalAiResults\[entry.key\] = AiConsensus\.fromJson/);
  assert.match(controller, /consensus = null;/);
  assert.match(aiScreen, /displayConsensus => consensus \?\? widget\.analysis\.latestHistoricalConsensus/);
  assert.match(aiScreen, /صرفاً جهت مشاهده/);
  assert.match(aiScreen, /historicalProviderResult\(provider\)/);
  assert.match(controller, /AiModelResult\? historicalProviderResult\(String provider\)/);
});

test('AI requests are guarded by snapshot and request generation and retry only active failed providers', () => {
  assert.match(controller, /int get requestGeneration => _requestGeneration/);
  assert.match(aiScreen, /widget\.analysis\.requestGeneration != generation/);
  assert.match(aiScreen, /\(_providerEnabled\[e\.key\] \?\? false\)/);
  assert.match(aiScreen, /selectedProviders: eligibleProviders/);
});

test('Snapshot identity fingerprints every closed OHLCV candle and a quantized price anchor', () => {
  assert.match(controller, /static String buildSnapshotId\(/);
  assert.match(controller, /candle\.open\.toStringAsPrecision\(17\)/);
  assert.match(controller, /candle\.high\.toStringAsPrecision\(17\)/);
  assert.match(controller, /candle\.low\.toStringAsPrecision\(17\)/);
  assert.match(controller, /candle\.close\.toStringAsPrecision\(17\)/);
  assert.match(controller, /candle\.volume\.toStringAsPrecision\(17\)/);
  assert.match(controller, /priceBucketPermille/);
  assert.match(controller, /buildSnapshotId\(/);
  assert.match(aiScreen, /!aiModelIsConsensusEligible\(currentResults\[provider\]/);
});

test('Market restore generations prevent a previous symbol cache from winning a race', () => {
  assert.match(controller, /final restoreGeneration = \+\+_restoreGeneration/);
  assert.match(controller, /restoreGeneration != _restoreGeneration/);
  assert.match(controller, /requestedExchange != appState\.exchange \|\| requestedSymbol != appState\.symbol/);
  assert.match(controller, /_restoreGeneration\+\+; \/\/ invalidate every restore belonging to the old market/);
  assert.match(controller, /analysis_cache_\$\{targetExchange\}_\$targetSymbol/);
});


test('Technical Engine and AI consume the same frozen closed-candle arrays', () => {
  assert.match(controller, /history1h = _closedHistory\(candles1h, 3600, 1000\);[\s\S]*?history15m = _closedHistory\(candles15m, 900, 1500\);[\s\S]*?history5m = _closedHistory\(candles5m, 300, 2000\);[\s\S]*?engine\.analyze\(h1: history1h, m15: history15m, m5: history5m\)/);
  assert.match(aiScreen, /history1h: snapshotHistory1h,[\s\S]*?history15m: snapshotHistory15m,[\s\S]*?history5m: snapshotHistory5m/);
});
