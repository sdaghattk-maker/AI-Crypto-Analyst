import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

test('automatic retry is based on actual failure or invalid contract, not consensus ineligibility', async () => {
  const service = await read('lib/services/ai_service.dart');
  const screen = await read('lib/screens/ai_analysis.dart');
  assert.match(service, /bool aiModelIsRetryableFailure\(AiModelResult provider\)/);
  assert.match(service, /provider\.contractStatus\.toUpperCase\(\) != 'VALID'/);
  assert.match(service, /provider\.evidenceStatus\.toUpperCase\(\) == 'INVALID'/);
  assert.match(screen, /where\(\(e\) => \(_providerEnabled\[e\.key\] \?\? false\) &&\s*aiModelIsRetryableFailure\(e\.value\)\)/);
  assert.match(screen, /bool allowReanalysis = false/);
  assert.match(screen, /if \(allowReanalysis\) return true/);
  assert.match(screen, /aiModelIsRetryableFailure\(previous\)/);
  assert.match(screen, /allowReanalysis: true/);
});

test('partial consensus merge requires a non-null identical Snapshot and preserves only a valid prior result', async () => {
  const source = await read('lib/services/ai_service.dart');
  assert.match(source, /snapshotId == null \|\| incoming\.snapshotId == null \|\| snapshotId != incoming\.snapshotId/);
  assert.match(source, /previous\.contractStatus\.toUpperCase\(\) == 'VALID'/);
  assert.match(source, /previous\.evidenceStatus\.toUpperCase\(\) != 'INVALID'/);
});

test('structured gateway failures preserve per-provider codes, HTTP status, retryability and attempted models', async () => {
  const service = await read('lib/services/ai_service.dart');
  const screen = await read('lib/screens/ai_analysis.dart');
  const worker = await read('ai-gateway/worker.js');
  assert.match(service, /providerResults: structuredProviders/);
  assert.match(service, /httpStatus: response\.statusCode/);
  assert.match(service, /retryable: raw\['retryable'\]/);
  assert.match(screen, /AiModelResult\.fromJson\(label, raw\)/);
  assert.match(worker, /httpStatus: Number\.isFinite\(item\.reason\?\.httpStatus\)/);
  assert.match(worker, /retryable: item\.reason\?\.retryable === true/);
  assert.match(worker, /isPermanentProviderFailure/);
});

test('transient Durable Object state failures remain eligible for a user-requested retry', async () => {
  const service = await read('lib/services/ai_service.dart');
  assert.doesNotMatch(service, /'CIRCUIT_STATE_UNAVAILABLE',[\s\S]{0,100}'CIRCUIT_STORE_TIMEOUT'/);
  assert.match(service, /retryable: raw\['retryable'\] is bool/);
});
