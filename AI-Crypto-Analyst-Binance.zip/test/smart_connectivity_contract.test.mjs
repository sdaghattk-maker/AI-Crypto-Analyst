import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

test('Smart Connectivity separates Provider access, authentication, regional and model failures', async () => {
  const source = await read('lib/services/smart_connectivity_service.dart');
  assert.match(source, /code == 'ACCESS_DENIED' \? LinkState\.blocked/);
  assert.match(source, /code == 'AUTHENTICATION_FAILED' \? LinkState\.authenticationFailed/);
  assert.match(source, /code == 'REGION_RESTRICTED' \? LinkState\.regionRestricted/);
  assert.match(source, /'MODEL_UNAVAILABLE'[\s\S]*?LinkState\.degraded/);
  assert.match(source, /LinkState\.gatewayAccessDenied/);
});

test('Binance Proxy health check requires a live BTCUSDT price and Chart Analyzer status comes from WebView', async () => {
  const source = await read('lib/services/smart_connectivity_service.dart');
  const chart = await read('lib/screens/chart_analyzer_screen.dart');
  assert.match(source, /endpoint=price&symbol=BTCUSDT/);
  assert.match(source, /proxyPrice != null && proxyPrice > 0/);
  assert.match(source, /chartAnalyzerStatus\.value/);
  assert.match(chart, /reportChartAnalyzerStatus\(\s*LinkState\.unknown/);
  assert.match(chart, /reportChartAnalyzerStatus\(\s*LinkState\.unknown/);
});

test('Gateway errors are not interpreted as upstream Provider or regional failures', async () => {
  const source = await read('lib/services/smart_connectivity_service.dart');
  assert.match(source, /status == 401 \|\| status == 403/);
  assert.match(source, /LinkState\.gatewayAccessDenied/);
  assert.match(source, /این پاسخ به‌تنهایی خطای دسترسی یا محدودیت منطقه‌ای Providerها را ثابت نمی‌کند/);
});

test('failed refresh marks previous connectivity results stale instead of leaving old green states', async () => {
  const service = await read('lib/services/smart_connectivity_service.dart');
  const screen = await read('lib/screens/connectivity_and_sources.dart');
  assert.match(service, /ConnectivityReport markStale\(String reason\)/);
  assert.match(screen, /_connectivityReport = _connectivityReport!\.markStale/);
  assert.match(screen, /LinkState\.stale/);
});
