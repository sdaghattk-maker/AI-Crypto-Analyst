import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ai_crypto_analyst/services/altfins_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  Future<AltFinsService> serviceFor(Map<String, dynamic> payload) async {
    final client = MockClient((request) async {
      expect(request.url.path, endsWith('/altfins/validation'));
      final body = jsonDecode(request.body) as Map<String, dynamic>;
      expect(body['tradingType'], 'SPOT');
      return http.Response(jsonEncode(payload), 200,
          headers: {'content-type': 'application/json'});
    });
    return AltFinsService(client: client);
  }

  test('available altFINS response without source timestamp is never marked fresh', () async {
    final service = await serviceFor({
      'ok': true,
      'source': 'altfins',
      'status': 'AVAILABLE',
      'data': {'rsi14': 58},
    });
    final result = await service.validateSmart(
      symbol: 'BTCUSDT', timeframe: '15m', exchange: 'BINANCE', forceRefresh: true,
    );
    expect(result['status'], 'INVALID_RESPONSE');
    expect(result['usableForAnalysis'], isFalse);
    expect(result['_refreshFailed'], isTrue);
  });

  test('stale altFINS response is rejected instead of being persisted as fresh', () async {
    final service = await serviceFor({
      'ok': true,
      'source': 'altfins',
      'status': 'AVAILABLE',
      'refreshedAt': DateTime.now().toUtc().subtract(const Duration(minutes: 16)).toIso8601String(),
      'data': {'rsi14': 58},
    });
    final result = await service.validateSmart(
      symbol: 'ETHUSDT', timeframe: '15m', exchange: 'BINANCE', forceRefresh: true,
    );
    expect(result['status'], 'STALE_RESPONSE');
    expect(result['usableForAnalysis'], isFalse);
  });

  test('fresh timestamped altFINS response is eligible only within its timeframe TTL', () async {
    final service = await serviceFor({
      'ok': true,
      'source': 'altfins',
      'status': 'AVAILABLE',
      'refreshedAt': DateTime.now().toUtc().subtract(const Duration(seconds: 20)).toIso8601String(),
      'data': {'rsi14': 58},
    });
    final result = await service.validateSmart(
      symbol: 'SOLUSDT', timeframe: '15m', exchange: 'BINANCE', forceRefresh: true,
    );
    expect(result['status'], 'AVAILABLE');
    expect(result['usableForAnalysis'], isTrue);
  });
}
