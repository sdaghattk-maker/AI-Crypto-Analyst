import 'package:flutter_test/flutter_test.dart';
import 'package:ai_crypto_analyst/services/ai_service.dart';
import 'package:ai_crypto_analyst/services/market_api.dart';

AiModelResult result(String model, String status, {String? bias, String? error}) {
  final side = bias?.toUpperCase();
  final direction = side == 'BUY' ? 'bullish' : 'bearish';
  const entry = 100.0;
  final overlays = status == 'ok' && (side == 'BUY' || side == 'SELL') ? [
    {'type':'line','kind':'Entry','price':entry,'timeframe':'5m','direction':direction},
    {'type':'line','kind':'SL','price':side == 'BUY' ? 99.0 : 101.0,'timeframe':'5m','direction':direction},
    {'type':'line','kind':'TP1','price':side == 'BUY' ? 101.0 : 99.0,'timeframe':'5m','direction':direction},
    {'type':'line','kind':'TP2','price':side == 'BUY' ? 101.5 : 98.5,'timeframe':'5m','direction':direction},
    {'type':'line','kind':'TP3','price':side == 'BUY' ? 102.0 : 98.0,'timeframe':'5m','direction':direction},
  ] : <Map<String, dynamic>>[];
  return AiModelResult(model:model, status:status, bias:bias, marketBias:bias, directionalVoteEligible:status == 'ok' && (side == 'BUY' || side == 'SELL'), tradePlanEligible:status == 'ok' && (side == 'BUY' || side == 'SELL'), confidence:status == 'ok' ? 80 : null,
    confidenceDeclared:status == 'ok', error:error, contractVersion:status == 'ok' ? 3 : 1,
    contractStatus:status == 'ok' ? 'VALID' : 'DEGRADED', evidenceStatus:status == 'ok' ? 'VALIDATED' : 'UNVERIFIED',
    weightsProvided:status == 'ok' && bias != null,
    analyticalWeights: status == 'ok' && bias != null ? const {'trend':20,'marketStructure':20,'liquidity':20,'entryConfirmation':20,'riskReward':20} : const {},
    factorScores: status == 'ok' && bias != null ? const {'trend':80,'marketStructure':80,'liquidity':80,'entryConfirmation':80,'riskReward':80} : const {},
    overlays:overlays);
}

void main() {
  group('AiConsensus partial retry merge', () {
    test('retry policy excludes valid WAIT and unverified non-voting responses but includes invalid contracts and real failures', () {
      final validWait = AiModelResult(model:'Gemini', status:'ok', bias:'WAIT',
        contractStatus:'VALID', evidenceStatus:'UNVERIFIED');
      final validNoVote = AiModelResult(model:'OpenRouter', status:'ok', bias:'BUY',
        directionalVoteEligible:false, contractStatus:'VALID', evidenceStatus:'UNVERIFIED');
      final failed = AiModelResult(model:'Groq', status:'error', errorCode:'PROVIDER_REQUEST_FAILED');
      final partial = AiModelResult(model:'Gemini', status:'ok', contractStatus:'PARTIAL', evidenceStatus:'UNVERIFIED');
      final invalidEvidence = AiModelResult(model:'OpenRouter', status:'ok', contractStatus:'VALID', evidenceStatus:'INVALID');
      final authFailure = AiModelResult(model:'Groq', status:'error', errorCode:'AUTHENTICATION_FAILED');
      final rateLimited = AiModelResult(model:'Groq', status:'error', errorCode:'RATE_LIMITED');
      final circuitStoreUnavailable = AiModelResult(model:'Groq', status:'error', errorCode:'CIRCUIT_STATE_UNAVAILABLE');
      expect(aiModelIsRetryableFailure(validWait), isFalse);
      expect(aiModelIsRetryableFailure(validNoVote), isFalse);
      expect(aiModelIsRetryableFailure(failed), isTrue);
      expect(aiModelIsRetryableFailure(partial), isTrue);
      expect(aiModelIsRetryableFailure(invalidEvidence), isTrue);
      expect(aiModelIsRetryableFailure(authFailure), isFalse);
      expect(aiModelIsRetryableFailure(rateLimited), isFalse);
      expect(aiModelIsRetryableFailure(circuitStoreUnavailable), isTrue);
    });

    test('Gateway rate limiting is not retried immediately while transport timeouts remain retryable', () {
      const limited = AiServiceException('Gateway rate limited', httpStatus:429, errorCode:'RATE_LIMITED', retryable:false);
      const timeout = AiServiceException('Gateway timeout', errorCode:'GATEWAY_TIMEOUT', retryable:true);
      final limitedResult = AiModelResult(model:'Gateway', status:'error', errorCode:limited.errorCode, httpStatus:limited.httpStatus, retryable:limited.retryable);
      final timeoutResult = AiModelResult(model:'Gateway', status:'error', errorCode:timeout.errorCode, retryable:timeout.retryable);
      expect(aiModelIsRetryableFailure(limitedResult), isFalse);
      expect(aiModelIsRetryableFailure(timeoutResult), isTrue);
    });

    test('structured provider HTTP failure preserves diagnostics and authoritative retry policy', () {
      final auth = AiModelResult.fromJson('Gemini', {
        'status':'error','error':'Gemini HTTP 401: invalid key',
        'errorCode':'AUTHENTICATION_FAILED','httpStatus':401,'retryable':false,
        'attemptedModels':['gemini-live-a','gemini-live-b'],
      });
      expect(auth.errorCode, 'AUTHENTICATION_FAILED');
      expect(auth.httpStatus, 401);
      expect(auth.retryable, isFalse);
      expect(auth.attemptedModels, ['gemini-live-a','gemini-live-b']);
      expect(aiModelIsRetryableFailure(auth), isFalse);
      final transient = AiModelResult.fromJson('Groq', {
        'status':'error','errorCode':'TIMEOUT_OR_NETWORK','httpStatus':null,'retryable':true,
      });
      expect(aiModelIsRetryableFailure(transient), isTrue);
    });

    test('missing provider status does not default to a successful response', () {
      final parsed = AiModelResult.fromJson('Gemini', {'bias':'BUY','confidence':80,'confidenceDeclared':true,'contractStatus':'VALID','weightsProvided':true});
      expect(parsed.status, 'unknown');
    });

    test('raw provider envelope and evidence validation state survive model-result serialization', () {
      final parsed = AiModelResult.fromJson('Gemini', {
        'status':'ok','contractStatus':'VALID','schemaStatus':'VALID','evidenceStatus':'VALIDATED',
        'rawProviderResponse':'{\"candidates\":[{\"content\":{\"parts\":[{\"text\":\"raw\"}]}}]}',
        'rawProviderResponseTruncated':false,
        'evidenceValidation':{'status':'VALIDATED','findings':[]},
        'executionPriceValidation':{'status':'INVALID','reasons':['Entry از قیمت مرجع دور است.'],'atr':2.0},
      });
      final restored = AiModelResult.fromJson('Gemini', parsed.toJson());
      expect(restored.evidenceStatus, 'VALIDATED');
      expect(restored.rawProviderResponse, parsed.rawProviderResponse);
      expect(restored.rawProviderResponseTruncated, isFalse);
      expect(restored.evidenceValidation['status'], 'VALIDATED');
      expect(restored.executionPriceValidation['status'], 'INVALID');
      expect(restored.executionPriceValidation['reasons'], ['Entry از قیمت مرجع دور است.']);
    });

    test('compact OHLCV encoding is explicitly quantized, ordered and volume-capped', () {
      final candles=<MarketCandle>[
        const MarketCandle(time:300,open:100,high:101,low:99,close:100,volume:100),
        const MarketCandle(time:600,open:100.00004,high:101.00006,low:99.00004,close:100.00004,volume:200),
        const MarketCandle(time:900,open:100.00004,high:101.00008,low:99.00002,close:100.00016,volume:10000000),
      ];
      final encoded=encodeAiMarketHistory(candles,300);
      final rows=encoded['rows'] as List<List<int>>;
      expect(rows.length,3);
      expect(rows.map((row)=>row[0]).toList(),[0,300,300]);
      expect(encoded['baseVolumeMedian'],200);
      expect(rows.last[5],1000000);
      expect(rows[1][4],0); // 0.4 ppm is rounded to the nearest integer ppm.
      expect(rows[2][4],1);
    });

    test('normalization details and both raw truncation states survive model serialization', () {
      final parsed = AiModelResult.fromJson('Gemini', {
        'status':'ok',
        'rawText':List.filled(20000, 'x').join(),
        'rawTextTruncated':true,
        'rawTextOriginalLength':26000,
        'normalization':{'sourceFormat':'provider_json','tradePlanIncomplete':true,'missingTradeFields':['TP3'],'rawTextTruncated':true},
        'rawProviderResponse':'raw',
        'rawProviderResponseTruncated':true,
        'rawProviderResponseOriginalLength':120000,
      });
      final restored=AiModelResult.fromJson('Gemini',parsed.toJson());
      expect(restored.normalization['tradePlanIncomplete'],isTrue);
      expect(restored.normalization['missingTradeFields'],['TP3']);
      expect(restored.rawTextTruncated,isTrue);
      expect(restored.rawTextOriginalLength,26000);
      expect(restored.rawProviderResponseTruncated,isTrue);
      expect(restored.rawProviderResponseOriginalLength,120000);
    });

    test('gateway candle-quality report survives consensus serialization', () {
      final consensus = AiConsensus.fromJson({
        'gemini': {'status':'not_selected'},
        'openrouter': {'status':'not_selected'},
        'groq': {'status':'not_selected'},
        'decision':'WAIT','conflicts':[],
        'dataQuality': {'status':'VALIDATED','timeframes':{'5m':{'candleCount':2000,'gapCount':0}}},
      });
      final restored = AiConsensus.fromJson(consensus.toJson());
      expect(restored.dataQuality['status'], 'VALIDATED');
      expect((restored.dataQuality['timeframes'] as Map)['5m']['gapCount'], 0);
    });

    test('out-of-range or malformed persisted confidence cannot qualify a vote', () {
      final tooHigh = AiModelResult.fromJson('Gemini', {
        'status':'ok','bias':'BUY','confidence':'140','confidenceDeclared':true,
        'contractStatus':'VALID','evidenceStatus':'VALIDATED','weightsProvided':true,
      });
      final malformed = AiModelResult.fromJson('OpenRouter', {
        'status':'ok','bias':'BUY','confidence':'not-a-number','confidenceDeclared':true,
        'contractStatus':'VALID','evidenceStatus':'VALIDATED','weightsProvided':true,
      });
      expect(tooHigh.confidence, isNull);
      expect(tooHigh.confidenceDeclared, isFalse);
      expect(malformed.confidence, isNull);
      expect(malformed.confidenceDeclared, isFalse);
    });

    test('persisted weight metadata is eligible only with all five valid scores and a 100-point weight total', () {
      final valid = AiModelResult.fromJson('Gemini', {
        'status':'ok','bias':'WAIT','confidence':80,'confidenceDeclared':true,
        'contractStatus':'VALID','evidenceStatus':'VALIDATED','weightsProvided':true,
        'analyticalWeights':{'trend':20,'marketStructure':20,'liquidity':20,'entryConfirmation':20,'riskReward':20},
        'factorScores':{'trend':70,'marketStructure':70,'liquidity':70,'entryConfirmation':70,'riskReward':70},
      });
      final invalidTotal = AiModelResult.fromJson('OpenRouter', {
        'status':'ok','bias':'WAIT','confidence':80,'confidenceDeclared':true,
        'contractStatus':'VALID','evidenceStatus':'VALIDATED','weightsProvided':true,
        'analyticalWeights':{'trend':19,'marketStructure':20,'liquidity':20,'entryConfirmation':20,'riskReward':20},
        'factorScores':{'trend':70,'marketStructure':70,'liquidity':70,'entryConfirmation':70,'riskReward':70},
      });
      final missingFactor = AiModelResult.fromJson('Groq', {
        'status':'ok','bias':'WAIT','confidence':80,'confidenceDeclared':true,
        'contractStatus':'VALID','evidenceStatus':'VALIDATED','weightsProvided':true,
        'analyticalWeights':{'trend':20,'marketStructure':20,'liquidity':20,'entryConfirmation':20,'riskReward':20},
        'factorScores':{'trend':70,'marketStructure':70,'liquidity':70,'entryConfirmation':70},
      });
      expect(valid.weightsProvided, isTrue);
      expect(invalidTotal.weightsProvided, isFalse);
      expect(missingFactor.weightsProvided, isFalse);
    });

    test('missing confidence is preserved as undeclared and does not block an evidenced directional vote', () {
      final parsed = AiModelResult.fromJson('Gemini', {'status':'ok','bias':'WAIT','marketBias':'BUY','directionalVoteEligible':true,'confidence':null,'confidenceDeclared':false,'contractStatus':'VALID','evidenceStatus':'VALIDATED','weightsProvided':false});
      expect(parsed.confidence, isNull);
      expect(parsed.confidenceDeclared, isFalse);
      final consensus = AiConsensus(gemini: parsed, openrouter: parsed, groq: result('Groq','not_selected'), decision:'BUY', conflicts: const [], snapshotId:'snapshot-confidence');
      final merged = consensus.mergePartial(AiConsensus(gemini: parsed, openrouter: parsed, groq: result('Groq','not_selected'), decision:'WAIT', conflicts: const [], snapshotId:'snapshot-confidence'));
      expect(merged.decision, 'BUY');
    });
    test('two SELL votes remain consensus when the third provider returns WAIT', () {
      final sell = result('Gemini','ok',bias:'SELL');
      final sell2 = result('OpenRouter','ok',bias:'SELL');
      final wait = result('Groq','ok',bias:'WAIT');
      final initial = AiConsensus(gemini:sell,openrouter:sell2,groq:wait,decision:'WAIT',conflicts:const [],snapshotId:'snapshot-sell');
      final merged = initial.mergePartial(initial);
      expect(merged.decision,'SELL');
    });

    test('keeps successful answers when other providers are retried', () {
      final previous = AiConsensus(
        gemini: result('Gemini', 'ok', bias: 'BUY'),
        openrouter: result('OpenRouter', 'error', error: 'rate limit'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-1',
      );
      final retry = AiConsensus(
        gemini: result('Gemini', 'not_selected'),
        openrouter: result('OpenRouter', 'ok', bias: 'BUY'),
        groq: result('Groq', 'not_selected'),
        decision: 'BUY', conflicts: const [], snapshotId: 'snapshot-1',
      );

      final merged = previous.mergePartial(retry);
      expect(merged.gemini.status, 'ok');
      expect(merged.gemini.bias, 'BUY');
      expect(merged.openrouter.status, 'ok');
      expect(merged.groq.status, 'not_selected');
      expect(merged.decision, 'BUY');
      expect(merged.snapshotId, 'snapshot-1');
    });


    test('one successful model is WAIT, not a directional consensus', () {
      final previous = AiConsensus(
        gemini: result('Gemini', 'ok', bias: 'BUY'),
        openrouter: result('OpenRouter', 'error', error: 'timeout'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-3',
      );
      final retry = AiConsensus(
        gemini: result('Gemini', 'not_selected'),
        openrouter: result('OpenRouter', 'error', error: 'still unavailable'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-3',
      );
      final merged = previous.mergePartial(retry);
      expect(merged.decision, 'WAIT');
      expect(merged.conflicts.any((x) => x.contains('اجماع چندمدلی نیست')), isTrue);
    });

    test('returns WAIT when successful providers conflict', () {
      final previous = AiConsensus(
        gemini: result('Gemini', 'ok', bias: 'BUY'),
        openrouter: result('OpenRouter', 'error', error: 'temporary'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-2',
      );
      final retry = AiConsensus(
        gemini: result('Gemini', 'not_selected'),
        openrouter: result('OpenRouter', 'ok', bias: 'SELL'),
        groq: result('Groq', 'not_selected'),
        decision: 'SELL', conflicts: const [], snapshotId: 'snapshot-2',
      );
      expect(previous.mergePartial(retry).decision, 'WAIT');
    });
    test('aggregate AI overlays require corroboration from two eligible agreeing providers', () {
      AiModelResult withOverlay(String model, {double zoneLow = 99.0, double zoneHigh = 100.0}) => AiModelResult(
        model:model, status:'ok', bias:'BUY', marketBias:'BUY', directionalVoteEligible:true, tradePlanEligible:true, confidence:80, confidenceDeclared:true,
        contractVersion:3, contractStatus:'VALID', evidenceStatus:'VALIDATED', weightsProvided:true,
        analyticalWeights:const {'trend':20,'marketStructure':20,'liquidity':20,'entryConfirmation':20,'riskReward':20},
        factorScores:const {'trend':80,'marketStructure':80,'liquidity':80,'entryConfirmation':80,'riskReward':80},
        overlays: [
          {'type':'zone','kind':'Bullish OB','direction':'bullish','timeframe':'15m','low':zoneLow,'high':zoneHigh},
          {'type':'line','kind':'Entry','direction':'bullish','timeframe':'5m','price':model == 'Gemini' ? 100.0 : 101.0},
          {'type':'line','kind':'SL','direction':'bullish','timeframe':'5m','price':model == 'Gemini' ? 99.0 : 100.0},
          {'type':'line','kind':'TP1','direction':'bullish','timeframe':'5m','price':model == 'Gemini' ? 101.0 : 102.0},
          {'type':'line','kind':'TP2','direction':'bullish','timeframe':'5m','price':model == 'Gemini' ? 101.5 : 102.5},
          {'type':'line','kind':'TP3','direction':'bullish','timeframe':'5m','price':model == 'Gemini' ? 102.0 : 103.0},
        ],
      );
      final one = AiConsensus(
        gemini:withOverlay('Gemini'), openrouter:result('OpenRouter','error'),
        groq:result('Groq','not_selected'), decision:'WAIT', conflicts:const [], snapshotId:'s1',
      );
      final oneMerged = one.mergePartial(AiConsensus(
        gemini:result('Gemini','not_selected'), openrouter:result('OpenRouter','not_selected'),
        groq:result('Groq','not_selected'), decision:'WAIT', conflicts:const [], snapshotId:'s1',
      ));
      expect(oneMerged.aiOverlays, isEmpty);

      final two = AiConsensus(
        gemini:withOverlay('Gemini'), openrouter:withOverlay('OpenRouter'),
        groq:result('Groq','not_selected'), decision:'BUY', conflicts:const [], snapshotId:'s2',
      );
      final twoMerged = two.mergePartial(AiConsensus(
        gemini:result('Gemini','not_selected'), openrouter:result('OpenRouter','not_selected'),
        groq:result('Groq','not_selected'), decision:'WAIT', conflicts:const [], snapshotId:'s2',
      ));
      expect(twoMerged.aiOverlays.length, 1);
      expect(twoMerged.aiOverlays.single['agreement'], 'multi');

      final three = AiConsensus(
        gemini:withOverlay('Gemini'), openrouter:withOverlay('OpenRouter'),
        groq:withOverlay('Groq', zoneLow:110, zoneHigh:111),
        decision:'BUY', conflicts:const [], snapshotId:'s3',
      );
      final threeMerged = three.mergePartial(AiConsensus(
        gemini:result('Gemini','not_selected'), openrouter:result('OpenRouter','not_selected'),
        groq:result('Groq','not_selected'), decision:'WAIT', conflicts:const [], snapshotId:'s3',
      ));
      expect(threeMerged.aiOverlays.any((item) => item['kind'] == 'Bullish OB'), isTrue);
    });

    test('partial results without an explicit snapshot id are never merged', () {
      final previous = AiConsensus(
        gemini: result('Gemini','ok',bias:'BUY'),
        openrouter: result('OpenRouter','not_selected'),
        groq: result('Groq','not_selected'), decision:'WAIT', conflicts:const [],
      );
      final incoming = AiConsensus(
        gemini: result('Gemini','error',error:'network timeout'),
        openrouter: result('OpenRouter','not_selected'),
        groq: result('Groq','not_selected'), decision:'WAIT', conflicts:const [],
      );
      expect(previous.mergePartial(incoming).gemini.status, 'error');
    });

    test('failed retry replaces a prior invalid contract instead of preserving it as a successful answer', () {
      final previous = AiConsensus(
        gemini: AiModelResult(model:'Gemini',status:'ok',contractStatus:'PARTIAL',evidenceStatus:'UNVERIFIED'),
        openrouter: result('OpenRouter','not_selected'), groq: result('Groq','not_selected'),
        decision:'WAIT', conflicts:const [], snapshotId:'snapshot-invalid',
      );
      final incoming = AiConsensus(
        gemini: result('Gemini','error',error:'provider request failed'),
        openrouter: result('OpenRouter','not_selected'), groq: result('Groq','not_selected'),
        decision:'WAIT', conflicts:const [], snapshotId:'snapshot-invalid',
      );
      expect(previous.mergePartial(incoming).gemini.status, 'error');
    });

    test('failed retry preserves a successful provider result for the same snapshot', () {
      final previous = AiConsensus(
        gemini: result('Gemini', 'ok', bias: 'BUY'),
        openrouter: result('OpenRouter', 'not_selected'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'same-snapshot',
      );
      final failedRetry = AiConsensus(
        gemini: AiModelResult(model:'Gemini', status:'error', error:'temporary gateway failure'),
        openrouter: result('OpenRouter', 'not_selected'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'same-snapshot',
      );
      final merged = previous.mergePartial(failedRetry);
      expect(merged.gemini.status, 'ok');
      expect(merged.gemini.bias, 'BUY');
      expect(merged.conflicts.any((item) => item.contains('پاسخ موفق قبلی')), isTrue);
    });

    test('different market snapshots are never merged during a partial retry', () {
      final previous = AiConsensus(
        gemini: result('Gemini', 'ok', bias: 'BUY'),
        openrouter: result('OpenRouter', 'not_selected'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-old',
      );
      final incoming = AiConsensus(
        gemini: result('Gemini', 'not_selected'),
        openrouter: result('OpenRouter', 'ok', bias: 'SELL'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-new',
      );
      final merged = previous.mergePartial(incoming);
      expect(merged.snapshotId, 'snapshot-new');
      expect(merged.gemini.status, 'not_selected');
      expect(merged.openrouter.bias, 'SELL');
    });

  });
}
