import 'package:flutter/material.dart';
import '../models/app_state.dart';
import '../services/analysis_controller.dart';
import '../services/technical_engine.dart';

const _bg = Color(0xFF0B1020);
const _panel = Color(0xFF121C31);
const _cyan = Color(0xFF28C8F5);
const _mint = Color(0xFF35D9A1);
const _purple = Color(0xFF9B62F5);
const _muted = Color(0xFF9AAAC2);

class TechnicalOverviewScreen extends StatelessWidget {
  const TechnicalOverviewScreen({super.key, required this.state, required this.analysis});
  final AppState state;
  final AnalysisController analysis;

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: Listenable.merge([state, analysis]),
    builder: (context, _) {
      final r = analysis.report;
      return ListView(padding: const EdgeInsets.all(16), children: [
        _pageHeader('تحلیل تکنیکال', 'موتور مستقل • کندل‌های بسته‌شده', Icons.query_stats, _cyan),
        const SizedBox(height: 14),
        _panelCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Expanded(child: Text('وضعیت تحلیل', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),), _pill(analysis.isStale ? 'قدیمی' : 'تازه', analysis.isStale ? Colors.orangeAccent : _mint)]),
          const SizedBox(height: 8),
          Text('${state.symbol} • ${state.exchange}', style: const TextStyle(color: _muted)),
          Text('آخرین به‌روزرسانی: ${analysis.technicalAt?.toLocal().toString().substring(0,16) ?? 'هنوز اجرا نشده'}', style: const TextStyle(color: _muted, fontSize: 11)),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: analysis.loading ? null : analysis.run, icon: analysis.loading ? const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)) : const Icon(Icons.refresh), label: Text(analysis.loading ? 'در حال تحلیل...' : 'اجرای تحلیل تکنیکال'))),
          if (analysis.error != null) Text(analysis.error!, style: const TextStyle(color: Colors.orangeAccent, fontSize: 11)),
        ])),
        const SizedBox(height: 12),
        if (r == null) _empty('برای نمایش ساختار، ابتدا تحلیل تکنیکال را اجرا کنید.') else ...[
          _panelCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('جهت تایم‌فریم‌ها', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            const SizedBox(height: 12),
            Row(children: [
              _tf('1H', r.bias1h.toString().split('.').last),
              const SizedBox(width: 8), _tf('15M', r.bias15m.toString().split('.').last),
              const SizedBox(width: 8), _tf('5M', r.bias5m.toString().split('.').last),
            ]),
          ])),
          const SizedBox(height: 12),
          _panelCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('قدرت خریدار و فروشنده', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 12), _meter('خریدار', r.buyerPower.toDouble(), _mint),
            const SizedBox(height: 10), _meter('فروشنده', r.sellerPower.toDouble(), const Color(0xFFFF647C)),
          ])),
          const SizedBox(height: 12),
          _panelCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('برنامه معامله تکنیکال', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            _line('وضعیت', r.state.toString().split('.').last.toUpperCase()),
            _line('Entry', _price(r.entry)), _line('Stop Loss', _price(r.stopLoss)),
            _line('TP1 / TP2 / TP3', '${_price(r.tp1)} / ${_price(r.tp2)} / ${_price(r.tp3)}'),
            ...r.reasons.map((x) => _bullet(x, _cyan)),
            if (r.warnings.isNotEmpty) ...r.warnings.map((x) => _bullet(x, Colors.orangeAccent)),
          ])),
        ],
      ]);
    },
  );
}

class SourcesOverviewScreen extends StatelessWidget {
  const SourcesOverviewScreen({super.key, required this.onOpenAi, required this.onOpenChart});
  final VoidCallback onOpenAi;
  final VoidCallback onOpenChart;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    _pageHeader('تحلیل منابع', 'اعتبارسنجی مستقل، بدون رأی‌سازی', Icons.verified_user_outlined, _purple),
    const SizedBox(height: 14),
    _sourceCard('altFINS', 'اعتبارسنجی بیرونی و شاخص‌های در دسترس', 'منبع کمکی مستقل؛ محدودیت پلن رایگان حفظ می‌شود. تایم‌فریم 5M و Trade Setup پولی/محدود، مبنای سیگنال ورود قرار نمی‌گیرند.', Icons.insights, _mint, onOpenAi, 'مشاهده وضعیت و داده‌های altFINS'),
    const SizedBox(height: 12),
    _sourceCard('Chart Analyzer AI', 'تحلیل تصویری مستقل نمودار', 'از نمودار تمیز و بدون ترسیمات داخلی استفاده می‌کند. نتیجه آن با موتور تکنیکال و مدل‌های زبانی قابل مقایسه است، اما رأی مصنوعی به اجماع اضافه نمی‌کند.', Icons.auto_awesome, _cyan, onOpenChart, 'باز کردن نمودار و تحلیل تصویری'),
    const SizedBox(height: 12),
    _sourceCard('Technical Engine', 'مرجع مستقل ساختار و سطوح', 'تحلیل تکنیکال از خروجی مدل‌های AI جدا نگه داشته می‌شود؛ منبع ترسیم روی نمودار نیز جداگانه قابل انتخاب است.', Icons.query_stats, _purple, onOpenChart, 'مشاهده نمودار و انتخاب منبع ترسیم'),
    const SizedBox(height: 10),
    _panelCard(child: const Text('اصل اعتبارسنجی: هر منبع با نام، زمان دریافت و وضعیت تازگی خودش نمایش داده می‌شود. داده غایب یا منقضی به‌عنوان تأیید مثبت محاسبه نمی‌شود.', style: TextStyle(color: _muted, height: 1.6, fontSize: 12))),
  ]);
}

class ReportsOverviewScreen extends StatelessWidget {
  const ReportsOverviewScreen({super.key, required this.state, required this.analysis, required this.onOpenAi});
  final AppState state;
  final AnalysisController analysis;
  final VoidCallback onOpenAi;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: Listenable.merge([state, analysis]), builder: (context, _) {
    final r = analysis.report; final ai = analysis.consensus;
    return ListView(padding: const EdgeInsets.all(16), children: [
      _pageHeader('تاریخچه و گزارش‌ها', 'آخرین Snapshot ذخیره‌شده', Icons.history, _purple),
      const SizedBox(height: 14),
      if (r == null) _empty('هنوز گزارشی برای این نماد ذخیره نشده است.') else ...[
        _panelCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Text('${state.symbol} • ${state.exchange}', style: const TextStyle(fontWeight: FontWeight.w800))), _pill(analysis.isStale ? 'قدیمی' : 'تازه', analysis.isStale ? Colors.orangeAccent : _mint)]),
          const SizedBox(height: 8), Text('تحلیل تکنیکال: ${analysis.technicalAt?.toLocal().toString().substring(0,16) ?? '—'}', style: const TextStyle(color: _muted, fontSize: 11)),
          Text('تحلیل AI: ${analysis.aiAt?.toLocal().toString().substring(0,16) ?? 'ثبت نشده'}', style: const TextStyle(color: _muted, fontSize: 11)),
          const Divider(height: 22),
          _line('وضعیت تکنیکال', r.state.toString().split('.').last.toUpperCase()),
          _line('قیمت مرجع', _price(analysis.latestReferencePrice)),
          _line('کندل‌های بسته‌شده', '1H ${analysis.historyCount1h} • 15M ${analysis.historyCount15m} • 5M ${analysis.historyCount5m}'),
          _line('Snapshot ID', analysis.snapshotId ?? '—'),
        ])),
        const SizedBox(height: 12),
        _panelCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('گزارش هوش مصنوعی', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(ai == null ? 'برای این Snapshot هنوز خروجی AI ثبت نشده است.' : 'تصمیم ذخیره‌شده: ${ai.decision} • مدل‌های پاسخ‌گو: ${[ai.gemini, ai.openrouter, ai.groq].where((m) => m.status == 'ok').length}/3', style: const TextStyle(color: _muted, fontSize: 12)),
          const SizedBox(height: 8), OutlinedButton.icon(onPressed: onOpenAi, icon: const Icon(Icons.psychology), label: const Text('مشاهده گزارش کامل مدل‌ها')),
        ])),
      ],
      const SizedBox(height: 10),
      const Text('این صفحه فعلاً آخرین گزارش ذخیره‌شده برای نماد انتخابی را نمایش می‌دهد؛ آرشیو چندنسخه‌ای تاریخی در این نسخه ادعا نمی‌شود.', style: TextStyle(color: _muted, fontSize: 11, height: 1.5)),
    ]);
  });
}

Widget _pageHeader(String title, String subtitle, IconData icon, Color color) => Row(children: [
  Container(width: 46, height: 46, decoration: BoxDecoration(color: color.withOpacity(.13), borderRadius: BorderRadius.circular(15), border: Border.all(color: color.withOpacity(.3))), child: Icon(icon, color: color)),
  const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), Text(subtitle, style: const TextStyle(color: _muted, fontSize: 11))])),
]);
Widget _panelCard({required Widget child}) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(.07)), boxShadow: [BoxShadow(color: _cyan.withOpacity(.035), blurRadius: 18)]), child: child);
Widget _pill(String text, Color color) => Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(20), border: Border.all(color: color.withOpacity(.3))), child: Text(text, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w800)));
Widget _tf(String tf, String value) => Expanded(child: Container(padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4), decoration: BoxDecoration(color: _cyan.withOpacity(.07), borderRadius: BorderRadius.circular(13), border: Border.all(color: _cyan.withOpacity(.18))), child: Column(children: [Text(tf, style: const TextStyle(color: _muted, fontSize: 11)), const SizedBox(height: 5), Text(value, style: const TextStyle(color: _cyan, fontWeight: FontWeight.w800, fontSize: 12))])));
Widget _meter(String label, double value, Color color) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: Text(label, style: const TextStyle(color: _muted, fontSize: 12))), Text('${value.toStringAsFixed(0)}%', style: TextStyle(color: color, fontWeight: FontWeight.w800))]), const SizedBox(height: 5), ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: (value / 100).clamp(0,1), minHeight: 7, color: color, backgroundColor: Colors.white10))]);
Widget _line(String a, String b) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(children: [Expanded(child: Text(a, style: const TextStyle(color: _muted, fontSize: 11))), Flexible(child: Text(b, textAlign: TextAlign.end, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)))]));
Widget _bullet(String text, Color color) => Padding(padding: const EdgeInsets.only(top: 7), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.circle, size: 5, color: color), const SizedBox(width: 7), Expanded(child: Text(text, style: const TextStyle(color: _muted, fontSize: 11, height: 1.4)))]));
Widget _empty(String text) => _panelCard(child: Text(text, style: const TextStyle(color: _muted, fontSize: 12)));
Widget _sourceCard(String title, String subtitle, String body, IconData icon, Color color, VoidCallback action, String button) => _panelCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, color: color, size: 24), const SizedBox(width: 9), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)), Text(subtitle, style: TextStyle(color: color, fontSize: 10))]))]), const SizedBox(height: 9), Text(body, style: const TextStyle(color: _muted, fontSize: 11, height: 1.55)), const SizedBox(height: 8), SizedBox(width: double.infinity, child: OutlinedButton(onPressed: action, child: Text(button)))]));
String _price(double? v) => v == null ? 'ارائه نشده' : v.toStringAsFixed(2);
