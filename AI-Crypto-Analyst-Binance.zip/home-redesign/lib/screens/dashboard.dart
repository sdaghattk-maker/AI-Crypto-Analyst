import 'package:flutter/material.dart';
import '../models/app_state.dart';
import '../services/analysis_controller.dart';
import '../services/technical_engine.dart';
import '../services/ai_service.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.state, required this.analysis, this.onOpenAi});
  final AppState state;
  final AnalysisController analysis;
  final VoidCallback? onOpenAi;
  static const symbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT'];
  static const _mint = Color(0xFF46D6B3);
  static const _muted = Color(0xFF9AA8BD);

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: Listenable.merge([state, analysis]),
    builder: (context, _) {
      final report = analysis.report;
      final consensus = analysis.consensus;
      final providers = consensus == null
          ? <AiModelResult>[]
          : [consensus.gemini, consensus.openrouter, consensus.groq];
      final valid = providers.where(_isValid).toList();
      final aiStale = analysis.aiAt != null && DateTime.now().difference(analysis.aiAt!) > const Duration(minutes: 15);
      final decision = consensus == null || aiStale || valid.length < 2 ? 'WAIT' : consensus.decision;
      final isActionable = consensus != null && !aiStale && valid.length >= 2 && (decision == 'BUY' || decision == 'SELL');
      final decisionColor = isActionable
          ? (decision == 'BUY' ? const Color(0xFF36D69A) : const Color(0xFFFF647C))
          : const Color(0xFFFFC45C);
      final reason = aiStale ? 'نتیجه AI قدیمی است؛ برای تصمیم تازه باید تحلیل جدید اجرا شود.' : _decisionReason(consensus, valid);

      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 22),
        children: [
          Row(children: [
            Container(width: 42, height: 42, decoration: BoxDecoration(color: _mint.withValues(alpha: .13), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.insights_rounded, color: _mint)),
            const SizedBox(width: 11),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('AI Crypto Analyst', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              SizedBox(height: 2), Text('مرکز تصمیم‌گیری بازار', style: TextStyle(color: _muted, fontSize: 12)),
            ])),
            _livePill(analysis.loading),
          ]),
          const SizedBox(height: 16),
          _marketSelector(),
          const SizedBox(height: 14),
          _decisionCard(
            decision: decision,
            color: decisionColor,
            actionable: isActionable,
            consensus: consensus,
            validCount: valid.length,
            reason: reason,
          ),
          const SizedBox(height: 14),
          _sectionTitle('ساختار بازار', trailing: report == null ? 'منتظر تحلیل تکنیکال' : 'تحلیل تکنیکال'),
          _structureCard(report),
          const SizedBox(height: 14),
          _sectionTitle('عوامل مؤثر بر تصمیم', trailing: 'خلاصه'),
          _factorsCard(report, consensus, valid),
          const SizedBox(height: 14),
          _sectionTitle('تحلیل و جزئیات', trailing: 'قابل باز شدن'),
          _detailsCard(report, consensus, providers),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: SizedBox(height: 50, child: FilledButton.icon(
              onPressed: analysis.loading ? null : analysis.run,
              icon: analysis.loading ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.query_stats_rounded),
              label: const Text('تحلیل تکنیکال', maxLines: 1, overflow: TextOverflow.ellipsis),
              style: FilledButton.styleFrom(backgroundColor: _mint, foregroundColor: const Color(0xFF071B19), textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
            ))),
            const SizedBox(width: 9),
            Expanded(child: SizedBox(height: 50, child: OutlinedButton.icon(
              onPressed: onOpenAi,
              icon: const Icon(Icons.auto_awesome_rounded, color: Color(0xFFB88BFF)),
              label: const Text('تحلیل هوشمند', maxLines: 1, overflow: TextOverflow.ellipsis),
              style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Color(0xFF8E5BE8)), textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
            ))),
          ]),
          if (analysis.error != null) Padding(padding: const EdgeInsets.only(top: 9), child: Text(analysis.error!, style: const TextStyle(color: Colors.orangeAccent, fontSize: 12))),
          if (analysis.status.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 7), child: Text(analysis.status, textAlign: TextAlign.center, style: const TextStyle(color: _muted, fontSize: 11))),
        ],
      );
    },
  );

  Widget _marketSelector() => Card(
    margin: EdgeInsets.zero,
    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), child: Row(children: [
      const Icon(Icons.currency_bitcoin, color: _mint, size: 20),
      const SizedBox(width: 8),
      Expanded(child: DropdownButtonFormField<String>(
        value: state.symbol,
        isDense: true,
        decoration: const InputDecoration(labelText: 'بازار', border: InputBorder.none, contentPadding: EdgeInsets.zero),
        items: symbols.map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(fontWeight: FontWeight.w700)))).toList(),
        onChanged: (v) { if (v != null) state.selectSymbol(v); },
      )),
      const SizedBox(width: 10),
      Container(width: 1, height: 35, color: Colors.white12),
      const SizedBox(width: 10),
      DropdownButtonHideUnderline(child: DropdownButton<String>(
        value: state.exchange,
        isDense: true,
        items: const [DropdownMenuItem(value: 'Binance', child: Text('Binance')), DropdownMenuItem(value: 'Nobitex', child: Text('نوبیتکس'))],
        onChanged: (v) { if (v != null) state.selectExchange(v); },
      )),
    ])),
  );

  Widget _decisionCard({required String decision, required Color color, required bool actionable, required AiConsensus? consensus, required int validCount, required String reason}) {
    final stale = analysis.aiAt != null && DateTime.now().difference(analysis.aiAt!) > const Duration(minutes: 15);
    final label = consensus == null ? 'تحلیل AI هنوز اجرا نشده' : actionable ? 'اجماع معتبر چندمدلی' : 'ورود تأیید نشده';
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [color.withValues(alpha: .19), const Color(0xFF151D31), const Color(0xFF11192B)]),
        border: Border.all(color: color.withValues(alpha: .48)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Expanded(child: Text('تصمیم فعلی', style: TextStyle(color: _muted, fontSize: 13, fontWeight: FontWeight.w600))),
          _statusPill(label, color),
        ]),
        const SizedBox(height: 7),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(decision, style: TextStyle(fontSize: 42, height: 1.05, letterSpacing: 1.2, fontWeight: FontWeight.w900, color: color)),
          const Spacer(),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('$validCount از ۳ مدل معتبر', style: const TextStyle(color: Colors.white70, fontSize: 11)),
            if (analysis.aiAt != null) Text('آخرین تحلیل: ${_date(analysis.aiAt!)}', style: const TextStyle(color: _muted, fontSize: 10)),
          ]),
        ]),
        const SizedBox(height: 12),
        Container(height: 1, color: Colors.white12),
        const SizedBox(height: 11),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.info_outline_rounded, color: color, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(reason, style: const TextStyle(fontSize: 13, height: 1.6, color: Colors.white))),
        ]),
        if (consensus == null) const Padding(padding: EdgeInsets.only(top: 9), child: Text('برای دریافت نظر مدل‌ها، از بخش «تحلیل AI» تحلیل را اجرا کنید.', style: TextStyle(color: _muted, fontSize: 11))),
        if (stale) const Padding(padding: EdgeInsets.only(top: 9), child: Row(children: [Icon(Icons.schedule, size: 14, color: Colors.orangeAccent), SizedBox(width: 5), Text('این نتیجه بیش از ۱۵ دقیقه قدمت دارد.', style: TextStyle(color: Colors.orangeAccent, fontSize: 11))])),
      ]),
    );
  }

  Widget _structureCard(TechnicalReport? r) {
    if (r == null) return _emptyCard('ساختار بازار پس از دریافت کندل‌های بسته‌شده نمایش داده می‌شود.');
    return Card(margin: EdgeInsets.zero, child: Padding(padding: const EdgeInsets.all(13), child: Column(children: [
      Row(children: [
        Expanded(child: _tfTile('۱ ساعته', _biasFa(r.bias1h), _biasColor(r.bias1h), 'جهت زمینه')),
        const SizedBox(width: 7), Expanded(child: _tfTile('۱۵ دقیقه', _biasFa(r.bias15m), _biasColor(r.bias15m), 'ساختار ستاپ')),
        const SizedBox(width: 7), Expanded(child: _tfTile('۵ دقیقه', _biasFa(r.bias5m), _biasColor(r.bias5m), 'اجرای ورود')),
      ]),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: _miniMetric('قدرت خریدار', '${r.buyerPower}%', const Color(0xFF36D69A))),
        const SizedBox(width: 12),
        Expanded(child: _miniMetric('قدرت فروشنده', '${r.sellerPower}%', const Color(0xFFFF647C))),
      ]),
    ])));
  }

  Widget _factorsCard(TechnicalReport? r, AiConsensus? c, List<AiModelResult> valid) {
    final hasEntry = r?.entry != null && r?.stopLoss != null;
    final modelAgreement = valid.length >= 2 && c != null && (c.decision == 'BUY' || c.decision == 'SELL');
    final structureAligned = r != null && r.bias1h == r.bias15m && r.bias15m == r.bias5m && r.bias1h != TradeBias.neutral;
    return Card(margin: EdgeInsets.zero, child: Column(children: [
      _factorRow(Icons.account_tree_outlined, 'جهت تایم‌فریم‌ها', structureAligned ? 'هم‌جهت' : r == null ? 'داده موجود نیست' : 'ناهمسو / خنثی', structureAligned ? _mint : Colors.orangeAccent),
      const Divider(height: 1, indent: 14, endIndent: 14),
      _factorRow(Icons.groups_2_outlined, 'توافق مدل‌ها', modelAgreement ? 'اجماع ${_decisionFa(c!.decision)}' : '${valid.length} مدل معتبر؛ بدون اجماع ورود', modelAgreement ? _mint : Colors.orangeAccent),
      const Divider(height: 1, indent: 14, endIndent: 14),
      _factorRow(Icons.my_location_outlined, 'نقشه ورود تکنیکال', hasEntry ? 'سطوح محاسبه شده' : 'ورود مشخص نشده', hasEntry ? _mint : _muted),
      const Divider(height: 1, indent: 14, endIndent: 14),
      _factorRow(Icons.verified_outlined, 'کیفیت پاسخ AI', c == null ? 'تحلیلی دریافت نشده' : '${valid.length} پاسخ با قرارداد معتبر', valid.length >= 2 ? _mint : Colors.orangeAccent),
    ]));
  }

  Widget _detailsCard(TechnicalReport? r, AiConsensus? c, List<AiModelResult> providers) => Card(
    margin: EdgeInsets.zero,
    child: Column(children: [
      ExpansionTile(leading: const Icon(Icons.tune_rounded, color: _mint), title: const Text('جزئیات تکنیکال', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('RSI، CRT، Entry، حد ضرر و اهداف', style: TextStyle(color: _muted, fontSize: 11)), children: [
        if (r == null) const Padding(padding: EdgeInsets.all(14), child: Text('هنوز گزارش تکنیکال وجود ندارد.')) else Padding(padding: const EdgeInsets.fromLTRB(15, 0, 15, 14), child: Column(children: [
          _detailLine('امتیاز شواهد', '${r.score}/100'), _detailLine('RSI پنج‌دقیقه', r.rsi.toStringAsFixed(1)),
          _detailLine('محدوده CRT', '${_p(r.rangeLow)} تا ${_p(r.rangeHigh)}'),
          _detailLine('Entry', _p(r.entry)), _detailLine('Stop Loss', _p(r.stopLoss)),
          _detailLine('TP1 / TP2 / TP3', '${_p(r.tp1)} / ${_p(r.tp2)} / ${_p(r.tp3)}'),
          ...r.reasons.take(5).map((x) => _bullet(x, _mint)),
          ...r.warnings.take(5).map((x) => _bullet(x, Colors.orangeAccent)),
        ])),
      ]),
      const Divider(height: 1, indent: 14, endIndent: 14),
      ExpansionTile(leading: const Icon(Icons.hub_outlined, color: _mint), title: const Text('وضعیت سه مدل AI', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('جزئیات، اختلاف‌ها و خطاها', style: TextStyle(color: _muted, fontSize: 11)), children: [
        if (c == null) const Padding(padding: EdgeInsets.all(14), child: Text('نتیجه‌ای از مدل‌ها ذخیره نشده است.')) else Padding(padding: const EdgeInsets.fromLTRB(15, 0, 15, 14), child: Column(children: [
          for (final p in providers) _providerTile(p),
          if (c.conflicts.isNotEmpty) ...[
            const Align(alignment: Alignment.centerRight, child: Text('اختلاف‌ها و محدودیت‌ها', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orangeAccent))),
            ...c.conflicts.take(8).map((x) => _bullet(x, Colors.orangeAccent)),
          ],
        ])),
      ]),
      const Divider(height: 1, indent: 14, endIndent: 14),
      ExpansionTile(leading: const Icon(Icons.dataset_outlined, color: _mint), title: const Text('داده‌های تکمیلی', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('فقط داده‌های واقعاً گزارش‌شده توسط مدل‌ها', style: TextStyle(color: _muted, fontSize: 11)), children: [
        if (c == null) const Padding(padding: EdgeInsets.all(14), child: Text('داده‌ای در دسترس نیست.')) else Padding(padding: const EdgeInsets.fromLTRB(15, 0, 15, 14), child: _dataSummary(providers)),
      ]),
    ]),
  );

  Widget _dataSummary(List<AiModelResult> providers) {
    const labels = {'orderBook':'دفتر سفارش','derivatives':'مشتقات','liquidations':'لیکوییدیشن','onChain':'آن‌چین','news':'اخبار و احساسات','externalIndicators':'شاخص‌های بیرونی'};
    final rows = <Widget>[];
    for (final p in providers.where(_isValid)) {
      for (final entry in p.dataCategories.entries) {
        final key = entry.key;
        final value = entry.value;
        final title = labels[key] ?? key;
        final text = value is Map ? (value['status'] ?? value['availability'] ?? value['summary'] ?? 'گزارش شده').toString() : value.toString();
        rows.add(_detailLine('${p.model} • $title', text));
      }
    }
    if (rows.isEmpty) return const Align(alignment: Alignment.centerRight, child: Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('مدل‌ها داده تکمیلی قابل‌استنادی گزارش نکرده‌اند؛ چیزی از روی حدس پر نشده است.', style: TextStyle(color: _muted, fontSize: 12))));
    return Column(children: rows.take(18).toList());
  }

  Widget _providerTile(AiModelResult p) {
    final ok = _isValid(p);
    final color = ok ? _mint : Colors.orangeAccent;
    final summary = (p.summary ?? '').trim();
    return Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(p.model, style: const TextStyle(fontWeight: FontWeight.w700))), _statusPill(ok ? 'معتبر' : _statusFa(p), color)]),
      const SizedBox(height: 4),
      _detailLine('جهت / اطمینان', '${p.bias ?? '—'} • ${p.confidence}%'),
      if (summary.isNotEmpty) Text(summary, style: const TextStyle(color: Colors.white70, fontSize: 12, height: 1.5)),
      if (p.timeframeAnalysis.isNotEmpty) ...[
        const SizedBox(height: 8),
        const Align(alignment: Alignment.centerRight, child: Text('Market Structure مدل', style: TextStyle(color: _mint, fontSize: 11, fontWeight: FontWeight.w800))),
        const SizedBox(height: 4),
        for (final tf in const ['1h', '15m', '5m'])
          if (p.timeframeAnalysis[tf] is Map) _aiTimeframeRow(tf, Map<String, dynamic>.from(p.timeframeAnalysis[tf] as Map)),
      ],
      if ((p.error ?? '').isNotEmpty) Text(p.error!, style: const TextStyle(color: Colors.orangeAccent, fontSize: 11)),
    ]));
  }

  Widget _aiTimeframeRow(String tf, Map<String, dynamic> data) {
    final structure = _enumFa(data['structure']?.toString() ?? 'UNKNOWN');
    final trend = _enumFa(data['trend']?.toString() ?? 'UNKNOWN');
    final event = _eventFa(data['structureEvent']?.toString() ?? 'UNKNOWN');
    final phase = _enumFa(data['phase']?.toString() ?? 'UNKNOWN');
    final liquidity = _enumFa(data['liquidity']?.toString() ?? 'UNKNOWN');
    final evidence = data['evidence'] is List ? (data['evidence'] as List).map((e) => e.toString()).take(2).join(' • ') : '';
    return Container(margin: const EdgeInsets.only(top: 5), padding: const EdgeInsets.all(9), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .035), borderRadius: BorderRadius.circular(10)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Text(tf.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 10, color: _mint)), const SizedBox(width: 8), Expanded(child: Text('ساختار: $structure  |  روند: $trend', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600))),]),
      const SizedBox(height: 3),
      Text('رویداد: $event  •  فاز: $phase  •  نقدینگی: $liquidity', style: const TextStyle(fontSize: 10, color: _muted)),
      if (evidence.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(evidence, style: const TextStyle(fontSize: 10, color: Colors.white60, height: 1.4))),
    ]));
  }

  Widget _tfTile(String title, String value, Color color, String hint) => Container(
    padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 7),
    decoration: BoxDecoration(color: color.withValues(alpha: .08), borderRadius: BorderRadius.circular(13), border: Border.all(color: color.withValues(alpha: .22))),
    child: Column(children: [Text(title, style: const TextStyle(color: _muted, fontSize: 11)), const SizedBox(height: 6), Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 14)), const SizedBox(height: 3), Text(hint, style: const TextStyle(color: _muted, fontSize: 9), textAlign: TextAlign.center)],),
  );
  Widget _miniMetric(String title, String value, Color color) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: Text(title, style: const TextStyle(color: _muted, fontSize: 10))), Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 11))]), const SizedBox(height: 5), ClipRRect(borderRadius: BorderRadius.circular(5), child: LinearProgressIndicator(value: (int.tryParse(value.replaceAll('%', '')) ?? 0) / 100, minHeight: 5, backgroundColor: Colors.white10, color: color))]);
  Widget _factorRow(IconData icon, String title, String value, Color color) => Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), child: Row(children: [Icon(icon, size: 18, color: _muted), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12))), Flexible(child: Text(value, textAlign: TextAlign.end, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)))]));
  Widget _detailLine(String title, String value) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Text(title, style: const TextStyle(color: _muted, fontSize: 11))), const SizedBox(width: 10), Flexible(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)))]));
  Widget _bullet(String text, Color color) => Padding(padding: const EdgeInsets.only(top: 6), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.circle, size: 5, color: color), const SizedBox(width: 7), Expanded(child: Text(text, style: const TextStyle(color: Colors.white70, fontSize: 11, height: 1.45)))]));
  Widget _emptyCard(String text) => Card(margin: EdgeInsets.zero, child: Padding(padding: const EdgeInsets.all(15), child: Text(text, style: const TextStyle(color: _muted, fontSize: 12))));
  Widget _sectionTitle(String title, {String? trailing}) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(children: [Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)), const Spacer(), if (trailing != null) Text(trailing, style: const TextStyle(color: _muted, fontSize: 10))]));
  Widget _statusPill(String text, Color color) => Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(20), border: Border.all(color: color.withValues(alpha: .25))), child: Text(text, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700)));
  Widget _livePill(bool loading) => Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: (loading ? Colors.orangeAccent : _mint).withValues(alpha: .10), borderRadius: BorderRadius.circular(18)), child: Row(children: [Icon(loading ? Icons.sync : Icons.circle, size: 8, color: loading ? Colors.orangeAccent : _mint), const SizedBox(width: 5), Text(loading ? 'در حال تحلیل' : 'داشبورد', style: TextStyle(color: loading ? Colors.orangeAccent : _mint, fontSize: 10, fontWeight: FontWeight.w700))]));

  static bool _isValid(AiModelResult p) => p.status == 'ok' && p.contractStatus == 'VALID' && p.weightsProvided && p.bias != null;
  static String _decisionReason(AiConsensus? c, List<AiModelResult> valid) {
    if (c == null) return 'هنوز خروجی معتبری از تحلیل هوش مصنوعی ثبت نشده است.';
    if (valid.length < 2) return 'برای تصمیم جهت‌دار، حداقل دو پاسخ معتبر و قابل‌مقایسه لازم است. فعلاً ورود تأیید نمی‌شود.';
    if (c.decision == 'WAIT') return c.conflicts.isNotEmpty ? c.conflicts.first : 'مدل‌ها اجماع جهت‌دار کافی ندارند یا شرایط ورود کامل نشده است.';
    final summaries = valid.where((p) => p.bias?.toUpperCase() == c.decision).map((p) => p.summary).whereType<String>().where((s) => s.trim().isNotEmpty).take(1).toList();
    return summaries.isNotEmpty ? summaries.first : 'حداقل دو مدل معتبر با جهت ${c.decision} هم‌نظر هستند؛ جزئیات و ریسک‌ها را پیش از اقدام بررسی کنید.';
  }
  static String _enumFa(String value) => switch (value.toUpperCase()) {
    'BULLISH' => 'صعودی', 'BEARISH' => 'نزولی', 'RANGE' => 'رنج', 'TRANSITION' => 'گذار',
    'TRENDING' => 'رونددار', 'RANGING' => 'نوسانی', 'ACCUMULATION' => 'تجمیع', 'DISTRIBUTION' => 'توزیع', 'REVERSAL' => 'بازگشت',
    'BUY_SIDE_SWEEP' => 'جمع‌آوری نقدینگی خرید', 'SELL_SIDE_SWEEP' => 'جمع‌آوری نقدینگی فروش', 'BOTH' => 'هر دو سمت', 'NONE' => 'مشاهده نشد', 'UNKNOWN' => 'ارائه نشده', _ => value,
  };
  static String _eventFa(String value) => switch (value.toUpperCase()) {
    'BOS_BULLISH' => 'BOS صعودی', 'BOS_BEARISH' => 'BOS نزولی',
    'CHOCH_BULLISH' => 'CHOCH صعودی', 'CHOCH_BEARISH' => 'CHOCH نزولی',
    'MSS_BULLISH' => 'MSS صعودی', 'MSS_BEARISH' => 'MSS نزولی',
    'NONE' => 'رویداد تأییدشده ندارد', 'UNKNOWN' => 'ارائه نشده / نامشخص', _ => value,
  };
  static String _decisionFa(String d) => d == 'BUY' ? 'خرید' : d == 'SELL' ? 'فروش' : 'انتظار';
  static String _statusFa(AiModelResult p) => p.status == 'error' ? 'خطا' : p.contractStatus == 'VALID' ? 'پاسخ ناقص/غیرقابل‌اجماع' : 'قالب نامعتبر';
  static String _biasFa(TradeBias b) => switch (b) { TradeBias.bullish => 'صعودی', TradeBias.bearish => 'نزولی', TradeBias.neutral => 'خنثی' };
  static Color _biasColor(TradeBias b) => b == TradeBias.bullish ? const Color(0xFF36D69A) : b == TradeBias.bearish ? const Color(0xFFFF647C) : const Color(0xFFFFC45C);
  static String _p(double? v) => v == null ? '—' : v.toStringAsFixed(2);
  static String _date(DateTime d) => '${d.toLocal().month.toString().padLeft(2, '0')}/${d.toLocal().day.toString().padLeft(2, '0')} ${d.toLocal().hour.toString().padLeft(2, '0')}:${d.toLocal().minute.toString().padLeft(2, '0')}';
}
