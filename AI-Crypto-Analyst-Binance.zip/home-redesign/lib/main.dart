import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'models/app_state.dart';
import 'services/analysis_controller.dart';
import 'screens/dashboard.dart';
import 'screens/chart_screen.dart';
import 'screens/ai_analysis.dart';
import 'screens/overview_pages.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterError.onError = (details) {
    FlutterError.presentError(details);
    debugPrint('APP_WIDGET_ERROR: ${details.exceptionAsString()}\n${details.stack ?? ''}');
  };
  ui.PlatformDispatcher.instance.onError = (error, stack) {
    debugPrint('APP_ASYNC_ERROR: $error\n$stack');
    return true;
  };
  ErrorWidget.builder = (details) => Directionality(
    textDirection: TextDirection.rtl,
    child: ColoredBox(color: const Color(0xFF0B1020), child: Center(child: Padding(
      padding: const EdgeInsets.all(20), child: Text('خطا در نمایش این بخش\n${details.exceptionAsString()}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white)),
    ))),
  );
  final state = AppState();
  final analysis = AnalysisController(state);
  state.addListener(analysis.onStateChanged);
  analysis.restore();
  runApp(CryptoAnalystApp(state: state, analysis: analysis));
}

class CryptoAnalystApp extends StatelessWidget {
  const CryptoAnalystApp({super.key, required this.state, required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'AI Crypto Analyst',
    builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox.shrink()),
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF0B1020),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF28C8F5), brightness: Brightness.dark, surface: const Color(0xFF121C31)),
      useMaterial3: true,
      cardTheme: CardThemeData(color: const Color(0xFF121C31), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF0B1020), elevation: 0),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: const Color(0xFF0E1729), indicatorColor: const Color(0xFF153B5C),
        labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(fontSize: 10, fontWeight: states.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w500, color: states.contains(WidgetState.selected) ? const Color(0xFF28C8F5) : Colors.white60)),
      ),
    ),
    home: AppShell(state: state, analysis: analysis),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.state, required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  @override State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  void _go(int value) => setState(() => index = value);
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: IndexedStack(index: index, children: [
      DashboardScreen(state: widget.state, analysis: widget.analysis, onOpenAi: () => _go(2)),
      ChartScreen(state: widget.state, analysis: widget.analysis),
      AiAnalysisScreen(state: widget.state, analysis: widget.analysis),
      TechnicalOverviewScreen(state: widget.state, analysis: widget.analysis),
      SourcesOverviewScreen(onOpenAi: () => _go(2), onOpenChart: () => _go(1)),
      ReportsOverviewScreen(state: widget.state, analysis: widget.analysis, onOpenAi: () => _go(2)),
    ])),
    bottomNavigationBar: NavigationBar(
      height: 66,
      selectedIndex: index,
      onDestinationSelected: _go,
      destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard_rounded), label: 'داشبورد'),
        NavigationDestination(icon: Icon(Icons.candlestick_chart_outlined), selectedIcon: Icon(Icons.candlestick_chart), label: 'نمودار'),
        NavigationDestination(icon: Icon(Icons.psychology_alt_outlined), selectedIcon: Icon(Icons.psychology_alt), label: 'تحلیل AI'),
        NavigationDestination(icon: Icon(Icons.query_stats_outlined), selectedIcon: Icon(Icons.query_stats), label: 'تکنیکال'),
        NavigationDestination(icon: Icon(Icons.hub_outlined), selectedIcon: Icon(Icons.hub), label: 'منابع'),
        NavigationDestination(icon: Icon(Icons.history_outlined), selectedIcon: Icon(Icons.history), label: 'گزارش‌ها'),
      ],
    ),
  );
}
