# AI Crypto Analyst — Visual Design Reference

The approved visual reference is `design/APP-REFERENCE-MOCKUP-2026-11-20.png`.

## Visual language
- Deep navy / near-black canvas (`#0B1020`) with layered navy cards (`#121C31`).
- Neon cyan (`#28C8F5`) for chart/navigation emphasis; mint green (`#35D9A1`) for valid/positive states; purple (`#9B62F5`) for AI/source areas; red and amber only for bearish/warning states.
- Rounded cards, thin low-opacity borders, subtle glows, compact but readable labels, clear iconography, RTL-first Persian layout.
- Mobile-first information density: decision and most important context above the fold; detail stays accessible without crowding the dashboard.

## Page map
1. Dashboard — BUY/SELL/WAIT, model agreement, freshness, 1H/15M/5M structure, quick Technical and AI actions.
2. Chart — live candles, timeframe selector, and exclusive overlay source selector (Technical or AI); Chart Analyzer AI remains a separate visual-analysis flow.
3. AI Analysis — independent Gemini, OpenRouter and Groq results, model configuration, Smart Connectivity, altFINS context and structured reports.
4. Technical — independent technical-engine structure, buyer/seller strength and trade plan.
5. Sources — independent altFINS and Chart Analyzer AI validation paths; never fabricate a combined vote.
6. Reports — latest saved market snapshot and report timestamps. This build does not claim a multi-snapshot historical archive.

## Data integrity rules
- The mockup's prices, BUY label, confidence percentages, ratings and chart levels are illustrative only. They must never be treated as live market data.
- Missing provider fields remain unavailable; no cross-provider substitution.
- altFINS free-plan constraints remain explicit: no 5m data and no paid Trade Setup dependency.
- Chart Analyzer AI remains independent from the Technical Engine and AI model consensus.
- A provider/source is attributed by name and freshness; agreement is not the same as confidence.
