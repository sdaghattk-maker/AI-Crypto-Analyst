import test, { beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import worker, { ProviderCircuitBreaker, circuitRequest, resetProviderCircuitState } from '../worker.js';

const testCircuitObjects = new Map();
const testCircuitStores = new Map();
let testCircuitTail = Promise.resolve();
function testCircuitNamespace() {
  return {
    idFromName: key => key,
    get: id => {
      if (!testCircuitObjects.has(id)) {
        const values = testCircuitStores.get(id) || new Map();
        testCircuitStores.set(id, values);
        const storage = {
          transaction: async callback => {
            const run = testCircuitTail.then(() => callback({
              get: async key => values.get(key),
              put: async (key, value) => values.set(key, structuredClone(value)),
              delete: async key => values.delete(key)
            }));
            testCircuitTail = run.catch(() => {});
            return run;
          }
        };
        testCircuitObjects.set(id, new ProviderCircuitBreaker({storage}, {}));
      }
      const instance = testCircuitObjects.get(id);
      return {fetch: (url, options) => instance.fetch(new Request(url, options))};
    }
  };
}
beforeEach(() => {
  resetProviderCircuitState();
  testCircuitObjects.clear(); testCircuitStores.clear(); testCircuitTail = Promise.resolve();
});

test('Durable Object circuit network and response parsing are bounded by the caller deadline', async () => {
  const hangingFetch = {PROVIDER_CIRCUIT_BREAKER:{idFromName:key=>key,get:()=>({fetch:()=>new Promise(()=>{})})}};
  const started = Date.now();
  await assert.rejects(circuitRequest(hangingFetch,'acquire',{key:'gemini:auto'},{deadlineAt:Date.now()+25}),/CIRCUIT_STORE_TIMEOUT/);
  assert.ok(Date.now()-started < 250, 'circuit network operation should not outlive the request deadline');
  const hangingBody = {PROVIDER_CIRCUIT_BREAKER:{idFromName:key=>key,get:()=>({fetch:async()=>({ok:true,json:()=>new Promise(()=>{})})})}};
  await assert.rejects(circuitRequest(hangingBody,'acquire',{key:'groq:auto'},{deadlineAt:Date.now()+25}),/CIRCUIT_STORE_TIMEOUT/);
});

const makeHistory = (intervalSeconds, count=60, side='buy') => {
  const candles=Array.from({length:count},()=>({open:100,high:101,low:99,close:100}));
  if(intervalSeconds===900&&count>=60){
    if(side==='sell'){
      candles[57]={open:100,high:101,low:99,close:100.5};
      candles[58]={open:99.4,high:99.5,low:98.5,close:98.7};
      candles[59]={open:98.7,high:98.9,low:97.5,close:97.8};
    }else{
      candles[57]={open:100.5,high:101,low:99,close:100};
      candles[58]={open:100.6,high:102,low:100.6,close:101.6};
      candles[59]={open:101.6,high:103,low:101.2,close:102};
    }
  }
  return encodeCandles(intervalSeconds,candles);
};
const makeTrendCandles = (count=60, side='buy') => {
  const direction=side==='sell'?-1:1;
  return Array.from({length:count},(_,i)=>{
    const center=100+direction*(i-(count-1))*0.05;
    const high=center+0.5+(i%4===2?0.5:0);
    const low=center-0.5-(i%4===0?0.5:0);
    return {open:center-direction*0.03,high,low,close:center};
  });
};
const seedPriorSwingStructure = (candles, trend='bullish') => {
  const bullish = trend === 'bullish';
  const highs = bullish ? [[10,102],[30,103],[50,105]] : [[10,105],[30,104],[50,103]];
  const lows = bullish ? [[15,96],[35,97],[55,98]] : [[15,98],[35,97],[55,96]];
  for (const [index, high] of highs) candles[index] = {open:high-0.25,high,low:high-1.2,close:high-0.35};
  for (const [index, low] of lows) candles[index] = {open:low+0.25,high:low+1.2,low,close:low+0.35};
  return candles;
};
const makeTrendHistory = (intervalSeconds, count=60, side='buy') => {
  const candles=makeTrendCandles(count,side);
  if(intervalSeconds===900&&count>=60){
    if(side==='sell'){
      candles[57]={open:100,high:101,low:99,close:100.5};
      candles[58]={open:99.4,high:99.5,low:98.5,close:98.7};
      candles[59]={open:98.7,high:98.9,low:97.5,close:97.8};
    }else{
      candles[57]={open:100.5,high:101,low:99,close:100};
      candles[58]={open:100.6,high:102,low:100.6,close:101.6};
      candles[59]={open:101.6,high:103,low:101.2,close:102};
    }
  }
  return encodeCandles(intervalSeconds,candles);
};
const marketHistory = {format:'test delta OHLCV','1h':makeTrendHistory(3600),'15m':makeTrendHistory(900),'5m':makeTrendHistory(300)};
const validAnalysisSectionsV3 = Object.fromEntries([
  ['regime','رژیم بازار بر اساس شیب و دامنه کندل‌ها بررسی شد.'],
  ['structure','هم‌جهتی ساختار یک‌ساعته و پانزده‌دقیقه‌ای نیازمند تأیید است.'],
  ['liquidity','سطوح نقدینگی از سقف‌ها و کف‌های قابل مشاهده استخراج شد.'],
  ['poi','محدوده مورد علاقه از ناحیه ساختاری قابل مشاهده تعیین شد.'],
  ['premiumDiscount','موقعیت قیمت نسبت به دامنه معتبر بررسی شد.'],
  ['volumeMomentum','حجم و شتاب کندل‌ها از داده OHLCV ارزیابی شد.'],
  ['scenarios','سناریوی صعودی و نزولی با شروط فعال‌سازی جداگانه تعریف شد.'],
  ['execution','کیفیت ورود فقط پس از بسته‌شدن کندل تأییدی ارزیابی می‌شود.'],
  ['dataQuality','داده دفتر سفارش و نرخ تأمین مالی در ورودی وجود ندارد.']
].map(([key, finding]) => [key,{status:'AVAILABLE',findings:[finding]}]));
const validContractV3 = {
  contractVersion: 3,
  analysisSections: validAnalysisSectionsV3,
  timeframeAnalysis: {
    '1h': {trend:'BULLISH',structure:'BULLISH',structureEvent:'NONE',phase:'TRENDING',buyerStrength:65,sellerStrength:35,liquidity:'NONE',evidence:['کف بالاتر در ساختار مشاهده شد']},
    '15m': {trend:'BULLISH',structure:'BULLISH',structureEvent:'NONE',phase:'TRENDING',buyerStrength:58,sellerStrength:42,liquidity:'NONE',evidence:['کف‌های بالاتر در ساختار مشاهده شد']},
    '5m': {trend:'BULLISH',structure:'BULLISH',structureEvent:'NONE',phase:'TRENDING',buyerStrength:62,sellerStrength:38,liquidity:'NONE',evidence:['تأیید ساختار اجرایی دیده شد']}
  },
  evidence: [{timeframe:'5m',type:'OBSERVATION',event:'NO_CONFIRMED_EVENT',status:'NOT_CONFIRMED',explanation:'در پنجره بررسی‌شده رویداد ساختاری جدیدی تأیید نشد.'}],
  invalidation: 'بسته‌شدن کندل ۱۵ دقیقه زیر کف ساختاری سناریو را باطل می‌کند'
};
const input = {
  exchange: 'TEST', symbol: 'BTCUSDT', snapshotId: 'snapshot-test-001',
  referencePrice: 100, lastClosed5mClose: 100,
  technicalAnalysis: {signal: 'BUY'}, marketHistory,
  selectedProviders: ['gemini'], modelSelection: {gemini: 'gemini-3.8-flash'}
};
function encodeCandles(intervalSeconds, candles) {
  let previousClose = candles[0].open;
  let previousTime = 0;
  const timeStart = Math.floor(Math.floor(Date.now()/1000)/intervalSeconds)*intervalSeconds - intervalSeconds*candles.length;
  const rows = candles.map((candle,index)=>{
    const delta=value=>Math.round((value/previousClose-1)*1000000);
    const row=[index===0?0:intervalSeconds,delta(candle.open),delta(candle.high),delta(candle.low),delta(candle.close),100];
    previousClose=candle.close; previousTime+=index===0?0:intervalSeconds;
    return row;
  });
  return {timeStart,intervalSeconds,historyStartPrice:candles[0].open,baseVolumeMedian:10,rows};
}
function env() {
  return {
    GEMINI_API_KEY: 'test-gemini', OPENROUTER_API_KEY: 'test-openrouter', GROQ_API_KEY: 'test-groq',
    GEMINI_MODEL: 'gemini-3.8-flash', GEMINI_MODELS: 'gemini-3.8-flash,gemini-3.7-flash',
    OPENROUTER_MODEL: 'qwen/qwen3.8-27b', OPENROUTER_MODELS: 'qwen/qwen3.8-27b,openai/gpt-oss-120b',
    GROQ_MODEL: 'qwen/qwen3.8-27b', GROQ_MODELS: 'qwen/qwen3.8-27b,openai/gpt-oss-120b',
    GATEWAY_TOKEN: 'test-token', RATE_LIMITER: {limit: async () => ({success: true})},
    PROVIDER_CIRCUIT_BREAKER: testCircuitNamespace()
  };
}
function validBuyOverlays() { return [
  {type:'zone',kind:'Bullish OB',price:null,low:99,high:100.5,timeframe:'15m',direction:'bullish',status:'ACTIVE',timestamp:marketHistory['15m'].timeStart+57*900,evidence:'کندل نزولی مبنا و جابه‌جایی صعودی پس از آن ثبت شده است'},
  {type:'zone',kind:'Bullish FVG',price:null,low:100.1,high:100.3,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'Entry',price:100.5,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'SL',price:98.5,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'TP1',price:102.5,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'TP2',price:103.5,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'TP3',price:104.5,low:null,high:null,timeframe:'5m',direction:'bullish'}
]; }
function geminiResponse(text = JSON.stringify({...validContractV3,bias:'BUY',summary:'ساختار بازار متمایل به صعود است و ورود پس از تأیید محدوده انجام می‌شود.',observations:['کف‌های بالاتر در تایم‌فریم اجرایی دیده می‌شود.'],risks:['شکست حمایت نزدیک می‌تواند سناریو را باطل کند.'],confidence:75,analyticalWeights:{trend:30,marketStructure:25,liquidity:20,entryConfirmation:15,riskReward:10},factorScores:{trend:80,marketStructure:75,liquidity:65,entryConfirmation:85,riskReward:70},overlays:validBuyOverlays()})) {
  return new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text}]}}]}), {status:200});
}
function openRouterResponse() {
  return new Response(JSON.stringify({model:'test/free-model',usage:{prompt_tokens:100,completion_tokens:50},choices:[{finish_reason:'stop',message:{content:JSON.stringify({...validContractV3,bias:'BUY',summary:'ساختار بازار نشانه‌های صعودی دارد.',observations:['حمایت کوتاه‌مدت حفظ شده است.'],risks:[],confidence:70,analyticalWeights:{trend:25,marketStructure:25,liquidity:20,entryConfirmation:20,riskReward:10},factorScores:{trend:75,marketStructure:80,liquidity:70,entryConfirmation:75,riskReward:65},overlays:validBuyOverlays()})}}]}), {status:200});
}
async function call(path, body, mockFetch, headers={}, environment=env()) {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (url, options) => {
    const target = String(url);
    if (environment.__catalogFailure && (target.includes('/v1beta/models?') || target.includes('/openai/v1/models') || target.includes('/api/v1/models'))) {
      return new Response(JSON.stringify({error:{message:'catalog temporarily unavailable'}}),{status:503});
    }
    if (path !== '/models' && target.includes('generativelanguage.googleapis.com/v1beta/models') && new URL(target).pathname === '/v1beta/models')
      return new Response(JSON.stringify({models:[{name:'models/gemini-3.8-flash',supportedGenerationMethods:['generateContent'],inputTokenLimit:100000,outputTokenLimit:8192},{name:'models/gemini-3.7-flash',supportedGenerationMethods:['generateContent'],inputTokenLimit:100000,outputTokenLimit:8192},{name:'models/gemini-3.6-flash',supportedGenerationMethods:['generateContent'],inputTokenLimit:100000,outputTokenLimit:8192},{name:'models/gemini-3.5-flash',supportedGenerationMethods:['generateContent'],inputTokenLimit:100000,outputTokenLimit:8192}]}),{status:200});
    if (path !== '/models' && target.includes('api.groq.com/openai/v1/models') && new URL(target).pathname === '/openai/v1/models')
      return new Response(JSON.stringify({data:[{id:'openai/gpt-oss-120b',active:true,context_window:131072,max_completion_tokens:8192},{id:'qwen/qwen3.8-27b',active:true,context_window:131072,max_completion_tokens:8192}]}),{status:200});
    if (path !== '/models' && target.includes('openrouter.ai/api/v1/models/user') && new URL(target).pathname === '/api/v1/models/user')
      return new Response(JSON.stringify({data:[{id:'qwen/qwen3.8-27b:free',architecture:{input_modalities:['text'],output_modalities:['text']},context_length:262144,pricing:{prompt:'0',completion:'0'}}]}),{status:200});
    return mockFetch(url, options);
  };
  try {
    const request = new Request(`https://gateway.test${path}`, {
      method: path === '/health' || path === '/models' || path === '/altfins/quota' ? 'GET' : 'POST',
      headers: {'Content-Type':'application/json', ...headers},
      body: path === '/health' || path === '/models' || path === '/altfins/quota' ? undefined : JSON.stringify(body ?? input)
    });
    const response = await worker.fetch(request, environment);
    return {status:response.status, body:await response.json()};
  } finally { globalThis.fetch = originalFetch; }
}





test('/health reports the exact automatic-routing build and ranking version', async () => {
  const result=await call('/health',null,async()=>{throw new Error('health must not call upstream');});
  assert.equal(result.status,200);
  assert.equal(result.body.buildId,'V6.3.3.8-INTEGRATION-EVIDENCE-HARDENING-2026-11-23');
  assert.equal(result.body.modelRankingVersion,'2026-11-22.4-auto-selection-4-candidates');
});

test('/providers/health fails closed when the Durable Object binding is missing', async () => {
  const environment = env();
  delete environment.PROVIDER_CIRCUIT_BREAKER;
  let upstreamCalls = 0;
  const result = await call('/providers/health', {selectedProviders:['gemini'],modelSelection:{gemini:'gemini-3.8-flash'}}, async () => {
    upstreamCalls++;
    return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'OK'}]}}]}),{status:200});
  }, {}, environment);
  assert.equal(result.status, 200);
  assert.equal(result.body.providers.gemini.routable, false);
  assert.equal(result.body.providers.gemini.errorCode, 'CIRCUIT_STATE_UNAVAILABLE');
  assert.equal(result.body.providers.gemini.retryable, false);
  assert.equal(upstreamCalls, 0, 'no provider inference is allowed without shared circuit state');
});

test('/providers/health performs a tiny real text inference without a separate API-key test', async () => {
  let calls=0;
  const result = await call('/providers/health', {selectedProviders:['gemini'],modelSelection:{gemini:'gemini-3.8-flash'}}, async (url,options) => {
    calls++;
    assert.match(String(url),/gemini-3\.8-flash:generateContent/);
    const payload=JSON.parse(options.body);
    assert.equal(payload.generationConfig.maxOutputTokens,32);
    assert.equal(payload.contents[0].parts[0].text,'Reply with exactly OK.');
    assert.equal(options.headers['x-goog-api-key'],'test-gemini');
    return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'OK'}]}}]}),{status:200});
  });
  assert.equal(result.status,200);
  assert.equal(calls,1);
  assert.equal(result.body.providers.gemini.status,'READY');
  assert.equal(result.body.providers.gemini.routable,true);
  assert.equal(result.body.providers.gemini.selectedModel,'gemini-3.8-flash');
  assert.equal(result.body.policy,'text-only-trading-analysis');
});


test('provider health returns the exact probed candidate sequence for the subsequent analysis request', async () => {
  const result = await call('/providers/health', {selectedProviders:['gemini'],modelSelection:{gemini:'gemini-retired'}}, async () =>
    new Response(JSON.stringify({candidates:[{content:{parts:[{text:'OK'}]}}]}),{status:200}));
  assert.equal(result.body.providers.gemini.routable,true);
  assert.equal(result.body.providers.gemini.selectedModel,'gemini-3.8-flash');
  assert.deepEqual(result.body.providers.gemini.candidates,['gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash','gemini-3.5-flash']);
  assert.equal(result.body.providers.gemini.fallbackModel,'gemini-3.7-flash');
  assert.equal(result.body.providers.gemini.candidateStatus.additionalFallbacks,2);
  assert.equal(result.body.providers.gemini.candidateStatus.primary,'PROBED');
  assert.equal(result.body.providers.gemini.candidateStatus.fallback,'CATALOG_ELIGIBLE_UNPROBED');
  assert.equal(result.body.providers.gemini.attempts.length,1,'only the primary model is probed before full analysis');
});



test('provider health automatically probes the next live candidate when earlier models fail', async () => {
  const attempted=[];
  const result=await call('/providers/health',{selectedProviders:['gemini'],modelSelection:{gemini:'gemini-retired'}},async url=>{
    const value=String(url); attempted.push(value);
    if(value.includes('gemini-3.8-flash') || value.includes('gemini-3.7-flash'))
      return new Response(JSON.stringify({error:{message:'model unavailable'}}),{status:404});
    return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'OK'}]}}]}),{status:200});
  });
  assert.equal(result.body.providers.gemini.routable,true);
  assert.match(result.body.providers.gemini.selectedModel,/gemini-3.6-flash/);
  assert.equal(attempted.length,3);
  assert.deepEqual(result.body.providers.gemini.candidates,['gemini-3.6-flash','gemini-3.5-flash']);
});

test('/providers/health fails closed when the live model catalog is unavailable', async () => {
  const environment = env();
  environment.__catalogFailure = true;
  let inferenceCalls = 0;
  const result = await call('/providers/health', {selectedProviders:['gemini'],modelSelection:{gemini:'gemini-3.8-flash'}}, async () => {
    inferenceCalls++;
    return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'OK'}]}}]}),{status:200});
  }, {}, environment);
  assert.equal(result.body.providers.gemini.routable,false);
  assert.equal(result.body.providers.gemini.errorCode,'MODEL_CATALOG_UNAVAILABLE');
  assert.equal(result.body.providers.gemini.catalogSource,'catalog_unavailable');
  assert.equal(inferenceCalls,0,'must not probe a stale curated model after catalog failure');
});

test('/providers/health distinguishes explicit provider region restrictions from generic access denial', async () => {
  const region = await call('/providers/health', {selectedProviders:['groq'],modelSelection:{groq:'qwen/qwen3.8-27b'}}, async url => {
    if (String(url).includes('/models')) return new Response(JSON.stringify({data:[{id:'qwen/qwen3.8-27b',active:true,context_window:32768}]}),{status:200});
    return new Response(JSON.stringify({error:{message:'This service is not available in your region'}}),{status:403});
  });
  assert.equal(region.body.providers.groq.errorCode,'REGION_RESTRICTED');
  const denied = await call('/providers/health', {selectedProviders:['groq'],modelSelection:{groq:'qwen/qwen3.8-27b'},forceProbe:true}, async url => {
    if (String(url).includes('/models')) return new Response(JSON.stringify({data:[{id:'qwen/qwen3.8-27b',active:true,context_window:32768}]}),{status:200});
    return new Response(JSON.stringify({error:{message:'Forbidden'}}),{status:403});
  });
  assert.equal(denied.body.providers.groq.errorCode,'ACCESS_DENIED');
});

test('/providers/health marks rate-limited providers non-routable and reports exact error class', async () => {
  const result = await call('/providers/health', {selectedProviders:['groq'],modelSelection:{groq:'qwen/qwen3.8-27b'}}, async () =>
    new Response(JSON.stringify({error:{message:'Rate limit exceeded'}}),{status:429}));
  assert.equal(result.status,200);
  assert.equal(result.body.providers.groq.status,'DEGRADED');
  assert.equal(result.body.providers.groq.errorCode,'RATE_LIMITED');
  assert.equal(result.body.providers.groq.routable,false);
});

test('/providers/health opens a temporary circuit after repeated upstream failure', async () => {
  const first = await call('/providers/health', {selectedProviders:['groq'],modelSelection:{groq:'openai/gpt-oss-20b'}}, async () =>
    new Response(JSON.stringify({error:{message:'Rate limit exceeded'}}),{status:429}));
  assert.equal(first.body.providers.groq.errorCode,'RATE_LIMITED');
  let upstreamCalls=0;
  const second = await call('/providers/health', {selectedProviders:['groq'],modelSelection:{groq:'openai/gpt-oss-20b'}}, async () => { upstreamCalls++; throw new Error('circuit should be open'); });
  assert.equal(second.body.providers.groq.errorCode,'CIRCUIT_OPEN');
  assert.equal(second.body.providers.groq.routable,false);
  assert.equal(upstreamCalls,0);
});




test('/providers/health forceProbe performs one controlled live diagnostic during an open circuit and returns the upstream cause', async () => {
  const first = await call('/providers/health', {selectedProviders:['groq'],modelSelection:{groq:'openai/gpt-oss-20b'}}, async () =>
    new Response(JSON.stringify({error:{message:'Rate limit exceeded'}}),{status:429}));
  assert.equal(first.body.providers.groq.errorCode,'RATE_LIMITED');
  let upstreamCalls = 0;
  const diagnostic = await call('/providers/health', {selectedProviders:['groq'],modelSelection:{groq:'openai/gpt-oss-20b'},forceProbe:true}, async () => {
    upstreamCalls++;
    return new Response(JSON.stringify({error:{message:'Invalid API key'}}),{status:401});
  });
  assert.equal(upstreamCalls,2,'manual diagnostics may test the two bounded live candidates during cooldown');
  assert.equal(diagnostic.body.providers.groq.errorCode,'AUTHENTICATION_FAILED');
  assert.equal(diagnostic.body.providers.groq.attempts[0].httpStatus,401);
});

test('/providers/health uses the shared Durable Object namespace instead of isolate-local state', async () => {
  const objects = new Map();
  const stores = new Map();
  const namespace = {
    idFromName: key => key,
    get: id => {
      if (!objects.has(id)) {
        const values = stores.get(id) || new Map();
        stores.set(id,values);
        const storage = {
          transaction: async callback => callback({
            get: async key => values.get(key),
            put: async (key,value) => values.set(key,structuredClone(value)),
            delete: async key => values.delete(key)
          })
        };
        objects.set(id,new ProviderCircuitBreaker({storage},{}));
      }
      const instance=objects.get(id);
      return {fetch:(url,options)=>instance.fetch(new Request(url,options))};
    }
  };
  const environment=env();
  environment.PROVIDER_CIRCUIT_BREAKER=namespace;
  let upstreamCalls=0;
  const first=await call('/providers/health',{selectedProviders:['groq'],modelSelection:{groq:'openai/gpt-oss-120b'}},async()=>{
    upstreamCalls++;
    return new Response(JSON.stringify({error:{message:'Rate limit exceeded'}}),{status:429});
  },{},environment);
  assert.equal(first.body.providers.groq.errorCode,'RATE_LIMITED');
  const second=await call('/providers/health',{selectedProviders:['groq'],modelSelection:{groq:'openai/gpt-oss-120b'}},async()=>{
    upstreamCalls++;
    throw new Error('Durable circuit should prevent another upstream call');
  },{},environment);
  assert.equal(second.body.providers.groq.errorCode,'CIRCUIT_OPEN');
  assert.equal(upstreamCalls,1,'a provider-wide rate limit stops health probing after the first candidate');
  assert.equal(stores.size,1);
});

test('Durable Object circuit state persists across object instances and serializes half-open probes', async () => {
  const values = new Map();
  let transactionTail = Promise.resolve();
  const storage = {
    get: async key => values.get(key),
    put: async (key,value) => values.set(key,structuredClone(value)),
    delete: async key => values.delete(key),
    transaction: async callback => {
      const run = transactionTail.then(() => callback({
        get: async key => values.get(key),
        put: async (key,value) => values.set(key,structuredClone(value)),
        delete: async key => values.delete(key)
      }));
      transactionTail = run.catch(() => {});
      return run;
    }
  };
  const request = (instance,operation,body) => instance.fetch(new Request(`https://do.test/${operation}`,{
    method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)
  }));
  const firstInstance = new ProviderCircuitBreaker({storage},{});
  const failure = await request(firstInstance,'failure',{key:'groq:model-x',now:1000,baseCooldownMs:30000,maxCooldownMs:300000,errorCode:'RATE_LIMITED'});
  assert.equal(failure.status,200);
  const failedState = await failure.json();
  assert.equal(failedState.failures,1);
  const restartedInstance = new ProviderCircuitBreaker({storage},{});
  const competingInstance = new ProviderCircuitBreaker({storage},{});
  const blocked = await request(restartedInstance,'acquire',{key:'groq:model-x',now:2000,leaseMs:25000});
  assert.equal((await blocked.json()).allowed,false,'state survives construction of a new DO instance');
  const forcedProbe = await request(restartedInstance,'acquire',{key:'groq:model-x',now:3000,leaseMs:25000,forceProbe:true});
  const forcedResult = await forcedProbe.json();
  assert.equal(forcedResult.allowed,true,'manual health diagnostics can probe a provider during its analysis cooldown');
  assert.equal(forcedResult.forced,true);
  const competingForcedProbe = await request(competingInstance,'acquire',{key:'groq:model-x',now:4000,leaseMs:25000,forceProbe:true});
  assert.equal((await competingForcedProbe.json()).halfOpenInProgress,true,'forced probes still honor the shared single-flight lease');
  const [halfOpen, competing] = await Promise.all([
    request(restartedInstance,'acquire',{key:'groq:model-x',now:32000,leaseMs:25000}),
    request(competingInstance,'acquire',{key:'groq:model-x',now:32000,leaseMs:25000})
  ]);
  const raceResults = await Promise.all([halfOpen.json(),competing.json()]);
  assert.equal(raceResults.filter(x=>x.allowed).length,1,'exactly one concurrent half-open probe may acquire the lease');
  assert.equal(raceResults.filter(x=>x.halfOpenInProgress).length,1);
  const success = await request(competingInstance,'success',{key:'groq:model-x'});
  assert.equal((await success.json()).cleared,true);
  const afterRecovery = await request(firstInstance,'acquire',{key:'groq:model-x',now:40000,leaseMs:25000});
  assert.equal((await afterRecovery.json()).allowed,true,'success clears the durable breaker');
});

test('/providers/health independently reports an unavailable model without blocking other providers', async () => {
  const result = await call('/providers/health', {selectedProviders:['gemini','groq'],modelSelection:{gemini:'gemini-3.8-flash',groq:'openai/gpt-oss-120b'}}, async (url) => {
    if(String(url).includes('generativelanguage.googleapis.com')) return new Response(JSON.stringify({candidates:[{content:{parts:[{text:'OK'}]}}]}),{status:200});
    return new Response(JSON.stringify({error:{message:'model not found'}}),{status:404});
  });
  assert.equal(result.body.providers.gemini.routable,true);
  assert.equal(result.body.providers.groQ,undefined);
  assert.equal(result.body.providers.groq.routable,false);
  assert.equal(result.body.ok,true);
});

test('retired Claude route is not exposed', async () => {
  const response = await call('/shadow/claude', input, async () => { throw new Error('must not call providers'); });
  assert.equal(response.status, 404);
  assert.equal(response.body.error, 'Not found');
});

test('one selected model is enough to return and display an independent analysis; other providers are not called', async () => {
  let calls = 0;
  const result = await call('/analyze', input, async (url, options) => {
    calls++;
    assert.match(String(url), /gemini-3.8-flash/);
    const sent = JSON.parse(options.body);
    const prompt = sent.contents?.[0]?.parts?.[0]?.text || '';
    assert.match(prompt, /historyStartPrice/);
    assert.match(prompt, /set both buyerStrength and sellerStrength to JSON null/);
    assert.doesNotMatch(prompt, /\"basePrice\"/);
    assert.equal(sent.generationConfig.responseMimeType, undefined);
    assert.equal(sent.generationConfig.responseJsonSchema, undefined);
    return geminiResponse();
  });
  assert.equal(result.status, 200);
  assert.equal(result.body.ok, true);
  assert.equal(result.body.providers.gemini.status, 'ok');
  assert.equal(result.body.providers.gemini.providerModel, 'gemini-3.8-flash');
  assert.match(result.body.providers.gemini.rawProviderResponse, /candidates/);
  assert.equal(result.body.providers.gemini.rawProviderResponseTruncated, false);
  assert.equal(result.body.providers.gemini.weightsProvided, true);
  assert.equal(Object.values(result.body.providers.gemini.analyticalWeights).reduce((a,b)=>a+b,0),100);
  assert.equal(result.body.providers.openrouter.status, 'not_selected');
  assert.equal(result.body.providers.groq.status, 'not_selected');
  assert.equal(result.body.decision, 'WAIT');
  assert.equal(result.body.analysisMode, 'SINGLE_PROVIDER_INDEPENDENT');
  assert.ok(result.body.consensus.conflicts.some(x => x.includes('اجماع')) || result.body.consensus.conflicts.some(x => x.includes('یک مدل')));
  assert.equal(result.body.snapshotId, 'snapshot-test-001');
  assert.equal(calls, 1);
});


test('Gemini output format is not forced and provider-native JSON remains locally normalized', async () => {
  let calls=0;
  const result=await call('/analyze',input,async (_url,options)=>{
    calls++;
    const sent=JSON.parse(options.body);
    if(calls===1){assert.equal(sent.generationConfig.responseJsonSchema,undefined);return geminiResponse();}
    assert.equal(sent.generationConfig.responseJsonSchema,undefined);
    assert.equal(sent.generationConfig.responseMimeType,undefined);
    return geminiResponse();
  });
  assert.equal(calls,1);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.contractStatus,'VALID');
});

test('absolute price hallucinations downgrade the trade plan but preserve independently evidenced market direction', async () => {
  const hallucinated = JSON.stringify({...validContractV3,bias:'BUY',summary:'قیمت بازار به ۸۳٬۰۰۰ دلار رسیده و روند صعودی است.',observations:['ساختار صعودی مشاهده می‌شود.'],risks:[],confidence:80,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:80,marketStructure:80,liquidity:70,entryConfirmation:75,riskReward:80},overlays:validBuyOverlays()});
  const withAnchor = {...input,referencePrice:100.2,lastClosed5mClose:100};
  const result = await call('/analyze', withAnchor, async () => geminiResponse(hallucinated));
  const ai = result.body.providers.gemini;
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.contractStatus,'VALID');
  assert.equal(ai.directionalVoteEligible,true, 'validated 1h/15m structure remains an independent market-direction vote');
  assert.equal(ai.tradePlanEligible,false);
  assert.equal(ai.weightsProvided,true);
  assert.ok(!ai.summary.includes('۸۳٬۰۰۰'));
  assert.ok(ai.risks.some(x=>x.includes('عدد قیمتی خارج')));
});

test('narrative market prices must agree with the live reference anchor, not merely old history extremes', async () => {
  const anchored = {...input, referencePrice:100, lastClosed5mClose:100};
  const response = {...validContractV3,bias:'WAIT',summary:'قیمت فعلی بازار حدود ۸۳۰۴۰ دلار است و ساختار نیازمند انتظار است.',observations:[],risks:[],confidence:55,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:55,marketStructure:55,liquidity:55,entryConfirmation:55,riskReward:55},overlays:[]};
  const result = await call('/analyze',anchored,async()=>geminiResponse(JSON.stringify(response)));
  const ai = result.body.providers.gemini;
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.contractStatus,'VALID');
  assert.equal(ai.directionalVoteEligible,false);
  assert.equal(ai.weightsProvided,true);
  assert.match(ai.risks.join(' '),/عدد قیمتی خارج از/);
  assert.doesNotMatch(ai.summary,/۸۳۰۴۰/);
});

test('directional AI trade plans must agree with 5m trend and cannot ignore fully opposing 1h/15m structure', async () => {
  const fiveMinuteConflict = {
    ...validContractV3, bias:'BUY', summary:'سناریوی خرید با وجود فشار نزولی 5M پیشنهاد شده است.',
    observations:['روند اجرایی هنوز نزولی است.'], risks:[], confidence:75,
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'5m':{...validContractV3.timeframeAnalysis['5m'],trend:'BEARISH'}},
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:75,marketStructure:75,liquidity:75,entryConfirmation:75,riskReward:75},
    overlays:validBuyOverlays(),
  };
  const fiveMinuteResult=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(fiveMinuteConflict)));
  assert.equal(fiveMinuteResult.body.providers.gemini.marketBias,'BUY');
  assert.equal(fiveMinuteResult.body.providers.gemini.bias,'WAIT');
  assert.equal(fiveMinuteResult.body.providers.gemini.directionalVoteEligible,true, 'valid 1h/15m market direction remains a market vote even when 5m execution is not aligned');
  assert.equal(fiveMinuteResult.body.providers.gemini.tradePlanEligible,false);
  assert.ok(fiveMinuteResult.body.providers.gemini.risks.some(x=>x.includes('روند 5M')));

  const higherTimeframeConflict = {
    ...validContractV3, bias:'BUY', summary:'سناریوی خرید خلاف جهت هم‌زمان 1H و 15M پیشنهاد شده است.',
    observations:['هر دو تایم‌فریم بالاتر نزولی هستند.'], risks:[], confidence:75,
    timeframeAnalysis:{
      ...validContractV3.timeframeAnalysis,
      '1h':{...validContractV3.timeframeAnalysis['1h'],trend:'BEARISH'},
      '15m':{...validContractV3.timeframeAnalysis['15m'],trend:'BEARISH'},
    },
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:75,marketStructure:75,liquidity:75,entryConfirmation:75,riskReward:75},
    overlays:validBuyOverlays(),
  };
  const higherResult=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(higherTimeframeConflict)));
  assert.equal(higherResult.body.providers.gemini.marketBias,'BUY');
  assert.equal(higherResult.body.providers.gemini.bias,'WAIT');
  assert.equal(higherResult.body.providers.gemini.directionalVoteEligible,false);
  assert.ok(higherResult.body.providers.gemini.risks.some(x=>x.includes('روند 5M')));
});

test('confirmed BOS evidence is accepted only when its exact candle closes beyond a prior confirmed swing', async () => {
  const candles=seedPriorSwingStructure(Array.from({length:60},()=>({open:100,high:101,low:99,close:100})),'bullish');
  candles[59]={open:104.5,high:106.5,low:104.4,close:106};
  const verified=structuredClone(input);
  verified.marketHistory['5m']=encodeCandles(300,candles);
  verified.lastClosed5mClose=106; verified.referencePrice=106;
  const eventTime=verified.marketHistory['5m'].timeStart+59*300;
  const response={...validContractV3,bias:'WAIT',summary:'شکست سقف ساختاری در کندل بسته‌شده ثبت شد.',observations:[],risks:[],confidence:45,
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'5m':{...validContractV3.timeframeAnalysis['5m'],structure:'BULLISH',structureEvent:'BOS_BULLISH',evidence:['بسته‌شدن کندل بالای سقف پیوت قبلی مشاهده شد.']}},
    evidence:[{timeframe:'5m',type:'STRUCTURE',event:'BOS_BULLISH',status:'CONFIRMED',explanation:'کندل بسته‌شده بالای سقف پیوت قبلی بسته شد.',candleTime:eventTime,price:106,referenceLevel:105}],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:45,marketStructure:45,liquidity:45,entryConfirmation:45,riskReward:45},overlays:[]};
  const result=await call('/analyze',verified,async()=>geminiResponse(JSON.stringify(response)));
  assert.equal(result.status,200);
  assert.equal(result.body.providers.gemini.evidenceValidation.findings.find(x=>x.timeframe==='5m' && x.event==='BOS_BULLISH').status,'VALIDATED');
});

test('CHOCH and MSS claims require opposing-swing breaks and displacement evidence', async () => {
  const mssCandles=seedPriorSwingStructure(Array.from({length:60},()=>({open:100,high:101,low:99,close:100})),'bearish');
  mssCandles[59]={open:103.5,high:106.5,low:103.4,close:106};
  const mssInput=structuredClone(input);
  mssInput.marketHistory['5m']=encodeCandles(300,mssCandles);mssInput.lastClosed5mClose=106;mssInput.referencePrice=106;
  const mssTime=mssInput.marketHistory['5m'].timeStart+59*300;
  const mssResponse={...validContractV3,bias:'WAIT',summary:'جابجایی ساختاری با بدنه قدرتمند کندل تأیید شد.',observations:[],risks:[],confidence:40,
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'5m':{...validContractV3.timeframeAnalysis['5m'],structure:'BULLISH',structureEvent:'MSS_BULLISH'}},
    evidence:[{timeframe:'5m',type:'STRUCTURE',event:'MSS_BULLISH',status:'CONFIRMED',explanation:'کندل جابه‌جایی بالای سقف پیوت بسته شد.',candleTime:mssTime,price:106,referenceLevel:103}],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:40,marketStructure:40,liquidity:40,entryConfirmation:40,riskReward:40},overlays:[]};
  const mss=await call('/analyze',mssInput,async()=>geminiResponse(JSON.stringify(mssResponse)));
  assert.equal(mss.body.providers.gemini.evidenceStatus,'VALIDATED');

  const chochCandles=seedPriorSwingStructure(Array.from({length:60},()=>({open:100,high:101,low:99,close:100})),'bearish');
  chochCandles[59]={open:102.5,high:106.5,low:102.4,close:104};
  const chochInput=structuredClone(input);
  chochInput.marketHistory['5m']=encodeCandles(300,chochCandles);chochInput.lastClosed5mClose=104;chochInput.referencePrice=104;
  const chochTime=chochInput.marketHistory['5m'].timeStart+59*300;
  const chochResponse={...validContractV3,bias:'WAIT',summary:'تغییر کاراکتر پس از روند نزولی و عبور از سقف محافظت‌شده ثبت شد.',observations:[],risks:[],confidence:40,
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'5m':{...validContractV3.timeframeAnalysis['5m'],structure:'BULLISH',structureEvent:'CHOCH_BULLISH'}},
    evidence:[{timeframe:'5m',type:'STRUCTURE',event:'CHOCH_BULLISH',status:'CONFIRMED',explanation:'پس از توالی نزولی، کندل بالای سقف پیوت بسته شد.',candleTime:chochTime,price:104,referenceLevel:103}],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:40,marketStructure:40,liquidity:40,entryConfirmation:40,riskReward:40},overlays:[]};
  const choch=await call('/analyze',chochInput,async()=>geminiResponse(JSON.stringify(chochResponse)));
  assert.equal(choch.body.providers.gemini.evidenceStatus,'VALIDATED');
});


test('BOS is rejected when its break direction opposes the independently reconstructed prior swing structure', async () => {
  const candles=seedPriorSwingStructure(Array.from({length:60},()=>({open:100,high:101,low:99,close:100})),'bearish');
  candles[59]={open:102.5,high:106,low:102.4,close:104};
  const bad=structuredClone(input);
  bad.marketHistory['5m']=encodeCandles(300,candles); bad.lastClosed5mClose=104; bad.referencePrice=104;
  const eventTime=bad.marketHistory['5m'].timeStart+59*300;
  const response={...validContractV3,bias:'WAIT',summary:'شکست صعودی خلاف ساختار قبلی گزارش شد.',observations:[],risks:[],confidence:40,
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'5m':{...validContractV3.timeframeAnalysis['5m'],structure:'BULLISH',structureEvent:'BOS_BULLISH'}},
    evidence:[{timeframe:'5m',type:'STRUCTURE',event:'BOS_BULLISH',status:'CONFIRMED',explanation:'شکست صعودی در کندل بسته‌شده گزارش شد.',candleTime:eventTime,price:104,referenceLevel:103}],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:40,marketStructure:40,liquidity:40,entryConfirmation:40,riskReward:40},overlays:[]};
  const result=await call('/analyze',bad,async()=>geminiResponse(JSON.stringify(response)));
  assert.equal(result.body.providers.gemini.evidenceValidation.findings.find(x=>x.timeframe==='5m' && x.event==='BOS_BULLISH').status,'INVALID');
  assert.match(result.body.providers.gemini.evidenceValidation.findings.find(x=>x.timeframe==='5m' && x.event==='BOS_BULLISH').reason,/BOS/);
});


test('bearish BOS requires a descending prior swing structure and the latest protected low', async () => {
  const candles=seedPriorSwingStructure(Array.from({length:60},()=>({open:100,high:101,low:99,close:100})),'bearish');
  candles[59]={open:97,high:97.2,low:94.5,close:95};
  const bearishInput=structuredClone(input);
  bearishInput.marketHistory['5m']=encodeCandles(300,candles); bearishInput.lastClosed5mClose=95; bearishInput.referencePrice=95;
  const eventTime=bearishInput.marketHistory['5m'].timeStart+59*300;
  const response={...validContractV3,bias:'WAIT',summary:'شکست نزولی پس از ساختار نزولی قبلی ثبت شد.',observations:[],risks:[],confidence:40,
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'5m':{...validContractV3.timeframeAnalysis['5m'],trend:'BEARISH',structure:'BEARISH',structureEvent:'BOS_BEARISH'}},
    evidence:[{timeframe:'5m',type:'STRUCTURE',event:'BOS_BEARISH',status:'CONFIRMED',explanation:'کندل بسته‌شده زیر کف محافظت‌شده قرار گرفت.',candleTime:eventTime,price:95,referenceLevel:96}],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:40,marketStructure:40,liquidity:40,entryConfirmation:40,riskReward:40},overlays:[]};
  const result=await call('/analyze',bearishInput,async()=>geminiResponse(JSON.stringify(response)));
  const finding=result.body.providers.gemini.evidenceValidation.findings.find(x=>x.timeframe==='5m' && x.event==='BOS_BEARISH');
  assert.equal(finding.status,'VALIDATED');
});

test('a confirmed structure event that contradicts the timeframe event is rejected', async () => {
  const candles=Array.from({length:60},()=>({open:100,high:101,low:99,close:100}));
  candles[54]={open:104,high:105,low:103,close:104.5};
  candles[59]={open:104.5,high:106.5,low:104.4,close:106};
  const bad=structuredClone(input);
  bad.marketHistory['5m']=encodeCandles(300,candles);bad.lastClosed5mClose=106;bad.referencePrice=106;
  const eventTime=bad.marketHistory['5m'].timeStart+59*300;
  const response={...validContractV3,bias:'WAIT',summary:'شواهد متناقض ساختاری دریافت شده است.',observations:[],risks:[],confidence:40,
    evidence:[{timeframe:'5m',type:'STRUCTURE',event:'BOS_BULLISH',status:'CONFIRMED',explanation:'شکست سقف ساختاری ثبت شده است.',candleTime:eventTime,price:106,referenceLevel:105}],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:40,marketStructure:40,liquidity:40,entryConfirmation:40,riskReward:40},overlays:[]};
  const result=await call('/analyze',bad,async()=>geminiResponse(JSON.stringify(response)));
  assert.equal(result.body.providers.gemini.evidenceStatus,'INVALID');
  assert.ok(result.body.providers.gemini.evidenceValidation.findings.some(x=>x.reason?.includes('تعارض')));
});

test('BUY-side liquidity sweep requires a prior pool, wick through the level and close reclaim', async () => {
  const candles=Array.from({length:60},()=>({open:100,high:101,low:99,close:100}));
  candles[59]={open:100.4,high:102,low:99.5,close:100.5};
  const swept=structuredClone(input);
  swept.marketHistory['5m']=encodeCandles(300,candles);swept.lastClosed5mClose=100.5;swept.referencePrice=100.5;
  const candleTime=swept.marketHistory['5m'].timeStart+59*300;
  const response={...validContractV3,bias:'WAIT',summary:'قیمت بالای استخر نقدینگی خرید نفوذ کرد و زیر آن بسته شد.',observations:[],risks:[],confidence:45,
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'5m':{...validContractV3.timeframeAnalysis['5m'],liquidity:'BUY_SIDE_SWEEP'}},
    evidence:[{timeframe:'5m',type:'LIQUIDITY_SWEEP',event:'BUY_SIDE_SWEEP',status:'CONFIRMED',explanation:'سقف قبلی جمع‌آوری شد و کندل دوباره زیر سطح بسته شد.',candleTime,price:102,referenceLevel:101}],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:45,marketStructure:45,liquidity:45,entryConfirmation:45,riskReward:45},overlays:[]};
  const good=await call('/analyze',swept,async()=>geminiResponse(JSON.stringify(response)));
  assert.equal(good.body.providers.gemini.timeframeFactorEvidenceValidation['5m'].liquidity,'VALIDATED');
  const noReclaim=structuredClone(swept);
  noReclaim.marketHistory['5m']=encodeCandles(300,candles.map((c,i)=>i===59?{...c,close:101.5}:c));
  noReclaim.lastClosed5mClose=101.5;noReclaim.referencePrice=101.5;
  const bad=await call('/analyze',noReclaim,async()=>geminiResponse(JSON.stringify(response)));
  assert.equal(bad.body.providers.gemini.evidenceStatus,'INVALID');
  assert.equal(bad.body.providers.gemini.directionalVoteEligible,false);
});

test('a claimed BOS with a mismatched event price is semantically invalid even when the JSON contract is complete', async () => {
  const candles=Array.from({length:60},()=>({open:100,high:101,low:99,close:100}));
  candles[54]={open:104,high:105,low:103,close:104.5};
  candles[59]={open:104.5,high:106.5,low:104.4,close:106};
  const bad=structuredClone(input);
  bad.marketHistory['5m']=encodeCandles(300,candles);bad.lastClosed5mClose=106;bad.referencePrice=106;
  const eventTime=bad.marketHistory['5m'].timeStart+59*300;
  const response={...validContractV3,bias:'WAIT',summary:'ادعای شکست ساختار نیازمند تطبیق قیمت است.',observations:[],risks:[],confidence:40,
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'5m':{...validContractV3.timeframeAnalysis['5m'],structure:'BULLISH',structureEvent:'BOS_BULLISH'}},
    evidence:[{timeframe:'5m',type:'STRUCTURE',event:'BOS_BULLISH',status:'CONFIRMED',explanation:'شکست ساختار اعلام شده است.',candleTime:eventTime,price:103,referenceLevel:105}],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:40,marketStructure:40,liquidity:40,entryConfirmation:40,riskReward:40},overlays:[]};
  const result=await call('/analyze',bad,async()=>geminiResponse(JSON.stringify(response)));
  assert.equal(result.body.providers.gemini.contractStatus,'VALID');
  assert.equal(result.body.providers.gemini.evidenceStatus,'INVALID');
  assert.equal(result.body.consensus.decision,'WAIT');
});

test('unsupported CONFIRMED evidence types remain unverified instead of silently passing candle validation', async () => {
  const response={...validContractV3,bias:'WAIT',summary:'یک رویداد تأییدشده خارج از طبقه‌بندی ساختاری گزارش شده است.',
    evidence:[{timeframe:'5m',type:'VOLUME_EVENT',event:'UNSUPPORTED_CONFIRMED_EVENT',status:'CONFIRMED',explanation:'یک رویداد تأییدشده بدون شاهد کندلی مستقل گزارش شد.'}],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:50,marketStructure:50,liquidity:50,entryConfirmation:50,riskReward:50},overlays:[]};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  assert.equal(result.body.providers.gemini.contractStatus,'VALID');
  assert.equal(result.body.providers.gemini.evidenceStatus,'UNVERIFIED');
  assert.ok(result.body.providers.gemini.evidenceValidation.findings.some(x=>x.status==='UNVERIFIED'));
});

test('low-priced altcoin narrative prices are checked against the live anchor', async () => {
  const lowPrice = structuredClone(input);
  for (const [tf,interval] of [['1h',3600],['15m',900],['5m',300]]) { lowPrice.marketHistory[tf]=makeHistory(interval); lowPrice.marketHistory[tf].historyStartPrice = 0.5; }
  lowPrice.referencePrice = 0.5;
  lowPrice.lastClosed5mClose = 0.5;
  const response = {...validContractV3,bias:'WAIT',summary:'قیمت فعلی دارایی حدود ۰٫۷۵ دلار است و ورود نیازمند انتظار است.',observations:[],risks:[],confidence:35,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:35,marketStructure:35,liquidity:35,entryConfirmation:35,riskReward:35},overlays:[]};
  const result=await call('/analyze',lowPrice,async()=>geminiResponse(JSON.stringify(response)));
  const ai=result.body.providers.gemini;
  assert.equal(result.status,200);
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.contractStatus,'VALID');
  assert.equal(ai.directionalVoteEligible,false);
  assert.doesNotMatch(ai.summary,/۰٫۷۵/);
  assert.match(ai.summary,/قیمت خارج از داده مرجع/);
});

test('volatility-aware overlay envelope accepts structurally plausible levels beyond a fixed four-percent cap', async () => {
  const volatile=structuredClone(input);
  volatile.marketHistory['5m'].rows[59]=[300,0,80000,-80000,0,100];
  volatile.referencePrice=100;
  volatile.lastClosed5mClose=100;
  const response={...validContractV3,bias:'WAIT',summary:'سطح ساختاری با دامنه نوسان تایم‌فریم ارزیابی شد.',observations:[],risks:[],confidence:30,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:30,marketStructure:30,liquidity:30,entryConfirmation:30,riskReward:30},
    overlays:[{type:'line',kind:'BOS+',price:106.5,low:null,high:null,timeframe:'5m',direction:'bullish'}]};
  const result=await call('/analyze',volatile,async()=>geminiResponse(JSON.stringify(response)));
  assert.equal(result.status,200);
  assert.ok(result.body.providers.gemini.overlays.some(x=>x.kind==='BOS+'&&x.price===106.5));
});

test('analysis is blocked when live reference price and latest closed 5m close are inconsistent', async () => {
  const bad = {...input, referencePrice: 110, lastClosed5mClose: 100};
  let providerCalls = 0;
  const result = await call('/analyze', bad, async () => { providerCalls++; throw new Error('must not call provider'); });
  assert.equal(result.status, 409);
  assert.equal(result.body.code, 'REFERENCE_PRICE_MISMATCH');
  assert.equal(providerCalls, 0);
});

test('plain text model response is converted to a Persian WAIT explanation and never becomes a trade signal', async () => {
  const result = await call('/analyze', input, async () => geminiResponse('Market is choppy. Buyers have not confirmed a breakout yet.'));
  assert.equal(result.status, 200);
  assert.equal(result.body.providers.gemini.status, 'ok');
  assert.equal(result.body.providers.gemini.responseFormat, 'text');
  assert.match(result.body.providers.gemini.rawText, /Market is choppy/);
  assert.equal(result.body.providers.gemini.bias, 'WAIT');
  assert.equal(result.body.providers.gemini.confidence, null);
  assert.equal(result.body.providers.gemini.confidenceDeclared, false);
  assert.equal(result.body.providers.gemini.overlays.length, 0);
});

test('full Persian plain-text answer recovers independent 1h/15m/5m trends beyond the short summary cap', async () => {
  const prefix = 'گزارش کلی و توضیحات زمینه‌ای مدل. '.repeat(35);
  const prose = `${prefix}\nروند تایم‌فریم یک‌ساعته: نزولی؛ سقف‌ها و کف‌های پایین‌تر تشکیل شده‌اند.\nساختار ۱۵ دقیقه: صعودی؛ قیمت پس از بازپس‌گیری سطح کلیدی کف بالاتر ساخته است.\nتایم‌فریم ۵ دقیقه: نزولی؛ فشار فروش و شکست کف کوتاه‌مدت دیده می‌شود.`;
  const result = await call('/analyze', input, async () => geminiResponse(prose));
  const ai = result.body.providers.gemini;
  assert.equal(ai.responseFormat, 'text');
  assert.ok(ai.rawText.length > 420);
  assert.equal(ai.timeframeAnalysis['1h'].provided, true);
  assert.equal(ai.timeframeAnalysis['1h'].trend, 'BEARISH');
  assert.equal(ai.timeframeAnalysis['15m'].provided, true);
  assert.equal(ai.timeframeAnalysis['15m'].trend, 'BULLISH');
  assert.equal(ai.timeframeAnalysis['5m'].provided, true);
  assert.equal(ai.timeframeAnalysis['5m'].trend, 'BEARISH');
  for (const tf of ['1h','15m','5m']) {
    assert.equal(ai.timeframeAnalysis[tf].narrativeOnly, true);
    assert.equal(ai.timeframeAnalysis[tf].structureEvent, 'UNKNOWN');
  }
  assert.notEqual(ai.contractStatus, 'VALID'); // prose recovery is display-only, never a verified vote
  assert.equal(ai.bias, 'WAIT');
});

test('Gemini, OpenRouter and Groq all recover the same three Persian timeframe trends from native prose envelopes', async () => {
  const prose = 'روند 1H: نزولی؛ ساختار سقف و کف پایین‌تر دارد.\nروند 15 دقیقه: صعودی؛ کف بالاتر و بازپس‌گیری سطح دیده می‌شود.\nروند 5 دقیقه: رنج و بدون جهت روشن است.';
  const multi = {...input, selectedProviders:['gemini','openrouter','groq'], modelSelection:{gemini:'gemini-3.8-flash',openrouter:'qwen/qwen3.8-27b:free',groq:'openai/gpt-oss-120b'}};
  const result = await call('/analyze', multi, async url => {
    const target = String(url);
    if (target.includes('generativelanguage.googleapis.com')) return geminiResponse(prose);
    if (target.includes('openrouter.ai')) return new Response(JSON.stringify({model:'qwen/qwen3.8-27b:free',choices:[{finish_reason:'stop',message:{content:prose}}]}),{status:200});
    if (target.includes('api.groq.com')) return new Response(JSON.stringify({model:'openai/gpt-oss-120b',choices:[{finish_reason:'stop',message:{content:prose}}]}),{status:200});
    throw new Error(`unexpected provider URL ${target}`);
  });
  for (const name of ['gemini','openrouter','groq']) {
    const provider = result.body.providers[name];
    assert.equal(provider.status,'ok',`${name} should parse`);
    assert.deepEqual(['1h','15m','5m'].map(tf=>provider.timeframeAnalysis[tf].trend),['BEARISH','BULLISH','RANGE']);
    assert.ok(['1h','15m','5m'].every(tf=>provider.timeframeAnalysis[tf].narrativeOnly));
    assert.equal(provider.bias,'WAIT');
  }
});

test('structured timeframe data is supplemented only for missing timeframes from the same provider narrative', async () => {
  const partial = {
    ...validContractV3,
    timeframeAnalysis: {'1h': validContractV3.timeframeAnalysis['1h']},
    summary: 'روند ۱۵ دقیقه: نزولی و همراه با سقف‌های پایین‌تر.\nروند ۵ دقیقه: صعودی و در حال بازپس‌گیری کف محلی.',
    bias: 'WAIT', observations: [], risks: [], confidence: 50,
    analyticalWeights: {trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores: {trend:50,marketStructure:50,liquidity:50,entryConfirmation:50,riskReward:50}, overlays: []
  };
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify(partial)));
  const frames = result.body.providers.gemini.timeframeAnalysis;
  assert.equal(frames['1h'].trend, 'BULLISH');
  assert.equal(frames['1h'].narrativeOnly, false);
  assert.equal(frames['15m'].trend, 'BEARISH');
  assert.equal(frames['15m'].source, 'NARRATIVE');
  assert.equal(frames['15m'].narrativeOnly, true);
  assert.equal(frames['5m'].trend, 'BULLISH');
  assert.equal(frames['5m'].narrativeOnly, true);
  assert.equal(frames['5m'].structureEvent, 'UNKNOWN');
});

test('AI Data Engine keeps rich provider-native JSON and classifies unfamiliar field layouts', async () => {
  const native = {
    market_outlook: 'بازار در وضعیت رنج با تمایل صعودی محدود قرار دارد.',
    technicals: {market_structure: {bos: 'شکست سقف محلی تایید نشده', choch: 'در انتظار تایید'},
      liquidity_sweep: ['جمع‌آوری نقدینگی زیر کف روزانه'],
      order_blocks: [{type:'bullish', low: 60100, high: 60300}],
      momentum: {rsi: 54, macd: 'positive', volume: 'below average'}},
    additionalData: {funding_rate: 'نرخ تأمین مالی مثبت گزارش شده است.', open_interest: 'بهره باز در حال افزایش گزارش شده است.', order_book: 'عمق سفارش خرید نزدیک قیمت بیشتر گزارش شده است.'},
    scenarios: {bullish: 'تثبیت بالای مقاومت', bearish: 'بازگشت زیر حمایت'},
    risk_management: {invalidation: 'کلوز زیر کف اخیر'},
    custom_model_field: {novel_signal: 'model-specific observation'}
  };
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify(native)));
  assert.equal(result.status, 200);
  const ai = result.body.providers.gemini;
  assert.equal(ai.status, 'ok');
  assert.match(ai.rawText, /model-specific observation/);
  assert.equal(ai.dataCategories.marketStructure, undefined);
  assert.equal(ai.dataCategories.liquidity, undefined);
  assert.equal(ai.dataCategories.pointsOfInterest, undefined);
  assert.equal(ai.dataCategories.momentumAndVolume, undefined);
  assert.equal(ai.dataCategories.scenarios, undefined);
  assert.equal(ai.dataCategories.riskAndInvalidation, undefined);
  assert.equal(ai.dataCategories.derivatives?.length, 2);
  assert.equal(ai.dataCategories.orderBook?.length, 1);
  assert.ok(ai.extractedFacts.some(x => x.text === 'model-specific observation'));
  assert.equal(ai.bias, 'WAIT');
});

test('AI Data Engine categorizes explicitly titled plain-text sections without fabricating trade levels', async () => {
  const prose = 'Market structure: ساختار ۱۵ دقیقه‌ای در محدوده است.\nLiquidity: نقدینگی زیر کف قبلی جمع شد.\nScenarios: سناریوی صعودی مشروط به شکست مقاومت است.\nFunding Rate: نرخ تأمین مالی مثبت گزارش شده است.\nOrder Book: عمق سفارش خرید در محدوده نزدیک بیشتر است.\nRisks: شکست حمایت سناریو را باطل می‌کند.';
  const result = await call('/analyze', input, async () => geminiResponse(prose));
  assert.equal(result.status, 200);
  const ai = result.body.providers.gemini;
  assert.equal(ai.responseFormat, 'text');
  assert.equal(ai.dataCategories.marketStructure, undefined);
  assert.equal(ai.dataCategories.liquidity, undefined);
  assert.equal(ai.dataCategories.scenarios, undefined);
  assert.equal(ai.dataCategories.riskAndInvalidation, undefined);
  assert.ok(ai.dataCategories.derivatives?.length);
  assert.ok(ai.dataCategories.orderBook?.length);
  assert.equal(ai.overlays.length, 0);
  assert.equal(ai.bias, 'WAIT');
});


test('analysis preserves provider HTTP authentication diagnostics and does not poison the transient circuit', async () => {
  const sharedEnv = env();
  const unauthorized = async () => new Response(JSON.stringify({error:{message:'invalid API key'}}),{status:401});
  const result = await call('/analyze', input, unauthorized, {}, sharedEnv);
  assert.equal(result.status,502);
  const provider = result.body.providers.gemini;
  assert.equal(provider.status,'error');
  assert.equal(provider.errorCode,'AUTHENTICATION_FAILED');
  assert.equal(provider.httpStatus,401);
  assert.equal(provider.retryable,false);
  assert.ok(provider.attemptedModels.length >= 1);
  const health = await call('/providers/health', {selectedProviders:['gemini']}, unauthorized, {}, sharedEnv);
  assert.equal(health.status,200);
  assert.equal(health.body.providers.gemini.errorCode,'AUTHENTICATION_FAILED');
  assert.notEqual(health.body.providers.gemini.errorCode,'CIRCUIT_OPEN');
});

test('a stale saved model is ignored and automatic live candidates are attempted instead', async () => {
  const bad = {...input, modelSelection:{gemini:'unknown/model'}};
  const result = await call('/analyze', bad, async () => { throw new Error('provider probe intentionally unavailable'); });
  assert.equal(result.status, 502);
  assert.equal(result.body.ok, false);
  assert.doesNotMatch(result.body.providers.gemini.error, /unknown\/model/);
  assert.ok(result.body.providers.gemini.attemptedModels?.length);
});

test('/models fails closed when live provider catalogs cannot be reached and never exposes secrets', async () => {
  const result = await call('/models', null, async () => new Response(JSON.stringify({error:{message:'catalog unavailable'}}),{status:503}));
  assert.equal(result.status, 200);
  assert.deepEqual(result.body.providers.gemini.models,[]);
  assert.deepEqual(result.body.providers.groq.models,[]);
  assert.equal(result.body.providers.gemini.source,'catalog_unavailable');
  assert.equal(JSON.stringify(result.body).includes('test-gemini'), false);
});

test('/models is rate-limited before any upstream catalog request and uses an isolated key', async () => {
  let upstreamCalls=0, limiterKey='';
  const limitedEnv={...env(),RATE_LIMITER:{limit:async ({key})=>{limiterKey=key;return {success:false};}}};
  const result=await call('/models',null,async()=>{upstreamCalls++;throw new Error('upstream must not be called');},{},limitedEnv);
  assert.equal(result.status,429);
  assert.equal(result.body.code,'RATE_LIMITED');
  assert.equal(limiterKey,'models:unknown');
  assert.equal(upstreamCalls,0);
});

test('/analyze keeps a dedicated rate-limit bucket separate from catalog and quota probes', async () => {
  let limiterKey='', upstreamCalls=0;
  const limitedEnv={...env(),RATE_LIMITER:{limit:async ({key})=>{limiterKey=key;return {success:false};}}};
  const result=await call('/analyze',input,async()=>{upstreamCalls++;throw new Error('provider must not be called');},{},limitedEnv);
  assert.equal(result.status,429);
  assert.equal(result.body.code,'RATE_LIMITED');
  assert.equal(limiterKey,'analyze:unknown');
  assert.equal(upstreamCalls,0);
});

test('/altfins/quota is rate-limited before the paid quota endpoint and uses an isolated key', async () => {
  let upstreamCalls=0, limiterKey='';
  const limitedEnv={...env(),ALTFINS_API_KEY:'private-altfins-key',RATE_LIMITER:{limit:async ({key})=>{limiterKey=key;return {success:false};}}};
  const result=await call('/altfins/quota',null,async()=>{upstreamCalls++;throw new Error('upstream must not be called');},{},limitedEnv);
  assert.equal(result.status,429);
  assert.equal(result.body.status,'RATE_LIMITED');
  assert.equal(limiterKey,'altfins-quota:unknown');
  assert.equal(upstreamCalls,0);
});

test('/provider-test is rate-limited after token authorization and before provider calls', async () => {
  let upstreamCalls=0, limiterKey='';
  const limitedEnv={...env(),RATE_LIMITER:{limit:async ({key})=>{limiterKey=key;return {success:false};}}};
  const result=await call('/provider-test',{selectedProviders:['gemini']},async()=>{upstreamCalls++;throw new Error('provider must not be called');},{Authorization:'Bearer test-token'},limitedEnv);
  assert.equal(result.status,429);
  assert.equal(result.body.code,'RATE_LIMITED');
  assert.equal(limiterKey,'provider-test:unknown');
  assert.equal(upstreamCalls,0);
});

test('rate-limited external routes fail closed when the Cloudflare binding is unavailable', async () => {
  const missingBinding={...env()}; delete missingBinding.RATE_LIMITER;
  const models=await call('/models',null,async()=>{throw new Error('must not call upstream');},{},missingBinding);
  assert.equal(models.status,503);
  assert.equal(models.body.code,'RATE_LIMITER_UNAVAILABLE');
  const quota=await call('/altfins/quota',null,async()=>{throw new Error('must not call upstream');},{},{...missingBinding,ALTFINS_API_KEY:'private-altfins-key'});
  assert.equal(quota.status,503);
  assert.equal(quota.body.status,'RATE_LIMITED');
  assert.match(quota.body.error,/binding is missing/);
});

test('one successful provider in provider-test is reported as successful connectivity', async () => {
  const result = await call('/provider-test', {selectedProviders:['gemini'],modelSelection:{gemini:'gemini-3.8-flash'}},
    async () => geminiResponse(), {Authorization:'Bearer test-token'});
  assert.equal(result.status, 200);
  assert.equal(result.body.ok, true);
  assert.equal(result.body.successCount, 1);
  assert.equal(result.body.requiredForDisplay, 1);
});

test('OpenRouter model selection is passed through exactly and each provider result is independent', async () => {
  const selected = {...input, selectedProviders:['openrouter'], modelSelection:{openrouter:'qwen/qwen3.8-27b:free'}};
  let sentModel;
  const result = await call('/analyze', selected, async (url, options) => {
    sentModel = JSON.parse(options.body).model;
    return openRouterResponse();
  });
  assert.equal(result.status, 200);
  assert.equal(sentModel, 'qwen/qwen3.8-27b:free');
  assert.equal(result.body.providers.openrouter.status, 'ok');
  assert.equal(result.body.providers.openrouter.providerModel, 'test/free-model');
  assert.match(result.body.providers.openrouter.rawProviderResponse, /choices/);
});


test('OpenRouter retries without optional JSON schema when a free endpoint rejects it and safely rejects unstructured text', async () => {
  const selected = {...input, selectedProviders:['openrouter'], modelSelection:{openrouter:'qwen/qwen3.8-27b:free'}};
  let attempts = 0;
  const result = await call('/analyze', selected, async (url, options) => {
    attempts++;
    const payload = JSON.parse(options.body);
    assert.equal(payload.response_format, undefined);
    return new Response(JSON.stringify({model:'openai/gpt-oss-120b',choices:[{finish_reason:'stop',message:{content:'The market is range-bound; wait for a confirmed break.'}}]}),{status:200});
  });
  assert.equal(attempts,1);
  assert.equal(result.status,200);
  assert.equal(result.body.providers.openrouter.status,'ok');
  assert.equal(result.body.providers.openrouter.responseFormat,'text');
  assert.match(result.body.providers.openrouter.rawText,/range-bound/);
  assert.equal(result.body.providers.openrouter.bias,'WAIT');
});

test('a failed selected provider never discards another provider successful result', async () => {
  const selected = {...input, selectedProviders:['gemini','groq'], modelSelection:{gemini:'gemini-3.8-flash',groq:'openai/gpt-oss-120b'}};
  const result = await call('/analyze', selected, async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse();
    return new Response(JSON.stringify({error:{message:'model overloaded'}}),{status:503});
  });
  assert.equal(result.status,200);
  assert.equal(result.body.ok,true);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.groq.status,'error');
  assert.equal(result.body.analysisMode,'SINGLE_PROVIDER_INDEPENDENT');
  assert.equal(result.body.decision,'WAIT');
});


test('provider automatically tries its configured fallback model after the primary model is unavailable', async () => {
  const selected = {...input, selectedProviders:['gemini'], modelSelection:{gemini:'gemini-3.7-flash'}, fallbackSelection:{gemini:'gemini-3.8-flash'}};
  const attempted=[];
  const result = await call('/analyze', selected, async url => {
    attempted.push(String(url));
    if (String(url).includes('gemini-3.7-flash')) return new Response(JSON.stringify({error:{message:'model not found'}}),{status:404});
    return geminiResponse();
  });
  assert.equal(result.status,200);
  assert.equal(attempted.length,2);
  assert.match(attempted[0],/gemini-3.7-flash/);
  assert.match(attempted[1],/gemini-3.8-flash/);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.fallbackUsed,true);
  assert.deepEqual(result.body.providers.gemini.attemptedModels,['gemini-3.7-flash','gemini-3.8-flash']);
});


test('provider uses only the explicitly selected primary and fallback models', async () => {
  const selected = {...input, selectedProviders:['gemini'], modelSelection:{gemini:'gemini-3.8-flash'}, fallbackSelection:{gemini:'gemini-3.7-flash'}};
  const attempted = [];
  const result = await call('/analyze', selected, async url => {
    const value = String(url);
    attempted.push(value);
    return new Response(JSON.stringify({error:{message:'temporarily unavailable'}}), {status:503});
  });
  assert.equal(result.body.providers.gemini.status, 'error');
  assert.equal(attempted.length, 2);
  assert.match(attempted[0], /gemini-3.8-flash/);
  assert.match(attempted[1], /gemini-3.7-flash/);
  assert.deepEqual(result.body.providers.gemini.attemptedModels, ['gemini-3.8-flash','gemini-3.7-flash']);
});

test('analysis uses up to four health-verified live candidates and recovers on the third', async () => {
  const selected = {...input, selectedProviders:['gemini'], modelCandidates:{gemini:[
    'gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash','gemini-3.5-flash'
  ]}};
  const attempted=[];
  const result = await call('/analyze', selected, async url => {
    const value=String(url); attempted.push(value);
    if(value.includes('gemini-3.8-flash') || value.includes('gemini-3.7-flash')) {
      return new Response(JSON.stringify({error:{message:'temporary model failure'}}),{status:503});
    }
    return geminiResponse();
  });
  assert.equal(result.status,200);
  assert.equal(attempted.length,3);
  assert.match(attempted[0],/gemini-3.8-flash/);
  assert.match(attempted[1],/gemini-3.7-flash/);
  assert.match(attempted[2],/gemini-3.6-flash/);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.fallbackUsed,true);
  assert.deepEqual(result.body.providers.gemini.attemptedModels,['gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash']);
});

test('provider-wide 429/TPM failure stops before trying the fallback model', async () => {
  const selected = {...input, selectedProviders:['groq'], modelSelection:{groq:'openai/gpt-oss-120b'}, fallbackSelection:{groq:'qwen/qwen3.8-27b'}};
  let calls = 0;
  const result = await call('/analyze', selected, async () => {
    calls++;
    return new Response(JSON.stringify({error:{message:'Rate limit reached: tokens per minute (ITPM) limit exceeded'}}), {status:429});
  });
  assert.equal(calls, 1);
  assert.equal(result.body.providers.groq.status, 'error');
  assert.equal(result.body.providers.groq.errorCode, 'RATE_LIMITED');
  assert.deepEqual(result.body.providers.groq.attemptedModels, ['openai/gpt-oss-120b']);
  assert.match(result.body.providers.groq.error, /429|Rate limit|ITPM/i);
});

test('AI consensus is independent from the technical engine direction', async () => {
  const selected = {...input, technicalAnalysis:{signal:'SELL'}, selectedProviders:['gemini','openrouter'], modelSelection:{gemini:'gemini-3.8-flash',openrouter:'qwen/qwen3.8-27b:free'}};
  const result = await call('/analyze', selected, async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse(JSON.stringify({...validContractV3,bias:'BUY',summary:'ساختار مستقل این مدل متمایل به صعود است.',observations:['کف‌های بالاتر در نمودار دیده می‌شود.'],risks:[],confidence:72,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:75,marketStructure:75,liquidity:70,entryConfirmation:80,riskReward:70},overlays:validBuyOverlays()}));
    return openRouterResponse();
  });
  assert.equal(result.status,200);
  assert.equal(result.body.providers.gemini.bias,'BUY');
  assert.equal(result.body.providers.openrouter.bias,'BUY');
  assert.equal(result.body.consensus.decision,'BUY');
  assert.equal(result.body.consensus.technicalSignal,undefined);
});

test('Gemini, OpenRouter and Groq receive the exact same immutable market snapshot prompt', async () => {
  const selected={...input,marketType:'SPOT',snapshotId:'immutable-snapshot-3-provider',selectedProviders:['gemini','openrouter','groq']};
  const prompts={};
  const result=await call('/analyze',selected,async(url,options)=>{
    const address=String(url),payload=JSON.parse(options.body);
    if(address.includes('generativelanguage')){
      prompts.gemini=payload.contents[0].parts[0].text;
      return geminiResponse();
    }
    if(address.includes('openrouter')){
      prompts.openrouter=payload.messages.find(item=>item.role==='user').content;
      return openRouterResponse();
    }
    prompts.groq=payload.messages.find(item=>item.role==='user').content;
    const response={...validContractV3,bias:'BUY',summary:'ساختار بازار از دید مستقل مدل Groq با ناحیه تقاضا هم‌راستا است.',observations:['کندل‌های بسته‌شده نشانه ادامه فشار خرید دارند.'],risks:[],confidence:76,
      analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
      factorScores:{trend:76,marketStructure:76,liquidity:70,entryConfirmation:80,riskReward:75},overlays:validBuyOverlays()};
    return new Response(JSON.stringify({model:'openai/gpt-oss-120b',choices:[{finish_reason:'stop',message:{content:JSON.stringify(response)}}]}),{status:200});
  });
  assert.equal(result.status,200);
  assert.equal(Object.keys(prompts).length,3);
  assert.equal(prompts.gemini,prompts.openrouter);
  assert.equal(prompts.gemini,prompts.groq);
  const payload=JSON.parse(prompts.gemini.slice(prompts.gemini.lastIndexOf('\n')+1));
  assert.equal(payload.snapshotId,'immutable-snapshot-3-provider');
  assert.equal(payload.marketType,'SPOT');
  assert.match(prompts.gemini,/altFINS.*NOT supplied/i);
  assert.match(prompts.gemini,/snapshotId/);
  assert.equal(result.body.decision,'BUY');
  assert.equal(result.body.marketType,'SPOT');
  assert.equal(result.body.dataQuality.status,'VALIDATED');
  assert.equal(result.body.dataQuality.timeframes['5m'].candleCount,60);
  assert.equal(result.body.dataQuality.timeframes['5m'].gapCount,0);
  for(const provider of ['gemini','openrouter','groq']){
    assert.equal(result.body.providers[provider].evidenceStatus,'VALIDATED');
    assert.ok(result.body.providers[provider].rawProviderResponse?.length>0);
  }
});

test('large saved histories preserve every exact candle before reaching AI and technical report is excluded', async () => {
  const longHistory = Object.fromEntries(['1h','15m','5m'].map((tf)=>{const interval=tf==='1h'?3600:tf==='15m'?900:300;return [tf,makeHistory(interval,2000)];}));
  const selected = {...input,technicalAnalysis:{signal:'SELL',secretShouldNotReachAI:'NO'},marketHistory:longHistory};
  let prompt='';
  const result = await call('/analyze',selected,async (_url,options)=>{
    prompt=JSON.parse(options.body).contents[0].parts[0].text;
    return geminiResponse();
  });
  assert.equal(result.status,200);
  assert.doesNotMatch(prompt,/secretShouldNotReachAI|technicalAnalysis/);
  const payload=JSON.parse(prompt.slice(prompt.lastIndexOf('\n')+1));
  assert.equal(payload.history['1h'].rows.length,2000);
  assert.equal(payload.history['15m'].rows.length,2000);
  assert.equal(payload.history['5m'].rows.length,2000);
  assert.equal(payload.history['5m'].originalCount,2000);
  assert.match(payload.encoding,/COMPACT_QUANTIZED/);
  assert.match(payload.encoding,/not lossless/i);
  assert.equal(payload.encodingMetadata.exactOriginalValuesPreserved,false);
  assert.equal(payload.encodingMetadata.priceDeltaScale,1000000);
  assert.equal(payload.encodingMetadata.volumeRatioScale,100);
});

test('normalized raw model text exposes an explicit truncation flag and original length', async () => {
  const large = {...validContractV3,bias:'WAIT',summary:'تحلیل ساختاریافته دریافت شد.',observations:[],risks:[],confidence:70,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:70,marketStructure:70,liquidity:70,entryConfirmation:70,riskReward:70},overlays:[],
    extraProviderNotes:'x'.repeat(110000)};
  const result = await call('/analyze',input,async()=>geminiResponse(JSON.stringify(large)));
  assert.equal(result.status,200);
  const provider=result.body.providers.gemini;
  assert.equal(provider.rawText.length,20000);
  assert.equal(provider.rawTextTruncated,true);
  assert.ok(provider.rawTextOriginalLength>20000);
  assert.equal(provider.normalization.rawTextTruncated,true);
  assert.equal(provider.normalization.rawTextOriginalLength,provider.rawTextOriginalLength);
  assert.equal(provider.normalization.rawProviderResponseOriginalLength,provider.rawProviderResponseOriginalLength);
  assert.equal(provider.rawProviderResponse.length,100000);
  assert.ok(provider.rawProviderResponseOriginalLength>100000);
  assert.equal(provider.rawProviderResponseTruncated,true);
});

test('long plain-text provider answers are preserved up to the documented cap with original length', async () => {
  const plainText='این تحلیل متنی فارسی برای بررسی حفظ پاسخ خام است. '.repeat(700);
  const result=await call('/analyze',input,async()=>geminiResponse(plainText));
  assert.equal(result.status,200);
  const provider=result.body.providers.gemini;
  assert.equal(provider.responseFormat,'text');
  assert.equal(provider.rawText.length,20000);
  assert.equal(provider.rawTextTruncated,true);
  assert.equal(provider.normalization.sourceFormat,'plain_text');
  assert.equal(provider.normalization.rawTextOriginalLength,plainText.trim().length);
  assert.equal(provider.rawTextOriginalLength,plainText.trim().length);
});

test('quantized history encoding preserves one row per source candle and original sequence', async () => {
  const varied = structuredClone(input);
  const source = varied.marketHistory['5m'];
  source.timeStart = Math.floor(Math.floor(Date.now()/1000)/300)*300 - 300*75;
  source.historyStartPrice = 100;
  let previousClose = 100;
  source.rows = Array.from({length:75}, (_, i) => {
    const openDelta = (i % 7) - 3;
    const closeDelta = (i % 5) - 2;
    const highDelta = Math.max(openDelta, closeDelta) + 5 + (i % 3);
    const lowDelta = Math.min(openDelta, closeDelta) - 4 - (i % 4);
    const row = [i === 0 ? 0 : 300, openDelta, highDelta, lowDelta, closeDelta, 90 + i];
    previousClose *= 1 + closeDelta / 1000000;
    return row;
  });
  let prompt = '';
  const result = await call('/analyze', varied, async (_url, options) => {
    prompt = JSON.parse(options.body).contents[0].parts[0].text;
    return geminiResponse();
  });
  assert.equal(result.status, 200);
  const payload = JSON.parse(prompt.slice(prompt.lastIndexOf('\n') + 1));
  assert.deepEqual(payload.history['5m'].rows, source.rows);
});

test('gateway rejects quantized volume ratios beyond the documented 10000x cap', async () => {
  const bad=structuredClone(input);
  bad.marketHistory['5m'].rows[20][5]=1000001;
  const result=await call('/analyze',bad,async()=>{throw new Error('provider must not be called');});
  assert.equal(result.status,400);
  assert.equal(result.body.dataQuality['5m'].reason,'VOLUME_RATIO_OUT_OF_RANGE');
});

test('gateway rejects a missing candle instead of silently accepting a gapped timeframe', async () => {
  const bad = structuredClone(input);
  bad.marketHistory['5m'].rows[25][0] = 600;
  const result = await call('/analyze', bad, async () => { throw new Error('provider must not be called'); });
  assert.equal(result.status, 400);
  assert.equal(result.body.dataQuality['5m'].ok, false);
  assert.equal(result.body.dataQuality['5m'].reason, 'CANDLE_GAP_OR_WRONG_INTERVAL');
});


test('gateway rejects a timeframe history whose first candle is not aligned to the UTC interval boundary', async () => {
  const bad = structuredClone(input);
  bad.marketHistory['15m'].timeStart += 60;
  const result = await call('/analyze', bad, async () => { throw new Error('provider must not be called'); });
  assert.equal(result.status, 400);
  assert.equal(result.body.dataQuality['15m'].ok, false);
  assert.equal(result.body.dataQuality['15m'].reason, 'INVALID_HEADER_OR_TOO_FEW_CANDLES');
});

test('gateway rejects timeframe metadata that does not match its requested interval', async () => {
  const bad = structuredClone(input);
  bad.marketHistory['15m'].intervalSeconds = 300;
  const result = await call('/analyze', bad, async () => { throw new Error('provider must not be called'); });
  assert.equal(result.status, 400);
  assert.equal(result.body.dataQuality['15m'].reason, 'INVALID_HEADER_OR_TOO_FEW_CANDLES');
});

test('gateway blocks a supplied lastClosed5mClose that differs from the reconstructed candle close', async () => {
  const bad = {...input,lastClosed5mClose:99,referencePrice:99};
  const result = await call('/analyze',bad,async()=>{throw new Error('provider must not be called');});
  assert.equal(result.status,409);
  assert.equal(result.body.code,'HISTORY_CLOSE_MISMATCH');
});

test('gateway rejects stale closed-candle history before contacting AI providers', async () => {
  const bad = structuredClone(input);
  bad.marketHistory['5m'].timeStart -= 300 * 20;
  const result = await call('/analyze', bad, async () => { throw new Error('provider must not be called'); });
  assert.equal(result.status, 400);
  assert.equal(result.body.dataQuality['5m'].reason, 'STALE_HISTORY');
});

test('/models reads current provider catalogs and filters OpenRouter to free text models', async () => {
  const result = await call('/models', null, async (url) => {
    const value = String(url);
    if (value.includes('generativelanguage.googleapis.com')) return new Response(JSON.stringify({models:[
      {name:'models/gemini-3.8-flash',supportedGenerationMethods:['generateContent']},
      {name:'models/text-embedding-live',supportedGenerationMethods:['embedContent']}
    ]}),{status:200});
    if (value.includes('api.groq.com')) return new Response(JSON.stringify({data:[
      {id:'qwen/qwen3.8-27b',active:true,context_window:131072},
      {id:'whisper-large-v3',active:true,context_window:448}
    ]}),{status:200});
    if (value.includes('openrouter.ai')) {
      assert.match(value,/\/api\/v1\/models\/user\?/,'OpenRouter discovery must use the account-filtered model catalog');
      return new Response(JSON.stringify({data:[
      {id:'qwen/qwen4-max',architecture:{input_modalities:['text','image'],output_modalities:['text']},context_length:1000000,supported_parameters:['structured_outputs'],pricing:{prompt:'0.000001425',completion:'0.000004275'}},
      {id:'qwen/qwen3.8-27b:free',architecture:{input_modalities:['text'],output_modalities:['text']},context_length:262144,supported_parameters:[],pricing:{prompt:'0',completion:'0'}},
      {id:'qwen/qwen3.8-27b',architecture:{input_modalities:['text'],output_modalities:['text']},context_length:262144,supported_parameters:['structured_outputs'],pricing:{prompt:'0.00000006',completion:'0.0000022'}},
      {id:'openai/gpt-oss-120b',architecture:{input_modalities:['text'],output_modalities:['text']},context_length:131072,supported_parameters:['structured_outputs'],pricing:{prompt:'0.00000009',completion:'0.00000036'}},
      {id:'inclusionai/ling-3.2-flash:free',architecture:{input_modalities:['text','image'],output_modalities:['text']},context_length:1048576,supported_parameters:['structured_outputs'],pricing:{prompt:'0',completion:'0'}},
      {id:'sample/free-image:free',architecture:{input_modalities:['image'],output_modalities:['text']},context_length:100000,supported_parameters:['structured_outputs'],pricing:{prompt:'0',completion:'0'}},
      {id:'sample/no-json-free:free',architecture:{input_modalities:['text'],output_modalities:['text']},context_length:100000,supported_parameters:[],pricing:{prompt:'0',completion:'0'}},
      {id:'sample/too-expensive',architecture:{input_modalities:['text'],output_modalities:['text']},context_length:100000,supported_parameters:['structured_outputs'],pricing:{prompt:'0.00001',completion:'0.00002'}}
    ]}),{status:200});
    }
    throw new Error('unexpected catalog URL');
  });
  assert.equal(result.body.source,'live_provider_catalog');
  assert.deepEqual(result.body.providers.gemini.models,['gemini-3.8-flash']);
  assert.deepEqual(result.body.providers.groq.models,['qwen/qwen3.8-27b']);
  assert.deepEqual(result.body.providers.openrouter.models,['qwen/qwen3.8-27b:free','sample/no-json-free:free']);
  assert.ok(!result.body.providers.openrouter.models.includes('inclusionai/ling-3.2-flash:free')); // multimodal input is excluded
  assert.ok(!result.body.providers.openrouter.models.includes('sample/free-image:free'));
  assert.ok(result.body.providers.openrouter.models.includes('sample/no-json-free:free')); // JSON-mode fallback is allowed and locally validated
  assert.ok(!result.body.providers.openrouter.models.includes('openrouter/free')); // router alias is not a concrete model
  assert.ok(!result.body.providers.openrouter.models.includes('sample/too-expensive')); 
});

test('Groq provider-native response format is not constrained by a shared JSON Schema', async () => {
  const groqInput = {...input, selectedProviders:['groq'], modelSelection:{groq:'openai/gpt-oss-120b'}};
  const result = await call('/analyze', groqInput, async (url, options) => {
    assert.match(String(url),/api.groq.com\/openai\/v1\/chat\/completions/);
    const payload = JSON.parse(options.body);
    assert.equal(payload.response_format,undefined);
    return new Response(JSON.stringify({model:'openai/gpt-oss-120b',choices:[{finish_reason:'stop',message:{content:JSON.stringify({...validContractV3,bias:'WAIT',summary:'شرایط فعلی برای ورود تأیید کافی ندارد.',observations:[],risks:[],confidence:40,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:40,marketStructure:40,liquidity:40,entryConfirmation:40,riskReward:40},overlays:[]})}}]}),{status:200});
  });
  assert.equal(result.body.providers.groq.status,'ok');
});

test('Groq deeply nested JSON-string payload normalizes all three timeframes without losing contract sections', async () => {
  const timeframe = (trend, buyer, seller, evidence) => ({
    trend, structure:trend, structureEvent:'NONE', phase:'TRENDING',
    buyerSellerStrength:{buyer:{percentage:buyer},seller:{percentage:seller}},
    liquidity:'NONE', evidence:[evidence]
  });
  const nested = {
    contractVersion:3,
    analysisSections:validAnalysisSectionsV3,
    timeframeAnalysis:{
      '1H':timeframe('BULLISH',64,36,'ساختار صعودی یک‌ساعته با کف بالاتر تأیید شد.'),
      '15M':timeframe('BULLISH',59,41,'ساختار صعودی پانزده‌دقیقه‌ای حفظ شده است.'),
      '5M':timeframe('BULLISH',61,39,'ساختار اجرایی پنج‌دقیقه‌ای صعودی است.')
    },
    evidence:[{timeframe:'5m',type:'OBSERVATION',event:'NO_CONFIRMED_EVENT',status:'NOT_CONFIRMED',explanation:'در پنجره بررسی‌شده شکست ساختاری جدیدی تأیید نشد.'}],
    invalidation:'بسته‌شدن کندل زیر کف ساختاری سناریو را باطل می‌کند.',
    bias:'WAIT',summary:'برای ورود هنوز تأیید کافی وجود ندارد.',observations:[],risks:[],confidence:55,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:55,marketStructure:55,liquidity:55,entryConfirmation:55,riskReward:55},overlays:[]
  };
  const wrapped = {data:{result:JSON.stringify(nested)}};
  const groqInput={...input,selectedProviders:['groq'],modelSelection:{groq:'openai/gpt-oss-120b'}};
  const result=await call('/analyze',groqInput,async()=>new Response(JSON.stringify({
    model:'openai/gpt-oss-120b',choices:[{finish_reason:'stop',message:{content:JSON.stringify(wrapped)}}]
  }),{status:200}));
  const groq=result.body.providers.groq;
  assert.equal(groq.status,'ok');
  assert.equal(groq.contractStatus,'VALID');
  for (const tf of ['1h','15m','5m']) assert.equal(groq.timeframeAnalysis[tf].provided,true);
  assert.deepEqual(['1h','15m','5m'].map(tf=>groq.timeframeAnalysis[tf].trend),['BULLISH','BULLISH','BULLISH']);
  assert.deepEqual(['1h','15m','5m'].map(tf=>groq.timeframeAnalysis[tf].buyerStrength),[64,59,61]);
  assert.equal(groq.analysisSections.execution.status,'AVAILABLE');
  assert.ok(groq.rawProviderResponse.includes("data"));
});

test('Groq nested JSON normalizer refuses to stitch split timeframe branches and preserves supplementary facts', async () => {
  const groqInput = {...input, selectedProviders:['groq'], modelSelection:{groq:'openai/gpt-oss-120b'}};
  const groqPayload = {
    result: JSON.stringify({
      contractVersion: 3,
      analysisSections: validAnalysisSectionsV3,
      timeframeAnalysis: {
        '1h': {trend:'BEARISH',structure:'BEARISH',structureEvent:'NONE',phase:'BEARISH',buyerStrength:30,sellerStrength:70,liquidity:'NONE',evidence:[{timeframe:'1h',type:'priceMovement',event:'نزول ساختاری',status:'CONFIRMED',explanation:'سقف‌ها و کف‌های پایین‌تر در تایم‌فریم یک‌ساعته ثبت شده‌اند.'}]}
      },
      marketContext: {timeframes: {
        '5m': {trend:'BEARISH',structure:'BEARISH',structureEvent:'BOS_BEARISH',phase:'BEARISH',buyerStrength:25,sellerStrength:75,liquidity:'SELL_SIDE_SWEEP',evidence:['شکست کف و ادامه فشار فروش در ۵ دقیقه مشاهده شد']}
      }},
      additionalData:{fundingRate:'نرخ تأمین مالی مثبت و محدود است.',openInterest:1250000,orderBook:'عمق سفارش فروش در نزدیکی قیمت بیشتر است.'},
      bias:'WAIT',summary:'برای ورود، تأیید مستقل بیشتری لازم است.',observations:[],risks:[],confidence:50,
      analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
      factorScores:{trend:50,marketStructure:50,liquidity:50,entryConfirmation:50,riskReward:50},overlays:[]
    })
  };
  const result = await call('/analyze', groqInput, async () => new Response(JSON.stringify({model:'openai/gpt-oss-120b',choices:[{finish_reason:'stop',message:{content:JSON.stringify(groqPayload)}}]}),{status:200}));
  const groq = result.body.providers.groq;
  assert.equal(groq.status,'ok');
  assert.equal(groq.timeframeAnalysis['1h'].provided,true);
  assert.equal(groq.timeframeAnalysis['1h'].trend,'BEARISH');
  assert.equal(groq.timeframeAnalysis['1h'].buyerStrength,30);
  assert.equal(groq.timeframeAnalysis['1h'].sellerStrength,70);
  assert.equal(groq.timeframeAnalysis['1h'].phase,'TRENDING');
  assert.equal(groq.timeframeAnalysis['1h'].structureEvent,'NONE');
  assert.equal(groq.timeframeAnalysis['15m'].provided,false);
  assert.equal(groq.timeframeAnalysis['5m'].provided,false); // separate branches are never stitched into one timeframe contract
  assert.ok(groq.dataCategories.derivatives?.length >= 1);
  assert.ok(groq.dataCategories.orderBook?.length >= 1);
  assert.notEqual(groq.contractStatus,'VALID'); // missing 15M must remain visibly incomplete
});

test('truncated Gemini response is downgraded to WAIT and cannot retain execution overlays', async () => {
  const complete = {...validContractV3,bias:'BUY',summary:'ساختار صعودی مشاهده می‌شود.',observations:['تأیید ورود در تایم‌فریم پنج دقیقه دیده می‌شود.'],risks:[],confidence:80,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:80,marketStructure:80,liquidity:80,entryConfirmation:80,riskReward:80},overlays:validBuyOverlays()};
  const result = await call('/analyze', input, async () => new Response(JSON.stringify({candidates:[{finishReason:'MAX_TOKENS',content:{parts:[{text:JSON.stringify(complete)}]}}]}),{status:200}));
  const ai = result.body.providers.gemini;
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.contractStatus,'DEGRADED');
  assert.equal(ai.weightsProvided,false);
  assert.equal(ai.normalization.providerCompletionTruncated,true);
  assert.equal(ai.overlays.some(x=>['Entry','SL','TP1','TP2','TP3'].includes(x.kind)),false);
});

test('newly discovered live Gemini models are retained alongside curated candidates', async () => {
  const result = await call('/models', null, async (url) => {
    const value = String(url);
    if (value.includes('generativelanguage.googleapis.com')) return new Response(JSON.stringify({models:[
      {name:'models/gemini-live-new',supportedGenerationMethods:['generateContent'],inputTokenLimit:32768,outputTokenLimit:8192},
      {name:'models/gemini-3.8-flash',supportedGenerationMethods:['generateContent'],inputTokenLimit:32768,outputTokenLimit:8192}
    ]}),{status:200});
    if (value.includes('api.groq.com')) return new Response(JSON.stringify({data:[]}),{status:200});
    return new Response(JSON.stringify({data:[]}),{status:200});
  });
  assert.equal(result.status,200);
  assert.ok(result.body.providers.gemini.models.includes('gemini-live-new'));
  assert.ok(result.body.providers.gemini.models.includes('gemini-3.8-flash'));
});

test('each AI provider response requires Persian narrative and its own complete coherent trade plan', async () => {
  const selected = {...input, selectedProviders:['gemini']};
  const result = await call('/analyze', selected, async () => geminiResponse());
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.bias,'BUY');
  assert.deepEqual(ai.overlays.filter(x=>['Entry','SL','TP1','TP2','TP3'].includes(x.kind)).map(x=>x.kind),['Entry','SL','TP1','TP2','TP3']);
  assert.ok(ai.overlays.some(x=>x.kind==='Bullish OB'));
  assert.ok(ai.overlays.some(x=>x.kind==='Bullish FVG'));
  assert.match(ai.summary,/\p{Script=Arabic}/u);
});

test('English narrative is rejected and cannot be displayed as an AI analysis', async () => {
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({bias:'WAIT',summary:'Market is bullish and ready',observations:['higher highs'],risks:[],confidence:55,overlays:[]})));
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.bias,'WAIT');
  assert.match(result.body.providers.gemini.rawText,/Market is bullish/);
});

test('BUY plan with inverted stop or targets is rejected', async () => {
  const broken = validBuyOverlays().map(x=>x.kind==='SL'?{...x,price:101}:x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({bias:'BUY',summary:'سناریوی صعودی نیازمند تأیید نهایی است.',observations:[],risks:[],confidence:65,overlays:broken})));
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.bias,'WAIT');
});


test('SELL plans require descending targets and are kept as a provider-specific output', async () => {
  const sellHistory=structuredClone(input.marketHistory);
  sellHistory['1h']=makeTrendHistory(3600,60,'sell');
  sellHistory['15m']=makeTrendHistory(900,60,'sell');
  sellHistory['5m']=makeTrendHistory(300,60,'sell');
  const sell = [
    {type:'zone',kind:'Bearish OB',price:null,low:100,high:101,timeframe:'15m',direction:'bearish',status:'ACTIVE',timestamp:sellHistory['15m'].timeStart+57*900,evidence:'کندل صعودی مبنا و جابه‌جایی نزولی پس از آن ثبت شده است'},
    {type:'zone',kind:'Bearish FVG',price:null,low:100.4,high:100.6,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'Entry',price:100.5,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'SL',price:101.5,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'TP1',price:99.5,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'TP2',price:98.8,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'TP3',price:98.0,low:null,high:null,timeframe:'5m',direction:'bearish'}
  ];
  const selected={...input,marketHistory:sellHistory,selectedProviders:['gemini']};
  const sellResponse={...validContractV3,
    timeframeAnalysis:Object.fromEntries(['1h','15m','5m'].map(tf=>[tf,{...validContractV3.timeframeAnalysis[tf],trend:'BEARISH',structure:'BEARISH'}])),
    bias:'SELL',summary:'ساختار کوتاه‌مدت نشانه‌های نزولی دارد و شکست حمایت باید تأیید شود.',
    observations:['قیمت زیر محدوده عرضه معامله می‌شود.'],risks:[],confidence:68,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:68,marketStructure:68,liquidity:68,entryConfirmation:68,riskReward:68},overlays:sell};
  const result=await call('/analyze',selected,async()=>geminiResponse(JSON.stringify(sellResponse)));
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.bias,'SELL');
  assert.equal(result.body.providers.gemini.overlays.find(x=>x.kind==='TP3').price,98.0);
});

test('Gemini and OpenRouter keep their own separate overlays and plans without cross-model replacement', async () => {
  const selected={...input,selectedProviders:['gemini','openrouter'],modelSelection:{gemini:'gemini-3.8-flash',openrouter:'qwen/qwen3.8-27b:free'}};
  const result=await call('/analyze',selected,async url=>{
    if(String(url).includes('generativelanguage'))return geminiResponse();
    const different=validBuyOverlays().map(x=>x.kind==='Entry'?{...x,price:100.6}:x.kind==='SL'?{...x,price:98.4}:x.kind==='TP1'?{...x,price:102.8}:x.kind==='TP2'?{...x,price:103.9}:x.kind==='TP3'?{...x,price:105.0}:x);
    return new Response(JSON.stringify({model:'test/free-model',choices:[{finish_reason:'stop',message:{content:JSON.stringify({...validContractV3,bias:'BUY',summary:'ساختار صعودی از دید مستقل این مدل قابل بررسی است.',observations:[],risks:[],confidence:67,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:67,marketStructure:67,liquidity:67,entryConfirmation:67,riskReward:67},overlays:different})}}]}),{status:200});
  });
  const g=result.body.providers.gemini, o=result.body.providers.openrouter;
  assert.equal(g.status,'ok');assert.equal(o.status,'ok');
  assert.equal(g.overlays.find(x=>x.kind==='Entry').price,100.5);
  assert.equal(o.overlays.find(x=>x.kind==='Entry').price,100.6);
  assert.notDeepEqual(g.overlays,o.overlays);
});

test('a plausible-looking but stale BUY entry beyond the live-price ATR envelope is rejected', async () => {
  const stale=validBuyOverlays().map(item=>item.kind==='Entry'?{...item,price:104}:item.kind==='SL'?{...item,price:102}:item.kind==='TP1'?{...item,price:106}:item.kind==='TP2'?{...item,price:107}:item.kind==='TP3'?{...item,price:108}:item);
  const response={...validContractV3,bias:'BUY',summary:'سناریوی خرید با سطوح پیشنهادی نیازمند بررسی است.',observations:[],risks:[],confidence:75,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:75,marketStructure:75,liquidity:70,entryConfirmation:75,riskReward:75},overlays:stale};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  const ai=result.body.providers.gemini;
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.executionPriceValidation.status,'INCOMPLETE','the stale Entry is removed before geometry validation, leaving an incomplete plan');
  assert.ok(ai.rejectedOverlays > 0 || ai.risks.some(reason=>reason.includes('سطح خارج از محدوده')));
  assert.equal(ai.overlays.some(item=>['Entry','SL','TP1','TP2','TP3'].includes(item.kind)),false);
});

test('a stop placed inside the only candle-validated POI is rejected even when price order and R multiples look valid', async () => {
  const insidePoi=validBuyOverlays().map(item=>item.kind==='SL'?{...item,price:99.5}:item);
  const response={...validContractV3,bias:'BUY',summary:'سناریوی خرید از نظر جهت و اهداف قابل بررسی است.',observations:[],risks:[],confidence:75,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:75,marketStructure:75,liquidity:70,entryConfirmation:75,riskReward:75},overlays:insidePoi};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  const ai=result.body.providers.gemini;
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.executionPriceValidation.status,'INVALID');
  assert.ok(ai.executionPriceValidation.reasons.some(reason=>reason.includes('POI فعال')));
});

test('execution levels outside historical price bounds are removed and the AI signal is downgraded to WAIT', async () => {
  const extended = validBuyOverlays().map(x => x.kind === 'TP3' ? {...x, price: 500} : x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({
    ...validContractV3,bias:'BUY',summary:'سناریوی صعودی فقط در صورت حفظ ساختار معتبر است.',observations:[],risks:[],confidence:70,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:70,marketStructure:70,liquidity:70,entryConfirmation:70,riskReward:70},overlays:extended
  })));
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.confidence,0);
  assert.equal(ai.overlays.some(x=>['Entry','SL','TP1','TP2','TP3'].includes(x.kind)),false);
  assert.ok(ai.risks.some(x=>x.includes('سطح خارج') || x.includes('برنامه ورود') || x.includes('POI معتبر')));
});


test('BUY signal is downgraded when every available POI is outside the submitted market-history envelope', async () => {
  const invalidZone = validBuyOverlays().map(x => ['Bullish OB','Bullish FVG'].includes(x.kind) ? {...x, low: 180, high: 181} : x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({
    bias:'BUY',summary:'سناریوی صعودی تنها با ناحیه تقاضای معتبر قابل قبول است.',observations:[],risks:[],confidence:72,overlays:invalidZone
  })));
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.confidence,0);
  assert.equal(ai.overlays.some(x=>['Entry','SL','TP1','TP2','TP3'].includes(x.kind)),false);
  assert.equal(ai.overlays.some(x=>x.kind==='Bullish OB'),false);
  assert.ok(ai.risks.some(x=>x.includes('POI معتبر')));
});

test('a valid OB alone is sufficient POI; FVG is not mandatory', async () => {
  const obOnly = validBuyOverlays().filter(x => x.kind !== 'Bullish FVG').map(x => x.kind==='SL'?{...x,price:98.5}:x);
  const response = JSON.stringify({...validContractV3,bias:'BUY',summary:'ناحیه تقاضای معتبر با ساختار صعودی هم‌راستا است.',observations:['بازآزمایی ناحیه تقاضا قابل مشاهده است.'],risks:[],confidence:72,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:75,marketStructure:75,liquidity:70,entryConfirmation:80,riskReward:70},overlays:obOnly});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  assert.equal(result.body.providers.gemini.bias,'BUY');
  assert.ok(result.body.providers.gemini.overlays.some(x=>x.kind==='Bullish OB' && x.validation==='CANDLE_BACKED' && x.status==='ACTIVE'));
  assert.equal(result.body.providers.gemini.overlays.some(x=>x.kind==='Bullish FVG'),false);
});

test('a POI marked ACTIVE is downgraded to MITIGATED when later candles retest the zone', async () => {
  const touched=structuredClone(input);
  touched.marketHistory['15m'].rows[59]=[900,-20000,0,-30000,-25000,100];
  const response={...validContractV3,bias:'BUY',summary:'ناحیه تقاضا پس از بازگشت قیمت دیگر فعال نیست.',observations:[],risks:[],confidence:75,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:75,marketStructure:75,liquidity:70,entryConfirmation:80,riskReward:70},
    overlays:validBuyOverlays().map(item=>item.kind==='Bullish OB'?{...item,timestamp:touched.marketHistory['15m'].timeStart+57*900,status:'ACTIVE'}:item)};
  const result=await call('/analyze',touched,async()=>geminiResponse(JSON.stringify(response)));
  const ai=result.body.providers.gemini;
  assert.equal(ai.overlays.find(x=>x.kind==='Bullish OB').status,'MITIGATED');
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.evidenceStatus,'VALIDATED');
  assert.equal(ai.tradePlanEligible,false);
});

test('a bullish FVG is accepted only when its exact three-candle gap exists in the selected timeframe', async () => {
  const candles=makeTrendCandles(60,'buy');
  candles[57]={open:100,high:100.2,low:99.8,close:100.1};
  candles[58]={open:100.3,high:100.5,low:100.25,close:100.4};
  candles[59]={open:100.7,high:101,low:100.6,close:100.8};
  const fvgInput=structuredClone(input);
  fvgInput.marketHistory['5m']=encodeCandles(300,candles);fvgInput.lastClosed5mClose=100.8;fvgInput.referencePrice=100.8;
  const fvgTime=fvgInput.marketHistory['5m'].timeStart+59*300;
  const response={...validContractV3,bias:'BUY',summary:'شکاف ارزش منصفانه با سه کندل متوالی تأیید شده است.',observations:[],risks:[],confidence:70,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:70,marketStructure:70,liquidity:65,entryConfirmation:75,riskReward:70},
    overlays:[{type:'zone',kind:'Bullish FVG',price:null,low:100.2,high:100.6,timeframe:'5m',direction:'bullish',status:'ACTIVE',timestamp:fvgTime,evidence:'شکاف بین سقف کندل اول و کف کندل سوم'} ,
      {type:'line',kind:'Entry',price:100.8,low:null,high:null,timeframe:'5m',direction:'bullish'},
      {type:'line',kind:'SL',price:100,low:null,high:null,timeframe:'5m',direction:'bullish'},
      {type:'line',kind:'TP1',price:101.6,low:null,high:null,timeframe:'5m',direction:'bullish'},
      {type:'line',kind:'TP2',price:102,low:null,high:null,timeframe:'5m',direction:'bullish'},
      {type:'line',kind:'TP3',price:102.4,low:null,high:null,timeframe:'5m',direction:'bullish'}]};
  const result=await call('/analyze',fvgInput,async()=>geminiResponse(JSON.stringify(response)));
  const ai=result.body.providers.gemini;
  assert.equal(ai.overlays.find(x=>x.kind==='Bullish FVG').validation,'CANDLE_BACKED');
  assert.equal(ai.overlays.find(x=>x.kind==='Bullish FVG').status,'ACTIVE');
  assert.equal(ai.bias,'BUY');
});

test('directional OB/FVG metadata must agree with the zone label', async () => {
  const invalidZone = validBuyOverlays().filter(x => x.kind !== 'Bullish OB').map(x => x.kind === 'Bullish FVG' ? {...x, direction:'bearish'} : x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({
    bias:'BUY',summary:'ساختار صعودی برای ورود به تأیید نیاز دارد.',observations:[],risks:[],confidence:70,overlays:invalidZone
  })));
  assert.notEqual(result.body.providers.gemini.bias,'BUY');
  assert.equal(result.body.providers.gemini.status,'ok');
});

test('provider analytical weights are normalized and factor scores are preserved independently', async () => {
  const response = JSON.stringify({...validContractV3,bias:'WAIT',summary:'برای ورود هنوز تأیید کافی دیده نمی‌شود.',observations:['ساختار کوتاه‌مدت خنثی است.'],risks:['شکست محدوده می‌تواند نوسان را افزایش دهد.'],confidence:62,analyticalWeights:{trend:40,marketStructure:20,liquidity:15,entryConfirmation:15,riskReward:10},factorScores:{trend:80,marketStructure:65,liquidity:55,entryConfirmation:60,riskReward:75},overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.weightsProvided,true);
  assert.equal(Object.values(ai.analyticalWeights).reduce((a,b)=>a+b,0),100);
  assert.equal(ai.analyticalWeights.trend,40);
  assert.equal(ai.factorScores.riskReward,75);
});

test('legacy or incomplete analysis contract is marked degraded and cannot provide Hybrid weights', async () => {
  const incomplete = {...validContractV3, evidence:[], timeframeAnalysis:{...validContractV3.timeframeAnalysis, '5m':{trend:'UNKNOWN'}}};
  const response = JSON.stringify({...incomplete,bias:'WAIT',summary:'برای ورود تأیید کافی وجود ندارد.',observations:[],risks:[],confidence:55,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:50,marketStructure:50,liquidity:50,entryConfirmation:50,riskReward:50},overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  assert.equal(result.body.providers.gemini.contractStatus,'NORMALIZED');
  assert.equal(result.body.providers.gemini.weightsProvided,true);
});

test('legacy model response without self-assigned weights is marked unqualified for hybrid decisions', async () => {
  const response = JSON.stringify({bias:'WAIT',summary:'بازار هنوز جهت مشخصی ندارد و بهتر است منتظر ماند.',observations:[],risks:[],confidence:45,overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.weightsProvided,false);
});


test('altFINS quota endpoint uses the server secret and exposes balances without exposing the key', async () => {
  const originalFetch = globalThis.fetch;
  let requestHeaders;
  globalThis.fetch = async (url, options) => {
    assert.match(String(url), /monthly-available-permits$/);
    requestHeaders = new Headers(options.headers);
    return new Response(JSON.stringify({availablePermits:29,monthlyAvailablePermits:987,monthlyAvailableAiTradeSetupPrompts:0}), {status:200});
  };
  try {
    const request = new Request('https://gateway.test/altfins/quota');
    const response = await worker.fetch(request, {...env(), ALTFINS_API_KEY:'private-altfins-key'});
    const body = await response.json();
    assert.equal(response.status,200);
    assert.equal(body.quota.monthlyAvailablePermits,987);
    assert.equal(body.quota.monthlyAvailableAiTradeSetupPrompts,0);
    assert.equal(requestHeaders.get('X-API-KEY'),'private-altfins-key');
    assert.equal(JSON.stringify(body).includes('private-altfins-key'),false);
  } finally { globalThis.fetch = originalFetch; }
});

test('altFINS validation maps Binance symbols and 15m interval and returns normalized context', async () => {
  const originalFetch = globalThis.fetch;
  let sent;
  globalThis.fetch = async (url, options) => {
    assert.match(String(url), /screener-data\/search-requests/);
    sent = JSON.parse(options.body);
    assert.equal(new Headers(options.headers).get('X-API-KEY'),'private-altfins-key');
    return new Response(JSON.stringify({content:[{symbol:'BTC',name:'Bitcoin',lastPrice:65000,rsi14:54,adx:23,macd:12,macdSignalLine:8,ema9:64900,ema50:64000,ema200:61000,atr:500,volume:123456,volumeRelative:1.4,shortTermTrend:'UP',mediumTermTrend:'UP',longTermTrend:'NEUTRAL',support:63000,resistance:67000}]}),{status:200});
  };
  try {
    const request = new Request('https://gateway.test/altfins/validation', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({symbol:'BTCUSDT',timeframe:'15m',exchange:'BINANCE',tradingType:'SPOT'})});
    const response = await worker.fetch(request, {...env(), ALTFINS_API_KEY:'private-altfins-key'});
    const body = await response.json();
    assert.equal(response.status,200);
    assert.equal(body.status,'AVAILABLE');
    assert.equal(body.symbol,'BTC');
    assert.equal(body.data.rsi14,54);
    assert.equal(sent.symbols[0],'BTC');
    assert.equal(sent.timeInterval,'MINUTES15');
    assert.equal(sent.exchangeFilter,'BINANCE');
    assert.equal(sent.tradingTypeFilter,'SPOT');
  assert.equal(body.marketType,'SPOT');
    assert.equal(body.affectsTradeDecision,undefined);
  } finally { globalThis.fetch = originalFetch; }
});

test('altFINS rejects unsupported exchanges instead of silently substituting Binance', async () => {
  const originalFetch=globalThis.fetch;
  globalThis.fetch=async()=>{throw new Error('unsupported exchange must not call upstream');};
  try{
    const request=new Request('https://gateway.test/altfins/validation',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({symbol:'BTCUSDT',timeframe:'15m',exchange:'NOBITEX',tradingType:'SPOT'})});
    const response=await worker.fetch(request,{...env(),ALTFINS_API_KEY:'private-altfins-key'});
    const body=await response.json();
    assert.equal(response.status,400);
    assert.equal(body.status,'UNSUPPORTED_EXCHANGE');
    assert.equal(body.exchange,'NOBITEX');
  }finally{globalThis.fetch=originalFetch;}
});

test('altFINS unsupported 5m timeframe is rejected without spending API credits', async () => {
  const originalFetch = globalThis.fetch;
  let called = false;
  globalThis.fetch = async () => { called = true; throw new Error('must not call altFINS'); };
  try {
    const request = new Request('https://gateway.test/altfins/validation', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({symbol:'BTCUSDT',timeframe:'5m'})});
    const response = await worker.fetch(request, {...env(), ALTFINS_API_KEY:'private-altfins-key'});
    const body = await response.json();
    assert.equal(response.status,400);
    assert.equal(body.status,'INVALID_INPUT');
    assert.equal(called,false);
  } finally { globalThis.fetch = originalFetch; }
});

test('altFINS Basic plan restriction is soft-failed and cannot affect trade decisions', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify({message:'Forbidden'}),{status:403});
  try {
    const request = new Request('https://gateway.test/altfins/validation', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({symbol:'ETHUSDT',timeframe:'1h'})});
    const response = await worker.fetch(request, {...env(), ALTFINS_API_KEY:'private-altfins-key'});
    const body = await response.json();
    assert.equal(response.status,200);
    assert.equal(body.status,'PLAN_RESTRICTED');
    assert.equal(body.affectsTradeDecision,false);
  } finally { globalThis.fetch = originalFetch; }
});

test('OpenRouter retries endpoint incompatibility without strict schema and without require_parameters', async () => {
  let calls=0;
  const result=await call('/analyze',{...input,selectedProviders:['openrouter'],modelSelection:{openrouter:'qwen/qwen3.8-27b:free'}},async (url,options)=>{
    if(String(url).includes('/models')) return new Response(JSON.stringify({data:[{id:'qwen/qwen3.8-27b:free',architecture:{input_modalities:['text'],output_modalities:['text']},pricing:{prompt:'0',completion:'0'},context_length:262144,supported_parameters:[]}]}),{status:200});
    calls++;
    const sent=JSON.parse(options.body);
    if(calls===1) { assert.equal(sent.provider.require_parameters,undefined); return new Response(JSON.stringify({error:{message:'No endpoints found that support the requested parameters'}}),{status:404}); }
    assert.equal(sent.response_format,undefined); assert.equal(sent.reasoning,undefined); assert.equal(sent.provider.require_parameters,undefined); assert.equal(sent.model,'qwen/qwen3.8-27b:free');
    assert.deepEqual(sent.provider,{allow_fallbacks:false});
    return openRouterResponse();
  });
  assert.equal(calls,2);
  assert.equal(result.body.providers.openrouter.status,'ok');
  assert.equal(result.body.providers.openrouter.contractVersion,3);
});

test('V3 preserves small buyer/seller rounding drift without rewriting provider values', async () => {
  const normalized = {...validContractV3,
    timeframeAnalysis: Object.fromEntries(['1h','15m','5m'].map(tf=>[tf,{...validContractV3.timeframeAnalysis[tf],buyerStrength:67,sellerStrength:34}])),
    analysisSections:{...validAnalysisSectionsV3,scenarios:{status:'INSUFFICIENT_DATA',findings:[]}},
    bias:'WAIT',summary:'داده‌های فعلی برای ورود قطعی کافی نیستند.',observations:[],risks:[],confidence:30,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:30,marketStructure:30,liquidity:30,entryConfirmation:30,riskReward:30},overlays:[]
  };
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(normalized)));
  const ai=result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.contractStatus,'VALID');
  assert.equal(ai.timeframeAnalysis['5m'].buyerStrength,67);
  assert.equal(ai.timeframeAnalysis['5m'].sellerStrength,34);
  assert.equal(ai.timeframeAnalysis['5m'].strengthComparable,true);
  assert.equal(ai.analysisSections.scenarios.status,'INSUFFICIENT_DATA');
  assert.ok(ai.analysisSections.scenarios.findings.length===0);
});

test('V3 accepts empty findings for explicit insufficient/unavailable sections but rejects empty AVAILABLE sections', async () => {
  const allowed = {...validContractV3, bias:'WAIT', summary:'اطلاعات این بخش در داده‌های ورودی موجود نیست.', observations:[], risks:[], confidence:null, overlays:[],
    analysisSections:{...validAnalysisSectionsV3, liquidity:{status:'INSUFFICIENT_DATA',findings:[]}, poi:{status:'NOT_AVAILABLE',findings:[]}}};
  const good = await call('/analyze', input, async()=>geminiResponse(JSON.stringify(allowed)));
  assert.equal(good.body.providers.gemini.contractStatus,'VALID');
  assert.deepEqual(good.body.providers.gemini.analysisSections.liquidity,{status:'INSUFFICIENT_DATA',findings:[]});
  const malformed = {...allowed, analysisSections:{...allowed.analysisSections, regime:{status:'AVAILABLE',findings:[]}}};
  const bad = await call('/analyze', input, async()=>geminiResponse(JSON.stringify(malformed)));
  assert.notEqual(bad.body.providers.gemini.contractStatus,'VALID');
  const missingField = {...allowed, analysisSections:{...allowed.analysisSections, poi:{status:'NOT_AVAILABLE'}}};
  const missing = await call('/analyze', input, async()=>geminiResponse(JSON.stringify(missingField)));
  assert.notEqual(missing.body.providers.gemini.contractStatus,'VALID');
});

test('V3 timeframe normalization preserves valid fields when one strength field is missing and accepts provider casing aliases', async () => {
  const varied = JSON.parse(JSON.stringify(validContractV3));
  varied.timeframeAnalysis = {
    '1H': {...varied.timeframeAnalysis['1h'], buyerStrength:null},
    '15M': {...varied.timeframeAnalysis['15m'], trend:'bull', structure:'transition', phase:'trend', liquidity:'sell_side_sweep'},
    '5M': {...varied.timeframeAnalysis['5m']}
  };
  const response = JSON.stringify({...varied,bias:'WAIT',summary:'برای ورود هنوز شواهد کافی وجود ندارد.',observations:[],risks:[],confidence:50,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:50,marketStructure:50,liquidity:50,entryConfirmation:50,riskReward:50},overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  const tf = result.body.providers.gemini.timeframeAnalysis;
  assert.equal(tf['1h'].trend,'BULLISH');
  assert.equal(tf['1h'].structure,'BULLISH');
  assert.equal(tf['1h'].buyerStrength,null);
  assert.equal(tf['1h'].sellerStrength,null);
  assert.equal(tf['1h'].strengthStatus,'INSUFFICIENT_DATA');
  assert.equal(result.body.providers.gemini.contractStatus,'VALID');
  assert.equal(result.body.providers.gemini.weightsProvided,true, 'missing optional strength must not disqualify an otherwise complete analysis contract');
  assert.equal(tf['15m'].trend,'BULLISH');
  assert.equal(tf['15m'].structure,'TRANSITION');
  assert.equal(tf['15m'].phase,'TRENDING');
  assert.equal(tf['15m'].liquidity,'SELL_SIDE_SWEEP');
  assert.equal(tf['5m'].trend,'BULLISH');
});

test('V3 contract rejects missing comprehensive analysis sections', async () => {
  const bad={...validAnalysisSectionsV3}; delete bad.scenarios;
  const result=await call('/analyze',input,async (url)=>{
    if(String(url).includes('generateContent')) return geminiResponse(JSON.stringify({...validContractV3,analysisSections:bad,bias:'WAIT',summary:'تحلیل نیازمند داده بیشتری است.',observations:[],risks:[],confidence:0,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:0,marketStructure:0,liquidity:0,entryConfirmation:0,riskReward:0},overlays:[]}));
    throw new Error('unexpected provider');
  });
  assert.equal(result.body.providers.gemini.contractStatus,'NORMALIZED');
  assert.equal(result.body.providers.gemini.weightsProvided,true);
});


test('timeframe parser recognizes explicit BOS/CHOCH aliases and does not mislabel omitted timeframes as UNKNOWN', async () => {
  const varied = {...validContractV3, timeframeAnalysis: {
    '1H': {trend:'uptrend',structure:'BOS bullish',phase:'markup',buyerStrength:60,sellerStrength:40,liquidity:'none',evidence:['کف بالاتر و شکست سقف ساختاری مشاهده شد']},
    '15M': {trend:'bearish',structure:'CHOCH bearish',phase:'trend',buyerStrength:35,sellerStrength:65,liquidity:'SSL',evidence:['تغییر ساختار نزولی پس از شکست کف ثبت شد']}
  }};
  const response = JSON.stringify({...varied,bias:'WAIT',summary:'برای ورود هنوز شواهد کافی وجود ندارد.',observations:[],risks:[],confidence:30,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:30,marketStructure:30,liquidity:30,entryConfirmation:30,riskReward:30},overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  const tf = result.body.providers.gemini.timeframeAnalysis;
  assert.equal(tf['1h'].provided,true);
  assert.equal(tf['1h'].structure,'BULLISH');
  assert.equal(tf['1h'].structureEvent,'BOS_BULLISH');
  assert.equal(tf['15m'].structure,'TRANSITION');
  assert.equal(tf['15m'].structureEvent,'CHOCH_BEARISH');
  assert.equal(tf['15m'].trend,'BEARISH');
  assert.equal(tf['15m'].liquidity,'SELL_SIDE_LIQUIDITY_POOL');
  assert.equal(tf['5m'].provided,false);
  assert.equal(tf['5m'].structure,'UNKNOWN');
  assert.notEqual(result.body.providers.gemini.contractStatus,'VALID');
});

test('explicit sweep events and liquidity pools remain semantically distinct', async () => {
  const response = {...validContractV3, timeframeAnalysis:{
    '1h':{...validContractV3.timeframeAnalysis['1h'],liquidity:'BSL'},
    '15m':{...validContractV3.timeframeAnalysis['15m'],liquidity:'SSL'},
    '5m':{...validContractV3.timeframeAnalysis['5m'],liquidity:'BUY_SIDE_SWEEP'}
  },bias:'WAIT',summary:'سطوح نقدینگی و رویداد جاروب به‌صورت مستقل تفکیک شدند.',observations:[],risks:[],confidence:40,
  analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
  factorScores:{trend:40,marketStructure:40,liquidity:40,entryConfirmation:40,riskReward:40},overlays:[]};
  const result = await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  const tf=result.body.providers.gemini.timeframeAnalysis;
  assert.equal(tf['1h'].liquidity,'BUY_SIDE_LIQUIDITY_POOL');
  assert.equal(tf['15m'].liquidity,'SELL_SIDE_LIQUIDITY_POOL');
  assert.equal(tf['5m'].liquidity,'BUY_SIDE_SWEEP');
});

test('negated or unconfirmed CHOCH evidence cannot become a directional structure event', async () => {
  const response = {...validContractV3,timeframeAnalysis:{...validContractV3.timeframeAnalysis,
    '5m':{...validContractV3.timeframeAnalysis['5m'],structure:'BULLISH',structureEvent:'CHOCH_BULLISH',evidence:['شکست CHOCH صعودی هنوز تأیید نشده است']}
  },bias:'WAIT',summary:'رویداد ساختاری هنوز تأیید نشده است.',observations:[],risks:[],confidence:20,
  analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
  factorScores:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},overlays:[]};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  const tf=result.body.providers.gemini.timeframeAnalysis['5m'];
  assert.equal(tf.structureEvent,'UNKNOWN');
  assert.equal(tf.structure,'UNKNOWN');
  assert.notEqual(result.body.providers.gemini.contractStatus,'VALID');
});

test('overlay normalization preserves mitigation state, timestamp and provider evidence', async () => {
  const response={...validContractV3,bias:'WAIT',summary:'وضعیت ناحیه همراه با زمان و شواهد نگهداری شد.',observations:[],risks:[],confidence:20,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    overlays:[{type:'zone',kind:'Bullish OB',price:null,low:99.8,high:100.1,timeframe:'15m',direction:'bullish',status:'MITIGATED',timestamp:1700000300,evidence:'قیمت پیش‌تر به محدوده بازگشته و آن را مصرف کرده است'}]};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  const zone=result.body.providers.gemini.overlays.find(item=>item.kind==='Bullish OB');
  assert.equal(zone.status,'MITIGATED');
  assert.equal(zone.timestamp,1700000300);
  assert.match(zone.sourceEvidence,/مصرف کرده/);
  assert.equal(zone.provenance,'provider_unverified');
  assert.equal(zone.validation,'UNVERIFIED');
});

test('supplementary categories exclude canonical analysis and metadata noise', async () => {
  const responseObject = {...validContractV3,bias:'WAIT',summary:'تحلیل فعلی برای ورود کافی نیست.',observations:[],risks:[],confidence:25,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:25,marketStructure:25,liquidity:25,entryConfirmation:25,riskReward:25},overlays:[],
    additionalData:{openInterest:1250000,fundingRate:'نرخ تأمین مالی مثبت و محدود گزارش شده است.',orderBook:'عمق سفارش خرید در نزدیکی قیمت بیشتر گزارش شده است.'}};
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify(responseObject)));
  const categories = result.body.providers.gemini.dataCategories;
  assert.equal(categories.derivatives.length,2);
  assert.ok(categories.derivatives.some(x=>x.text==='1250000'));
  assert.equal(categories.orderBook.length,1);
  assert.equal(categories.marketStructure,undefined);
  assert.equal(categories.marketRegime,undefined);
  for (const items of Object.values(categories)) {
    for (const item of items) assert.match(item.sourcePath,/^additionalData\./);
  }
});

test('historyStartPrice is treated only as the first-candle decoding seed, not a live-price anchor', async () => {
  const newInput = JSON.parse(JSON.stringify(input));
  const lastClose = 100;
  for (const [tf,interval] of [['1h',3600],['15m',900],['5m',300]]) {
    newInput.marketHistory[tf]=makeHistory(interval);
    newInput.marketHistory[tf].historyStartPrice = 100;
    delete newInput.marketHistory[tf].basePrice;
  }
  newInput.referencePrice = lastClose;
  newInput.lastClosed5mClose = lastClose;
  const result = await call('/analyze', newInput, async (url, options) => {
    const request = JSON.parse(options.body);
    const prompt = request.contents?.[0]?.parts?.[0]?.text || '';
    assert.match(prompt, /historyStartPrice/);
    assert.match(prompt, /NOT the current price/);
    assert.match(prompt, /Never compare historyStartPrice values across timeframes/);
    return geminiResponse(JSON.stringify({...validContractV3,bias:'WAIT',summary:'قیمت مرجع با آخرین کندل بسته‌شده هم‌خوان است و هنوز تأیید ورود وجود ندارد.',observations:[],risks:[],confidence:35,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:35,marketStructure:35,liquidity:35,entryConfirmation:35,riskReward:35},overlays:[]}));
  });
  assert.equal(result.status,200);
  assert.equal(result.body.providers.gemini.status,'ok');
});


test('timeframe normalizer extracts explicit Persian and English timeframe findings from provider prose without qualifying incomplete contracts', async () => {
  const varied = {...validContractV3};
  delete varied.timeframeAnalysis;
  varied.summary = 'تحلیل مستقل مدل:\n1H: ساختار BEARISH است؛ سقف و کف‌های پایین‌تر دیده می‌شود.\n15M: ساختار RANGE/ACCUMULATION است و قیمت بین یک دامنه محدود نوسان می‌کند.\n5M: ساختار BEARISH است؛ پس از شکست نزولی BOS_BEArISH قیمت به دنبال نزول ادامه داده است.';
  const response = JSON.stringify({...varied,bias:'WAIT',observations:[],risks:[],confidence:45,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:45,marketStructure:45,liquidity:45,entryConfirmation:45,riskReward:45},overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  const tf = result.body.providers.gemini.timeframeAnalysis;
  assert.equal(tf['1h'].provided,true);
  assert.equal(tf['1h'].trend,'BEARISH');
  assert.equal(tf['15m'].trend,'RANGE');
  assert.equal(tf['15m'].phase,'ACCUMULATION');
  assert.equal(tf['5m'].trend,'BEARISH');
  assert.notEqual(result.body.providers.gemini.contractStatus,'VALID');
});


test('Groq normalizer extracts buyer/seller percentages from nested objects and Persian percent strings', async () => {
  const groqInput = {...input, selectedProviders:['groq'], modelSelection:{groq:'openai/gpt-oss-120b'}};
  const nested = {
    contractVersion:3,
    timeframeAnalysis:{
      '5M': {
        trend:'BEARISH', structure:'BEARISH', structureEvent:'BOS_BEARISH', phase:'BEARISH', liquidity:'NONE',
        buyerSellerStrength:{buyers:'٣٥٪', sellers:{value:'65%'}},
        evidence:['در تایم‌فریم پنج دقیقه فشار فروش غالب است و شکست ساختار ثبت شده است.']
      }
    },
    bias:'WAIT', summary:'ساختار نزولی است و برای ورود باید تأیید بیشتری دریافت شود.', observations:[], risks:[], confidence:55,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:55,marketStructure:55,liquidity:55,entryConfirmation:55,riskReward:55}, overlays:[]
  };
  const result = await call('/analyze', groqInput, async () => new Response(JSON.stringify({model:'openai/gpt-oss-120b',choices:[{finish_reason:'stop',message:{content:JSON.stringify({result:JSON.stringify(nested)})}}]}),{status:200}));
  const groq = result.body.providers.groq;
  assert.equal(groq.timeframeAnalysis['5m'].provided,true);
  assert.equal(groq.timeframeAnalysis['5m'].buyerStrength,35);
  assert.equal(groq.timeframeAnalysis['5m'].sellerStrength,65);
  assert.equal(groq.timeframeAnalysis['5m'].strengthMethod,'PROVIDER_DECLARED_COMPLEMENTARY_PERCENT');
  assert.equal(groq.timeframeAnalysis['5m'].strengthSource,'MODEL_RESPONSE');
  assert.match(groq.rawProviderResponse,/openai\/gpt-oss-120b/);
});


test('AI-declared buyer/seller percentages are never mislabeled as independently computed OHLCV pressure', async () => {
  const response={...validContractV3,bias:'WAIT',summary:'درصدهای اعلامی مدل از توازن نسبی خریدار و فروشنده حکایت دارند.',
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:50,marketStructure:50,liquidity:50,entryConfirmation:50,riskReward:50},overlays:[]};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  const strength=result.body.providers.gemini.timeframeAnalysis['5m'];
  assert.equal(strength.strengthMethod,'PROVIDER_DECLARED_COMPLEMENTARY_PERCENT');
  assert.equal(strength.strengthSource,'MODEL_RESPONSE');
  assert.notEqual(strength.strengthMethod,'ESTIMATED_OHLCV_CANDLE_PRESSURE');
});

test('ambiguous MSS or CHOCH never receives an invented bullish direction', async () => {
  const ambiguous = JSON.parse(JSON.stringify(validContractV3));
  ambiguous.timeframeAnalysis['15m'].structureEvent = 'MSS';
  ambiguous.timeframeAnalysis['15m'].evidence = ['تغییر ساختار در محدوده فعلی مشاهده شد اما جهت شکست مشخص نیست'];
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({
    ...ambiguous,bias:'WAIT',summary:'جهت رویداد ساختاری هنوز روشن نیست و ورود نیازمند تأیید است.',observations:[],risks:[],confidence:61,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:61,marketStructure:61,liquidity:61,entryConfirmation:61,riskReward:61},overlays:[]
  })));
  const tf = result.body.providers.gemini.timeframeAnalysis['15m'];
  assert.equal(tf.structureEvent,'UNKNOWN');
  assert.notEqual(result.body.providers.gemini.contractStatus,'VALID');
});

test('independent buyer and seller scores are preserved and cannot masquerade as complementary percentages', async () => {
  const independent = JSON.parse(JSON.stringify(validContractV3));
  for (const tf of ['1h','15m','5m']) {
    independent.timeframeAnalysis[tf].buyerStrength = 70;
    independent.timeframeAnalysis[tf].sellerStrength = 60;
  }
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({
    ...independent,bias:'WAIT',summary:'قدرت نسبی دو سمت به‌صورت امتیاز مستقل گزارش شده است.',observations:[],risks:[],confidence:62,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:62,marketStructure:62,liquidity:62,entryConfirmation:62,riskReward:62},overlays:[]
  })));
  const tf = result.body.providers.gemini.timeframeAnalysis['5m'];
  assert.equal(tf.buyerStrength,70);
  assert.equal(tf.sellerStrength,60);
  assert.equal(tf.strengthComparable,false);
  assert.equal(tf.strengthScale,'UNVERIFIED_INDEPENDENT_SCORES');
  assert.notEqual(result.body.providers.gemini.contractStatus,'VALID');
});

test('missing model confidence remains undeclared instead of becoming a fabricated 50 percent', async () => {
  const noConfidence = {...validContractV3,bias:'WAIT',score:88,summary:'داده کافی برای اعلام اطمینان عددی وجود ندارد.',observations:[],risks:[],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:50,marketStructure:50,liquidity:50,entryConfirmation:50,riskReward:50},overlays:[]};
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify(noConfidence)));
  assert.equal(result.body.providers.gemini.confidence,null);
  assert.equal(result.body.providers.gemini.confidenceDeclared,false);
});

test('final provider validation downgrades a correctly ordered trade plan that fails TP1/TP2/TP3 minimum R multiples', async () => {
  const lowRewardPlan = validBuyOverlays().map(item => ({...item}));
  lowRewardPlan.find(item => item.kind === 'TP2').price = 101.8;
  lowRewardPlan.find(item => item.kind === 'TP3').price = 102.0;
  const response = JSON.stringify({...validContractV3,bias:'BUY',summary:'برنامه صعودی از نظر جهت بازار قابل بررسی است اما نسبت سود به زیان اهداف کافی نیست.',observations:[],risks:[],confidence:78,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:78,marketStructure:78,liquidity:78,entryConfirmation:78,riskReward:78},overlays:lowRewardPlan});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  const provider = result.body.providers.gemini;
  assert.equal(provider.bias,'WAIT');
  assert.equal(provider.normalization.tradePlanInconsistent,true);
  assert.equal(provider.overlays.some(item => ['Entry','SL','TP1','TP2','TP3'].includes(item.kind)),false);
});

test('two evidenced directional providers can form consensus without model weights or declared confidence', async () => {
  const multi = {...input, selectedProviders:['gemini','openrouter'], modelSelection:{gemini:'gemini-3.8-flash',openrouter:'qwen/qwen3.8-27b:free'}};
  const noConfidence = {...validContractV3,bias:'BUY',summary:'ساختار صعودی است اما مدل اطمینان عددی اعلام نکرده است.',observations:[],risks:[],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:80,marketStructure:80,liquidity:80,entryConfirmation:80,riskReward:80},overlays:validBuyOverlays()};
  const raw = JSON.stringify(noConfidence);
  const result = await call('/analyze',multi,async url=>{
    if(String(url).includes('generativelanguage.googleapis.com')) return geminiResponse(raw);
    return new Response(JSON.stringify({model:'qwen/qwen3.8-27b',choices:[{finish_reason:'stop',message:{content:raw}}]}),{status:200});
  });
  assert.equal(result.body.providers.gemini.contractStatus,'VALID');
  assert.equal(result.body.providers.openrouter.contractStatus,'VALID');
  assert.equal(result.body.consensus.validProviders.length,2);
  assert.equal(result.body.consensus.voteEligibleProviders.length,2);
  assert.equal(result.body.consensus.decision,'BUY');
});

test('two SELL votes form directional AI consensus when Groq is unavailable and trade plans are incomplete', async () => {
  const sellHistory = structuredClone(input.marketHistory);
  sellHistory['1h'] = makeTrendHistory(3600,60,'sell');
  sellHistory['15m'] = makeTrendHistory(900,60,'sell');
  sellHistory['5m'] = makeTrendHistory(300,60,'sell');
  const sellPoi = [
    {type:'zone',kind:'Bearish OB',price:null,low:100,high:101,timeframe:'15m',direction:'bearish',status:'ACTIVE',timestamp:sellHistory['15m'].timeStart+57*900,evidence:'کندل مبنا و جابه‌جایی نزولی در داده ثبت شده است'}
  ];
  const sellResponse = {...validContractV3,
    timeframeAnalysis:Object.fromEntries(['1h','15m','5m'].map(tf=>[tf,{...validContractV3.timeframeAnalysis[tf],trend:'BEARISH',structure:'BEARISH'}])),
    bias:'SELL', summary:'ساختار بازار نزولی است اما برنامه ورود کامل ارائه نشده است.', observations:['سقف‌ها و کف‌های پایین‌تر مشاهده شده‌اند.'], risks:[], confidence:null,
    overlays:sellPoi,
    analysisSections:{...validAnalysisSectionsV3, execution:{status:'INSUFFICIENT_DATA',findings:[]}}
  };
  const selected={...input,marketHistory:sellHistory,selectedProviders:['gemini','openrouter','groq'],modelSelection:{gemini:'gemini-3.8-flash',openrouter:'qwen/qwen3.8-27b:free',groq:'openai/gpt-oss-120b'}};
  const raw=JSON.stringify(sellResponse);
  const result=await call('/analyze',selected,async url=>{
    if(String(url).includes('generativelanguage')) return geminiResponse(raw);
    if(String(url).includes('openrouter')) return new Response(JSON.stringify({model:'test/free-model',choices:[{finish_reason:'stop',message:{content:raw}}]}),{status:200});
    return new Response('provider unavailable',{status:503});
  });
  assert.equal(result.body.providers.gemini.marketBias,'SELL');
  assert.equal(result.body.providers.openrouter.marketBias,'SELL');
  assert.equal(result.body.providers.gemini.directionalVoteEligible,true);
  assert.equal(result.body.providers.gemini.tradePlanEligible,false);
  assert.equal(result.body.providers.groq.status,'error');
  assert.equal(result.body.consensus.decision,'SELL');
  assert.equal(result.body.consensus.voteEligibleProviders.length,2);
  assert.deepEqual(result.body.consensus.votes,{BUY:0,SELL:2,WAIT:0});
});

test('two SELL directional votes remain consensus when the third valid model returns WAIT', async () => {
  const sellHistory = structuredClone(input.marketHistory);
  sellHistory['1h'] = makeTrendHistory(3600,60,'sell');
  sellHistory['15m'] = makeTrendHistory(900,60,'sell');
  sellHistory['5m'] = makeTrendHistory(300,60,'sell');
  const sellPoi = [{type:'zone',kind:'Bearish OB',price:null,low:100,high:101,timeframe:'15m',direction:'bearish',status:'ACTIVE',timestamp:sellHistory['15m'].timeStart+57*900,evidence:'کندل مبنا و جابه‌جایی نزولی ثبت شده است'}];
  const sell = {...validContractV3,timeframeAnalysis:Object.fromEntries(['1h','15m','5m'].map(tf=>[tf,{...validContractV3.timeframeAnalysis[tf],trend:'BEARISH',structure:'BEARISH'}])),bias:'SELL',summary:'ساختار نزولی است.',observations:[],risks:[],confidence:null,overlays:sellPoi,analysisSections:{...validAnalysisSectionsV3,execution:{status:'INSUFFICIENT_DATA',findings:[]}}};
  const wait = {...validContractV3,bias:'WAIT',summary:'داده کافی برای جهت قطعی وجود ندارد.',observations:[],risks:[],confidence:null,overlays:[],analysisSections:{...validAnalysisSectionsV3,execution:{status:'INSUFFICIENT_DATA',findings:[]}}};
  const selected={...input,marketHistory:sellHistory,selectedProviders:['gemini','openrouter','groq'],modelSelection:{gemini:'gemini-3.8-flash',openrouter:'qwen/qwen3.8-27b:free',groq:'openai/gpt-oss-120b'}};
  const sellRaw=JSON.stringify(sell), waitRaw=JSON.stringify(wait);
  const result=await call('/analyze',selected,async url=>{
    if(String(url).includes('generativelanguage')) return geminiResponse(sellRaw);
    if(String(url).includes('openrouter')) return new Response(JSON.stringify({model:'test/free-model',choices:[{finish_reason:'stop',message:{content:sellRaw}}]}),{status:200});
    return new Response(JSON.stringify({model:'test/groq',choices:[{finish_reason:'stop',message:{content:waitRaw}}]}),{status:200});
  });
  assert.equal(result.body.providers.groq.bias,'WAIT');
  assert.equal(result.body.providers.groq.directionalVoteEligible,false);
  assert.equal(result.body.consensus.decision,'SELL');
  assert.deepEqual(result.body.consensus.votes,{BUY:0,SELL:2,WAIT:0});
});

test('conflicting equally ranked timeframe roots are exposed with provenance and cannot qualify the contract', async () => {
  const ambiguousRoots = {...validContractV3, alternateTimeframes: JSON.parse(JSON.stringify(validContractV3.timeframeAnalysis))};
  ambiguousRoots.alternateTimeframes['1h'].trend = 'BEARISH';
  ambiguousRoots.alternateTimeframes['1h'].structure = 'BEARISH';
  ambiguousRoots.alternateTimeframes['1h'].structureEvent = 'BOS_BEARISH';
  const response = JSON.stringify({...ambiguousRoots,bias:'WAIT',summary:'دو شاخه ساختاری متفاوت برای تایم‌فریم‌ها در پاسخ دیده شد و باید منبع روشن شود.',observations:[],risks:[],confidence:60,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:60,marketStructure:60,liquidity:60,entryConfirmation:60,riskReward:60},overlays:[]});
  const result = await call('/analyze',input,async()=>geminiResponse(response));
  const provider = result.body.providers.gemini;
  assert.equal(provider.timeframeProvenance.conflict,true);
  assert.equal(provider.timeframeProvenance.sourcePath,'$.timeframeAnalysis');
  assert.deepEqual(provider.timeframeProvenance.conflictPaths,['$.alternateTimeframes']);
  assert.notEqual(provider.contractStatus,'VALID');
});

test('V3 factor section invalidity is isolated and preserves sibling factor data and status', async () => {
  const sections = {...validAnalysisSectionsV3,
    liquidity: {status:'AVAILABLE',findings:[]},
    poi: {status:'AVAILABLE',findings:['ناحیه عرضه در محدوده مشخص‌شده قابل مشاهده است.']}
  };
  const response = JSON.stringify({...validContractV3,analysisSections:sections,bias:'WAIT',summary:'تحلیل چندعاملی با یک بخش ناقص دریافت شد.',observations:[],risks:[],confidence:null,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:70,marketStructure:70,liquidity:60,entryConfirmation:50,riskReward:50},overlays:[]});
  const result = await call('/analyze',input,async()=>geminiResponse(response));
  const provider = result.body.providers.gemini;
  assert.equal(provider.contractStatus,'NORMALIZED');
  assert.equal(provider.analysisSections.liquidity.status,'INVALID');
  assert.equal(provider.analysisSectionStatus.liquidity.reason,'AVAILABLE_REQUIRES_FINDING');
  assert.equal(provider.analysisSections.poi.status,'AVAILABLE');
  assert.equal(provider.analysisSectionStatus.poi.valid,true);
  assert.equal(provider.analysisSections.regime.status,'AVAILABLE');
  assert.equal(provider.analysisSectionStatus.regime.valid,true);
});

test('evidence failure in 5m is isolated and does not invalidate the 1h directional factor vote', async () => {
  const badEvidence = {...validContractV3,
    bias:'BUY', summary:'تحلیل صعودی با یک شاهد نامعتبر در تایم‌فریم پنج دقیقه.', observations:[], risks:[], confidence:null,
    evidence:[{timeframe:'5m',type:'STRUCTURE',event:'BOS_BEARISH',status:'CONFIRMED',explanation:'ادعای شکست نزولی در پنج دقیقه ثبت شده است.',candleTime:marketHistory['5m'].timeStart+59*300,price:100,referenceLevel:101}],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:70,marketStructure:70,liquidity:60,entryConfirmation:50,riskReward:50},overlays:[]
  };
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(badEvidence)));
  const provider=result.body.providers.gemini;
  assert.equal(provider.timeframeEvidenceValidation['5m'],'INVALID');
  assert.equal(provider.timeframeEvidenceValidation['1h'],'VALIDATED');
  assert.equal(provider.timeframeVoteEligibility['1h'].eligible,true);
  assert.equal(provider.timeframeVoteEligibility['5m'].eligible,false);
});

test('missing factor scores remain NOT_PROVIDED and are never replaced with synthetic 50-point values', async () => {
  const noScores = {...validContractV3,bias:'WAIT',summary:'امتیاز عوامل توسط مدل ارائه نشده است.',observations:[],risks:[],confidence:null,
    overlays:[],analyticalWeights:undefined,factorScores:undefined};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(noScores)));
  const provider=result.body.providers.gemini;
  assert.deepEqual(provider.factorScores,{});
  assert.deepEqual(provider.analyticalWeights,{});
  assert.equal(provider.factorScoresStatus,'NOT_PROVIDED');
  assert.equal(provider.weightsProvided,false);
});

test('factor scores and analytical weights are normalized independently when only one is supplied', async () => {
  const scoresOnly = {...validContractV3,bias:'WAIT',summary:'امتیاز شواهد عوامل موجود است اما وزن اهمیت عوامل ارائه نشده است.',observations:[],risks:[],confidence:null,
    analyticalWeights:undefined,factorScores:{trend:81,marketStructure:72,liquidity:63,entryConfirmation:54,riskReward:45},overlays:[]};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(scoresOnly)));
  const provider=result.body.providers.gemini;
  assert.equal(provider.factorScoresStatus,'PROVIDED');
  assert.equal(provider.analyticalWeightsStatus,'NOT_PROVIDED');
  assert.equal(provider.weightsProvided,false);
  assert.equal(provider.factorScores.trend,81);
  assert.deepEqual(provider.analyticalWeights,{});
});

test('invalid liquidity evidence does not invalidate independent market-structure evidence in the same timeframe', async () => {
  const response = {...validContractV3,bias:'BUY',summary:'ساختار صعودی مستقل است اما ادعای Sweep با داده نقدینگی تعارض دارد.',observations:[],risks:[],confidence:null,
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'1h':{...validContractV3.timeframeAnalysis['1h'],liquidity:'NONE'}},
    evidence:[{timeframe:'1h',type:'LIQUIDITY',event:'BUY_SIDE_SWEEP',status:'CONFIRMED',explanation:'ادعای Sweep خرید ارائه شده است.',candleTime:marketHistory['1h'].timeStart+59*3600,price:99,referenceLevel:100}],
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:80,marketStructure:80,liquidity:60,entryConfirmation:50,riskReward:50},overlays:[]};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  const provider=result.body.providers.gemini;
  assert.equal(provider.timeframeFactorEvidenceValidation['1h'].liquidity,'INVALID');
  assert.equal(provider.timeframeFactorEvidenceValidation['1h'].marketStructure,'VALIDATED');
  assert.equal(provider.timeframeVoteEligibility['1h'].eligible,true);
  assert.equal(provider.factorEvidenceValidation.liquidity,'INVALID');
  assert.equal(provider.factorEvidenceValidation.marketStructure,'VALIDATED');
});

test('unselected and failed providers do not receive fabricated zero or neutral factor scores', async () => {
  const result=await call('/analyze',{...input,selectedProviders:['gemini']},async()=>geminiResponse());
  for (const name of ['openrouter','groq']) {
    assert.equal(result.body.providers[name].status,'not_selected');
    assert.deepEqual(result.body.providers[name].factorScores,{});
    assert.deepEqual(result.body.providers[name].analyticalWeights,{});
    assert.equal(result.body.providers[name].factorScoresStatus,'NOT_PROVIDED');
  }
});

test('invalid aggregate structure section does not suppress independently validated timeframe trend votes', async () => {
  const response={...validContractV3,bias:'BUY',summary:'ساختار کلی روایت ناقص است اما داده مستقل 1H معتبر باقی مانده است.',observations:[],risks:[],confidence:null,
    analysisSections:{...validAnalysisSectionsV3,structure:{status:'AVAILABLE',findings:[]}},
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:80,marketStructure:70,liquidity:60,entryConfirmation:50,riskReward:50},overlays:[]};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  const provider=result.body.providers.gemini;
  assert.equal(provider.contractStatus,'NORMALIZED');
  assert.equal(provider.analysisSectionStatus.structure.valid,false);
  assert.equal(provider.timeframeVoteEligibility['1h'].eligible,true);
  assert.equal(provider.directionalVoteEligible,true);
});

test('text-only trend narratives with NONE structure events cannot create timeframe votes', async () => {
  const flatInput={...input,marketHistory:{format:'test delta OHLCV','1h':makeHistory(3600),'15m':makeHistory(900),'5m':makeHistory(300)}};
  const response={...validContractV3,bias:'BUY',summary:'روند صعودی در توضیحات مدل گزارش شده است.',observations:['کف‌های بالاتر در متن تحلیل ذکر شده‌اند.'],risks:[],confidence:70,overlays:[]};
  const result=await call('/analyze',flatInput,async()=>geminiResponse(JSON.stringify(response)));
  const provider=result.body.providers.gemini;
  for (const tf of ['1h','15m','5m']) {
    assert.equal(provider.timeframeFactorEvidenceValidation[tf].marketStructure,'UNVERIFIED');
    assert.equal(provider.timeframeVoteEligibility[tf].eligible,false);
    assert.ok(provider.evidenceValidation.findings.some(item=>item.timeframe===tf&&item.event==='CANDLE_SWING_TREND'&&item.status==='UNVERIFIED'));
  }
  assert.equal(provider.directionalVoteEligible,false);
});

test('a declared BOS without matching candle evidence is attributed to its timeframe as UNVERIFIED', async () => {
  const flatInput={...input,marketHistory:{format:'test delta OHLCV','1h':makeHistory(3600),'15m':makeHistory(900),'5m':makeHistory(300)}};
  const response={...validContractV3,bias:'BUY',summary:'شکست صعودی گزارش شده اما شاهد دقیق ارائه نشده است.',observations:[],risks:[],confidence:60,overlays:[],
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'1h':{...validContractV3.timeframeAnalysis['1h'],structureEvent:'BOS_BULLISH'}}};
  const result=await call('/analyze',flatInput,async()=>geminiResponse(JSON.stringify(response)));
  const provider=result.body.providers.gemini;
  assert.equal(provider.timeframeFactorEvidenceValidation['1h'].marketStructure,'UNVERIFIED');
  assert.equal(provider.timeframeVoteEligibility['1h'].eligible,false);
  assert.ok(provider.evidenceValidation.findings.some(item=>item.timeframe==='1h'&&item.event==='BOS_BULLISH'&&item.status==='UNVERIFIED'));
});

test('closed-candle HH/HL and LH/LL swing sequences validate each timeframe independently', async () => {
  const response={...validContractV3,bias:'BUY',summary:'ساختار صعودی از توالی سقف‌ها و کف‌های بالاتر تأیید می‌شود.',observations:[],risks:[],confidence:70,overlays:[]};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  const provider=result.body.providers.gemini;
  for (const tf of ['1h','15m','5m']) {
    assert.equal(provider.timeframeFactorEvidenceValidation[tf].marketStructure,'VALIDATED');
    assert.equal(provider.timeframeVoteEligibility[tf].eligible,true);
    assert.ok(provider.evidenceValidation.findings.some(item=>item.timeframe===tf&&item.event==='CANDLE_SWING_TREND'&&item.status==='VALIDATED'));
  }
});

test('a timeframe candle conflict is isolated and does not suppress a separately validated higher-timeframe vote', async () => {
  const response={...validContractV3,bias:'BUY',summary:'1H با جهت اعلامی تعارض دارد اما 15M و 5M ساختار صعودی دارند.',observations:[],risks:[],confidence:70,overlays:[],
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'1h':{...validContractV3.timeframeAnalysis['1h'],trend:'BEARISH'}}};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  const provider=result.body.providers.gemini;
  assert.equal(provider.timeframeFactorEvidenceValidation['1h'].marketStructure,'INVALID');
  assert.equal(provider.timeframeVoteEligibility['1h'].eligible,false);
  assert.equal(provider.timeframeFactorEvidenceValidation['15m'].marketStructure,'VALIDATED');
  assert.equal(provider.timeframeVoteEligibility['15m'].eligible,true);
  assert.equal(provider.timeframeVoteEligibility['5m'].eligible,true);
  assert.equal(provider.directionalVoteEligible,true);
});

test('timeframe votes remain independent when aggregate regime is invalid and provider bias is WAIT', async () => {
  const response={...validContractV3,bias:'WAIT',summary:'جهت کلی WAIT است اما روند ساختاری 1H مستقل و نزولی با شواهد کندلی معتبر ثبت شده است.',observations:[],risks:[],confidence:null,
    analysisSections:{...validAnalysisSectionsV3,regime:{status:'AVAILABLE',findings:[]}},
    timeframeAnalysis:{...validContractV3.timeframeAnalysis,'1h':{...validContractV3.timeframeAnalysis['1h'],trend:'BULLISH'}},
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:55,marketStructure:75,liquidity:60,entryConfirmation:45,riskReward:50},overlays:[]};
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
  const provider=result.body.providers.gemini;
  assert.equal(provider.analysisSectionStatus.regime.valid,false);
  assert.equal(provider.timeframeFactorEvidenceValidation['1h'].marketStructure,'VALIDATED');
  assert.equal(provider.timeframeVoteEligibility['1h'].eligible,true);
  assert.equal(provider.timeframeVoteEligibility['1h'].trend,'BULLISH');
  assert.equal(provider.directionalVoteEligible,false,'provider-level WAIT must remain separate from timeframe vote');
});

test('non-directional factor-section failures cannot contaminate independently validated market-direction votes', async () => {
  const factors=['liquidity','poi','premiumDiscount','volumeMomentum','scenarios','execution','dataQuality'];
  for (const factor of factors) {
    const sections={...validAnalysisSectionsV3,[factor]:{status:'AVAILABLE',findings:[]}};
    const response={...validContractV3,analysisSections:sections,bias:'BUY',summary:`نقص مستقل در عامل ${factor} نباید رأی روند و ساختار را حذف کند.`,observations:[],risks:[],confidence:null,
      analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
      factorScores:{trend:80,marketStructure:75,liquidity:60,entryConfirmation:50,riskReward:50},overlays:[]};
    const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(response)));
    const provider=result.body.providers.gemini;
    assert.equal(provider.analysisSectionStatus[factor].valid,false,`${factor} should be locally invalid`);
    assert.equal(provider.timeframeVoteEligibility['1h'].eligible,true,`${factor} must not suppress 1h`);
    assert.equal(provider.directionalVoteEligible,true,`${factor} must not suppress the market-direction vote`);
  }
});

test('full analysis falls back to the live-catalog secondary model when the health-probed primary fails', async () => {
  const selected = {
    ...input,
    selectedProviders:['gemini'],
    modelSelection:{gemini:'gemini-3.8-flash'},
    modelCandidates:{gemini:['gemini-3.8-flash','gemini-3.7-flash']}
  };
  const result = await call('/analyze', selected, async (url) => {
    const target=String(url);
    if (target.includes('gemini-3.8-flash:generateContent')) {
      return new Response(JSON.stringify({error:{message:'model overloaded'}}),{status:503});
    }
    if (target.includes('gemini-3.7-flash:generateContent')) return geminiResponse();
    throw new Error(`unexpected provider URL ${target}`);
  });
  assert.equal(result.status,200);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.providerModel,'gemini-3.7-flash');
  assert.equal(result.body.providers.gemini.fallbackUsed,true);
  assert.deepEqual(result.body.providers.gemini.attemptedModels,['gemini-3.8-flash','gemini-3.7-flash']);
});
