import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker.js';

const rows = Array.from({length: 60}, (_, i) => [i === 0 ? 0 : 300, 0, 10000, -10000, 5000, 100]);
const marketHistory = {
  format: 'test delta OHLCV',
  '1h': {timeStart: 1700000000, intervalSeconds: 3600, basePrice: 100, baseVolumeMedian: 10, rows},
  '15m': {timeStart: 1700000000, intervalSeconds: 900, basePrice: 100, baseVolumeMedian: 10, rows},
  '5m': {timeStart: 1700000000, intervalSeconds: 300, basePrice: 100, baseVolumeMedian: 10, rows}
};
const input = {
  exchange: 'TEST', symbol: 'BTCUSDT', snapshotId: 'snapshot-test-001',
  technicalAnalysis: {signal: 'BUY'}, marketHistory,
  selectedProviders: ['gemini'], modelSelection: {gemini: 'gemini-test-fast'}
};
function env() {
  return {
    GEMINI_API_KEY: 'test-gemini', OPENROUTER_API_KEY: 'test-openrouter', GROQ_API_KEY: 'test-groq',
    GEMINI_MODEL: 'gemini-3.5-flash-lite', GEMINI_MODELS: 'gemini-3.5-flash-lite,gemini-test-fast,gemini-retired-test',
    OPENROUTER_MODEL: 'openrouter/free', OPENROUTER_MODELS: 'openrouter/free,meta-llama/llama-3.3-70b-instruct:free',
    GROQ_MODEL: 'openai/gpt-oss-120b', GROQ_MODELS: 'openai/gpt-oss-120b,openai/gpt-oss-20b',
    GATEWAY_TOKEN: 'test-token', RATE_LIMITER: {limit: async () => ({success: true})}
  };
}
function validBuyOverlays() { return [
  {type:'zone',kind:'Bullish OB',price:null,low:99.8,high:100.1,timeframe:'15m',direction:'bullish'},
  {type:'zone',kind:'Bullish FVG',price:null,low:100.1,high:100.3,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'Entry',price:100.5,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'SL',price:99.5,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'TP1',price:101.5,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'TP2',price:102.2,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'TP3',price:103.1,low:null,high:null,timeframe:'5m',direction:'bullish'}
]; }
function geminiResponse(text = JSON.stringify({bias:'BUY',summary:'ساختار بازار متمایل به صعود است و ورود پس از تأیید محدوده انجام می‌شود.',observations:['کف‌های بالاتر در تایم‌فریم اجرایی دیده می‌شود.'],risks:['شکست حمایت نزدیک می‌تواند سناریو را باطل کند.'],confidence:75,analyticalWeights:{trend:30,marketStructure:25,liquidity:20,entryConfirmation:15,riskReward:10},factorScores:{trend:80,marketStructure:75,liquidity:65,entryConfirmation:85,riskReward:70},overlays:validBuyOverlays()})) {
  return new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text}]}}]}), {status:200});
}
function openRouterResponse() {
  return new Response(JSON.stringify({model:'test/free-model',usage:{prompt_tokens:100,completion_tokens:50},choices:[{finish_reason:'stop',message:{content:JSON.stringify({bias:'BUY',summary:'ساختار بازار نشانه‌های صعودی دارد.',observations:['حمایت کوتاه‌مدت حفظ شده است.'],risks:[],confidence:70,analyticalWeights:{trend:25,marketStructure:25,liquidity:20,entryConfirmation:20,riskReward:10},factorScores:{trend:75,marketStructure:80,liquidity:70,entryConfirmation:75,riskReward:65},overlays:validBuyOverlays()})}}]}), {status:200});
}
async function call(path, body, mockFetch, headers={}) {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = mockFetch;
  try {
    const request = new Request(`https://gateway.test${path}`, {
      method: path === '/health' || path === '/models' ? 'GET' : 'POST',
      headers: {'Content-Type':'application/json', ...headers},
      body: path === '/health' || path === '/models' ? undefined : JSON.stringify(body ?? input)
    });
    const response = await worker.fetch(request, env());
    return {status:response.status, body:await response.json()};
  } finally { globalThis.fetch = originalFetch; }
}

test('one selected model is enough to return and display an independent analysis; other providers are not called', async () => {
  let calls = 0;
  const result = await call('/analyze', input, async (url, options) => {
    calls++;
    assert.match(String(url), /gemini-test-fast/);
    return geminiResponse();
  });
  assert.equal(result.status, 200);
  assert.equal(result.body.ok, true);
  assert.equal(result.body.providers.gemini.status, 'ok');
  assert.equal(result.body.providers.gemini.providerModel, 'gemini-test-fast');
  assert.equal(result.body.providers.gemini.weightsProvided, true);
  assert.equal(Object.values(result.body.providers.gemini.analyticalWeights).reduce((a,b)=>a+b,0),100);
  assert.equal(result.body.providers.openrouter.status, 'not_selected');
  assert.equal(result.body.providers.groq.status, 'not_selected');
  assert.equal(result.body.decision, 'BUY');
  assert.equal(result.body.snapshotId, 'snapshot-test-001');
  assert.equal(calls, 1);
});

test('plain text model response is converted to a Persian WAIT explanation and never becomes a trade signal', async () => {
  const result = await call('/analyze', input, async () => geminiResponse('Market is choppy. Buyers have not confirmed a breakout yet.'));
  assert.equal(result.status, 200);
  assert.equal(result.body.providers.gemini.status, 'ok');
  assert.equal(result.body.providers.gemini.responseFormat, 'text');
  assert.equal(result.body.providers.gemini.rawText, null);
  assert.match(result.body.providers.gemini.summary, /فارسی/);
  assert.equal(result.body.providers.gemini.bias, 'WAIT');
  assert.equal(result.body.providers.gemini.confidence, 0);
  assert.equal(result.body.providers.gemini.overlays.length, 0);
});

test('requested model outside Worker allow-list is rejected without provider call', async () => {
  const bad = {...input, modelSelection:{gemini:'unknown/model'}};
  const result = await call('/analyze', bad, async () => { throw new Error('must not call provider'); });
  assert.equal(result.status, 502);
  assert.equal(result.body.ok, false);
  assert.match(result.body.providers.gemini.error, /not in the Worker allow-list/);
});

test('/models exposes configured provider model allow-lists without exposing secrets', async () => {
  const result = await call('/models', null, async () => { throw new Error('no external call expected'); });
  assert.equal(result.status, 200);
  assert.deepEqual(result.body.providers.gemini.models, ['gemini-3.5-flash-lite','gemini-test-fast','gemini-retired-test']);
  assert.deepEqual(result.body.providers.groq.models, ['openai/gpt-oss-120b','openai/gpt-oss-20b']);
  assert.equal(JSON.stringify(result.body).includes('test-gemini'), false);
});

test('one successful provider in provider-test is reported as successful connectivity', async () => {
  const result = await call('/provider-test', {selectedProviders:['gemini'],modelSelection:{gemini:'gemini-test-fast'}},
    async () => geminiResponse(), {Authorization:'Bearer test-token'});
  assert.equal(result.status, 200);
  assert.equal(result.body.ok, true);
  assert.equal(result.body.successCount, 1);
  assert.equal(result.body.requiredForDisplay, 1);
});

test('OpenRouter model selection is passed through exactly and each provider result is independent', async () => {
  const selected = {...input, selectedProviders:['openrouter'], modelSelection:{openrouter:'meta-llama/llama-3.3-70b-instruct:free'}};
  let sentModel;
  const result = await call('/analyze', selected, async (url, options) => {
    sentModel = JSON.parse(options.body).model;
    return openRouterResponse();
  });
  assert.equal(result.status, 200);
  assert.equal(sentModel, 'meta-llama/llama-3.3-70b-instruct:free');
  assert.equal(result.body.providers.openrouter.status, 'ok');
  assert.equal(result.body.providers.openrouter.providerModel, 'test/free-model');
});


test('OpenRouter retries without optional JSON schema when a free endpoint rejects it and safely rejects unstructured text', async () => {
  const selected = {...input, selectedProviders:['openrouter'], modelSelection:{openrouter:'meta-llama/llama-3.3-70b-instruct:free'}};
  let attempts = 0;
  const result = await call('/analyze', selected, async (url, options) => {
    attempts++;
    const payload = JSON.parse(options.body);
    if (attempts === 1) {
      assert.equal(payload.response_format.type, 'json_schema');
      return new Response(JSON.stringify({error:{message:'response_format json_schema is not supported by this endpoint'}}),{status:400});
    }
    assert.equal(payload.response_format, undefined);
    return new Response(JSON.stringify({model:'meta-llama/llama-3.3-70b-instruct:free',choices:[{finish_reason:'stop',message:{content:'The market is range-bound; wait for a confirmed break.'}}]}),{status:200});
  });
  assert.equal(attempts,2);
  assert.equal(result.status,200);
  assert.equal(result.body.providers.openrouter.status,'ok');
  assert.equal(result.body.providers.openrouter.responseFormat,'text');
  assert.equal(result.body.providers.openrouter.rawText,null);
  assert.match(result.body.providers.openrouter.summary,/فارسی/);
});

test('a failed selected provider never discards another provider successful result', async () => {
  const selected = {...input, selectedProviders:['gemini','groq'], modelSelection:{gemini:'gemini-test-fast',groq:'openai/gpt-oss-20b'}};
  const result = await call('/analyze', selected, async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse();
    return new Response(JSON.stringify({error:{message:'model overloaded'}}),{status:503});
  });
  assert.equal(result.status,200);
  assert.equal(result.body.ok,true);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.groq.status,'error');
  assert.equal(result.body.analysisMode,'SINGLE_PROVIDER_INDEPENDENT');
  assert.equal(result.body.decision,'BUY');
});


test('provider automatically tries its configured fallback model after the primary model is unavailable', async () => {
  const selected = {...input, selectedProviders:['gemini'], modelSelection:{gemini:'gemini-retired-test'}, fallbackSelection:{gemini:'gemini-test-fast'}};
  const attempted=[];
  const result = await call('/analyze', selected, async url => {
    attempted.push(String(url));
    if (String(url).includes('gemini-retired-test')) return new Response(JSON.stringify({error:{message:'model not found'}}),{status:404});
    return geminiResponse();
  });
  assert.equal(result.status,200);
  assert.equal(attempted.length,2);
  assert.match(attempted[0],/gemini-retired-test/);
  assert.match(attempted[1],/gemini-test-fast/);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.fallbackUsed,true);
  assert.deepEqual(result.body.providers.gemini.attemptedModels,['gemini-retired-test','gemini-test-fast']);
});


test('AI consensus is independent from the technical engine direction', async () => {
  const selected = {...input, technicalAnalysis:{signal:'SELL'}, selectedProviders:['gemini','openrouter'], modelSelection:{gemini:'gemini-test-fast',openrouter:'meta-llama/llama-3.3-70b-instruct:free'}};
  const result = await call('/analyze', selected, async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse(JSON.stringify({bias:'BUY',summary:'ساختار مستقل این مدل متمایل به صعود است.',observations:['کف‌های بالاتر در نمودار دیده می‌شود.'],risks:[],confidence:72,overlays:validBuyOverlays()}));
    return openRouterResponse();
  });
  assert.equal(result.status,200);
  assert.equal(result.body.providers.gemini.bias,'BUY');
  assert.equal(result.body.providers.openrouter.bias,'BUY');
  assert.equal(result.body.consensus.decision,'BUY');
  assert.equal(result.body.consensus.technicalSignal,undefined);
});

test('large saved histories are compressed before reaching every AI model and technical report is excluded', async () => {
  const longRows = Array.from({length:2000},(_,i)=>[i===0?0:300,0,10000,-10000,5000,100]);
  const longHistory = Object.fromEntries(['1h','15m','5m'].map((tf)=>[tf,{timeStart:1700000000,intervalSeconds:tf==='1h'?3600:tf==='15m'?900:300,basePrice:100,baseVolumeMedian:10,rows:longRows}]));
  const selected = {...input,technicalAnalysis:{signal:'SELL',secretShouldNotReachAI:'NO'},marketHistory:longHistory};
  let prompt='';
  const result = await call('/analyze',selected,async (_url,options)=>{
    prompt=JSON.parse(options.body).contents[0].parts[0].text;
    return geminiResponse();
  });
  assert.equal(result.status,200);
  assert.doesNotMatch(prompt,/secretShouldNotReachAI|technicalAnalysis/);
  const payload=JSON.parse(prompt.slice(prompt.lastIndexOf('\n')+1));
  assert.ok(payload.history['1h'].rows.length<=58);
  assert.ok(payload.history['15m'].rows.length<=74);
  assert.ok(payload.history['5m'].rows.length<=90);
  assert.ok(Buffer.byteLength(prompt,'utf8')<20000,'provider prompt should stay compact enough for free-tier TPM limits');
  assert.equal(payload.history['5m'].originalCount,2000);
});

test('/models reads current provider catalogs and filters OpenRouter to free text models', async () => {
  const result = await call('/models', null, async (url) => {
    const value = String(url);
    if (value.includes('generativelanguage.googleapis.com')) return new Response(JSON.stringify({models:[
      {name:'models/gemini-live-flash',supportedGenerationMethods:['generateContent']},
      {name:'models/text-embedding-live',supportedGenerationMethods:['embedContent']}
    ]}),{status:200});
    if (value.includes('api.groq.com')) return new Response(JSON.stringify({data:[
      {id:'llama-live-chat',active:true,context_window:131072},
      {id:'whisper-large-v3',active:true,context_window:448}
    ]}),{status:200});
    if (value.includes('openrouter.ai')) return new Response(JSON.stringify({data:[
      {id:'sample/free-chat:free',architecture:{input_modalities:['text'],output_modalities:['text']},pricing:{prompt:'0',completion:'0'}},
      {id:'sample/paid-chat',architecture:{input_modalities:['text'],output_modalities:['text']},pricing:{prompt:'0.1',completion:'0.2'}},
      {id:'sample/free-image:free',architecture:{input_modalities:['image'],output_modalities:['text']},pricing:{prompt:'0',completion:'0'}}
    ]}),{status:200});
    throw new Error('unexpected catalog URL');
  });
  assert.equal(result.body.source,'live_provider_catalog');
  assert.deepEqual(result.body.providers.gemini.models,['gemini-live-flash']);
  assert.deepEqual(result.body.providers.groq.models,['llama-live-chat']);
  assert.ok(result.body.providers.openrouter.models.includes('sample/free-chat:free'));
  assert.ok(!result.body.providers.openrouter.models.includes('sample/paid-chat'));
  assert.ok(!result.body.providers.openrouter.models.includes('sample/free-image:free'));
});

test('Groq request omits constrained JSON mode to avoid GPT-OSS JSON validation HTTP 400', async () => {
  const groqInput = {...input, selectedProviders:['groq'], modelSelection:{groq:'openai/gpt-oss-120b'}};
  const result = await call('/analyze', groqInput, async (url, options) => {
    assert.match(String(url),/api.groq.com\/openai\/v1\/chat\/completions/);
    const payload = JSON.parse(options.body);
    assert.equal(payload.response_format,undefined);
    assert.match(payload.messages[0].content,/syntactically valid JSON/);
    return new Response(JSON.stringify({model:'openai/gpt-oss-120b',choices:[{finish_reason:'stop',message:{content:JSON.stringify({bias:'WAIT',summary:'شرایط فعلی برای ورود تأیید کافی ندارد.',observations:[],risks:[],confidence:40,overlays:[]})}}]}),{status:200});
  });
  assert.equal(result.body.providers.groq.status,'ok');
});

test('newly discovered live Gemini model is accepted after server-side catalog validation', async () => {
  const liveInput = {...input, modelSelection:{gemini:'gemini-live-new'}, fallbackSelection:{gemini:''}};
  const result = await call('/analyze', liveInput, async (url) => {
    const value = String(url);
    if (value.includes('/v1beta/models?')) return new Response(JSON.stringify({models:[
      {name:'models/gemini-live-new',supportedGenerationMethods:['generateContent']}
    ]}),{status:200});
    if (value.includes('gemini-live-new:generateContent')) return geminiResponse();
    throw new Error(`unexpected URL ${value}`);
  });
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.providerModel,'gemini-live-new');
});


test('each AI provider response requires Persian narrative and its own complete coherent trade plan', async () => {
  const selected = {...input, selectedProviders:['gemini']};
  const result = await call('/analyze', selected, async () => geminiResponse());
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.bias,'BUY');
  assert.deepEqual(ai.overlays.filter(x=>['Entry','SL','TP1','TP2','TP3'].includes(x.kind)).map(x=>x.kind),['Entry','SL','TP1','TP2','TP3']);
  assert.ok(ai.overlays.some(x=>x.kind==='Bullish OB'));
  assert.ok(ai.overlays.some(x=>x.kind==='Bullish FVG'));
  assert.match(ai.summary,/\p{Script=Arabic}/u);
});

test('English narrative is rejected and cannot be displayed as an AI analysis', async () => {
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({bias:'WAIT',summary:'Market is bullish and ready',observations:['higher highs'],risks:[],confidence:55,overlays:[]})));
  assert.equal(result.body.providers.gemini.status,'error');
  assert.match(result.body.providers.gemini.error,/language validation failed/);
});

test('BUY plan with inverted stop or targets is rejected', async () => {
  const broken = validBuyOverlays().map(x=>x.kind==='SL'?{...x,price:101}:x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({bias:'BUY',summary:'سناریوی صعودی نیازمند تأیید نهایی است.',observations:[],risks:[],confidence:65,overlays:broken})));
  assert.equal(result.body.providers.gemini.status,'error');
});


test('SELL plans require descending targets and are kept as a provider-specific output', async () => {
  const sell = [
    {type:'zone',kind:'Bearish OB',price:null,low:100.7,high:101.0,timeframe:'15m',direction:'bearish'},
    {type:'zone',kind:'Bearish FVG',price:null,low:100.4,high:100.6,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'Entry',price:100.5,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'SL',price:101.5,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'TP1',price:99.5,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'TP2',price:98.8,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'TP3',price:98.0,low:null,high:null,timeframe:'5m',direction:'bearish'}
  ];
  const selected={...input,selectedProviders:['gemini']};
  const result=await call('/analyze',selected,async()=>geminiResponse(JSON.stringify({bias:'SELL',summary:'ساختار کوتاه‌مدت نشانه‌های نزولی دارد و شکست حمایت باید تأیید شود.',observations:['قیمت زیر محدوده عرضه معامله می‌شود.'],risks:[],confidence:68,overlays:sell})));
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.bias,'SELL');
  assert.equal(result.body.providers.gemini.overlays.find(x=>x.kind==='TP3').price,98.0);
});

test('Gemini and OpenRouter keep their own separate overlays and plans without cross-model replacement', async () => {
  const selected={...input,selectedProviders:['gemini','openrouter'],modelSelection:{gemini:'gemini-test-fast',openrouter:'meta-llama/llama-3.3-70b-instruct:free'}};
  const result=await call('/analyze',selected,async url=>{
    if(String(url).includes('generativelanguage'))return geminiResponse();
    const different=validBuyOverlays().map(x=>x.kind==='Entry'?{...x,price:100.6}:x.kind==='SL'?{...x,price:99.4}:x.kind==='TP1'?{...x,price:102.0}:x.kind==='TP2'?{...x,price:103.0}:x.kind==='TP3'?{...x,price:104.0}:x);
    return new Response(JSON.stringify({model:'test/free-model',choices:[{finish_reason:'stop',message:{content:JSON.stringify({bias:'BUY',summary:'ساختار صعودی از دید مستقل این مدل قابل بررسی است.',observations:[],risks:[],confidence:67,overlays:different})}}]}),{status:200});
  });
  const g=result.body.providers.gemini, o=result.body.providers.openrouter;
  assert.equal(g.status,'ok');assert.equal(o.status,'ok');
  assert.equal(g.overlays.find(x=>x.kind==='Entry').price,100.5);
  assert.equal(o.overlays.find(x=>x.kind==='Entry').price,100.6);
  assert.notDeepEqual(g.overlays,o.overlays);
});

test('execution levels outside historical price bounds are removed and the AI signal is downgraded to WAIT', async () => {
  const extended = validBuyOverlays().map(x => x.kind === 'TP3' ? {...x, price: 500} : x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({
    bias:'BUY',summary:'سناریوی صعودی فقط در صورت حفظ ساختار معتبر است.',observations:[],risks:[],confidence:70,overlays:extended
  })));
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.confidence,0);
  assert.equal(ai.overlays.some(x=>['Entry','SL','TP1','TP2','TP3'].includes(x.kind)),false);
  assert.ok(ai.risks.some(x=>x.includes('برنامه ورود')));
});


test('BUY signal is downgraded when its OB or FVG zone is outside the submitted market-history envelope', async () => {
  const invalidZone = validBuyOverlays().map(x => x.kind === 'Bullish OB' ? {...x, low: 180, high: 181} : x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({
    bias:'BUY',summary:'سناریوی صعودی تنها با ناحیه تقاضای معتبر قابل قبول است.',observations:[],risks:[],confidence:72,overlays:invalidZone
  })));
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.confidence,0);
  assert.equal(ai.overlays.some(x=>['Entry','SL','TP1','TP2','TP3'].includes(x.kind)),false);
  assert.equal(ai.overlays.some(x=>x.kind==='Bullish OB'),false);
  assert.ok(ai.risks.some(x=>x.includes('OB یا FVG')));
});

test('directional OB/FVG metadata must agree with the zone label', async () => {
  const invalidZone = validBuyOverlays().map(x => x.kind === 'Bullish FVG' ? {...x, direction:'bearish'} : x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({
    bias:'BUY',summary:'ساختار صعودی برای ورود به تأیید نیاز دارد.',observations:[],risks:[],confidence:70,overlays:invalidZone
  })));
  assert.notEqual(result.body.providers.gemini.bias,'BUY');
  assert.notEqual(result.body.providers.gemini.status,'ok');
});

test('provider analytical weights are normalized and factor scores are preserved independently', async () => {
  const response = JSON.stringify({bias:'WAIT',summary:'برای ورود هنوز تأیید کافی دیده نمی‌شود.',observations:['ساختار کوتاه‌مدت خنثی است.'],risks:['شکست محدوده می‌تواند نوسان را افزایش دهد.'],confidence:62,analyticalWeights:{trend:40,marketStructure:20,liquidity:15,entryConfirmation:15,riskReward:10},factorScores:{trend:80,marketStructure:65,liquidity:55,entryConfirmation:60,riskReward:75},overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.weightsProvided,true);
  assert.equal(Object.values(ai.analyticalWeights).reduce((a,b)=>a+b,0),100);
  assert.equal(ai.analyticalWeights.trend,40);
  assert.equal(ai.factorScores.riskReward,75);
});

test('legacy model response without self-assigned weights is marked unqualified for hybrid decisions', async () => {
  const response = JSON.stringify({bias:'WAIT',summary:'بازار هنوز جهت مشخصی ندارد و بهتر است منتظر ماند.',observations:[],risks:[],confidence:45,overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.weightsProvided,false);
});
