import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker.js';

const rows = Array.from({length: 60}, (_, i) => [i === 0 ? 0 : 300, 0, 10000, -10000, 5000, 100]);
const marketHistory = {
  format: 'test delta OHLCV',
  '1h': {timeStart: 1700000000, intervalSeconds: 3600, basePrice: 100, baseVolumeMedian: 10, rows},
  '15m': {timeStart: 1700000000, intervalSeconds: 900, basePrice: 100, baseVolumeMedian: 10, rows},
  '5m': {timeStart: 1700000000, intervalSeconds: 300, basePrice: 100, baseVolumeMedian: 10, rows}
};
const validAnalysisSectionsV3 = Object.fromEntries([
  ['regime','رژیم بازار بر اساس شیب و دامنه کندل‌ها بررسی شد.'],
  ['structure','هم‌جهتی ساختار یک‌ساعته و پانزده‌دقیقه‌ای نیازمند تأیید است.'],
  ['liquidity','سطوح نقدینگی از سقف‌ها و کف‌های قابل مشاهده استخراج شد.'],
  ['poi','محدوده مورد علاقه از ناحیه ساختاری قابل مشاهده تعیین شد.'],
  ['premiumDiscount','موقعیت قیمت نسبت به دامنه معتبر بررسی شد.'],
  ['volumeMomentum','حجم و شتاب کندل‌ها از داده OHLCV ارزیابی شد.'],
  ['scenarios','سناریوی صعودی و نزولی با شروط فعال‌سازی جداگانه تعریف شد.'],
  ['execution','کیفیت ورود فقط پس از بسته‌شدن کندل تأییدی ارزیابی می‌شود.'],
  ['dataQuality','داده دفتر سفارش و نرخ تأمین مالی در ورودی وجود ندارد.']
].map(([key, finding]) => [key,{status:'AVAILABLE',findings:[finding]}]));
const validContractV3 = {
  contractVersion: 3,
  analysisSections: validAnalysisSectionsV3,
  timeframeAnalysis: {
    '1h': {trend:'BULLISH',structure:'BULLISH',structureEvent:'BOS_BULLISH',phase:'TRENDING',buyerStrength:65,sellerStrength:35,liquidity:'NONE',evidence:['کف بالاتر در ساختار مشاهده شد']},
    '15m': {trend:'BULLISH',structure:'TRANSITION',structureEvent:'MSS_BULLISH',phase:'TRENDING',buyerStrength:58,sellerStrength:42,liquidity:'SELL_SIDE_SWEEP',evidence:['جمع‌آوری نقدینگی فروشندگان مشاهده شد']},
    '5m': {trend:'BULLISH',structure:'BULLISH',structureEvent:'NONE',phase:'TRENDING',buyerStrength:62,sellerStrength:38,liquidity:'NONE',evidence:['تأیید ساختار اجرایی دیده شد']}
  },
  evidence: [{timeframe:'5m',type:'STRUCTURE',event:'BULLISH_MSS',status:'CONFIRMED',explanation:'شکست ساختار صعودی در کندل بسته‌شده مشاهده شد'}],
  invalidation: 'بسته‌شدن کندل ۱۵ دقیقه زیر کف ساختاری سناریو را باطل می‌کند'
};
const input = {
  exchange: 'TEST', symbol: 'BTCUSDT', snapshotId: 'snapshot-test-001',
  technicalAnalysis: {signal: 'BUY'}, marketHistory,
  selectedProviders: ['gemini'], modelSelection: {gemini: 'gemini-3.8-flash'}
};
function env() {
  return {
    GEMINI_API_KEY: 'test-gemini', OPENROUTER_API_KEY: 'test-openrouter', GROQ_API_KEY: 'test-groq',
    GEMINI_MODEL: 'gemini-3.8-flash', GEMINI_MODELS: 'gemini-3.8-flash,gemini-3.7-flash',
    OPENROUTER_MODEL: 'qwen/qwen3.8-27b', OPENROUTER_MODELS: 'qwen/qwen3.8-27b,openai/gpt-oss-120b',
    GROQ_MODEL: 'qwen/qwen3.8-27b', GROQ_MODELS: 'qwen/qwen3.8-27b,openai/gpt-oss-120b',
    GATEWAY_TOKEN: 'test-token', RATE_LIMITER: {limit: async () => ({success: true})}
  };
}
function validBuyOverlays() { return [
  {type:'zone',kind:'Bullish OB',price:null,low:99.8,high:100.1,timeframe:'15m',direction:'bullish'},
  {type:'zone',kind:'Bullish FVG',price:null,low:100.1,high:100.3,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'Entry',price:100.5,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'SL',price:99.5,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'TP1',price:101.5,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'TP2',price:102.2,low:null,high:null,timeframe:'5m',direction:'bullish'},
  {type:'line',kind:'TP3',price:103.1,low:null,high:null,timeframe:'5m',direction:'bullish'}
]; }
function geminiResponse(text = JSON.stringify({...validContractV3,bias:'BUY',summary:'ساختار بازار متمایل به صعود است و ورود پس از تأیید محدوده انجام می‌شود.',observations:['کف‌های بالاتر در تایم‌فریم اجرایی دیده می‌شود.'],risks:['شکست حمایت نزدیک می‌تواند سناریو را باطل کند.'],confidence:75,analyticalWeights:{trend:30,marketStructure:25,liquidity:20,entryConfirmation:15,riskReward:10},factorScores:{trend:80,marketStructure:75,liquidity:65,entryConfirmation:85,riskReward:70},overlays:validBuyOverlays()})) {
  return new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text}]}}]}), {status:200});
}
function openRouterResponse() {
  return new Response(JSON.stringify({model:'test/free-model',usage:{prompt_tokens:100,completion_tokens:50},choices:[{finish_reason:'stop',message:{content:JSON.stringify({...validContractV3,bias:'BUY',summary:'ساختار بازار نشانه‌های صعودی دارد.',observations:['حمایت کوتاه‌مدت حفظ شده است.'],risks:[],confidence:70,analyticalWeights:{trend:25,marketStructure:25,liquidity:20,entryConfirmation:20,riskReward:10},factorScores:{trend:75,marketStructure:80,liquidity:70,entryConfirmation:75,riskReward:65},overlays:validBuyOverlays()})}}]}), {status:200});
}
async function call(path, body, mockFetch, headers={}) {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = mockFetch;
  try {
    const request = new Request(`https://gateway.test${path}`, {
      method: path === '/health' || path === '/models' || path === '/altfins/quota' ? 'GET' : 'POST',
      headers: {'Content-Type':'application/json', ...headers},
      body: path === '/health' || path === '/models' || path === '/altfins/quota' ? undefined : JSON.stringify(body ?? input)
    });
    const response = await worker.fetch(request, env());
    return {status:response.status, body:await response.json()};
  } finally { globalThis.fetch = originalFetch; }
}



test('retired Claude route is not exposed', async () => {
  const response = await call('/shadow/claude', input, async () => { throw new Error('must not call providers'); });
  assert.equal(response.status, 404);
  assert.equal(response.body.error, 'Not found');
});

test('one selected model is enough to return and display an independent analysis; other providers are not called', async () => {
  let calls = 0;
  const result = await call('/analyze', input, async (url, options) => {
    calls++;
    assert.match(String(url), /gemini-3.8-flash/);
    const sent = JSON.parse(options.body);
    const prompt = sent.contents?.[0]?.parts?.[0]?.text || '';
    assert.match(prompt, /historyStartPrice/);
    assert.doesNotMatch(prompt, /\"basePrice\"/);
    assert.equal(sent.generationConfig.responseMimeType, undefined);
    assert.equal(sent.generationConfig.responseJsonSchema, undefined);
    return geminiResponse();
  });
  assert.equal(result.status, 200);
  assert.equal(result.body.ok, true);
  assert.equal(result.body.providers.gemini.status, 'ok');
  assert.equal(result.body.providers.gemini.providerModel, 'gemini-3.8-flash');
  assert.equal(result.body.providers.gemini.weightsProvided, true);
  assert.equal(Object.values(result.body.providers.gemini.analyticalWeights).reduce((a,b)=>a+b,0),100);
  assert.equal(result.body.providers.openrouter.status, 'not_selected');
  assert.equal(result.body.providers.groq.status, 'not_selected');
  assert.equal(result.body.decision, 'WAIT');
  assert.equal(result.body.analysisMode, 'SINGLE_PROVIDER_INDEPENDENT');
  assert.ok(result.body.consensus.conflicts.some(x => x.includes('اجماع')) || result.body.consensus.conflicts.some(x => x.includes('یک مدل')));
  assert.equal(result.body.snapshotId, 'snapshot-test-001');
  assert.equal(calls, 1);
});


test('Gemini output format is not forced and provider-native JSON remains locally normalized', async () => {
  let calls=0;
  const result=await call('/analyze',input,async (_url,options)=>{
    calls++;
    const sent=JSON.parse(options.body);
    if(calls===1){assert.equal(sent.generationConfig.responseJsonSchema,undefined);return geminiResponse();}
    assert.equal(sent.generationConfig.responseJsonSchema,undefined);
    assert.equal(sent.generationConfig.responseMimeType,undefined);
    return geminiResponse();
  });
  assert.equal(calls,1);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.contractStatus,'VALID');
});

test('absolute price hallucinations in model narrative are sanitized and downgrade the contract', async () => {
  const hallucinated = JSON.stringify({...validContractV3,bias:'BUY',summary:'قیمت بازار به ۸۳٬۰۰۰ دلار رسیده و روند صعودی است.',observations:['ساختار صعودی مشاهده می‌شود.'],risks:[],confidence:80,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:80,marketStructure:80,liquidity:70,entryConfirmation:75,riskReward:80},overlays:validBuyOverlays()});
  const withAnchor = {...input,referencePrice:100.2,lastClosed5mClose:100.2};
  const result = await call('/analyze', withAnchor, async () => geminiResponse(hallucinated));
  const ai = result.body.providers.gemini;
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.contractStatus,'DEGRADED');
  assert.equal(ai.weightsProvided,false);
  assert.ok(!ai.summary.includes('۸۳٬۰۰۰'));
  assert.ok(ai.risks.some(x=>x.includes('عدد قیمتی خارج')));
});

test('narrative market prices must agree with the live reference anchor, not merely old history extremes', async () => {
  const anchored = {...input, referencePrice:100, lastClosed5mClose:100};
  const response = {...validContractV3,bias:'WAIT',summary:'قیمت فعلی بازار حدود ۸۳۰۴۰ دلار است و ساختار نیازمند انتظار است.',observations:[],risks:[],confidence:55,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:55,marketStructure:55,liquidity:55,entryConfirmation:55,riskReward:55},overlays:[]};
  const result = await call('/analyze',anchored,async()=>geminiResponse(JSON.stringify(response)));
  const ai = result.body.providers.gemini;
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.contractStatus,'DEGRADED');
  assert.equal(ai.weightsProvided,false);
  assert.match(ai.risks.join(' '),/عدد قیمتی خارج از/);
  assert.doesNotMatch(ai.summary,/۸۳۰۴۰/);
});

test('analysis is blocked when live reference price and latest closed 5m close are inconsistent', async () => {
  const bad = {...input, referencePrice: 110, lastClosed5mClose: 100};
  let providerCalls = 0;
  const result = await call('/analyze', bad, async () => { providerCalls++; throw new Error('must not call provider'); });
  assert.equal(result.status, 409);
  assert.equal(result.body.code, 'REFERENCE_PRICE_MISMATCH');
  assert.equal(providerCalls, 0);
});

test('plain text model response is converted to a Persian WAIT explanation and never becomes a trade signal', async () => {
  const result = await call('/analyze', input, async () => geminiResponse('Market is choppy. Buyers have not confirmed a breakout yet.'));
  assert.equal(result.status, 200);
  assert.equal(result.body.providers.gemini.status, 'ok');
  assert.equal(result.body.providers.gemini.responseFormat, 'text');
  assert.match(result.body.providers.gemini.rawText, /Market is choppy/);
  assert.equal(result.body.providers.gemini.bias, 'WAIT');
  assert.equal(result.body.providers.gemini.confidence, 50);
  assert.equal(result.body.providers.gemini.overlays.length, 0);
});

test('AI Data Engine keeps rich provider-native JSON and classifies unfamiliar field layouts', async () => {
  const native = {
    market_outlook: 'بازار در وضعیت رنج با تمایل صعودی محدود قرار دارد.',
    technicals: {market_structure: {bos: 'شکست سقف محلی تایید نشده', choch: 'در انتظار تایید'},
      liquidity_sweep: ['جمع‌آوری نقدینگی زیر کف روزانه'],
      order_blocks: [{type:'bullish', low: 60100, high: 60300}],
      momentum: {rsi: 54, macd: 'positive', volume: 'below average'}},
    additionalData: {funding_rate: 'نرخ تأمین مالی مثبت گزارش شده است.', open_interest: 'بهره باز در حال افزایش گزارش شده است.', order_book: 'عمق سفارش خرید نزدیک قیمت بیشتر گزارش شده است.'},
    scenarios: {bullish: 'تثبیت بالای مقاومت', bearish: 'بازگشت زیر حمایت'},
    risk_management: {invalidation: 'کلوز زیر کف اخیر'},
    custom_model_field: {novel_signal: 'model-specific observation'}
  };
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify(native)));
  assert.equal(result.status, 200);
  const ai = result.body.providers.gemini;
  assert.equal(ai.status, 'ok');
  assert.match(ai.rawText, /model-specific observation/);
  assert.equal(ai.dataCategories.marketStructure, undefined);
  assert.equal(ai.dataCategories.liquidity, undefined);
  assert.equal(ai.dataCategories.pointsOfInterest, undefined);
  assert.equal(ai.dataCategories.momentumAndVolume, undefined);
  assert.equal(ai.dataCategories.scenarios, undefined);
  assert.equal(ai.dataCategories.riskAndInvalidation, undefined);
  assert.equal(ai.dataCategories.derivatives?.length, 2);
  assert.equal(ai.dataCategories.orderBook?.length, 1);
  assert.ok(ai.extractedFacts.some(x => x.text === 'model-specific observation'));
  assert.equal(ai.bias, 'WAIT');
});

test('AI Data Engine categorizes explicitly titled plain-text sections without fabricating trade levels', async () => {
  const prose = 'Market structure: ساختار ۱۵ دقیقه‌ای در محدوده است.\nLiquidity: نقدینگی زیر کف قبلی جمع شد.\nScenarios: سناریوی صعودی مشروط به شکست مقاومت است.\nFunding Rate: نرخ تأمین مالی مثبت گزارش شده است.\nOrder Book: عمق سفارش خرید در محدوده نزدیک بیشتر است.\nRisks: شکست حمایت سناریو را باطل می‌کند.';
  const result = await call('/analyze', input, async () => geminiResponse(prose));
  assert.equal(result.status, 200);
  const ai = result.body.providers.gemini;
  assert.equal(ai.responseFormat, 'text');
  assert.equal(ai.dataCategories.marketStructure, undefined);
  assert.equal(ai.dataCategories.liquidity, undefined);
  assert.equal(ai.dataCategories.scenarios, undefined);
  assert.equal(ai.dataCategories.riskAndInvalidation, undefined);
  assert.ok(ai.dataCategories.derivatives?.length);
  assert.ok(ai.dataCategories.orderBook?.length);
  assert.equal(ai.overlays.length, 0);
  assert.equal(ai.bias, 'WAIT');
});

test('requested model outside Worker allow-list is rejected without provider call', async () => {
  const bad = {...input, modelSelection:{gemini:'unknown/model'}};
  const result = await call('/analyze', bad, async () => { throw new Error('must not call provider'); });
  assert.equal(result.status, 502);
  assert.equal(result.body.ok, false);
  assert.match(result.body.providers.gemini.error, /not in the current Worker candidate list/);
});

test('/models exposes configured provider model allow-lists without exposing secrets', async () => {
  const result = await call('/models', null, async () => { throw new Error('no external call expected'); });
  assert.equal(result.status, 200);
  assert.ok(result.body.providers.gemini.models.includes('gemini-3.8-flash'));
  assert.ok(result.body.providers.gemini.models.length > 2);
  assert.ok(result.body.providers.groq.models.includes('qwen/qwen3.8-27b'));
  assert.ok(result.body.providers.groq.models.length > 2);
  assert.equal(JSON.stringify(result.body).includes('test-gemini'), false);
});

test('one successful provider in provider-test is reported as successful connectivity', async () => {
  const result = await call('/provider-test', {selectedProviders:['gemini'],modelSelection:{gemini:'gemini-3.8-flash'}},
    async () => geminiResponse(), {Authorization:'Bearer test-token'});
  assert.equal(result.status, 200);
  assert.equal(result.body.ok, true);
  assert.equal(result.body.successCount, 1);
  assert.equal(result.body.requiredForDisplay, 1);
});

test('OpenRouter model selection is passed through exactly and each provider result is independent', async () => {
  const selected = {...input, selectedProviders:['openrouter'], modelSelection:{openrouter:'qwen/qwen3.8-27b:free'}};
  let sentModel;
  const result = await call('/analyze', selected, async (url, options) => {
    sentModel = JSON.parse(options.body).model;
    return openRouterResponse();
  });
  assert.equal(result.status, 200);
  assert.equal(sentModel, 'qwen/qwen3.8-27b:free');
  assert.equal(result.body.providers.openrouter.status, 'ok');
  assert.equal(result.body.providers.openrouter.providerModel, 'test/free-model');
});


test('OpenRouter retries without optional JSON schema when a free endpoint rejects it and safely rejects unstructured text', async () => {
  const selected = {...input, selectedProviders:['openrouter'], modelSelection:{openrouter:'qwen/qwen3.8-27b:free'}};
  let attempts = 0;
  const result = await call('/analyze', selected, async (url, options) => {
    attempts++;
    const payload = JSON.parse(options.body);
    assert.equal(payload.response_format, undefined);
    return new Response(JSON.stringify({model:'openai/gpt-oss-120b',choices:[{finish_reason:'stop',message:{content:'The market is range-bound; wait for a confirmed break.'}}]}),{status:200});
  });
  assert.equal(attempts,1);
  assert.equal(result.status,200);
  assert.equal(result.body.providers.openrouter.status,'ok');
  assert.equal(result.body.providers.openrouter.responseFormat,'text');
  assert.match(result.body.providers.openrouter.rawText,/range-bound/);
  assert.equal(result.body.providers.openrouter.bias,'WAIT');
});

test('a failed selected provider never discards another provider successful result', async () => {
  const selected = {...input, selectedProviders:['gemini','groq'], modelSelection:{gemini:'gemini-3.8-flash',groq:'openai/gpt-oss-120b'}};
  const result = await call('/analyze', selected, async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse();
    return new Response(JSON.stringify({error:{message:'model overloaded'}}),{status:503});
  });
  assert.equal(result.status,200);
  assert.equal(result.body.ok,true);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.groq.status,'error');
  assert.equal(result.body.analysisMode,'SINGLE_PROVIDER_INDEPENDENT');
  assert.equal(result.body.decision,'WAIT');
});


test('provider automatically tries its configured fallback model after the primary model is unavailable', async () => {
  const selected = {...input, selectedProviders:['gemini'], modelSelection:{gemini:'gemini-3.7-flash'}, fallbackSelection:{gemini:'gemini-3.8-flash'}};
  const attempted=[];
  const result = await call('/analyze', selected, async url => {
    attempted.push(String(url));
    if (String(url).includes('gemini-3.7-flash')) return new Response(JSON.stringify({error:{message:'model not found'}}),{status:404});
    return geminiResponse();
  });
  assert.equal(result.status,200);
  assert.equal(attempted.length,2);
  assert.match(attempted[0],/gemini-3.7-flash/);
  assert.match(attempted[1],/gemini-3.8-flash/);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.fallbackUsed,true);
  assert.deepEqual(result.body.providers.gemini.attemptedModels,['gemini-3.7-flash','gemini-3.8-flash']);
});


test('provider walks the ranked fallback chain beyond the manually selected second model', async () => {
  const selected = {...input, selectedProviders:['gemini'], modelSelection:{gemini:'gemini-3.8-flash'}, fallbackSelection:{gemini:'gemini-3.7-flash'}};
  const attempted = [];
  const result = await call('/analyze', selected, async url => {
    const value = String(url);
    attempted.push(value);
    if (value.includes('gemini-3.8-flash') || value.includes('gemini-3.7-flash')) {
      return new Response(JSON.stringify({error:{message:'temporarily unavailable'}}), {status:503});
    }
    assert.match(value, /gemini-3.6-flash/);
    return geminiResponse();
  });
  assert.equal(result.body.providers.gemini.status, 'ok');
  assert.deepEqual(result.body.providers.gemini.attemptedModels, ['gemini-3.8-flash','gemini-3.7-flash','gemini-3.6-flash']);
  assert.equal(result.body.providers.gemini.fallbackUsed, true);
});

test('AI consensus is independent from the technical engine direction', async () => {
  const selected = {...input, technicalAnalysis:{signal:'SELL'}, selectedProviders:['gemini','openrouter'], modelSelection:{gemini:'gemini-3.8-flash',openrouter:'qwen/qwen3.8-27b:free'}};
  const result = await call('/analyze', selected, async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse(JSON.stringify({...validContractV3,bias:'BUY',summary:'ساختار مستقل این مدل متمایل به صعود است.',observations:['کف‌های بالاتر در نمودار دیده می‌شود.'],risks:[],confidence:72,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:75,marketStructure:75,liquidity:70,entryConfirmation:80,riskReward:70},overlays:validBuyOverlays()}));
    return openRouterResponse();
  });
  assert.equal(result.status,200);
  assert.equal(result.body.providers.gemini.bias,'BUY');
  assert.equal(result.body.providers.openrouter.bias,'BUY');
  assert.equal(result.body.consensus.decision,'BUY');
  assert.equal(result.body.consensus.technicalSignal,undefined);
});

test('large saved histories are compressed before reaching every AI model and technical report is excluded', async () => {
  const longRows = Array.from({length:2000},(_,i)=>[i===0?0:300,0,10000,-10000,5000,100]);
  const longHistory = Object.fromEntries(['1h','15m','5m'].map((tf)=>[tf,{timeStart:1700000000,intervalSeconds:tf==='1h'?3600:tf==='15m'?900:300,basePrice:100,baseVolumeMedian:10,rows:longRows}]));
  const selected = {...input,technicalAnalysis:{signal:'SELL',secretShouldNotReachAI:'NO'},marketHistory:longHistory};
  let prompt='';
  const result = await call('/analyze',selected,async (_url,options)=>{
    prompt=JSON.parse(options.body).contents[0].parts[0].text;
    return geminiResponse();
  });
  assert.equal(result.status,200);
  assert.doesNotMatch(prompt,/secretShouldNotReachAI|technicalAnalysis/);
  const payload=JSON.parse(prompt.slice(prompt.lastIndexOf('\n')+1));
  assert.ok(payload.history['1h'].rows.length<=58);
  assert.ok(payload.history['15m'].rows.length<=74);
  assert.ok(payload.history['5m'].rows.length<=90);
  assert.ok(Buffer.byteLength(prompt,'utf8')<20000,'provider prompt should stay compact enough for free-tier TPM limits');
  assert.equal(payload.history['5m'].originalCount,2000);
});

test('/models reads current provider catalogs and filters OpenRouter to free text models', async () => {
  const result = await call('/models', null, async (url) => {
    const value = String(url);
    if (value.includes('generativelanguage.googleapis.com')) return new Response(JSON.stringify({models:[
      {name:'models/gemini-3.8-flash',supportedGenerationMethods:['generateContent']},
      {name:'models/text-embedding-live',supportedGenerationMethods:['embedContent']}
    ]}),{status:200});
    if (value.includes('api.groq.com')) return new Response(JSON.stringify({data:[
      {id:'qwen/qwen3.8-27b',active:true,context_window:131072},
      {id:'whisper-large-v3',active:true,context_window:448}
    ]}),{status:200});
    if (value.includes('openrouter.ai')) return new Response(JSON.stringify({data:[
      {id:'qwen/qwen4-max',architecture:{input_modalities:['text','image'],output_modalities:['text']},context_length:1000000,supported_parameters:['structured_outputs'],pricing:{prompt:'0.000001425',completion:'0.000004275'}},
      {id:'qwen/qwen3.8-27b:free',architecture:{input_modalities:['text'],output_modalities:['text']},context_length:262144,supported_parameters:[],pricing:{prompt:'0',completion:'0'}},
      {id:'qwen/qwen3.8-27b',architecture:{input_modalities:['text'],output_modalities:['text']},context_length:262144,supported_parameters:['structured_outputs'],pricing:{prompt:'0.00000006',completion:'0.0000022'}},
      {id:'openai/gpt-oss-120b',architecture:{input_modalities:['text'],output_modalities:['text']},context_length:131072,supported_parameters:['structured_outputs'],pricing:{prompt:'0.00000009',completion:'0.00000036'}},
      {id:'inclusionai/ling-3.2-flash:free',architecture:{input_modalities:['text','image'],output_modalities:['text']},context_length:1048576,supported_parameters:['structured_outputs'],pricing:{prompt:'0',completion:'0'}},
      {id:'sample/free-image:free',architecture:{input_modalities:['image'],output_modalities:['text']},context_length:100000,supported_parameters:['structured_outputs'],pricing:{prompt:'0',completion:'0'}},
      {id:'sample/no-json-free:free',architecture:{input_modalities:['text'],output_modalities:['text']},context_length:100000,supported_parameters:[],pricing:{prompt:'0',completion:'0'}},
      {id:'sample/too-expensive',architecture:{input_modalities:['text'],output_modalities:['text']},context_length:100000,supported_parameters:['structured_outputs'],pricing:{prompt:'0.00001',completion:'0.00002'}}
    ]}),{status:200});
    throw new Error('unexpected catalog URL');
  });
  assert.equal(result.body.source,'live_provider_catalog');
  assert.deepEqual(result.body.providers.gemini.models,['gemini-3.8-flash']);
  assert.deepEqual(result.body.providers.groq.models,['qwen/qwen3.8-27b']);
  assert.deepEqual(result.body.providers.openrouter.models,['openrouter/free','qwen/qwen3.8-27b:free','inclusionai/ling-3.2-flash:free','sample/no-json-free:free']);
  assert.ok(result.body.providers.openrouter.models.includes('inclusionai/ling-3.2-flash:free'));
  assert.ok(!result.body.providers.openrouter.models.includes('sample/free-image:free'));
  assert.ok(result.body.providers.openrouter.models.includes('sample/no-json-free:free')); // JSON-mode fallback is allowed and locally validated
  assert.ok(!result.body.providers.openrouter.models.includes('sample/too-expensive')); 
});

test('Groq provider-native response format is not constrained by a shared JSON Schema', async () => {
  const groqInput = {...input, selectedProviders:['groq'], modelSelection:{groq:'openai/gpt-oss-120b'}};
  const result = await call('/analyze', groqInput, async (url, options) => {
    assert.match(String(url),/api.groq.com\/openai\/v1\/chat\/completions/);
    const payload = JSON.parse(options.body);
    assert.equal(payload.response_format,undefined);
    return new Response(JSON.stringify({model:'openai/gpt-oss-120b',choices:[{finish_reason:'stop',message:{content:JSON.stringify({...validContractV3,bias:'WAIT',summary:'شرایط فعلی برای ورود تأیید کافی ندارد.',observations:[],risks:[],confidence:40,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:40,marketStructure:40,liquidity:40,entryConfirmation:40,riskReward:40},overlays:[]})}}]}),{status:200});
  });
  assert.equal(result.body.providers.groq.status,'ok');
});

test('Groq nested JSON normalizer extracts split timeframe maps, directional phase aliases and supplementary facts', async () => {
  const groqInput = {...input, selectedProviders:['groq'], modelSelection:{groq:'openai/gpt-oss-120b'}};
  const groqPayload = {
    result: JSON.stringify({
      contractVersion: 3,
      analysisSections: validAnalysisSectionsV3,
      timeframeAnalysis: {
        '1h': {trend:'BEARISH',structure:'BEARISH',structureEvent:'NONE',phase:'BEARISH',buyerStrength:30,sellerStrength:70,liquidity:'NONE',evidence:[{timeframe:'1h',type:'priceMovement',event:'نزول ساختاری',status:'CONFIRMED',explanation:'سقف‌ها و کف‌های پایین‌تر در تایم‌فریم یک‌ساعته ثبت شده‌اند.'}]}
      },
      marketContext: {timeframes: {
        '5m': {trend:'BEARISH',structure:'BEARISH',structureEvent:'BOS_BEARISH',phase:'BEARISH',buyerStrength:25,sellerStrength:75,liquidity:'SELL_SIDE_SWEEP',evidence:['شکست کف و ادامه فشار فروش در ۵ دقیقه مشاهده شد']}
      }},
      additionalData:{fundingRate:'نرخ تأمین مالی مثبت و محدود است.',openInterest:1250000,orderBook:'عمق سفارش فروش در نزدیکی قیمت بیشتر است.'},
      bias:'WAIT',summary:'برای ورود، تأیید مستقل بیشتری لازم است.',observations:[],risks:[],confidence:50,
      analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
      factorScores:{trend:50,marketStructure:50,liquidity:50,entryConfirmation:50,riskReward:50},overlays:[]
    })
  };
  const result = await call('/analyze', groqInput, async () => new Response(JSON.stringify({model:'openai/gpt-oss-120b',choices:[{finish_reason:'stop',message:{content:JSON.stringify(groqPayload)}}]}),{status:200}));
  const groq = result.body.providers.groq;
  assert.equal(groq.status,'ok');
  assert.equal(groq.timeframeAnalysis['1h'].provided,true);
  assert.equal(groq.timeframeAnalysis['1h'].trend,'BEARISH');
  assert.equal(groq.timeframeAnalysis['1h'].buyerStrength,30);
  assert.equal(groq.timeframeAnalysis['1h'].sellerStrength,70);
  assert.equal(groq.timeframeAnalysis['1h'].phase,'TRENDING');
  assert.equal(groq.timeframeAnalysis['1h'].structureEvent,'NONE');
  assert.equal(groq.timeframeAnalysis['15m'].provided,false);
  assert.equal(groq.timeframeAnalysis['5m'].structureEvent,'BOS_BEARISH');
  assert.ok(groq.dataCategories.derivatives?.length >= 1);
  assert.ok(groq.dataCategories.orderBook?.length >= 1);
  assert.notEqual(groq.contractStatus,'VALID'); // missing 15M must remain visibly incomplete
});

test('truncated Gemini response is downgraded to WAIT and cannot retain execution overlays', async () => {
  const complete = {...validContractV3,bias:'BUY',summary:'ساختار صعودی مشاهده می‌شود.',observations:['تأیید ورود در تایم‌فریم پنج دقیقه دیده می‌شود.'],risks:[],confidence:80,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:80,marketStructure:80,liquidity:80,entryConfirmation:80,riskReward:80},overlays:validBuyOverlays()};
  const result = await call('/analyze', input, async () => new Response(JSON.stringify({candidates:[{finishReason:'MAX_TOKENS',content:{parts:[{text:JSON.stringify(complete)}]}}]}),{status:200}));
  const ai = result.body.providers.gemini;
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.contractStatus,'DEGRADED');
  assert.equal(ai.weightsProvided,false);
  assert.equal(ai.overlays.some(x=>['Entry','SL','TP1','TP2','TP3'].includes(x.kind)),false);
});

test('newly discovered unranked Gemini models remain excluded from the curated allow-list', async () => {
  const liveInput = {...input, modelSelection:{gemini:'gemini-live-new'}, fallbackSelection:{gemini:''}};
  const result = await call('/analyze', liveInput, async (url) => {
    const value = String(url);
    if (value.includes('/v1beta/models?')) return new Response(JSON.stringify({models:[
      {name:'models/gemini-live-new',supportedGenerationMethods:['generateContent']}
    ]}),{status:200});
    throw new Error(`unexpected URL ${value}`);
  });
  assert.equal(result.body.providers.gemini.status,'error');
  assert.match(result.body.providers.gemini.error,/not in the current Worker candidate list/);
});

test('each AI provider response requires Persian narrative and its own complete coherent trade plan', async () => {
  const selected = {...input, selectedProviders:['gemini']};
  const result = await call('/analyze', selected, async () => geminiResponse());
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.bias,'BUY');
  assert.deepEqual(ai.overlays.filter(x=>['Entry','SL','TP1','TP2','TP3'].includes(x.kind)).map(x=>x.kind),['Entry','SL','TP1','TP2','TP3']);
  assert.ok(ai.overlays.some(x=>x.kind==='Bullish OB'));
  assert.ok(ai.overlays.some(x=>x.kind==='Bullish FVG'));
  assert.match(ai.summary,/\p{Script=Arabic}/u);
});

test('English narrative is rejected and cannot be displayed as an AI analysis', async () => {
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({bias:'WAIT',summary:'Market is bullish and ready',observations:['higher highs'],risks:[],confidence:55,overlays:[]})));
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.bias,'WAIT');
  assert.match(result.body.providers.gemini.rawText,/Market is bullish/);
});

test('BUY plan with inverted stop or targets is rejected', async () => {
  const broken = validBuyOverlays().map(x=>x.kind==='SL'?{...x,price:101}:x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({bias:'BUY',summary:'سناریوی صعودی نیازمند تأیید نهایی است.',observations:[],risks:[],confidence:65,overlays:broken})));
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.bias,'WAIT');
});


test('SELL plans require descending targets and are kept as a provider-specific output', async () => {
  const sell = [
    {type:'zone',kind:'Bearish OB',price:null,low:100.7,high:101.0,timeframe:'15m',direction:'bearish'},
    {type:'zone',kind:'Bearish FVG',price:null,low:100.4,high:100.6,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'Entry',price:100.5,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'SL',price:101.5,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'TP1',price:99.5,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'TP2',price:98.8,low:null,high:null,timeframe:'5m',direction:'bearish'},
    {type:'line',kind:'TP3',price:98.0,low:null,high:null,timeframe:'5m',direction:'bearish'}
  ];
  const selected={...input,selectedProviders:['gemini']};
  const result=await call('/analyze',selected,async()=>geminiResponse(JSON.stringify({bias:'SELL',summary:'ساختار کوتاه‌مدت نشانه‌های نزولی دارد و شکست حمایت باید تأیید شود.',observations:['قیمت زیر محدوده عرضه معامله می‌شود.'],risks:[],confidence:68,overlays:sell})));
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.bias,'SELL');
  assert.equal(result.body.providers.gemini.overlays.find(x=>x.kind==='TP3').price,98.0);
});

test('Gemini and OpenRouter keep their own separate overlays and plans without cross-model replacement', async () => {
  const selected={...input,selectedProviders:['gemini','openrouter'],modelSelection:{gemini:'gemini-3.8-flash',openrouter:'qwen/qwen3.8-27b:free'}};
  const result=await call('/analyze',selected,async url=>{
    if(String(url).includes('generativelanguage'))return geminiResponse();
    const different=validBuyOverlays().map(x=>x.kind==='Entry'?{...x,price:100.6}:x.kind==='SL'?{...x,price:99.4}:x.kind==='TP1'?{...x,price:102.0}:x.kind==='TP2'?{...x,price:103.0}:x.kind==='TP3'?{...x,price:104.0}:x);
    return new Response(JSON.stringify({model:'test/free-model',choices:[{finish_reason:'stop',message:{content:JSON.stringify({...validContractV3,bias:'BUY',summary:'ساختار صعودی از دید مستقل این مدل قابل بررسی است.',observations:[],risks:[],confidence:67,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:67,marketStructure:67,liquidity:67,entryConfirmation:67,riskReward:67},overlays:different})}}]}),{status:200});
  });
  const g=result.body.providers.gemini, o=result.body.providers.openrouter;
  assert.equal(g.status,'ok');assert.equal(o.status,'ok');
  assert.equal(g.overlays.find(x=>x.kind==='Entry').price,100.5);
  assert.equal(o.overlays.find(x=>x.kind==='Entry').price,100.6);
  assert.notDeepEqual(g.overlays,o.overlays);
});

test('execution levels outside historical price bounds are removed and the AI signal is downgraded to WAIT', async () => {
  const extended = validBuyOverlays().map(x => x.kind === 'TP3' ? {...x, price: 500} : x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({
    bias:'BUY',summary:'سناریوی صعودی فقط در صورت حفظ ساختار معتبر است.',observations:[],risks:[],confidence:70,overlays:extended
  })));
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.confidence,0);
  assert.equal(ai.overlays.some(x=>['Entry','SL','TP1','TP2','TP3'].includes(x.kind)),false);
  assert.ok(ai.risks.some(x=>x.includes('برنامه ورود')));
});


test('BUY signal is downgraded when every available POI is outside the submitted market-history envelope', async () => {
  const invalidZone = validBuyOverlays().map(x => ['Bullish OB','Bullish FVG'].includes(x.kind) ? {...x, low: 180, high: 181} : x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({
    bias:'BUY',summary:'سناریوی صعودی تنها با ناحیه تقاضای معتبر قابل قبول است.',observations:[],risks:[],confidence:72,overlays:invalidZone
  })));
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.bias,'WAIT');
  assert.equal(ai.confidence,0);
  assert.equal(ai.overlays.some(x=>['Entry','SL','TP1','TP2','TP3'].includes(x.kind)),false);
  assert.equal(ai.overlays.some(x=>x.kind==='Bullish OB'),false);
  assert.ok(ai.risks.some(x=>x.includes('POI معتبر')));
});

test('a valid OB alone is sufficient POI; FVG is not mandatory', async () => {
  const obOnly = validBuyOverlays().filter(x => x.kind !== 'Bullish FVG');
  const response = JSON.stringify({...validContractV3,bias:'BUY',summary:'ناحیه تقاضای معتبر با ساختار صعودی هم‌راستا است.',observations:['بازآزمایی ناحیه تقاضا قابل مشاهده است.'],risks:[],confidence:72,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:75,marketStructure:75,liquidity:70,entryConfirmation:80,riskReward:70},overlays:obOnly});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  assert.equal(result.body.providers.gemini.bias,'BUY');
  assert.ok(result.body.providers.gemini.overlays.some(x=>x.kind==='Bullish OB'));
  assert.equal(result.body.providers.gemini.overlays.some(x=>x.kind==='Bullish FVG'),false);
});

test('directional OB/FVG metadata must agree with the zone label', async () => {
  const invalidZone = validBuyOverlays().filter(x => x.kind !== 'Bullish OB').map(x => x.kind === 'Bullish FVG' ? {...x, direction:'bearish'} : x);
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify({
    bias:'BUY',summary:'ساختار صعودی برای ورود به تأیید نیاز دارد.',observations:[],risks:[],confidence:70,overlays:invalidZone
  })));
  assert.notEqual(result.body.providers.gemini.bias,'BUY');
  assert.equal(result.body.providers.gemini.status,'ok');
});

test('provider analytical weights are normalized and factor scores are preserved independently', async () => {
  const response = JSON.stringify({...validContractV3,bias:'WAIT',summary:'برای ورود هنوز تأیید کافی دیده نمی‌شود.',observations:['ساختار کوتاه‌مدت خنثی است.'],risks:['شکست محدوده می‌تواند نوسان را افزایش دهد.'],confidence:62,analyticalWeights:{trend:40,marketStructure:20,liquidity:15,entryConfirmation:15,riskReward:10},factorScores:{trend:80,marketStructure:65,liquidity:55,entryConfirmation:60,riskReward:75},overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  const ai = result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.weightsProvided,true);
  assert.equal(Object.values(ai.analyticalWeights).reduce((a,b)=>a+b,0),100);
  assert.equal(ai.analyticalWeights.trend,40);
  assert.equal(ai.factorScores.riskReward,75);
});

test('legacy or incomplete analysis contract is marked degraded and cannot provide Hybrid weights', async () => {
  const incomplete = {...validContractV3, evidence:[], timeframeAnalysis:{...validContractV3.timeframeAnalysis, '5m':{trend:'UNKNOWN'}}};
  const response = JSON.stringify({...incomplete,bias:'WAIT',summary:'برای ورود تأیید کافی وجود ندارد.',observations:[],risks:[],confidence:55,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:50,marketStructure:50,liquidity:50,entryConfirmation:50,riskReward:50},overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  assert.equal(result.body.providers.gemini.contractStatus,'NORMALIZED');
  assert.equal(result.body.providers.gemini.weightsProvided,true);
});

test('legacy model response without self-assigned weights is marked unqualified for hybrid decisions', async () => {
  const response = JSON.stringify({bias:'WAIT',summary:'بازار هنوز جهت مشخصی ندارد و بهتر است منتظر ماند.',observations:[],risks:[],confidence:45,overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.weightsProvided,false);
});


test('altFINS quota endpoint uses the server secret and exposes balances without exposing the key', async () => {
  const originalFetch = globalThis.fetch;
  let requestHeaders;
  globalThis.fetch = async (url, options) => {
    assert.match(String(url), /monthly-available-permits$/);
    requestHeaders = new Headers(options.headers);
    return new Response(JSON.stringify({availablePermits:29,monthlyAvailablePermits:987,monthlyAvailableAiTradeSetupPrompts:0}), {status:200});
  };
  try {
    const request = new Request('https://gateway.test/altfins/quota');
    const response = await worker.fetch(request, {...env(), ALTFINS_API_KEY:'private-altfins-key'});
    const body = await response.json();
    assert.equal(response.status,200);
    assert.equal(body.quota.monthlyAvailablePermits,987);
    assert.equal(body.quota.monthlyAvailableAiTradeSetupPrompts,0);
    assert.equal(requestHeaders.get('X-API-KEY'),'private-altfins-key');
    assert.equal(JSON.stringify(body).includes('private-altfins-key'),false);
  } finally { globalThis.fetch = originalFetch; }
});

test('altFINS validation maps Binance symbols and 15m interval and returns normalized context', async () => {
  const originalFetch = globalThis.fetch;
  let sent;
  globalThis.fetch = async (url, options) => {
    assert.match(String(url), /screener-data\/search-requests/);
    sent = JSON.parse(options.body);
    assert.equal(new Headers(options.headers).get('X-API-KEY'),'private-altfins-key');
    return new Response(JSON.stringify({content:[{symbol:'BTC',name:'Bitcoin',lastPrice:65000,rsi14:54,adx:23,macd:12,macdSignalLine:8,ema9:64900,ema50:64000,ema200:61000,atr:500,volume:123456,volumeRelative:1.4,shortTermTrend:'UP',mediumTermTrend:'UP',longTermTrend:'NEUTRAL',support:63000,resistance:67000}]}),{status:200});
  };
  try {
    const request = new Request('https://gateway.test/altfins/validation', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({symbol:'BTCUSDT',timeframe:'15m',exchange:'BINANCE',tradingType:'FUTURES'})});
    const response = await worker.fetch(request, {...env(), ALTFINS_API_KEY:'private-altfins-key'});
    const body = await response.json();
    assert.equal(response.status,200);
    assert.equal(body.status,'AVAILABLE');
    assert.equal(body.symbol,'BTC');
    assert.equal(body.data.rsi14,54);
    assert.equal(sent.symbols[0],'BTC');
    assert.equal(sent.timeInterval,'MINUTES15');
    assert.equal(sent.exchangeFilter,'BINANCE');
    assert.equal(sent.tradingTypeFilter,'FUTURES');
    assert.equal(body.affectsTradeDecision,undefined);
  } finally { globalThis.fetch = originalFetch; }
});

test('altFINS unsupported 5m timeframe is rejected without spending API credits', async () => {
  const originalFetch = globalThis.fetch;
  let called = false;
  globalThis.fetch = async () => { called = true; throw new Error('must not call altFINS'); };
  try {
    const request = new Request('https://gateway.test/altfins/validation', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({symbol:'BTCUSDT',timeframe:'5m'})});
    const response = await worker.fetch(request, {...env(), ALTFINS_API_KEY:'private-altfins-key'});
    const body = await response.json();
    assert.equal(response.status,400);
    assert.equal(body.status,'INVALID_INPUT');
    assert.equal(called,false);
  } finally { globalThis.fetch = originalFetch; }
});

test('altFINS Basic plan restriction is soft-failed and cannot affect trade decisions', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => new Response(JSON.stringify({message:'Forbidden'}),{status:403});
  try {
    const request = new Request('https://gateway.test/altfins/validation', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({symbol:'ETHUSDT',timeframe:'1h'})});
    const response = await worker.fetch(request, {...env(), ALTFINS_API_KEY:'private-altfins-key'});
    const body = await response.json();
    assert.equal(response.status,200);
    assert.equal(body.status,'PLAN_RESTRICTED');
    assert.equal(body.affectsTradeDecision,false);
  } finally { globalThis.fetch = originalFetch; }
});

test('OpenRouter retries endpoint incompatibility without strict schema and without require_parameters', async () => {
  let calls=0;
  const result=await call('/analyze',{...input,selectedProviders:['openrouter'],modelSelection:{openrouter:'qwen/qwen3.8-27b:free'}},async (url,options)=>{
    if(String(url).includes('/models')) return new Response(JSON.stringify({data:[{id:'qwen/qwen3.8-27b:free',architecture:{input_modalities:['text'],output_modalities:['text']},pricing:{prompt:'0',completion:'0'},context_length:262144,supported_parameters:[]}]}),{status:200});
    calls++;
    const sent=JSON.parse(options.body);
    if(calls===1) { assert.equal(sent.provider.require_parameters,undefined); return new Response(JSON.stringify({error:{message:'No endpoints found that support the requested parameters'}}),{status:404}); }
    assert.equal(sent.response_format,undefined); assert.equal(sent.reasoning,undefined); assert.equal(sent.provider.require_parameters,undefined); assert.equal(sent.model,'openrouter/free');
    return openRouterResponse();
  });
  assert.equal(calls,2);
  assert.equal(result.body.providers.openrouter.status,'ok');
  assert.equal(result.body.providers.openrouter.contractVersion,3);
});

test('V3 normalizes small buyer/seller strength rounding drift and empty findings safely', async () => {
  const normalized = {...validContractV3,
    timeframeAnalysis: Object.fromEntries(['1h','15m','5m'].map(tf=>[tf,{...validContractV3.timeframeAnalysis[tf],buyerStrength:67,sellerStrength:36}])),
    analysisSections:{...validAnalysisSectionsV3,scenarios:{status:'INSUFFICIENT_DATA',findings:[]}},
    bias:'WAIT',summary:'داده‌های فعلی برای ورود قطعی کافی نیستند.',observations:[],risks:[],confidence:30,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:30,marketStructure:30,liquidity:30,entryConfirmation:30,riskReward:30},overlays:[]
  };
  const result=await call('/analyze',input,async()=>geminiResponse(JSON.stringify(normalized)));
  const ai=result.body.providers.gemini;
  assert.equal(ai.status,'ok');
  assert.equal(ai.contractStatus,'VALID');
  assert.equal(ai.timeframeAnalysis['5m'].buyerStrength+ai.timeframeAnalysis['5m'].sellerStrength,100);
  assert.equal(ai.analysisSections.scenarios.status,'INSUFFICIENT_DATA');
  assert.ok(ai.analysisSections.scenarios.findings.length===0);
});

test('V3 timeframe normalization preserves valid fields when one strength field is missing and accepts provider casing aliases', async () => {
  const varied = JSON.parse(JSON.stringify(validContractV3));
  varied.timeframeAnalysis = {
    '1H': {...varied.timeframeAnalysis['1h'], buyerStrength:null},
    '15M': {...varied.timeframeAnalysis['15m'], trend:'bull', structure:'transition', phase:'trend', liquidity:'sell_side_sweep'},
    '5M': {...varied.timeframeAnalysis['5m']}
  };
  const response = JSON.stringify({...varied,bias:'WAIT',summary:'برای ورود هنوز شواهد کافی وجود ندارد.',observations:[],risks:[],confidence:50,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:50,marketStructure:50,liquidity:50,entryConfirmation:50,riskReward:50},overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  const tf = result.body.providers.gemini.timeframeAnalysis;
  assert.equal(tf['1h'].trend,'BULLISH');
  assert.equal(tf['1h'].structure,'BULLISH');
  assert.equal(tf['1h'].buyerStrength,null);
  assert.equal(tf['15m'].trend,'BULLISH');
  assert.equal(tf['15m'].structure,'TRANSITION');
  assert.equal(tf['15m'].phase,'TRENDING');
  assert.equal(tf['15m'].liquidity,'SELL_SIDE_SWEEP');
  assert.equal(tf['5m'].trend,'BULLISH');
});

test('V3 contract rejects missing comprehensive analysis sections', async () => {
  const bad={...validAnalysisSectionsV3}; delete bad.scenarios;
  const result=await call('/analyze',input,async (url)=>{
    if(String(url).includes('generateContent')) return geminiResponse(JSON.stringify({...validContractV3,analysisSections:bad,bias:'WAIT',summary:'تحلیل نیازمند داده بیشتری است.',observations:[],risks:[],confidence:0,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:0,marketStructure:0,liquidity:0,entryConfirmation:0,riskReward:0},overlays:[]}));
    throw new Error('unexpected provider');
  });
  assert.equal(result.body.providers.gemini.contractStatus,'NORMALIZED');
  assert.equal(result.body.providers.gemini.weightsProvided,true);
});


test('timeframe parser recognizes explicit BOS/CHOCH aliases and does not mislabel omitted timeframes as UNKNOWN', async () => {
  const varied = {...validContractV3, timeframeAnalysis: {
    '1H': {trend:'uptrend',structure:'BOS bullish',phase:'markup',buyerStrength:60,sellerStrength:40,liquidity:'none',evidence:['کف بالاتر و شکست سقف ساختاری مشاهده شد']},
    '15M': {trend:'bearish',structure:'CHOCH bearish',phase:'trend',buyerStrength:35,sellerStrength:65,liquidity:'SSL',evidence:['تغییر ساختار نزولی پس از شکست کف ثبت شد']}
  }};
  const response = JSON.stringify({...varied,bias:'WAIT',summary:'برای ورود هنوز شواهد کافی وجود ندارد.',observations:[],risks:[],confidence:30,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:30,marketStructure:30,liquidity:30,entryConfirmation:30,riskReward:30},overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  const tf = result.body.providers.gemini.timeframeAnalysis;
  assert.equal(tf['1h'].provided,true);
  assert.equal(tf['1h'].structure,'BULLISH');
  assert.equal(tf['1h'].structureEvent,'BOS_BULLISH');
  assert.equal(tf['15m'].structure,'TRANSITION');
  assert.equal(tf['15m'].structureEvent,'CHOCH_BEARISH');
  assert.equal(tf['15m'].trend,'BEARISH');
  assert.equal(tf['5m'].provided,false);
  assert.equal(tf['5m'].structure,'UNKNOWN');
  assert.notEqual(result.body.providers.gemini.contractStatus,'VALID');
});

test('supplementary categories exclude canonical analysis and metadata noise', async () => {
  const responseObject = {...validContractV3,bias:'WAIT',summary:'تحلیل فعلی برای ورود کافی نیست.',observations:[],risks:[],confidence:25,
    analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},
    factorScores:{trend:25,marketStructure:25,liquidity:25,entryConfirmation:25,riskReward:25},overlays:[],
    additionalData:{openInterest:1250000,fundingRate:'نرخ تأمین مالی مثبت و محدود گزارش شده است.',orderBook:'عمق سفارش خرید در نزدیکی قیمت بیشتر گزارش شده است.'}};
  const result = await call('/analyze', input, async () => geminiResponse(JSON.stringify(responseObject)));
  const categories = result.body.providers.gemini.dataCategories;
  assert.equal(categories.derivatives.length,2);
  assert.ok(categories.derivatives.some(x=>x.text==='1250000'));
  assert.equal(categories.orderBook.length,1);
  assert.equal(categories.marketStructure,undefined);
  assert.equal(categories.marketRegime,undefined);
  for (const items of Object.values(categories)) {
    for (const item of items) assert.match(item.sourcePath,/^additionalData\./);
  }
});

test('historyStartPrice is treated only as the first-candle decoding seed, not a live-price anchor', async () => {
  const newInput = JSON.parse(JSON.stringify(input));
  const lastClose = 100 * Math.pow(1.005, 60);
  for (const tf of ['1h','15m','5m']) {
    newInput.marketHistory[tf].historyStartPrice = newInput.marketHistory[tf].basePrice;
    delete newInput.marketHistory[tf].basePrice;
  }
  newInput.referencePrice = lastClose;
  newInput.lastClosed5mClose = lastClose;
  const result = await call('/analyze', newInput, async (url, options) => {
    const request = JSON.parse(options.body);
    const prompt = request.contents?.[0]?.parts?.[0]?.text || '';
    assert.match(prompt, /historyStartPrice/);
    assert.match(prompt, /NOT the current price/);
    assert.match(prompt, /Never compare historyStartPrice values across timeframes/);
    return geminiResponse(JSON.stringify({...validContractV3,bias:'WAIT',summary:'قیمت مرجع با آخرین کندل بسته‌شده هم‌خوان است و هنوز تأیید ورود وجود ندارد.',observations:[],risks:[],confidence:35,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:35,marketStructure:35,liquidity:35,entryConfirmation:35,riskReward:35},overlays:[]}));
  });
  assert.equal(result.status,200);
  assert.equal(result.body.providers.gemini.status,'ok');
});


test('timeframe normalizer extracts explicit Persian and English timeframe findings from provider prose without qualifying incomplete contracts', async () => {
  const varied = {...validContractV3};
  delete varied.timeframeAnalysis;
  varied.summary = 'تحلیل مستقل مدل:\n1H: ساختار BEARISH است؛ سقف و کف‌های پایین‌تر دیده می‌شود.\n15M: ساختار RANGE/ACCUMULATION است و قیمت بین یک دامنه محدود نوسان می‌کند.\n5M: ساختار BEARISH است؛ پس از شکست نزولی BOS_BEArISH قیمت به دنبال نزول ادامه داده است.';
  const response = JSON.stringify({...varied,bias:'WAIT',observations:[],risks:[],confidence:45,analyticalWeights:{trend:20,marketStructure:20,liquidity:20,entryConfirmation:20,riskReward:20},factorScores:{trend:45,marketStructure:45,liquidity:45,entryConfirmation:45,riskReward:45},overlays:[]});
  const result = await call('/analyze', input, async () => geminiResponse(response));
  const tf = result.body.providers.gemini.timeframeAnalysis;
  assert.equal(tf['1h'].provided,true);
  assert.equal(tf['1h'].trend,'BEARISH');
  assert.equal(tf['15m'].trend,'RANGE');
  assert.equal(tf['15m'].phase,'ACCUMULATION');
  assert.equal(tf['5m'].trend,'BEARISH');
  assert.notEqual(result.body.providers.gemini.contractStatus,'VALID');
});

