# V6.3.3.5 — AI timeframe consensus and Smart Connectivity repair

## Findings from the 2026-11-22 screenshots
- The dashboard displayed timeframe directions for OpenRouter/Groq but reported 0/3 eligible votes.
- The Worker was requiring the aggregate `regime` section and provider-level directional bias to qualify each individual timeframe vote. This contradicted the per-timeframe independence contract.
- Smart Connectivity showed Gemini `TIMEOUT_OR_NETWORK` and OpenRouter `HTTP 200 / EMPTY_RESPONSE`. The health probe had an eight-token output budget, which is too small for some reasoning-capable models.

## Changes
1. A 1H/15M/5M vote is now eligible only when the provider response is `ok`, that timeframe is structured (not narrative-only), its trend is BULLISH/BEARISH, and its own market-structure evidence is `VALIDATED`. No aggregate regime, provider-level bias, other timeframe, factor, or trade-plan gate is applied to this per-timeframe vote.
2. Provider-level directional consensus remains separately governed by the existing directional evidence rules. Final trading decisions still require the existing Technical/AI agreement and minimum two-provider consensus.
3. Health-probe output budget increased from 8 to 32 tokens.
4. Smart Connectivity now explains `EMPTY_RESPONSE`, `TIMEOUT_OR_NETWORK`, `UPSTREAM_ERROR`, and `RATE_LIMITED` as transient/diagnostic states and does not render an HTTP 200 empty response as a confirmed access block. Authentication, access-denied, and unavailable-model errors remain blocked.

## Verification
- `node --check ai-gateway/worker.js`: passed.
- Full Node regression suite: 157 tests total; results recorded in `TEST-REPORT-V6.3.3.5.txt`.
- Flutter/Dart SDK is unavailable in the build environment; no claim is made that `flutter analyze`, Flutter tests, or APK build ran locally.
- No live provider inference, Cloudflare deployment, GitHub push, or APK build was performed.
- Confirmed Gateway domain, Worker name, secrets, and bindings are unchanged. Worker redeployment is required to activate V6.3.3.5.
