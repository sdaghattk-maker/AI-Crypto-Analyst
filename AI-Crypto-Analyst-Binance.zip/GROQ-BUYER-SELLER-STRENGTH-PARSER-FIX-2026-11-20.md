# Groq Buyer/Seller Strength Parser Fix — 2026-11-20

## Root cause addressed
The strength normalizer previously accepted only direct numeric fields (`buyerStrength` / `sellerStrength`). Provider-native Groq responses that expressed percentages as strings (including Persian digits and `%`) or nested them under `buyerSellerStrength`, `marketPower`, `orderFlow`, `strength`, `pressure`, or `power` could be missed.

The dashboard also required an exact lowercase `5m` map key and a `provided == true` marker, which could hide otherwise normalized values in compatible older snapshots.

## Changes
- Added normalized key matching and aliases for buyer/seller strength fields.
- Added safe percentage parsing for numbers, numeric strings, Persian/Arabic digits, percent signs, and nested `{value|percent|percentage|pct|score|strength}` objects.
- Added nested strength groups while preserving the requirement that both buyer and seller values are explicitly present and valid.
- Kept normalization source-local; no Technical/Gemini/OpenRouter values are substituted for Groq.
- Dashboard now resolves 5m/5min/5minute keys case-insensitively and can display explicitly present validated strength values even if an older cached payload lacks the `provided` marker. Explicit `provided:false` remains unavailable.
- Added a regression test for nested Groq payload, Persian percentage digits, and percent strings.

## Validation
- `node --check ai-gateway/worker.js`: passed.
- `node --test ai-gateway/tests/worker.test.mjs`: 49 passed, 0 failed.
- Flutter analyze/build was not run in this environment (Flutter SDK unavailable).
- Cloudflare Worker deployment and live Groq response validation are not performed by packaging this ZIP; deploy the updated `ai-gateway/worker.js` separately.
