# Groq nested payload normalization fix — 2026-11-20

## Scope

This patch is based on `AI-Crypto-Analyst-FOUR-SOURCE-HYBRID-DASHBOARD-FIX-2026-11-20.zip`. It changes only the AI Gateway normalizer and its tests. Dashboard rendering, provider independence, Technical Engine inputs, and the four-source decision architecture are left unchanged.

## Changes

- Recursively expands JSON strings nested in provider response objects (including `result`, `analysis`, `content`, `data`, and other nested fields), with bounded depth and payload size.
- Merges timeframe maps found at different nesting levels instead of stopping at the first map.
- Recognizes timeframe objects that expose `structureEvent` / `structure_event` without relying only on a narrow field list.
- Normalizes directional phase labels such as `BULLISH` / `BEARISH` to the existing `TRENDING` phase enum. This does not change the trend field; it only prevents a valid directional phase from being discarded as UNKNOWN.
- Preserves string and object evidence entries, including event explanation fields.
- Keeps omitted timeframes explicitly `provided: false`; missing 15M is not fabricated from 1H or 5M.
- Keeps the original provider response in `rawText`; no data is copied from Technical Engine or another AI provider.
- Adds a Groq-focused regression test with nested JSON, split timeframe maps, `phase: BEARISH`, 1H buyer/seller strength, 5M BOS, and supplementary derivatives/order-book data.

## Verification

- `node --check ai-gateway/worker.js` — passed.
- `node --test ai-gateway/tests/worker.test.mjs` — 48 tests passed, 0 failed.
- Flutter analyze / APK build — not run; Flutter SDK is not installed in this environment.
- Live Groq API response and Cloudflare Worker deployment — not run. The updated Worker must be deployed separately for the change to affect the installed APK.
