import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'app_config.dart';
import 'market_api.dart';

class AiModelResult {
  const AiModelResult({
    required this.model,
    required this.status,
    this.bias,
    this.marketBias,
    this.directionalVoteEligible = false,
    this.directionalVoteReason,
    this.tradePlanEligible = false,
    this.summary,
    this.risks = const [],
    this.observations = const [],
    this.confidence,
    this.confidenceDeclared = false,
    this.analyticalWeights = const {},
    this.factorScores = const {},
    this.weightsProvided = false,
    this.factorScoresStatus = 'NOT_PROVIDED',
    this.analyticalWeightsStatus = 'NOT_PROVIDED',
    this.overlays = const [],
    this.providerModel,
    this.finishReason,
    this.nativeFinishReason,
    this.promptTokens,
    this.completionTokens,
    this.reasoningTokens,
    this.error,
    this.rawText,
    this.rawTextTruncated = false,
    this.rawTextOriginalLength,
    this.normalization = const {},
    this.responseFormat,
    this.fallbackUsed = false,
    this.attemptedModels = const [],
    this.responseTimeMs,
    this.contractVersion = 1,
    this.analysisSections = const {},
    this.analysisSectionStatus = const {},
    this.timeframeEvidenceValidation = const {},
    this.timeframeFactorEvidenceValidation = const {},
    this.timeframeVoteEligibility = const {},
    this.factorEvidenceValidation = const {},
    this.contractStatus = 'DEGRADED',
    this.schemaStatus,
    this.evidenceStatus = 'UNVERIFIED',
    this.evidenceValidation = const {},
    this.executionPriceValidation = const {},
    this.timeframeAnalysis = const {},
    this.timeframeProvenance = const {},
    this.evidence = const [],
    this.invalidation,
    this.dataCategories = const {},
    this.extractedFacts = const [],
    this.rawProviderResponse,
    this.rawProviderResponseTruncated = false,
    this.rawProviderResponseOriginalLength,
  });

  final String model;
  final String status;
  final String? bias;
  final String? marketBias;
  final bool directionalVoteEligible;
  final String? directionalVoteReason;
  final bool tradePlanEligible;
  final String? summary;
  final List<String> risks;
  final List<String> observations;
  final int? confidence;
  final bool confidenceDeclared;
  final Map<String, int> analyticalWeights;
  final Map<String, int> factorScores;
  final bool weightsProvided;
  final String factorScoresStatus;
  final String analyticalWeightsStatus;
  final List<Map<String, dynamic>> overlays;
  final String? providerModel;
  final String? finishReason;
  final String? nativeFinishReason;
  final int? promptTokens;
  final int? completionTokens;
  final int? reasoningTokens;
  final String? error;
  final String? rawText;
  final bool rawTextTruncated;
  final int? rawTextOriginalLength;
  final Map<String, dynamic> normalization;
  final String? responseFormat;
  final bool fallbackUsed;
  final List<String> attemptedModels;
  final int? responseTimeMs;
  final int contractVersion;
  final Map<String, dynamic> analysisSections;
  final Map<String, dynamic> analysisSectionStatus;
  final Map<String, dynamic> timeframeEvidenceValidation;
  final Map<String, dynamic> timeframeFactorEvidenceValidation;
  final Map<String, dynamic> timeframeVoteEligibility;
  final Map<String, dynamic> factorEvidenceValidation;
  final String contractStatus;
  final String? schemaStatus;
  final String evidenceStatus;
  final Map<String, dynamic> evidenceValidation;
  final Map<String, dynamic> executionPriceValidation;
  final Map<String, dynamic> timeframeAnalysis;
  final Map<String, dynamic> timeframeProvenance;
  final List<Map<String, dynamic>> evidence;
  final String? invalidation;
  final Map<String, dynamic> dataCategories;
  final List<Map<String, dynamic>> extractedFacts;
  final String? rawProviderResponse;
  final bool rawProviderResponseTruncated;
  final int? rawProviderResponseOriginalLength;

  Map<String, dynamic> toJson() => {
    'model': model, 'status': status, 'bias': bias, 'marketBias': marketBias, 'directionalVoteEligible': directionalVoteEligible, 'directionalVoteReason': directionalVoteReason, 'tradePlanEligible': tradePlanEligible, 'summary': summary,
    'risks': risks, 'observations': observations, 'confidence': confidence, 'confidenceDeclared': confidenceDeclared, 'analyticalWeights': analyticalWeights, 'factorScores': factorScores, 'weightsProvided': weightsProvided, 'factorScoresStatus': factorScoresStatus, 'analyticalWeightsStatus': analyticalWeightsStatus, 'overlays': overlays, 'providerModel': providerModel,
    'finishReason': finishReason, 'nativeFinishReason': nativeFinishReason,
    'promptTokens': promptTokens, 'completionTokens': completionTokens,
    'reasoningTokens': reasoningTokens, 'error': error, 'rawText': rawText, 'rawTextTruncated': rawTextTruncated, 'rawTextOriginalLength': rawTextOriginalLength, 'normalization': normalization, 'responseFormat': responseFormat, 'fallbackUsed': fallbackUsed, 'attemptedModels': attemptedModels, 'responseTimeMs': responseTimeMs, 'contractVersion': contractVersion, 'contractStatus': contractStatus, 'schemaStatus': schemaStatus, 'evidenceStatus': evidenceStatus, 'evidenceValidation': evidenceValidation, 'executionPriceValidation': executionPriceValidation, 'timeframeAnalysis': timeframeAnalysis, 'timeframeProvenance': timeframeProvenance, 'evidence': evidence, 'invalidation': invalidation, 'analysisSections': analysisSections, 'analysisSectionStatus': analysisSectionStatus, 'timeframeEvidenceValidation': timeframeEvidenceValidation, 'timeframeFactorEvidenceValidation': timeframeFactorEvidenceValidation, 'timeframeVoteEligibility': timeframeVoteEligibility, 'factorEvidenceValidation': factorEvidenceValidation, 'dataCategories': dataCategories, 'extractedFacts': extractedFacts, 'rawProviderResponse': rawProviderResponse, 'rawProviderResponseTruncated': rawProviderResponseTruncated, 'rawProviderResponseOriginalLength': rawProviderResponseOriginalLength,
  };

  factory AiModelResult.fromJson(String model, dynamic raw) {
    if (raw is! Map) {
      return AiModelResult(model: model, status: 'not_selected');
    }
    final confidenceValue = raw['confidence'];
    final confidenceNumber = confidenceValue is num
        ? confidenceValue.toDouble()
        : (confidenceValue == null ? double.nan : double.tryParse('$confidenceValue') ?? double.nan);
    final confidenceInRange = confidenceNumber.isFinite && confidenceNumber >= 0 && confidenceNumber <= 100;
    final parsedConfidence = confidenceInRange ? confidenceNumber.round() : null;
    final confidenceDeclared = raw['confidenceDeclared'] == true && confidenceInRange;
    int safeFactorInt(dynamic item) {
      final parsed = item is num ? item.toDouble() : double.tryParse('$item') ?? 0;
      return parsed.isFinite ? parsed.round().clamp(0, 100).toInt() : 0;
    }
    Map<String, int> intMap(dynamic value) {
      if (value is! Map) return const {};
      return {for (final entry in value.entries) entry.key.toString(): safeFactorInt(entry.value)};
    }
    bool validNumericMap(dynamic value, {bool sumTo100 = false}) {
      if (value is! Map || !aiRequiredFactorKeys.every(value.containsKey)) return false;
      final parsed = <double>[];
      for (final key in aiRequiredFactorKeys) {
        final item = value[key];
        if (item is! num || !item.toDouble().isFinite || item < 0 || item > 100 ||
            item.toDouble() != item.toDouble().roundToDouble()) return false;
        parsed.add(item.toDouble());
      }
      return !sumTo100 || parsed.reduce((a, b) => a + b) == 100;
    }
    final validAnalyticalWeights = validNumericMap(raw['analyticalWeights'], sumTo100: true);
    final validFactorScores = validNumericMap(raw['factorScores']);
    final validWeightsProvided = raw['weightsProvided'] == true && validAnalyticalWeights && validFactorScores;
    return AiModelResult(
      model: model,
      status: (raw['status'] ?? 'unknown').toString(),
      bias: raw['bias']?.toString(),
      marketBias: raw['marketBias']?.toString() ?? raw['bias']?.toString(),
      directionalVoteEligible: raw['directionalVoteEligible'] == true,
      directionalVoteReason: raw['directionalVoteReason']?.toString(),
      tradePlanEligible: raw['tradePlanEligible'] == true,
      summary: raw['summary']?.toString(),
      risks: raw['risks'] is List
          ? (raw['risks'] as List).map((e) => e.toString()).toList()
          : const [],
      observations: raw['observations'] is List
          ? (raw['observations'] as List).map((e) => e.toString()).toList()
          : const [],
      confidence: parsedConfidence,
      confidenceDeclared: confidenceDeclared,
      analyticalWeights: validAnalyticalWeights ? intMap(raw['analyticalWeights']) : const {},
      factorScores: validFactorScores ? intMap(raw['factorScores']) : const {},
      weightsProvided: validWeightsProvided,
      factorScoresStatus: raw['factorScoresStatus']?.toString() ?? (raw['factorScores'] == null || (raw['factorScores'] is Map && (raw['factorScores'] as Map).isEmpty) ? 'NOT_PROVIDED' : validFactorScores ? 'PROVIDED' : 'INVALID_OPTIONAL_METADATA'),
      analyticalWeightsStatus: raw['analyticalWeightsStatus']?.toString() ?? (raw['analyticalWeights'] == null || (raw['analyticalWeights'] is Map && (raw['analyticalWeights'] as Map).isEmpty) ? 'NOT_PROVIDED' : validAnalyticalWeights ? 'PROVIDED' : 'INVALID_OPTIONAL_METADATA'),
      overlays: raw['overlays'] is List
          ? (raw['overlays'] as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
          : const [],
      providerModel: raw['providerModel']?.toString(),
      finishReason: raw['finishReason']?.toString(),
      nativeFinishReason: raw['nativeFinishReason']?.toString(),
      promptTokens: (raw['promptTokens'] as num?)?.toInt(),
      completionTokens: (raw['completionTokens'] as num?)?.toInt(),
      reasoningTokens: (raw['reasoningTokens'] as num?)?.toInt(),
      error: raw['error']?.toString(),
      rawText: raw['rawText']?.toString(),
      rawTextTruncated: raw['rawTextTruncated'] == true || (raw['normalization'] is Map && raw['normalization']['rawTextTruncated'] == true),
      rawTextOriginalLength: (raw['rawTextOriginalLength'] as num?)?.toInt(),
      normalization: raw['normalization'] is Map ? Map<String, dynamic>.from(raw['normalization'] as Map) : const {},
      responseFormat: raw['responseFormat']?.toString(),
      fallbackUsed: raw['fallbackUsed'] == true,
      attemptedModels: raw['attemptedModels'] is List ? (raw['attemptedModels'] as List).map((x)=>x.toString()).toList() : const [],
      responseTimeMs: (raw['responseTimeMs'] as num?)?.toInt(),
      contractVersion: (raw['contractVersion'] as num?)?.toInt() ?? 1,
      analysisSections: raw['analysisSections'] is Map ? Map<String,dynamic>.from(raw['analysisSections'] as Map) : const {},
      analysisSectionStatus: raw['analysisSectionStatus'] is Map ? Map<String,dynamic>.from(raw['analysisSectionStatus'] as Map) : const {},
      timeframeEvidenceValidation: raw['timeframeEvidenceValidation'] is Map ? Map<String,dynamic>.from(raw['timeframeEvidenceValidation'] as Map) : const {},
      timeframeFactorEvidenceValidation: raw['timeframeFactorEvidenceValidation'] is Map ? Map<String,dynamic>.from(raw['timeframeFactorEvidenceValidation'] as Map) : const {},
      timeframeVoteEligibility: raw['timeframeVoteEligibility'] is Map ? Map<String,dynamic>.from(raw['timeframeVoteEligibility'] as Map) : const {},
      factorEvidenceValidation: raw['factorEvidenceValidation'] is Map ? Map<String,dynamic>.from(raw['factorEvidenceValidation'] as Map) : const {},
      contractStatus: raw['contractStatus']?.toString() ?? 'DEGRADED',
      schemaStatus: raw['schemaStatus']?.toString(),
      evidenceStatus: raw['evidenceStatus']?.toString() ?? 'UNVERIFIED',
      evidenceValidation: raw['evidenceValidation'] is Map ? Map<String,dynamic>.from(raw['evidenceValidation'] as Map) : const {},
      executionPriceValidation: raw['executionPriceValidation'] is Map ? Map<String,dynamic>.from(raw['executionPriceValidation'] as Map) : const {},
      timeframeAnalysis: raw['timeframeAnalysis'] is Map ? Map<String,dynamic>.from(raw['timeframeAnalysis'] as Map) : const {},
      timeframeProvenance: raw['timeframeProvenance'] is Map ? Map<String,dynamic>.from(raw['timeframeProvenance'] as Map) : const {},
      evidence: raw['evidence'] is List ? (raw['evidence'] as List).whereType<Map>().map((e)=>Map<String,dynamic>.from(e)).toList() : const [],
      invalidation: raw['invalidation']?.toString(),
      dataCategories: raw['dataCategories'] is Map ? Map<String,dynamic>.from(raw['dataCategories'] as Map) : const {},
      extractedFacts: raw['extractedFacts'] is List ? (raw['extractedFacts'] as List).whereType<Map>().map((e)=>Map<String,dynamic>.from(e)).toList() : const [],
      rawProviderResponse: raw['rawProviderResponse']?.toString(),
      rawProviderResponseTruncated: raw['rawProviderResponseTruncated'] == true,
      rawProviderResponseOriginalLength: (raw['rawProviderResponseOriginalLength'] as num?)?.toInt(),
    );
  }
}

const aiRequiredFactorKeys = <String>{
  'trend', 'marketStructure', 'liquidity', 'entryConfirmation', 'riskReward',
};

/// Directional vote eligibility is authored by the Gateway after candle/evidence
/// validation. Trade-plan validity is checked separately by the execution layer.
bool aiModelIsConsensusEligible(AiModelResult provider) {
  // The Worker is the single authority for candle/evidence validation.
  // Flutter consumes its explicit vote decision; it does not re-run a stricter,
  // divergent approximation based on model weights, confidence or trade plan.
  final direction = (provider.marketBias ?? provider.bias)?.toUpperCase();
  return provider.directionalVoteEligible &&
      (direction == 'BUY' || direction == 'SELL');
}

bool aiModelHasValidExecutionPlan(AiModelResult provider) {
  // Trade-plan qualification is also computed by the Gateway against its
  // candle history, reference price, ATR and POI. Flutter only consumes it.
  return provider.tradePlanEligible;
}

List<Map<String, dynamic>> _buildConsensusOverlays(List<AiModelResult> agreeing) {
  if (agreeing.length < 2) return const [];
  bool matches(Map<String, dynamic> a, Map<String, dynamic> b) {
    if (a['type'] != b['type'] || a['kind'] != b['kind'] ||
        a['direction'] != b['direction'] || a['timeframe'] != b['timeframe']) return false;
    if (a['type'] == 'line') {
      final pa = double.tryParse('${a['price']}');
      final pb = double.tryParse('${b['price']}');
      if (pa == null || pb == null || !pa.isFinite || !pb.isFinite) return false;
      final mid = (pa + pb) / 2;
      return mid > 0 && (pa - pb).abs() / mid <= 0.0015;
    }
    if (a['type'] == 'zone') {
      final al = double.tryParse('${a['low']}');
      final ah = double.tryParse('${a['high']}');
      final bl = double.tryParse('${b['low']}');
      final bh = double.tryParse('${b['high']}');
      if (al == null || ah == null || bl == null || bh == null ||
          !al.isFinite || !ah.isFinite || !bl.isFinite || !bh.isFinite) return false;
      final overlap = (ah < bh ? ah : bh) - (al > bl ? al : bl);
      final span = (ah > bh ? ah : bh) - (al < bl ? al : bl);
      return span > 0 && overlap / span >= 0.5;
    }
    return false;
  }

  final result = <Map<String, dynamic>>[];
  final seen = <String>{};
  // The project rule is at least two independent providers, not unanimity.
  // Compare every provider pair so a third model cannot veto a valid pair.
  for (var i = 0; i < agreeing.length; i++) {
    for (var j = i + 1; j < agreeing.length; j++) {
      final first = agreeing[i];
      final second = agreeing[j];
      for (final a in first.overlays) {
        for (final b in second.overlays) {
          if (!matches(a, b)) continue;
          final key = '${a['type']}|${a['kind']}|${a['direction']}|${a['timeframe']}';
          if (seen.contains(key)) continue;
          if (a['type'] == 'line') {
            final pa = double.parse('${a['price']}');
            final pb = double.parse('${b['price']}');
            result.add({...a, 'price': (pa + pb) / 2, 'agreement': 'multi',
              'agreementCount': 2, 'agreementProviders': [first.model, second.model]});
          } else if (a['type'] == 'zone') {
            final low = [double.parse('${a['low']}'), double.parse('${b['low']}')]
                .reduce((x, y) => x > y ? x : y);
            final high = [double.parse('${a['high']}'), double.parse('${b['high']}')]
                .reduce((x, y) => x < y ? x : y);
            if (high <= low) continue;
            result.add({...a, 'low': low, 'high': high, 'agreement': 'multi',
              'agreementCount': 2, 'agreementProviders': [first.model, second.model]});
          }
          seen.add(key);
          if (result.length >= 30) return result;
        }
      }
    }
  }
  return result;
}

class AiConsensus {
  const AiConsensus({
    required this.gemini,
    required this.openrouter,
    required this.groq,
    required this.decision,
    required this.conflicts,
    this.aiOverlays = const [],
    this.snapshotId,
    this.dataQuality = const {},
  });

  final AiModelResult gemini;
  final AiModelResult openrouter;
  final AiModelResult groq;
  final String decision;
  final List<String> conflicts;
  final List<Map<String, dynamic>> aiOverlays;
  final String? snapshotId;
  final Map<String,dynamic> dataQuality;

  Map<String, dynamic> toJson() => {
    'gemini': gemini.toJson(), 'openrouter': openrouter.toJson(), 'groq': groq.toJson(),
    'decision': decision, 'conflicts': conflicts, 'aiOverlays': aiOverlays, 'snapshotId': snapshotId, 'dataQuality': dataQuality,
  };

  factory AiConsensus.fromJson(Map<String, dynamic> json) {
    final conflictsRaw = json['conflicts'];
    return AiConsensus(
      gemini: AiModelResult.fromJson('Gemini', json['gemini']),
      openrouter: AiModelResult.fromJson('OpenRouter', json['openrouter']),
      groq: AiModelResult.fromJson('Groq', json['groq']),
      decision: const {'BUY', 'SELL', 'WAIT'}.contains('${json['decision']}'.toUpperCase())
          ? '${json['decision']}'.toUpperCase() : 'WAIT',
      conflicts: conflictsRaw is List ? conflictsRaw.map((e) => e.toString()).toList() : const [],
      aiOverlays: json['aiOverlays'] is List
          ? (json['aiOverlays'] as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
          : const [],
      snapshotId: json['snapshotId']?.toString(),
      dataQuality: json['dataQuality'] is Map ? Map<String,dynamic>.from(json['dataQuality'] as Map) : const {},
    );
  }

  /// Merge a partial provider response into the saved result for the same
  /// market snapshot. `not_selected` means "not requested in this run", not
  /// "erase the previous answer".
  AiConsensus mergePartial(AiConsensus incoming) {
    // A partial retry is mergeable only within the exact same immutable
    // market snapshot. Never combine providers analyzed against different data.
    if (snapshotId != incoming.snapshotId) return incoming;
    AiModelResult keepOrUpdate(AiModelResult previous, AiModelResult next) {
      if (next.status == 'not_selected') return previous;
      if (next.status == 'error' && previous.status == 'ok') return previous;
      return next;
    }

    final mergedGemini = keepOrUpdate(gemini, incoming.gemini);
    final mergedOpenRouter = keepOrUpdate(openrouter, incoming.openrouter);
    final mergedGroq = keepOrUpdate(groq, incoming.groq);
    final voteEligible = [mergedGemini, mergedOpenRouter, mergedGroq]
        .where(aiModelIsConsensusEligible)
        .toList();
    final votes = <String, int>{'BUY': 0, 'SELL': 0, 'WAIT': 0};
    for (final r in voteEligible) {
      final direction = (r.marketBias ?? r.bias)!.toUpperCase();
      votes[votes.containsKey(direction) ? direction : 'WAIT'] =
          (votes[votes.containsKey(direction) ? direction : 'WAIT'] ?? 0) + 1;
    }
    final majorityEntries = votes.entries.where((e) => e.value >= 2).toList();
    final majority = majorityEntries.isEmpty ? 'WAIT' : majorityEntries.first.key;
    final agreeing = voteEligible.where((r) => (r.marketBias ?? r.bias)!.toUpperCase() == majority).toList();
    final decision = agreeing.length >= 2 &&
            (majority == 'BUY' || majority == 'SELL')
        ? majority
        : 'WAIT';
    final conflicts = <String>[];
    if (voteEligible.isEmpty) {
      conflicts.add('هیچ مدلی هم‌زمان جهت ساختاریافته و شواهد کندلی معتبر برای رأی بازار ارائه نکرده است.');
    } else if (voteEligible.length == 1) {
      conflicts.add('فقط یک مدل دارای جهت و شواهد معتبر است؛ این جهت اجماع چندمدلی نیست.');
    } else if (voteEligible.length >= 2 && decision == 'WAIT') {
      conflicts.add('مدل‌های معتبر هم‌جهت نیستند؛ اجماع جهت‌دار تشکیل نشد.');
    }
    for (final r in [incoming.gemini, incoming.openrouter, incoming.groq]) {
      if (r.status == 'error' && (r.error ?? '').isNotEmpty) {
        final retained = [mergedGemini, mergedOpenRouter, mergedGroq]
            .any((saved) => saved.model == r.model && saved.status == 'ok');
        conflicts.add(retained
            ? '${r.model}: تلاش مجدد ناموفق بود؛ پاسخ موفق قبلی برای همین Snapshot حفظ شد. ${r.error}'
            : '${r.model}: ${r.error}');
      }
    }
    // The aggregate AI overlay layer is a consensus product, not a union of
    // provider drawings. Only overlays independently corroborated by at
    // least two eligible providers pointing in the agreed direction survive.
    final overlays = _buildConsensusOverlays(
      agreeing.where(aiModelHasValidExecutionPlan).toList(),
    );
    return AiConsensus(
      gemini: mergedGemini,
      openrouter: mergedOpenRouter,
      groq: mergedGroq,
      decision: decision,
      conflicts: conflicts,
      aiOverlays: overlays,
      snapshotId: incoming.snapshotId ?? snapshotId,
      dataQuality: incoming.dataQuality.isNotEmpty ? incoming.dataQuality : dataQuality,
    );
  }
}

/// Compact, quantized OHLCV transport encoding used by the AI Gateway.
/// This preserves one row and the chronological order per source candle,
/// but is intentionally not lossless: price deltas are rounded to 1 ppm,
/// and volume ratios are rounded to 0.01 and capped at 10,000x the median.
Map<String, dynamic> encodeAiMarketHistory(List<MarketCandle> candles, int intervalSeconds) {
  if (candles.isEmpty) return {'rows': <List<int>>[]};
  final positiveVolumes = candles.map((c) => c.volume).where((v) => v > 0).toList()..sort();
  final medianVolume = positiveVolumes.isEmpty
      ? 1.0
      : positiveVolumes.length.isOdd
          ? positiveVolumes[positiveVolumes.length ~/ 2]
          : (positiveVolumes[positiveVolumes.length ~/ 2 - 1] + positiveVolumes[positiveVolumes.length ~/ 2]) / 2;
  var previousClose = candles.first.open;
  var previousTime = candles.first.time;
  final rows = <List<int>>[];
  for (var i = 0; i < candles.length; i++) {
    final candle = candles[i];
    int delta(double value) => (((value / previousClose) - 1) * 1000000).round();
    final timeDelta = i == 0 ? 0 : candle.time - previousTime;
    rows.add([
      timeDelta,
      delta(candle.open),
      delta(candle.high),
      delta(candle.low),
      delta(candle.close),
      ((candle.volume / medianVolume) * 100).round().clamp(0, 1000000).toInt(),
    ]);
    previousClose = candle.close;
    previousTime = candle.time;
  }
  return {
    'timeStart': candles.first.time,
    'intervalSeconds': intervalSeconds,
    'historyStartPrice': candles.first.open,
    'baseVolumeMedian': medianVolume,
    'rows': rows,
  };
}

class AiService {
  bool get isConfigured =>
      AppConfig.aiGatewayBaseUrl.startsWith('https://') &&
      !AppConfig.aiGatewayBaseUrl.contains('YOUR_');

  Future<Map<String, List<String>>> fetchModelCatalog() async {
    if (!isConfigured) return const {};
    final base = AppConfig.aiGatewayBaseUrl.replaceFirst(RegExp(r'/+$'), '');
    final response = await http.get(Uri.parse('$base/models'), headers: const {'Accept':'application/json'})
        .timeout(const Duration(seconds: 12));
    if (response.statusCode != 200) throw AiServiceException('دریافت فهرست مدل‌ها ناموفق بود: HTTP ${response.statusCode}');
    final decoded = jsonDecode(response.body);
    if (decoded is! Map || decoded['providers'] is! Map) throw const AiServiceException('ساختار فهرست مدل‌ها معتبر نیست.');
    final result = <String, List<String>>{};
    final providers = decoded['providers'] as Map;
    for (final key in ['gemini','openrouter','groq']) {
      final entry = providers[key];
      final models = entry is Map && entry['models'] is List ? (entry['models'] as List).map((x)=>x.toString()).where((x)=>x.isNotEmpty).toList() : <String>[];
      result[key] = models;
    }
    return result;
  }

  Map<String, dynamic> _encodeHistory(List<MarketCandle> candles, int intervalSeconds) =>
      encodeAiMarketHistory(candles, intervalSeconds);

  Future<AiConsensus> analyze({
    required String exchange,
    required String symbol,
    required List<MarketCandle> history1h,
    required List<MarketCandle> history15m,
    required List<MarketCandle> history5m,
    Map<String, String> modelSelection = const {},
    Map<String, String> fallbackSelection = const {},
    List<String> selectedProviders = const ['gemini', 'openrouter', 'groq'],
    String? snapshotId,
    double? referencePrice,
  }) async {
    if (referencePrice == null || !referencePrice.isFinite || referencePrice <= 0) {
      throw const AiServiceException('قیمت مرجع لحظه‌ای در این Snapshot موجود نیست؛ ابتدا تحلیل بازار را تازه‌سازی کنید.');
    }

    if (!isConfigured) {
      throw const AiServiceException(
        'آدرس AI Gateway در تنظیمات Build تعریف نشده است. '
        'مقدار AI_GATEWAY_BASE_URL را در GitHub Actions Secret بررسی کنید.',
      );
    }

    final base = AppConfig.aiGatewayBaseUrl.replaceFirst(RegExp(r'/+$'), '');
    // Run a tiny real inference probe before spending tokens on full analysis.
    // Provider secrets remain exclusively in Cloudflare; this is not an API-key test.
    final healthResponse = await http.post(
      Uri.parse('$base/providers/health'),
      headers: const {'Content-Type':'application/json','Accept':'application/json'},
      body: jsonEncode({
        'selectedProviders': selectedProviders,
        'modelSelection': modelSelection,
        'fallbackSelection': fallbackSelection,
      }),
    ).timeout(const Duration(seconds: 40));
    if (healthResponse.statusCode != 200) {
      throw AiServiceException('بررسی پاسخ‌گویی مدل‌ها انجام نشد (HTTP ${healthResponse.statusCode}). تحلیل کامل برای جلوگیری از ارسال درخواست به مدل‌های تأییدنشده آغاز نشد.');
    }
    final healthDecoded = jsonDecode(healthResponse.body);
    if (healthDecoded is! Map || healthDecoded['providers'] is! Map) {
      throw const AiServiceException('پاسخ Health Check ساختار معتبر ندارد؛ تحلیل آغاز نشد.');
    }
    final healthProviders = healthDecoded['providers'] as Map;
    final routableProviders = <String>[];
    final verifiedModels = <String,String>{...modelSelection};
    for (final provider in selectedProviders) {
      final result = healthProviders[provider];
      if (result is Map && result['routable'] == true) {
        routableProviders.add(provider);
        final verifiedModel = result['selectedModel'];
        if (verifiedModel is String && verifiedModel.isNotEmpty) verifiedModels[provider] = verifiedModel;
      }
    }
    if (routableProviders.isEmpty) {
      final reasons = healthProviders.entries.map((entry) {
        final value = entry.value;
        if (value is! Map) return '${entry.key}: وضعیت نامشخص';
        return '${entry.key}: ${value['errorCode'] ?? value['status'] ?? 'UNAVAILABLE'}';
      }).join('، ');
      throw AiServiceException('هیچ مدل واجدشرایط و پاسخ‌گویی برای تحلیل پیدا نشد. $reasons');
    }
    final uri = Uri.parse('$base/analyze');
    final stableSnapshotId = snapshotId ?? '${exchange}_${symbol}_SPOT_${history1h.first.time}_${history1h.last.time}_${history15m.last.time}_${history5m.last.time}_${history1h.length}_${history15m.length}_${history5m.length}';

    final requestBody = jsonEncode({
            'exchange': exchange,
            'symbol': symbol,
            'marketType': 'SPOT',
            'snapshotId': stableSnapshotId,
            if (referencePrice != null && referencePrice > 0) 'referencePrice': referencePrice,
            if (history5m.isNotEmpty) 'lastClosed5mClose': history5m.last.close,
            'asOfUtc': DateTime.now().toUtc().toIso8601String(),
            'modelSelection': verifiedModels,
            'fallbackSelection': fallbackSelection,
            'selectedProviders': routableProviders,
            // Full completed history is preserved in compact delta-OHLCV form to fit free-model context limits.
            'marketHistory': {
              'format': 'COMPACT_QUANTIZED rows=[delta_time_seconds, open_delta_ppm, high_delta_ppm, low_delta_ppm, close_delta_ppm, volume_ratio_x100]; price deltas reference previous close and are rounded to nearest 1 ppm; volume ratio references timeframe median, rounded to 0.01 and capped at 10000x; not lossless',
              'encodingMetadata': {'kind': 'COMPACT_QUANTIZED_DELTA_OHLCV', 'priceDeltaScale': 1000000, 'priceDeltaRounding': 'nearest_integer_ppm', 'volumeRatioScale': 100, 'volumeRatioRounding': 'nearest_integer_ratio_0_01', 'volumeRatioMaximum': 1000000, 'exactOriginalValuesPreserved': false},
              '1h': _encodeHistory(history1h, 3600),
              '15m': _encodeHistory(history15m, 900),
              '5m': _encodeHistory(history5m, 300),
            },
          });
    if (utf8.encode(requestBody).length > 900 * 1024) {
      throw const AiServiceException('حجم تاریخچه کندل‌ها برای ارسال به AI بیش از حد مجاز است.');
    }

    late final http.Response response;
    try {
      response = await http
          .post(
            uri,
            headers: const {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: requestBody,
          )
          .timeout(AppConfig.aiRequestTimeout);
    } on http.ClientException catch (e) {
      throw AiServiceException(
        'اتصال برنامه به AI Gateway قطع شد و پاسخی از سرور دریافت نشد. '
        'این خطا به معنی رد تحلیل توسط مدل‌ها نیست. از تکرار پشت‌سرهم خودداری کنید؛ '
        'اتصال Worker و گزارش‌های Cloudflare را بررسی کنید. (${e.message})',
      );
    } on TimeoutException {
      throw const AiServiceException(
        'پاسخ AI Gateway در مهلت تعیین‌شده نرسید. ممکن است ارائه‌دهنده‌ها شلوغ باشند؛ '
        'آخرین تحلیل ذخیره‌شده حفظ می‌شود.',
      );
    }

    final decoded = _decodeResponse(response.body);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = decoded is Map
          ? (decoded['error'] ?? decoded['message'] ?? response.body).toString()
          : response.body;
      final providerMap = decoded is Map && decoded['providers'] is Map
          ? decoded['providers'] as Map
          : decoded is Map ? decoded : const <dynamic, dynamic>{};
      String providerDiagnostic(String key, String label) {
        final raw = providerMap[key];
        if (raw is! Map) return '';
        final providerStatus = (raw['status'] ?? '').toString();
        final detail = (raw['error'] ?? raw['message'] ?? '').toString().trim();
        if (providerStatus == 'ok' && detail.isEmpty) return '';
        final text = detail.isEmpty ? (providerStatus.isEmpty ? 'پاسخ نامشخص' : providerStatus) : detail;
        return '$label: ${text.length > 260 ? text.substring(0, 260) : text}';
      }
      final diagnostics = <String>[
        providerDiagnostic('gemini', 'Gemini'),
        providerDiagnostic('openrouter', 'OpenRouter'),
        providerDiagnostic('groq', 'Groq'),
      ].where((x) => x.isNotEmpty).toList();
      final shortMessage = message.length > 220 ? message.substring(0, 220) : message;
      throw AiServiceException(
        'AI Gateway خطای HTTP ${response.statusCode}: $shortMessage'
        '${diagnostics.isEmpty ? '' : '\n${diagnostics.join('\n')}'}',
      );
    }

    if (decoded is! Map || decoded['ok'] == false) {
      throw const AiServiceException('ساختار پاسخ AI Gateway معتبر نیست.');
    }

    // Support both the current nested contract and the previous flat response.
    final providers = decoded['providers'] is Map
        ? decoded['providers'] as Map
        : decoded;
    final gemini = AiModelResult.fromJson(
      'Gemini',
      providers['gemini'] ?? decoded['gemini'],
    );
    final openrouter = AiModelResult.fromJson(
      'OpenRouter',
      providers['openrouter'] ?? decoded['openrouter'],
    );
    final groq = AiModelResult.fromJson(
      'Groq',
      providers['groq'] ?? decoded['groq'],
    );

    final consensus = decoded['consensus'] is Map
        ? decoded['consensus'] as Map
        : const <dynamic, dynamic>{};

    final decision =
        (consensus['decision'] ?? decoded['decision'] ?? 'WAIT')
            .toString()
            .toUpperCase();
    final conflicts = decoded['conflicts'] is List
        ? (decoded['conflicts'] as List).map((e) => e.toString()).toList()
        : <String>[];

    final aiOverlaysRaw = decoded['aiOverlays'] is List ? decoded['aiOverlays'] as List : consensus['aiOverlays'] is List ? consensus['aiOverlays'] as List : const [];
    return AiConsensus(
      gemini: gemini,
      openrouter: openrouter,
      groq: groq,
      decision: const {'BUY', 'SELL', 'WAIT'}.contains(decision)
          ? decision
          : 'WAIT',
      conflicts: conflicts,
      aiOverlays: aiOverlaysRaw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList(),
      snapshotId: decoded['snapshotId']?.toString() ?? stableSnapshotId,
    );
  }

  dynamic _decodeResponse(String body) {
    try {
      return jsonDecode(body);
    } on FormatException {
      throw const AiServiceException(
        'پاسخ Worker JSON معتبر نیست؛ کد یا مسیر API را بررسی کنید.',
      );
    }
  }
}

class AiServiceException implements Exception {
  const AiServiceException(this.message);
  final String message;

  @override
  String toString() => message;
}
