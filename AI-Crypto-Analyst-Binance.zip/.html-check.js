
'use strict';
const $=id=>document.getElementById(id);
const SOURCE_NAMES=['تکنیکال اپ','Gemini','OpenRouter','Groq','altFINS'];
function safeText(v){if(v===null)return 'null';if(v===undefined)return '—';if(typeof v==='string'||typeof v==='number'||typeof v==='boolean')return String(v);return JSON.stringify(v,null,2)}
function flatten(value,prefix='',out={}){
  if(value&&typeof value==='object'&&!Array.isArray(value)){
    const keys=Object.keys(value);
    if(!keys.length){out[prefix||'(empty)']=value;return out;}
    for(const key of keys)flatten(value[key],prefix?prefix+'.'+key:key,out);
  }else out[prefix||'(value)']=value;
  return out;
}
function renderCell(value){
  if(value===undefined)return '<span class="cellmuted">در خروجی این منبع وجود ندارد</span>';
  if(value===null)return '<span class="cellmuted">null</span>';
  if(typeof value==='object'){
    const json=JSON.stringify(value,null,2);
    const title=Array.isArray(value)?`آرایه · ${value.length} مورد`:'مشاهده جزئیات';
    return `<details><summary>${title}</summary><pre class="details">${escapeHtml(json)}</pre></details>`;
  }
  const s=String(value),u=s.toUpperCase();
  const cls=/BUY|BULLISH|AVAILABLE|VALID|^OK$/.test(u)?'good':/SELL|BEARISH|ERROR|INVALID|UNAVAILABLE/.test(u)?'bad':/WAIT|RANGE|NEUTRAL|STALE|DEGRADED|NOT_FETCHED|UNSUPPORTED/.test(u)?'warn':'neutral';
  return `<span class="${cls}">${escapeHtml(s)}</span>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function addCard(label,value,hint=''){$('cards').insertAdjacentHTML('beforeend',`<div class="card"><div class="k">${escapeHtml(label)}</div><div class="v">${escapeHtml(value??'—')}</div>${hint?`<div class="hint">${escapeHtml(hint)}</div>`:''}</div>`)}
function statusPill(label,value,good){$('statusbar').insertAdjacentHTML('beforeend',`<span class="pill"><i class="dot ${good?'ok':'bad'}"></i>${escapeHtml(label)} <b>${escapeHtml(value??'—')}</b></span>`)}
function render(snapshot){
  if(snapshot?.schema!=='ai_crypto_analyst_exact_snapshot_v1')throw new Error('قالب فایل معتبر نیست. باید خروجی مستقیم اپ با schema نسخه exact_snapshot_v1 باشد.');
  const id=snapshot.identity||{},ai=snapshot.ai||{},alt=snapshot.altfins||{},hybrid=snapshot.hybrid||{};
  $('empty').classList.add('hidden');$('content').classList.remove('hidden');$('statusbar').innerHTML='';$('cards').innerHTML='';$('tbody').innerHTML='';
  statusPill('نماد',id.symbol,true);statusPill('صرافی',id.exchange,true);statusPill('Snapshot',id.snapshotId?String(id.snapshotId).slice(-18):'ارائه نشده',!!id.snapshotId);
  statusPill('اعتبار تکنیکال',id.technicalStale?'قدیمی / نامعتبر':'تازه',!id.technicalStale);
  statusPill('اعتبار AI',id.aiStale?'قدیمی / نامعتبر':ai?'تازه':'اجرا نشده',!id.aiStale&&!!ai);
  addCard('قیمت مرجع اپ',id.referencePrice??'ارائه نشده','عین مقدار خروجی اپ');
  addCard('تصمیم نهایی اپ',hybrid.decision??'ارائه نشده','بدون محاسبه مجدد');
  addCard('اجماع مستقل AI',ai.decision??'اجرا نشده','خروجی ذخیره‌شده سه مدل');
  addCard('مدل‌های معتبر',hybrid.validProviderCount??0,'از ۳ مدل');
  addCard('زمان تکنیکال',id.technicalAt??'ارائه نشده');
  addCard('زمان AI',id.aiAt??'ارائه نشده');
  addCard('زمان خروجی',snapshot.exportedAt??'ارائه نشده');
  addCard('تعداد کندل 1H / 15M / 5M',`${id.historyCount1h??0} / ${id.historyCount15m??0} / ${id.historyCount5m??0}`,'تاریخچه استفاده‌شده در اپ');
  const sources=[
    snapshot.technical??null,
    ai.gemini??null,
    ai.openrouter??null,
    ai.groq??null,
    {quota:alt.quota??null,timeframes:alt.timeframes??{}}
  ];
  const maps=sources.map(x=>flatten(x));
  const keys=[...new Set(maps.flatMap(x=>Object.keys(x)))].sort((a,b)=>a.localeCompare(b,'fa'));
  const groups=new Map();
  for(const key of keys){const group=key.includes('.')?key.split('.')[0]:'اطلاعات اصلی';if(!groups.has(group))groups.set(group,[]);groups.get(group).push(key);}
  for(const [group,groupKeys] of groups){
    const g=document.createElement('tr');g.className='group';const td=document.createElement('td');td.colSpan=6;td.textContent=group;g.appendChild(td);$('tbody').appendChild(g);
    for(const key of groupKeys){const tr=document.createElement('tr');const name=document.createElement('td');name.textContent=key;tr.appendChild(name);for(const map of maps){const cell=document.createElement('td');cell.innerHTML=renderCell(Object.prototype.hasOwnProperty.call(map,key)?map[key]:undefined);tr.appendChild(cell);} $('tbody').appendChild(tr);}
  }
  $('rowCount').textContent=`${keys.length} فیلد یکتا · همه فیلدهای موجود در خروجی`;
  $('consensusMeta').textContent=JSON.stringify({decision:ai.decision??null,conflicts:ai.conflicts??null,aiOverlays:ai.aiOverlays??null,snapshotId:ai.snapshotId??null},null,2);
  $('hybridMeta').textContent=JSON.stringify(hybrid,null,2);
  $('raw').textContent=JSON.stringify(snapshot,null,2);
}
window.loadSnapshotFromApp = function(snapshot){
  document.body.classList.add('app-mode');
  render(snapshot);
  const subtitle=document.querySelector('.sub');
  if(subtitle) subtitle.textContent='اتصال مستقیم به اپلیکیشن · داده‌های همان Snapshot بدون محاسبه مجدد';
};
$('snapshotFile').addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;try{const parsed=JSON.parse(await file.text());render(parsed);}catch(err){alert('فایل بارگذاری نشد: '+err.message);}finally{e.target.value='';}});
$('clearBtn').addEventListener('click',()=>{$('content').classList.add('hidden');$('empty').classList.remove('hidden');$('statusbar').innerHTML='';$('cards').innerHTML='';$('tbody').innerHTML='';$('raw').textContent='';$('consensusMeta').textContent='';$('hybridMeta').textContent='';});
