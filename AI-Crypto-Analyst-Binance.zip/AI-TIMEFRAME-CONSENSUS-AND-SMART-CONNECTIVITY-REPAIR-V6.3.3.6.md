# V6.3.3.6 — Smart Connectivity diagnostic classification repair

Based on a direct audit of the latest Library archive V6.3.3.5.

## Confirmed source issue
The Smart Connectivity screen previously mapped every non-routable provider result that was not in a small transient-error allow-list to `blocked`. This incorrectly presented unknown/operational states such as malformed responses, unavailable model catalogs, no eligible model, and circuit-state failures as confirmed access blocks.

## Repair
- `blocked` is now reserved for explicit upstream `ACCESS_DENIED`, `AUTHENTICATION_FAILED`, and `MODEL_UNAVAILABLE` results.
- Transient and operational failures remain `degraded`; unclassified states remain `unknown`.
- `NOT_CONFIGURED` remains separate.
- A provider is shown as available only when the Worker explicitly reports `routable=true`; a configured API key or HTTP 200 alone is not enough.
- Added Flutter unit tests for unknown, explicit-denial, transient, and successful inference-probe states.

## Preserved
- Per-timeframe 1H/15M/5M consensus logic from V6.3.3.5 is unchanged.
- Gateway domain, Worker name, secrets, bindings, and Binance Proxy are unchanged.
- No provider API key is moved into the APK.

## Verification limits
The Node regression suite and static checks are run for this package. Flutter/Dart tests and APK build require the Flutter SDK and must be confirmed by GitHub Actions. Live Gemini/OpenRouter/Groq inference and Cloudflare deployment are not claimed.
