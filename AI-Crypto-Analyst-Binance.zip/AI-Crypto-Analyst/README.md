# AI Crypto Analyst — Binance live market data starter

این نسخه برای دریافت داده عمومی بازار مستقیماً به Binance Worker موجود متصل می‌شود.

## منبع داده
- صرافی پیش‌فرض: Binance
- Worker: `https://hrs-binance-proxy.sdaghat-tk.workers.dev`
- تست اتصال: `/?endpoint=ping`
- قیمت: `/?endpoint=price&symbol=BTCUSDT`
- کندل: `/?endpoint=klines&symbol=BTCUSDT&interval=5m&limit=500`

## اجرای برنامه
در صفحه «نمودار»، تایم‌فریم 5m، 15m یا 1h را انتخاب کنید. برنامه ابتدا Worker را ping می‌کند، سپس قیمت و حداکثر 500 کندل را می‌گیرد و فقط کندل‌های بسته‌شده را روی نمودار نشان می‌دهد. دکمه تازه‌سازی برای دریافت مجدد داده است.

## ساخت APK
پروژه Flutter است. از Flutter SDK استفاده کنید:
```bash
flutter pub get
flutter analyze
flutter build apk --release
```
اگر پروژه از ZIP در GitHub Actions ساخته می‌شود، ابتدا Android platform files را با `flutter create --platforms=android --project-name ai_crypto_analyst .` تولید کنید.

## محدودیت‌های فعلی
- این نسخه فقط اتصال داده عمومی Binance و نمودار زنده را پیاده‌سازی می‌کند.
- موتور تحلیل تکنیکال، Gemini، DeepSeek و AI Coordinator هنوز به Backend متصل نشده‌اند.
- هیچ سفارش معاملاتی ارسال نمی‌شود.
- در صورت خطای Worker یا محدودیت شبکه، پیام خطا در صفحه نمودار نمایش داده می‌شود.
