/**
 * Binance Spot Market Data Proxy
 * Deploy as the existing Cloudflare Worker: hrs-binance-proxy
 * Supports GET /?endpoint=price&symbol=BTCUSDT
 *          GET /?endpoint=klines&symbol=BTCUSDT&interval=5m&limit=1000&endTime=...
 */
const BINANCE = "https://api.binance.com";
const ALLOWED_INTERVALS = new Set(["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w", "1M"]);

function json(data, status = 200, origin = "*") {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Cache-Control": "no-store",
      "Vary": "Origin"
    }
  });
}

export default {
  async fetch(request) {
    const origin = request.headers.get("Origin") || "*";
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: {
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Max-Age": "86400",
      "Vary": "Origin"
    }});
    if (request.method !== "GET") return json({ ok: false, error: "Method not allowed" }, 405, origin);

    const incoming = new URL(request.url);
    const endpoint = incoming.searchParams.get("endpoint");
    const symbol = (incoming.searchParams.get("symbol") || "").toUpperCase();
    if (!/^[A-Z0-9]{5,20}$/.test(symbol)) return json({ ok: false, error: "Invalid symbol" }, 400, origin);

    const target = new URL(BINANCE);
    if (endpoint === "price") {
      target.pathname = "/api/v3/ticker/price";
      target.searchParams.set("symbol", symbol);
    } else if (endpoint === "klines") {
      const interval = incoming.searchParams.get("interval") || "5m";
      if (!ALLOWED_INTERVALS.has(interval)) return json({ ok: false, error: "Invalid interval" }, 400, origin);
      const limit = Math.max(1, Math.min(1000, Number.parseInt(incoming.searchParams.get("limit") || "500", 10) || 500));
      target.pathname = "/api/v3/klines";
      target.searchParams.set("symbol", symbol);
      target.searchParams.set("interval", interval);
      target.searchParams.set("limit", String(limit));
      for (const key of ["startTime", "endTime"]) {
        const value = incoming.searchParams.get(key);
        if (value !== null && /^\d{1,16}$/.test(value)) target.searchParams.set(key, value);
      }
    } else {
      return json({ ok: false, error: "Unsupported endpoint. Use price or klines." }, 400, origin);
    }

    let upstream;
    let lastError;
    for (let attempt = 0; attempt < 2; attempt++) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 15000);
      try {
        upstream = await fetch(target.toString(), {
          headers: { "Accept": "application/json" },
          cf: { cacheTtl: 0, cacheEverything: false },
          signal: controller.signal
        });
      } catch (error) {
        lastError = error;
      } finally {
        clearTimeout(timer);
      }
      if (upstream && ![429, 500, 502, 503, 504].includes(upstream.status)) break;
      if (attempt === 0) await new Promise(resolve => setTimeout(resolve, 350));
    }
    if (!upstream) {
      const timedOut = lastError?.name === "AbortError";
      return json({ ok: false, error: timedOut
        ? "Binance upstream timeout after 15 seconds (one bounded retry attempted)"
        : String(lastError?.message || lastError || "Binance upstream connection failed").slice(0, 300)
      }, timedOut ? 504 : 502, origin);
    }
    const body = await upstream.text();
    let parsed;
    try { parsed = JSON.parse(body); }
    catch { return json({ ok: false, error: `Binance returned non-JSON HTTP ${upstream.status}` }, 502, origin); }
    if (!upstream.ok) {
      const message = parsed?.msg || parsed?.message || `Binance HTTP ${upstream.status}`;
      return json({ ok: false, error: String(message).slice(0, 300), upstreamStatus: upstream.status }, upstream.status, origin);
    }
    return json({ ok: true, data: parsed }, 200, origin);
  }
};
