import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker.js';

const rows = Array.from({length: 60}, (_, i) => [i === 0 ? 0 : 300, 0, 10000, -10000, 5000, 100]);
const marketHistory = {
  format: 'test delta OHLCV',
  '1h': {timeStart: 1700000000, intervalSeconds: 3600, basePrice: 100, baseVolumeMedian: 10, rows},
  '15m': {timeStart: 1700000000, intervalSeconds: 900, basePrice: 100, baseVolumeMedian: 10, rows},
  '5m': {timeStart: 1700000000, intervalSeconds: 300, basePrice: 100, baseVolumeMedian: 10, rows}
};
const input = {
  exchange: 'TEST', symbol: 'BTCUSDT', technicalAnalysis: {signal: 'BUY'}, marketHistory
};

function env() {
  return {
    GEMINI_API_KEY: 'test-gemini', OPENROUTER_API_KEY: 'test-openrouter',
    RATE_LIMITER: {limit: async () => ({success: true})}
  };
}
function geminiResponse() {
  return new Response(JSON.stringify({candidates: [{content: {parts: [{text: JSON.stringify({
    bias: 'BUY', summary: 'Gemini test', observations: ['structure'], risks: [], confidence: 75,
    overlays: [{type: 'line', kind: 'Swing High', price: 101, timeframe: '1h', direction: 'bullish'}]
  })}]}}]}), {status: 200});
}
function openRouterResponse(bias = 'LONG') {
  return new Response(JSON.stringify({choices: [{finish_reason: 'stop', message: {content: JSON.stringify({
    bias, summary: 'OpenRouter test', observations: ['higher highs'], risks: [], confidence: 72,
    overlays: [{type: 'line', kind: 'Swing High', price: 101.05, timeframe: '1h', direction: 'bullish'}]
  })}}]}), {status: 200});
}

async function analyzeWith(mockFetch) {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = mockFetch;
  try {
    const request = new Request('https://gateway.test/analyze', {
      method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(input)
    });
    const response = await worker.fetch(request, env());
    return {status: response.status, body: await response.json()};
  } finally {
    globalThis.fetch = originalFetch;
  }
}

test('normalizes OpenRouter LONG, requests strict schema and publishes only dual-agreed AI POIs', async () => {
  let openRouterPayload;
  const result = await analyzeWith(async (url, options) => {
    if (String(url).includes('generativelanguage')) return geminiResponse();
    openRouterPayload = JSON.parse(options.body);
    return openRouterResponse();
  });
  assert.equal(openRouterPayload.response_format.type, 'json_schema');
  assert.equal(openRouterPayload.response_format.json_schema.strict, true);
  assert.equal(openRouterPayload.provider.require_parameters, true);
  assert.equal(result.status, 200);
  assert.equal(result.body.openrouter.bias, 'BUY');
  assert.equal(result.body.decision, 'BUY');
  assert.equal(result.body.aiOverlays.length, 1);
  assert.equal(result.body.aiOverlays[0].agreement, 'dual');
});

test('keeps single-provider analysis visible but non-executable when OpenRouter fails', async () => {
  const result = await analyzeWith(async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse();
    return new Response(JSON.stringify({error: {message: 'security policy denied'}}), {status: 403});
  });
  assert.equal(result.status, 200);
  assert.equal(result.body.analysisMode, 'SINGLE_PROVIDER_NON_EXECUTABLE');
  assert.equal(result.body.decision, 'WAIT');
  assert.equal(result.body.openrouter.status, 'error');
  assert.match(result.body.openrouter.error, /HTTP 403/);
  assert.equal(result.body.aiOverlays.length, 0);
});
