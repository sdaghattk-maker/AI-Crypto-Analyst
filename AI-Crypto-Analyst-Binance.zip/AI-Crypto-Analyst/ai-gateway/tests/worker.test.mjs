import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker.js';

const rows = Array.from({length: 60}, (_, i) => [i === 0 ? 0 : 300, 0, 10000, -10000, 5000, 100]);
const marketHistory = {
  format: 'test delta OHLCV',
  '1h': {timeStart: 1700000000, intervalSeconds: 3600, basePrice: 100, baseVolumeMedian: 10, rows},
  '15m': {timeStart: 1700000000, intervalSeconds: 900, basePrice: 100, baseVolumeMedian: 10, rows},
  '5m': {timeStart: 1700000000, intervalSeconds: 300, basePrice: 100, baseVolumeMedian: 10, rows}
};
const input = {
  exchange: 'TEST', symbol: 'BTCUSDT', snapshotId: 'snapshot-test-001',
  technicalAnalysis: {signal: 'BUY'}, marketHistory,
  selectedProviders: ['gemini'], modelSelection: {gemini: 'gemini-test-fast'}
};
function env() {
  return {
    GEMINI_API_KEY: 'test-gemini', OPENROUTER_API_KEY: 'test-openrouter', GROQ_API_KEY: 'test-groq',
    GEMINI_MODEL: 'gemini-3.5-flash-lite', GEMINI_MODELS: 'gemini-3.5-flash-lite,gemini-test-fast,gemini-retired-test',
    OPENROUTER_MODEL: 'openrouter/free', OPENROUTER_MODELS: 'openrouter/free,meta-llama/llama-3.3-70b-instruct:free',
    GROQ_MODEL: 'openai/gpt-oss-120b', GROQ_MODELS: 'openai/gpt-oss-120b,openai/gpt-oss-20b',
    GATEWAY_TOKEN: 'test-token', RATE_LIMITER: {limit: async () => ({success: true})}
  };
}
function geminiResponse(text = JSON.stringify({bias:'BUY',summary:'Gemini test',observations:['structure'],risks:[],confidence:75,overlays:[]})) {
  return new Response(JSON.stringify({candidates:[{finishReason:'STOP',content:{parts:[{text}]}}]}), {status:200});
}
function openRouterResponse() {
  return new Response(JSON.stringify({model:'test/free-model',usage:{prompt_tokens:100,completion_tokens:50},choices:[{finish_reason:'stop',message:{content:JSON.stringify({bias:'BUY',summary:'OR test',observations:[],risks:[],confidence:70,overlays:[]})}}]}), {status:200});
}
async function call(path, body, mockFetch, headers={}) {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = mockFetch;
  try {
    const request = new Request(`https://gateway.test${path}`, {
      method: path === '/health' || path === '/models' ? 'GET' : 'POST',
      headers: {'Content-Type':'application/json', ...headers},
      body: path === '/health' || path === '/models' ? undefined : JSON.stringify(body ?? input)
    });
    const response = await worker.fetch(request, env());
    return {status:response.status, body:await response.json()};
  } finally { globalThis.fetch = originalFetch; }
}

test('one selected model is enough to return and display an independent analysis; other providers are not called', async () => {
  let calls = 0;
  const result = await call('/analyze', input, async (url, options) => {
    calls++;
    assert.match(String(url), /gemini-test-fast/);
    return geminiResponse();
  });
  assert.equal(result.status, 200);
  assert.equal(result.body.ok, true);
  assert.equal(result.body.providers.gemini.status, 'ok');
  assert.equal(result.body.providers.gemini.providerModel, 'gemini-test-fast');
  assert.equal(result.body.providers.openrouter.status, 'not_selected');
  assert.equal(result.body.providers.groq.status, 'not_selected');
  assert.equal(result.body.decision, 'BUY');
  assert.equal(result.body.snapshotId, 'snapshot-test-001');
  assert.equal(calls, 1);
});

test('plain text model response is preserved for display and never becomes a trade signal', async () => {
  const result = await call('/analyze', input, async () => geminiResponse('Market is choppy. Buyers have not confirmed a breakout yet.'));
  assert.equal(result.status, 200);
  assert.equal(result.body.providers.gemini.status, 'ok');
  assert.equal(result.body.providers.gemini.responseFormat, 'text');
  assert.match(result.body.providers.gemini.rawText, /Market is choppy/);
  assert.equal(result.body.providers.gemini.bias, 'WAIT');
  assert.equal(result.body.providers.gemini.confidence, 0);
  assert.equal(result.body.providers.gemini.overlays.length, 0);
});

test('requested model outside Worker allow-list is rejected without provider call', async () => {
  const bad = {...input, modelSelection:{gemini:'unknown/model'}};
  const result = await call('/analyze', bad, async () => { throw new Error('must not call provider'); });
  assert.equal(result.status, 502);
  assert.equal(result.body.ok, false);
  assert.match(result.body.providers.gemini.error, /not in the Worker allow-list/);
});

test('/models exposes configured provider model allow-lists without exposing secrets', async () => {
  const result = await call('/models', null, async () => { throw new Error('no external call expected'); });
  assert.equal(result.status, 200);
  assert.deepEqual(result.body.providers.gemini.models, ['gemini-3.5-flash-lite','gemini-test-fast','gemini-retired-test']);
  assert.deepEqual(result.body.providers.groq.models, ['openai/gpt-oss-120b','openai/gpt-oss-20b']);
  assert.equal(JSON.stringify(result.body).includes('test-gemini'), false);
});

test('one successful provider in provider-test is reported as successful connectivity', async () => {
  const result = await call('/provider-test', {selectedProviders:['gemini'],modelSelection:{gemini:'gemini-test-fast'}},
    async () => geminiResponse(), {Authorization:'Bearer test-token'});
  assert.equal(result.status, 200);
  assert.equal(result.body.ok, true);
  assert.equal(result.body.successCount, 1);
  assert.equal(result.body.requiredForDisplay, 1);
});

test('OpenRouter model selection is passed through exactly and each provider result is independent', async () => {
  const selected = {...input, selectedProviders:['openrouter'], modelSelection:{openrouter:'meta-llama/llama-3.3-70b-instruct:free'}};
  let sentModel;
  const result = await call('/analyze', selected, async (url, options) => {
    sentModel = JSON.parse(options.body).model;
    return openRouterResponse();
  });
  assert.equal(result.status, 200);
  assert.equal(sentModel, 'meta-llama/llama-3.3-70b-instruct:free');
  assert.equal(result.body.providers.openrouter.status, 'ok');
  assert.equal(result.body.providers.openrouter.providerModel, 'test/free-model');
});


test('OpenRouter retries without optional JSON schema when a free endpoint rejects it and preserves plain text', async () => {
  const selected = {...input, selectedProviders:['openrouter'], modelSelection:{openrouter:'meta-llama/llama-3.3-70b-instruct:free'}};
  let attempts = 0;
  const result = await call('/analyze', selected, async (url, options) => {
    attempts++;
    const payload = JSON.parse(options.body);
    if (attempts === 1) {
      assert.equal(payload.response_format.type, 'json_schema');
      return new Response(JSON.stringify({error:{message:'response_format json_schema is not supported by this endpoint'}}),{status:400});
    }
    assert.equal(payload.response_format, undefined);
    return new Response(JSON.stringify({model:'meta-llama/llama-3.3-70b-instruct:free',choices:[{finish_reason:'stop',message:{content:'The market is range-bound; wait for a confirmed break.'}}]}),{status:200});
  });
  assert.equal(attempts,2);
  assert.equal(result.status,200);
  assert.equal(result.body.providers.openrouter.status,'ok');
  assert.equal(result.body.providers.openrouter.responseFormat,'text');
  assert.match(result.body.providers.openrouter.rawText,/range-bound/);
});

test('a failed selected provider never discards another provider successful result', async () => {
  const selected = {...input, selectedProviders:['gemini','groq'], modelSelection:{gemini:'gemini-test-fast',groq:'openai/gpt-oss-20b'}};
  const result = await call('/analyze', selected, async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse();
    return new Response(JSON.stringify({error:{message:'model overloaded'}}),{status:503});
  });
  assert.equal(result.status,200);
  assert.equal(result.body.ok,true);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.groq.status,'error');
  assert.equal(result.body.analysisMode,'SINGLE_PROVIDER_INDEPENDENT');
  assert.equal(result.body.decision,'BUY');
});


test('provider automatically tries its configured fallback model after the primary model is unavailable', async () => {
  const selected = {...input, selectedProviders:['gemini'], modelSelection:{gemini:'gemini-retired-test'}, fallbackSelection:{gemini:'gemini-test-fast'}};
  const attempted=[];
  const result = await call('/analyze', selected, async url => {
    attempted.push(String(url));
    if (String(url).includes('gemini-retired-test')) return new Response(JSON.stringify({error:{message:'model not found'}}),{status:404});
    return geminiResponse();
  });
  assert.equal(result.status,200);
  assert.equal(attempted.length,2);
  assert.match(attempted[0],/gemini-retired-test/);
  assert.match(attempted[1],/gemini-test-fast/);
  assert.equal(result.body.providers.gemini.status,'ok');
  assert.equal(result.body.providers.gemini.fallbackUsed,true);
  assert.deepEqual(result.body.providers.gemini.attemptedModels,['gemini-retired-test','gemini-test-fast']);
});


test('AI consensus is independent from the technical engine direction', async () => {
  const selected = {...input, technicalAnalysis:{signal:'SELL'}, selectedProviders:['gemini','openrouter'], modelSelection:{gemini:'gemini-test-fast',openrouter:'meta-llama/llama-3.3-70b-instruct:free'}};
  const result = await call('/analyze', selected, async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse(JSON.stringify({bias:'BUY',summary:'Independent bullish read',observations:['higher lows'],risks:[],confidence:72,overlays:[]}));
    return openRouterResponse();
  });
  assert.equal(result.status,200);
  assert.equal(result.body.providers.gemini.bias,'BUY');
  assert.equal(result.body.providers.openrouter.bias,'BUY');
  assert.equal(result.body.consensus.decision,'BUY');
  assert.equal(result.body.consensus.technicalSignal,undefined);
});

test('large saved histories are compressed before reaching every AI model and technical report is excluded', async () => {
  const longRows = Array.from({length:2000},(_,i)=>[i===0?0:300,0,10000,-10000,5000,100]);
  const longHistory = Object.fromEntries(['1h','15m','5m'].map((tf)=>[tf,{timeStart:1700000000,intervalSeconds:tf==='1h'?3600:tf==='15m'?900:300,basePrice:100,baseVolumeMedian:10,rows:longRows}]));
  const selected = {...input,technicalAnalysis:{signal:'SELL',secretShouldNotReachAI:'NO'},marketHistory:longHistory};
  let prompt='';
  const result = await call('/analyze',selected,async (_url,options)=>{
    prompt=JSON.parse(options.body).contents[0].parts[0].text;
    return geminiResponse();
  });
  assert.equal(result.status,200);
  assert.doesNotMatch(prompt,/secretShouldNotReachAI|technicalAnalysis/);
  const payload=JSON.parse(prompt.slice(prompt.lastIndexOf('\n')+1));
  assert.ok(payload.history['1h'].rows.length<=58);
  assert.ok(payload.history['15m'].rows.length<=74);
  assert.ok(payload.history['5m'].rows.length<=90);
  assert.ok(Buffer.byteLength(prompt,'utf8')<20000,'provider prompt should stay compact enough for free-tier TPM limits');
  assert.equal(payload.history['5m'].originalCount,2000);
});
