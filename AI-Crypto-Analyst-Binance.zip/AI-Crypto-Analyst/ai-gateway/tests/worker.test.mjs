import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker.js';

const rows = Array.from({length: 60}, (_, i) => [i === 0 ? 0 : 300, 0, 10000, -10000, 5000, 100]);
const marketHistory = {
  format: 'test delta OHLCV',
  '1h': {timeStart: 1700000000, intervalSeconds: 3600, basePrice: 100, baseVolumeMedian: 10, rows},
  '15m': {timeStart: 1700000000, intervalSeconds: 900, basePrice: 100, baseVolumeMedian: 10, rows},
  '5m': {timeStart: 1700000000, intervalSeconds: 300, basePrice: 100, baseVolumeMedian: 10, rows}
};
const input = {
  exchange: 'TEST', symbol: 'BTCUSDT', technicalAnalysis: {signal: 'BUY'}, marketHistory
};

function env() {
  return {
    GEMINI_API_KEY: 'test-gemini', OPENROUTER_API_KEY: 'test-openrouter',
    RATE_LIMITER: {limit: async () => ({success: true})}
  };
}
function geminiResponse() {
  return new Response(JSON.stringify({candidates: [{content: {parts: [{text: JSON.stringify({
    bias: 'BUY', summary: 'Gemini test', observations: ['structure'], risks: [], confidence: 75,
    overlays: [{type: 'line', kind: 'Swing High', price: 101, timeframe: '1h', direction: 'bullish'}]
  })}]}}]}), {status: 200});
}
function openRouterResponse(bias = 'LONG') {
  return new Response(JSON.stringify({model: 'test/free-model', usage: {prompt_tokens: 1000, completion_tokens: 220, completion_tokens_details: {reasoning_tokens: 20}}, choices: [{finish_reason: 'stop', native_finish_reason: 'stop', message: {content: JSON.stringify({
    bias, summary: 'OpenRouter test', observations: ['higher highs'], risks: [], confidence: 72,
    overlays: [{type: 'line', kind: 'Swing High', price: 101.05, timeframe: '1h', direction: 'bullish'}]
  })}}]}), {status: 200});
}

async function analyzeWith(mockFetch) {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = mockFetch;
  try {
    const request = new Request('https://gateway.test/analyze', {
      method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(input)
    });
    const response = await worker.fetch(request, env());
    return {status: response.status, body: await response.json()};
  } finally {
    globalThis.fetch = originalFetch;
  }
}

test('normalizes OpenRouter LONG, requests strict schema and publishes only dual-agreed AI POIs', async () => {
  let openRouterPayload;
  const result = await analyzeWith(async (url, options) => {
    if (String(url).includes('generativelanguage')) return geminiResponse();
    openRouterPayload = JSON.parse(options.body);
    return openRouterResponse();
  });
  assert.equal(openRouterPayload.response_format.type, 'json_schema');
  assert.equal(openRouterPayload.response_format.json_schema.strict, true);
  assert.equal(openRouterPayload.provider.require_parameters, true);
  assert.equal(openRouterPayload.max_tokens, 1800);
  assert.deepEqual(openRouterPayload.reasoning, {effort: 'none'});
  assert.equal('max_completion_tokens' in openRouterPayload, false);
  assert.equal(openRouterPayload.provider.sort, 'throughput');
  assert.equal(openRouterPayload.response_format.json_schema.schema.properties.overlays.maxItems, 3);
  assert.equal(result.status, 200);
  assert.equal(result.body.openrouter.bias, 'BUY');
  assert.equal(result.body.openrouter.providerModel, 'test/free-model');
  assert.equal(result.body.openrouter.completionTokens, 220);
  assert.equal(result.body.openrouter.reasoningTokens, 20);
  assert.equal(result.body.decision, 'BUY');
  assert.equal(result.body.aiOverlays.length, 1);
  assert.equal(result.body.aiOverlays[0].agreement, 'dual');
});

test('keeps single-provider analysis visible but non-executable when OpenRouter fails', async () => {
  const result = await analyzeWith(async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse();
    return new Response(JSON.stringify({error: {message: 'security policy denied'}}), {status: 403});
  });
  assert.equal(result.status, 200);
  assert.equal(result.body.analysisMode, 'SINGLE_PROVIDER_NON_EXECUTABLE');
  assert.equal(result.body.decision, 'WAIT');
  assert.equal(result.body.openrouter.status, 'error');
  assert.match(result.body.openrouter.error, /HTTP 403/);
  assert.equal(result.body.aiOverlays.length, 0);
});


test('reports actual model and finish reason when OpenRouter output is truncated', async () => {
  const result = await analyzeWith(async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse();
    return new Response(JSON.stringify({
      model: 'example/free-endpoint',
      usage: {prompt_tokens: 12000, completion_tokens: 4096},
      choices: [{finish_reason: 'length', native_finish_reason: 'max_tokens', message: {content: '{"bias":"BUY"'}}]
    }), {status: 200});
  });
  assert.equal(result.status, 200);
  assert.equal(result.body.openrouter.status, 'error');
  assert.match(result.body.openrouter.error, /model=example\/free-endpoint/);
  assert.match(result.body.openrouter.error, /native_finish_reason=max_tokens/);
  assert.match(result.body.openrouter.error, /reasoning_effort=none, max_tokens=1800/);
  assert.equal(result.body.decision, 'WAIT');
  assert.equal(result.body.aiOverlays.length, 0);
});


test('rejects malformed provider JSON without converting an absent bias into WAIT', async () => {
  const result = await analyzeWith(async url => {
    if (String(url).includes('generativelanguage')) return geminiResponse();
    return new Response(JSON.stringify({model: 'test/free-model', choices: [{finish_reason: 'stop', message: {content: JSON.stringify({summary: 'missing bias', confidence: 80, observations: [], risks: [], overlays: []})}}]}), {status: 200});
  });
  assert.equal(result.status, 200);
  assert.equal(result.body.openrouter.status, 'error');
  assert.match(result.body.openrouter.error, /missing a recognized BUY\/SELL\/WAIT bias/);
  assert.equal(result.body.decision, 'WAIT');
  assert.equal(result.body.aiOverlays.length, 0);
});
