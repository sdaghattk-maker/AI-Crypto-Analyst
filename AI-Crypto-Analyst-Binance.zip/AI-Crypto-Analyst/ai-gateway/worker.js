/**
 * AI Crypto Analyst Gateway - FREE PROVIDER EDITION
 *
 * Cloudflare Worker Secrets:
 *   GEMINI_API_KEY       - Google AI Studio free-tier API key
 *   OPENROUTER_API_KEY   - OpenRouter API key (use a :free model/router)
 *   GATEWAY_TOKEN        - protects /provider-test only
 *
 * Cloudflare Binding:
 *   RATE_LIMITER         - Rate Limiter binding, Limit 5, Period 60 seconds
 *
 * Routes:
 *   GET  /health
 *   POST /provider-test
 *   POST /analyze
 *
 * IMPORTANT:
 *   /analyze is protected by the RATE_LIMITER binding.
 *   No API key or gateway token is embedded in the app.
 */

const GEMINI_DEFAULT = "gemini-3.5-flash-lite";
const OPENROUTER_DEFAULT = "openrouter/free";
const MAX_AI_OVERLAYS = 3;
const MAX_BODY_BYTES = 1024 * 1024;
const PROVIDER_TIMEOUT_MS = 24000;

function responseJson(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Vary": "Origin"
    }
  });
}

function getAllowedOrigin(request, env) {
  const configured = (env.ALLOWED_ORIGIN || "*").trim();
  const incoming = request.headers.get("Origin");
  if (configured === "*") return "*";
  if (!incoming) return configured;
  return incoming === configured ? configured : "null";
}

function normalizeSignal(value) {
  const signal = String(value || "WAIT").trim().toUpperCase();
  if (["BUY", "LONG", "BULLISH", "STRONG_BUY"].includes(signal)) return "BUY";
  if (["SELL", "SHORT", "BEARISH", "STRONG_SELL"].includes(signal)) return "SELL";
  if (["WAIT", "HOLD", "NEUTRAL", "NO_TRADE"].includes(signal)) return "WAIT";
  return "WAIT";
}

function safeError(error) {
  return String(error?.message || error || "Unknown provider error")
    .replace(/(key|token|authorization)\s*[:=]\s*[^,\s]+/ig, "$1=[redacted]")
    .slice(0, 500);
}

async function fetchTimed(url, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), PROVIDER_TIMEOUT_MS);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function fetchProvider(url, options) {
  let response;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      response = await fetchTimed(url, options);
    } catch (error) {
      // A single bounded retry for transient upstream socket resets/timeouts.
      // Never retry authentication/security denials returned as HTTP responses.
      if (attempt === 1) throw error;
      await new Promise(resolve => setTimeout(resolve, 600));
      continue;
    }
    if (![429, 500, 502, 503, 504].includes(response.status) || attempt === 1) {
      return response;
    }
    const retryAfter = Number(response.headers.get("Retry-After"));
    const delayMs = Number.isFinite(retryAfter) && retryAfter > 0
      ? Math.min(1500, Math.max(400, retryAfter * 1000))
      : 600;
    await new Promise(resolve => setTimeout(resolve, delayMs));
  }
  return response;
}

async function readJsonResponse(response, provider) {
  const raw = await response.text();
  let body;
  try {
    body = JSON.parse(raw);
  } catch {
    throw new Error(`${provider} returned non-JSON HTTP ${response.status}`);
  }
  if (!response.ok) {
    const message = body?.error?.message || body?.message || raw;
    const edgeHint = provider === "OpenRouter" && response.status === 403 &&
      /security policy|access denied/i.test(String(message))
      ? " (server-side provider security block; phone VPN does not change Worker egress)"
      : "";
    throw new Error(`${provider} HTTP ${response.status}: ${String(message).slice(0, 350)}${edgeHint}`);
  }
  return body;
}

function extractJsonObject(raw, provider) {
  if (raw && typeof raw === "object" && !Array.isArray(raw)) return raw;
  const text = String(raw || "").trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "");

  try {
    return JSON.parse(text);
  } catch (_) {
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(text.slice(start, end + 1));
      } catch (_) {}
    }
    throw new Error(`${provider} response was not valid JSON`);
  }
}

function parseModelJson(raw, provider) {
  const value = extractJsonObject(raw, provider);
  const rawBias = String(value.bias || value.decision || value.signal || value.direction || "").trim().toUpperCase();
  const recognizedBias = ["BUY", "LONG", "BULLISH", "STRONG_BUY", "SELL", "SHORT", "BEARISH", "STRONG_SELL", "WAIT", "HOLD", "NEUTRAL", "NO_TRADE"];
  if (!recognizedBias.includes(rawBias)) throw new Error(`${provider} response is missing a recognized BUY/SELL/WAIT bias`);
  const bias = normalizeSignal(rawBias);
  const confidenceNumber = Number(value.confidence);
  if (!Number.isFinite(confidenceNumber) || confidenceNumber < 0 || confidenceNumber > 100) {
    throw new Error(`${provider} response has invalid confidence; expected a number from 0 to 100`);
  }

  return {
    status: "ok",
    bias,
    summary: String(value.summary || "خلاصه‌ای ارائه نشد.").slice(0, 260),
    observations: Array.isArray(value.observations)
      ? value.observations.slice(0, 3).map(item => String(item).slice(0, 180))
      : [],
    risks: Array.isArray(value.risks)
      ? value.risks.slice(0, 3).map(item => String(item).slice(0, 180))
      : Array.isArray(value.risk_factors)
        ? value.risk_factors.slice(0, 3).map(item => String(item).slice(0, 180))
        : [],
    confidence: Number.isFinite(confidenceNumber)
      ? Math.max(0, Math.min(100, Math.round(confidenceNumber)))
      : 0,
    overlays: normalizeAiOverlays(value.overlays)
  };
}

// AI POIs are accepted only as explicit structured levels. Entry/SL/TP are
// deliberately excluded: those remain technical-engine outputs in this phase.
function normalizeAiOverlays(raw) {
  if (!Array.isArray(raw)) return [];
  const allowedKinds = new Set(["Swing High", "Swing Low", "FVG", "Bullish FVG", "Bearish FVG", "Bullish OB", "Bearish OB", "EQH", "EQL", "BOS+", "BOS-", "CRT-H", "CRT-L", "EQ"]);
  const out = [];
  for (const item of raw.slice(0, MAX_AI_OVERLAYS)) {
    if (!item || typeof item !== "object") continue;
    const kind = String(item.kind || "").trim().slice(0, 32);
    const type = item.type === "zone" ? "zone" : item.type === "line" ? "line" : "";
    if (!["1h", "15m", "5m"].includes(item.timeframe)) continue;
    if (!["bullish", "bearish", "neutral"].includes(item.direction)) continue;
    const timeframe = item.timeframe;
    const direction = item.direction;
    const expectedType = ["FVG", "Bullish FVG", "Bearish FVG", "Bullish OB", "Bearish OB"].includes(kind) ? "zone" : "line";
    if (!type || !allowedKinds.has(kind) || type !== expectedType) continue;
    if (type === "line") {
      const price = Number(item.price);
      if (!Number.isFinite(price) || price <= 0) continue;
      out.push({type, kind, price, timeframe, direction});
    } else {
      const low = Number(item.low), high = Number(item.high);
      if (!Number.isFinite(low) || !Number.isFinite(high) || low <= 0 || high <= low) continue;
      out.push({type, kind, low, high, timeframe, direction});
    }
  }
  return out;
}


function openRouterOutputSchema() {
  return {
    type: "object",
    additionalProperties: false,
    properties: {
      bias: {type: "string", enum: ["BUY", "SELL", "WAIT"]},
      summary: {type: "string", maxLength: 260},
      observations: {type: "array", maxItems: 3, items: {type: "string", maxLength: 180}},
      risks: {type: "array", maxItems: 3, items: {type: "string", maxLength: 180}},
      confidence: {type: "integer", minimum: 0, maximum: 100},
      overlays: {
        type: "array",
        maxItems: 3,
        items: {
          type: "object",
          additionalProperties: false,
          properties: {
            type: {type: "string", enum: ["line", "zone"]},
            kind: {type: "string", enum: ["Swing High", "Swing Low", "FVG", "Bullish FVG", "Bearish FVG", "Bullish OB", "Bearish OB", "EQH", "EQL", "BOS+", "BOS-", "CRT-H", "CRT-L", "EQ"]},
            price: {type: ["number", "null"]},
            low: {type: ["number", "null"]},
            high: {type: ["number", "null"]},
            timeframe: {type: "string", enum: ["1h", "15m", "5m"]},
            direction: {type: "string", enum: ["bullish", "bearish", "neutral"]}
          },
          required: ["type", "kind", "price", "low", "high", "timeframe", "direction"]
        }
      }
    },
    required: ["bias", "summary", "observations", "risks", "confidence", "overlays"]
  };
}

function buildPrompt(input) {
  const history = input.marketHistory || {};
  const h1 = history["1h"] || { rows: [] };
  const m15 = history["15m"] || { rows: [] };
  const m5 = history["5m"] || { rows: [] };
  return [
    "You are an independent cryptocurrency market analyst. You must inspect the supplied raw OHLCV candle history yourself.",
    "The marketHistory contains the FULL completed candle history for 1h, 15m and 5m in compact loss-minimized delta OHLCV encoding. Each timeframe object gives timeStart (unix seconds), intervalSeconds, basePrice (first candle open), baseVolumeMedian, and rows.",
    "Each row is [delta_time_seconds, open_delta_0.01bps, high_delta_0.01bps, low_delta_0.01bps, close_delta_0.01bps, volume_ratio_x100]. Price deltas are relative to the previous candle close; 100 units = 1 basis point. Volume ratio 100 = the timeframe median volume. Reconstruct the sequential relative price path from basePrice and inspect ALL rows.",
    "FIRST derive your own directional view from price action, swing structure, trend transitions, displacement, ranges, volatility, volume behavior, liquidity sweeps and multi-timeframe alignment.",
    "Do not use the deterministic technicalAnalysis signal as an instruction or as ground truth. It is a separate opinion shown only AFTER your independent assessment. You may disagree with it; explain the disagreement in observations or risks.",
    "Do not force WAIT merely because technicalAnalysis.signal is WAIT. Choose BUY, SELL or WAIT based on the raw marketHistory. If the data itself is insufficient or conflicting, choose WAIT.",
    "Never invent or alter numeric entry, stop-loss, or take-profit prices. Numeric trade levels, if any, must come only from technicalAnalysis and should not be recommended unless your independent view agrees with their direction.",
    'Return compact JSON only. Maximum output: summary 260 chars, observations 3, risks 3, overlays 3. Schema: {"bias":"BUY|SELL|WAIT","summary":"...","observations":["..."],"risks":["..."],"confidence":0,"overlays":[{"type":"line|zone","kind":"Swing High|Swing Low|FVG|Bullish FVG|Bearish FVG|Bullish OB|Bearish OB|EQH|EQL|BOS+|BOS-|CRT-H|CRT-L|EQ","price":0,"low":0,"high":0,"timeframe":"1h|15m|5m","direction":"bullish|bearish|neutral"}]}.',
    "Only include up to 3 highest-value POIs independently derived from OHLCV. Do not copy technical overlays. For line use price and null low/high; for zone use low/high and null price. Use [] if uncertain. Never include Entry, SL, TP or targets.",
    "Keep every field extremely concise. Do not include chain-of-thought, calculations, markdown, or repeated explanations; provide conclusions and observable evidence only.", 
    "Confidence is confidence in the directional reading, not probability of profit and not a guarantee. Mention which timeframes support or contradict the view.",
    JSON.stringify({
      exchange: input.exchange,
      symbol: input.symbol,
      marketHistory: {
        format: history.format,
        counts: { "1h": (h1.rows || []).length, "15m": (m15.rows || []).length, "5m": (m5.rows || []).length },
        "1h": h1,
        "15m": m15,
        "5m": m5
      },
      technicalAnalysisForComparisonOnly: input.technicalAnalysis
    })
  ].join("\n");
}

async function callGemini(prompt, env) {
  if (!env.GEMINI_API_KEY) {
    throw new Error("GEMINI_API_KEY is not configured");
  }

  const model = env.GEMINI_MODEL || GEMINI_DEFAULT;
  const endpoint =
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;

  const response = await fetchProvider(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": env.GEMINI_API_KEY
    },
    body: JSON.stringify({
      system_instruction: {
        parts: [{ text: "Independently analyze the supplied full candle history before comparing the technical report. Return valid JSON only. Never invent trade prices." }]
      },
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: {
        responseMimeType: "application/json",
        temperature: 0.2,
        maxOutputTokens: 1800
      }
    })
  });

  const body = await readJsonResponse(response, "Gemini");
  const candidate = body?.candidates?.[0];
  if (!candidate) throw new Error("Gemini returned no candidate");
  if (candidate.finishReason === "MAX_TOKENS") {
    const usage = body?.usageMetadata || {};
    throw new Error(`Gemini output truncated: model=${model}, finishReason=MAX_TOKENS, outputTokens=${Number(usage.candidatesTokenCount || 0)}`);
  }
  if (candidate.finishReason === "SAFETY") throw new Error("Gemini response was blocked by safety filtering");
  const raw = candidate?.content?.parts?.map(part => part.text || "").join("");
  const parsed = parseModelJson(raw, "Gemini");
  const usage = body?.usageMetadata || {};
  return {
    ...parsed,
    providerModel: model,
    finishReason: String(candidate.finishReason || "unknown"),
    promptTokens: Number.isFinite(Number(usage.promptTokenCount)) ? Number(usage.promptTokenCount) : null,
    completionTokens: Number.isFinite(Number(usage.candidatesTokenCount)) ? Number(usage.candidatesTokenCount) : null,
    reasoningTokens: Number.isFinite(Number(usage.thoughtsTokenCount)) ? Number(usage.thoughtsTokenCount) : null
  };
}

async function callOpenRouter(prompt, env) {
  if (!env.OPENROUTER_API_KEY) {
    throw new Error("OPENROUTER_API_KEY is not configured");
  }

  const model = env.OPENROUTER_MODEL || OPENROUTER_DEFAULT;

  const response = await fetchProvider("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${env.OPENROUTER_API_KEY}`,
      "X-OpenRouter-Metadata": "enabled"
    },
    body: JSON.stringify({
      model,
      messages: [
        {
          role: "system",
          content: "Independently analyze the supplied full candle history before comparing the technical report. Return one valid JSON object with bias, summary, observations, risks and confidence. Never invent trade prices."
        },
        { role: "user", content: prompt }
      ],
      temperature: 0.1,
      // Modern OpenRouter parameter; the response schema itself is intentionally compact.
      max_completion_tokens: 4096,
      response_format: {
        type: "json_schema",
        json_schema: {name: "crypto_market_analysis", strict: true, schema: openRouterOutputSchema()}
      },
      plugins: [{ id: "response-healing" }],
      provider: { require_parameters: true, sort: "throughput", allow_fallbacks: true },
      stream: false
    })
  });

  const body = await readJsonResponse(response, "OpenRouter");
  const choice = body?.choices?.[0];
  const message = choice?.message;
  if (!choice || !message) throw new Error("OpenRouter returned no completion choice");
  const usage = body?.usage || {};
  const actualModel = String(body?.model || model);
  if (choice.finish_reason === "length") {
    const native = choice.native_finish_reason ? `, native_finish_reason=${choice.native_finish_reason}` : "";
    const counts = `prompt_tokens=${Number(usage.prompt_tokens || 0)}, completion_tokens=${Number(usage.completion_tokens || 0)}`;
    throw new Error(`OpenRouter output truncated: model=${actualModel}, finish_reason=length${native}, ${counts}; compact JSON contract exceeded the selected free endpoint completion capacity`);
  }
  if (choice.finish_reason === "content_filter") throw new Error(`OpenRouter completion blocked by content filtering (model=${actualModel})`);
  let raw = message?.content;
  if (Array.isArray(raw)) {
    raw = raw.map(part => typeof part === "string" ? part : (part?.text || "")).join("\n");
  }
  if ((raw === null || raw === undefined || raw === "") && message?.parsed && typeof message.parsed === "object") {
    raw = message.parsed;
  }
  if ((raw === null || raw === undefined || raw === "") && message?.refusal) {
    throw new Error(`OpenRouter refused the request: ${String(message.refusal).slice(0, 220)}`);
  }
  const parsed = parseModelJson(raw, "OpenRouter");
  return {
    ...parsed,
    providerModel: actualModel,
    finishReason: String(choice.finish_reason || "unknown"),
    nativeFinishReason: choice.native_finish_reason == null ? null : String(choice.native_finish_reason),
    promptTokens: Number.isFinite(Number(usage.prompt_tokens)) ? Number(usage.prompt_tokens) : null,
    completionTokens: Number.isFinite(Number(usage.completion_tokens)) ? Number(usage.completion_tokens) : null,
    reasoningTokens: Number.isFinite(Number(usage.completion_tokens_details?.reasoning_tokens))
      ? Number(usage.completion_tokens_details.reasoning_tokens) : null
  };
}

function historyPriceBounds(history) {
  let min = Infinity, max = 0;
  for (const tf of ["1h", "15m", "5m"]) {
    const item = history?.[tf];
    if (!item || !Array.isArray(item.rows)) continue;
    let previousClose = Number(item.basePrice);
    for (const row of item.rows) {
      const base = previousClose;
      const open = base * (1 + Number(row[1]) / 1000000);
      const high = base * (1 + Number(row[2]) / 1000000);
      const low = base * (1 + Number(row[3]) / 1000000);
      const close = base * (1 + Number(row[4]) / 1000000);
      if ([open, high, low, close].every(Number.isFinite) && low > 0 && high >= low) {
        min = Math.min(min, low);
        max = Math.max(max, high);
      }
      previousClose = close;
    }
  }
  return Number.isFinite(min) && max > 0 ? {min, max} : null;
}

function validateProviderOverlays(provider, history) {
  if (provider?.status !== "ok") return provider;
  const bounds = historyPriceBounds(history);
  if (!bounds) return {...provider, overlays: []};
  const floor = bounds.min * 0.95, ceiling = bounds.max * 1.05;
  const overlays = (provider.overlays || []).filter(item => item.type === "line"
    ? item.price >= floor && item.price <= ceiling
    : item.low >= floor && item.high <= ceiling);
  const rejected = (provider.overlays || []).length - overlays.length;
  return {
    ...provider,
    overlays,
    risks: rejected > 0
      ? [...(provider.risks || []).slice(0, 7), `${rejected} POI خارج از محدوده تاریخی قیمت بود و برای جلوگیری از ترسیم سطح ساختگی حذف شد.`]
      : provider.risks || []
  };
}

async function runProviders(input, env) {
  const prompt = buildPrompt(input);

  const settled = await Promise.allSettled([
    callGemini(prompt, env),
    callOpenRouter(prompt, env)
  ]);

  let gemini = settled[0].status === "fulfilled"
    ? settled[0].value
    : {
        status: "error",
        bias: "WAIT",
        summary: "فراخوانی Gemini ناموفق بود.",
        risks: [],
        confidence: 0,
        error: safeError(settled[0].reason)
      };

  let openrouter = settled[1].status === "fulfilled"
    ? settled[1].value
    : {
        status: "error",
        bias: "WAIT",
        summary: "فراخوانی OpenRouter ناموفق بود.",
        risks: [],
        confidence: 0,
        error: safeError(settled[1].reason)
      };

  gemini = validateProviderOverlays(gemini, input.marketHistory);
  openrouter = validateProviderOverlays(openrouter, input.marketHistory);
  return { gemini, openrouter };
}

function makeConsensus(technical, gemini, openrouter) {
  const technicalSignal = normalizeSignal(technical?.signal);
  const g = normalizeSignal(gemini?.bias);
  const o = normalizeSignal(openrouter?.bias);
  const conflicts = [];

  if (gemini.status !== "ok") conflicts.push("پاسخ معتبر از Gemini دریافت نشد.");
  if (openrouter.status !== "ok") conflicts.push("پاسخ معتبر از OpenRouter دریافت نشد.");
  if (g !== o) conflicts.push("تحلیل مستقل Gemini و OpenRouter هم‌جهت نیست؛ تصمیم نهایی WAIT است.");
  if (g !== technicalSignal || o !== technicalSignal) {
    conflicts.push("دیدگاه مستقل مدل‌ها با موتور تکنیکال اختلاف دارد؛ سطوح ورود موتور بدون تأیید هم‌جهت اجرا نمی‌شوند.");
  }
  if (technicalSignal === "WAIT") conflicts.push("موتور تکنیکال هنوز نقطه ورود معتبر تأیید نکرده است؛ حتی در صورت وجود سوگیری مستقل مدل‌ها، تصمیم اجرایی WAIT می‌ماند.");

  let decision = "WAIT";
  if (
    ["BUY", "SELL"].includes(technicalSignal) &&
    gemini.status === "ok" &&
    openrouter.status === "ok" &&
    g === o &&
    g === technicalSignal &&
    gemini.confidence >= 60 &&
    openrouter.confidence >= 60
  ) {
    decision = technicalSignal;
  }

  // A chart POI is exposed to the AI drawing source only when both independent
  // providers return the same kind/type and materially overlapping price area.
  const aiOverlays = [];
  if (gemini.status === "ok" && openrouter.status === "ok") {
    for (const a of (gemini.overlays || [])) {
      const match = (openrouter.overlays || []).find(b => {
        if (a.type !== b.type || a.kind !== b.kind || a.direction !== b.direction || a.timeframe !== b.timeframe) return false;
        if (a.type === "line") {
          const mid = (a.price + b.price) / 2;
          return mid > 0 && Math.abs(a.price - b.price) / mid <= 0.0015;
        }
        const overlap = Math.min(a.high, b.high) - Math.max(a.low, b.low);
        const span = Math.max(a.high, b.high) - Math.min(a.low, b.low);
        return span > 0 && overlap / span >= 0.5;
      });
      if (!match) continue;
      if (a.type === "line") {
        aiOverlays.push({...a, price: (a.price + match.price) / 2, color: a.direction === "bullish" ? "#22C99A" : a.direction === "bearish" ? "#F05D6C" : "#B58BE8", agreement: "dual"});
      } else {
        aiOverlays.push({...a, low: Math.max(a.low, match.low), high: Math.min(a.high, match.high), color: a.direction === "bullish" ? "#22C99A" : a.direction === "bearish" ? "#F05D6C" : "#B58BE8", agreement: "dual"});
      }
    }
  }
  if (aiOverlays.length === 0) conflicts.push("برای ترسیم منبع AI، هیچ POI مستقلی با توافق قابل‌قبول هر دو مدل تأیید نشد.");
  return { decision, technicalSignal, conflicts, aiOverlays };
}

async function readRequestBody(request) {
  const declared = Number(request.headers.get("Content-Length") || 0);
  if (declared > MAX_BODY_BYTES) throw new Error("Request body too large");

  const raw = await request.text();
  if (new TextEncoder().encode(raw).length > MAX_BODY_BYTES) {
    throw new Error("Request body too large");
  }

  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("Invalid JSON body");
  }
}

function constantTimeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) {
    return false;
  }
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function authorizedForProviderTest(request, env) {
  if (!env.GATEWAY_TOKEN) return false;
  const header = request.headers.get("Authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  return constantTimeEqual(token, env.GATEWAY_TOKEN);
}

async function applyRateLimit(request, env) {
  if (!env.RATE_LIMITER) {
    return { allowed: false, reason: "RATE_LIMITER binding is missing" };
  }

  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  try {
    const result = await env.RATE_LIMITER.limit({ key: ip });
    return { allowed: Boolean(result?.success), reason: null };
  } catch (error) {
    return { allowed: false, reason: "Rate limiter binding failed" };
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = getAllowedOrigin(request, env);

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          "Access-Control-Allow-Origin": origin,
          "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
          "Access-Control-Max-Age": "86400",
          "Vary": "Origin"
        }
      });
    }

    if (origin === "null") {
      return responseJson({ ok: false, error: "Origin not allowed" }, 403, origin);
    }

    if (url.pathname === "/health" && request.method === "GET") {
      return responseJson({
        ok: true,
        service: "AI Crypto Analyst Gateway",
        mode: "FREE_PROVIDERS",
        configured: {
          gemini: Boolean(env.GEMINI_API_KEY),
          openrouter: Boolean(env.OPENROUTER_API_KEY),
          gateway: Boolean(env.GATEWAY_TOKEN),
          rateLimiter: Boolean(env.RATE_LIMITER)
        },
        models: {
          gemini: env.GEMINI_MODEL || GEMINI_DEFAULT,
          openrouter: env.OPENROUTER_MODEL || OPENROUTER_DEFAULT
        }
      }, 200, origin);
    }

    if (url.pathname === "/provider-test") {
      if (request.method !== "POST") {
        return responseJson({ ok: false, error: "Method not allowed" }, 405, origin);
      }
      if (!authorizedForProviderTest(request, env)) {
        return responseJson({ ok: false, error: "Unauthorized" }, 401, origin);
      }

      const testInput = {
        exchange: "TEST",
        symbol: "BTCUSDT",
        technicalAnalysis: {
          signal: "WAIT",
          note: "Connectivity test only. Do not produce a trade signal."
        },
        marketHistory: {
          format: "delta OHLCV; price deltas in 0.01 bps; volume ratio x100",
          "1h": {timeStart:1700000000,intervalSeconds:3600,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:3600,0,10000,-10000,5000,100])},
          "15m": {timeStart:1700000000,intervalSeconds:900,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:900,0,10000,-10000,5000,100])},
          "5m": {timeStart:1700000000,intervalSeconds:300,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:300,0,10000,-10000,5000,100])}
        }
      };

      const { gemini, openrouter } = await runProviders(testInput, env);
      const ok = gemini.status === "ok" && openrouter.status === "ok";

      return responseJson({
        ok,
        test: "provider-connectivity",
        providers: { gemini, openrouter }
      }, ok ? 200 : 502, origin);
    }

    if (url.pathname !== "/analyze") {
      return responseJson({ ok: false, error: "Not found" }, 404, origin);
    }

    if (request.method !== "POST") {
      return responseJson({ ok: false, error: "Method not allowed" }, 405, origin);
    }

    const rate = await applyRateLimit(request, env);
    if (!rate.allowed) {
      return responseJson({
        ok: false,
        error: rate.reason || "Rate limit exceeded",
        code: rate.reason ? "RATE_LIMITER_UNAVAILABLE" : "RATE_LIMITED"
      }, rate.reason ? 503 : 429, origin);
    }

    if (!env.GEMINI_API_KEY && !env.OPENROUTER_API_KEY) {
      return responseJson({
        ok: false,
        error: "Neither GEMINI_API_KEY nor OPENROUTER_API_KEY is configured"
      }, 503, origin);
    }

    try {
      const input = await readRequestBody(request);
      const technical = input?.technicalAnalysis || input?.technical;
      const marketHistory = input?.marketHistory;
      const validHistory = (item) => item && typeof item === "object" &&
        Number.isFinite(Number(item.timeStart)) && Number(item.timeStart) > 0 &&
        Number.isFinite(Number(item.intervalSeconds)) && Number(item.intervalSeconds) > 0 &&
        Number.isFinite(Number(item.basePrice)) && Number(item.basePrice) > 0 &&
        Number.isFinite(Number(item.baseVolumeMedian)) && Number(item.baseVolumeMedian) >= 0 &&
        Array.isArray(item.rows) && item.rows.length >= 50 && item.rows.every((row) =>
          Array.isArray(row) && row.length === 6 && row.every((value) => Number.isFinite(Number(value))) &&
          Number(row[0]) >= 0 && Number(row[2]) >= Math.max(Number(row[1]), Number(row[4])) &&
          Number(row[3]) <= Math.min(Number(row[1]), Number(row[4])) && Number(row[2]) >= Number(row[3]) && Number(row[5]) >= 0
        );

      if (
        !input ||
        typeof input !== "object" ||
        Array.isArray(input) ||
        typeof input.exchange !== "string" ||
        typeof input.symbol !== "string" ||
        !technical ||
        typeof technical !== "object" ||
        !marketHistory || typeof marketHistory !== "object" ||
        !validHistory(marketHistory["1h"]) || !validHistory(marketHistory["15m"]) || !validHistory(marketHistory["5m"])
      ) {
        return responseJson({
          ok: false,
          error: "exchange, symbol, technicalAnalysis and valid 1h/15m/5m marketHistory are required"
        }, 400, origin);
      }

      const { gemini, openrouter } = await runProviders({
        exchange: input.exchange.slice(0, 40),
        symbol: input.symbol.slice(0, 40),
        technicalAnalysis: technical,
        marketHistory
      }, env);

      const successfulProviders = [gemini, openrouter].filter(provider => provider.status === "ok").length;
      if (successfulProviders === 0) {
        return responseJson({
          ok: false,
          decision: "WAIT",
          providers: { gemini, openrouter },
          gemini,
          openrouter,
          error: "Both AI providers failed; no independent AI assessment is available"
        }, 502, origin);
      }

      const consensus = makeConsensus(technical, gemini, openrouter);
      const partial = successfulProviders === 1;
      if (partial) {
        consensus.decision = "WAIT";
        consensus.conflicts.unshift("فقط یک مدل پاسخ معتبر داده است؛ تحلیل تک‌مدلی است و تا بازیابی هر دو مدل هیچ تصمیم اجرایی صادر نمی‌شود.");
      }

      return responseJson({
        ok: true,
        decision: consensus.decision,
        consensus,
        conflicts: consensus.conflicts,
        providers: { gemini, openrouter },
        gemini,
        openrouter,
        analysisMode: partial ? "SINGLE_PROVIDER_NON_EXECUTABLE" : "DUAL_PROVIDER",
        priceLevelsSource: "SOURCE_SELECTOR",
        aiOverlays: consensus.aiOverlays,
        historyCounts: {
          "1h": marketHistory["1h"].rows.length,
          "15m": marketHistory["15m"].rows.length,
          "5m": marketHistory["5m"].rows.length
        }
      }, 200, origin);

    } catch (error) {
      const message = safeError(error);
      const status =
        message === "Request body too large" ? 413 :
        message === "Invalid JSON body" ? 400 : 502;

      return responseJson({
        ok: false,
        error: message,
        decision: "WAIT"
      }, status, origin);
    }
  }
};
