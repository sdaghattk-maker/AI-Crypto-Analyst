/**
 * AI Crypto Analyst Gateway - FREE PROVIDER EDITION
 *
 * Cloudflare Worker Secrets:
 *   GEMINI_API_KEY       - Google AI Studio free-tier API key
 *   OPENROUTER_API_KEY   - OpenRouter API key (use a :free model/router)
 *   GATEWAY_TOKEN        - protects /provider-test only
 *
 * Cloudflare Binding:
 *   RATE_LIMITER         - Rate Limiter binding, Limit 5, Period 60 seconds
 *
 * Routes:
 *   GET  /health
 *   POST /provider-test
 *   POST /analyze
 *
 * IMPORTANT:
 *   /analyze is protected by the RATE_LIMITER binding.
 *   No API key or gateway token is embedded in the app.
 */

const GEMINI_DEFAULT = "gemini-3.5-flash-lite";
const OPENROUTER_DEFAULT = "openrouter/free";
const MAX_BODY_BYTES = 256 * 1024;
const PROVIDER_TIMEOUT_MS = 65000;

function responseJson(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Vary": "Origin"
    }
  });
}

function getAllowedOrigin(request, env) {
  const configured = (env.ALLOWED_ORIGIN || "*").trim();
  const incoming = request.headers.get("Origin");
  if (configured === "*") return "*";
  if (!incoming) return configured;
  return incoming === configured ? configured : "null";
}

function normalizeSignal(value) {
  const signal = String(value || "WAIT").trim().toUpperCase();
  return ["BUY", "SELL", "WAIT"].includes(signal) ? signal : "WAIT";
}

function safeError(error) {
  return String(error?.message || error || "Unknown provider error")
    .replace(/(key|token|authorization)\s*[:=]\s*[^,\s]+/ig, "$1=[redacted]")
    .slice(0, 500);
}

async function fetchTimed(url, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), PROVIDER_TIMEOUT_MS);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function readJsonResponse(response, provider) {
  const raw = await response.text();
  let body;
  try {
    body = JSON.parse(raw);
  } catch {
    throw new Error(`${provider} returned non-JSON HTTP ${response.status}`);
  }
  if (!response.ok) {
    const message = body?.error?.message || body?.message || raw;
    throw new Error(`${provider} HTTP ${response.status}: ${String(message).slice(0, 350)}`);
  }
  return body;
}

function extractJsonObject(raw, provider) {
  const text = String(raw || "").trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "");

  try {
    return JSON.parse(text);
  } catch (_) {
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(text.slice(start, end + 1));
      } catch (_) {}
    }
    throw new Error(`${provider} response was not valid JSON`);
  }
}

function parseModelJson(raw, provider) {
  const value = extractJsonObject(raw, provider);
  const bias = normalizeSignal(value.bias || value.decision);
  const confidenceNumber = Number(value.confidence);

  return {
    status: "ok",
    bias,
    summary: String(value.summary || "خلاصه‌ای ارائه نشد.").slice(0, 1200),
    risks: Array.isArray(value.risks)
      ? value.risks.slice(0, 8).map(item => String(item).slice(0, 300))
      : Array.isArray(value.risk_factors)
        ? value.risk_factors.slice(0, 8).map(item => String(item).slice(0, 300))
        : [],
    confidence: Number.isFinite(confidenceNumber)
      ? Math.max(0, Math.min(100, Math.round(confidenceNumber)))
      : 0
  };
}

function buildPrompt(input) {
  return [
    "You are a cautious cryptocurrency market-analysis assistant.",
    "Analyze the supplied technical report. Respond with one valid JSON object only.",
    'Required keys: {"bias":"BUY|SELL|WAIT","summary":"Persian text","risks":["..."],"confidence":0}.',
    "Never invent or alter entry, stop-loss, or take-profit prices.",
    "The deterministic technical engine is the only source of numeric trade levels.",
    "If the technical signal is WAIT, return WAIT.",
    "If evidence is insufficient or conflicting, return WAIT.",
    "Confidence is not a probability of profit and is not a guarantee.",
    JSON.stringify({
      exchange: input.exchange,
      symbol: input.symbol,
      technicalAnalysis: input.technicalAnalysis
    })
  ].join("\n");
}

async function callGemini(prompt, env) {
  if (!env.GEMINI_API_KEY) {
    throw new Error("GEMINI_API_KEY is not configured");
  }

  const model = env.GEMINI_MODEL || GEMINI_DEFAULT;
  const endpoint =
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;

  const response = await fetchTimed(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": env.GEMINI_API_KEY
    },
    body: JSON.stringify({
      system_instruction: {
        parts: [{ text: "Return valid JSON only. Never invent trade prices." }]
      },
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: {
        responseMimeType: "application/json",
        temperature: 0.2,
        maxOutputTokens: 1200
      }
    })
  });

  const body = await readJsonResponse(response, "Gemini");
  const raw = body?.candidates?.[0]?.content?.parts
    ?.map(part => part.text || "")
    .join("");

  return parseModelJson(raw, "Gemini");
}

async function callOpenRouter(prompt, env) {
  if (!env.OPENROUTER_API_KEY) {
    throw new Error("OPENROUTER_API_KEY is not configured");
  }

  const model = env.OPENROUTER_MODEL || OPENROUTER_DEFAULT;

  const response = await fetchTimed("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${env.OPENROUTER_API_KEY}`
    },
    body: JSON.stringify({
      model,
      messages: [
        {
          role: "system",
          content: "Return one valid JSON object only with bias, summary, risks, confidence. Never invent trade prices."
        },
        { role: "user", content: prompt }
      ],
      temperature: 0.2,
      max_tokens: 1400,
      stream: false
    })
  });

  const body = await readJsonResponse(response, "OpenRouter");
  const raw = body?.choices?.[0]?.message?.content;
  return parseModelJson(raw, "OpenRouter");
}

async function runProviders(input, env) {
  const prompt = buildPrompt(input);

  const settled = await Promise.allSettled([
    callGemini(prompt, env),
    callOpenRouter(prompt, env)
  ]);

  const gemini = settled[0].status === "fulfilled"
    ? settled[0].value
    : {
        status: "error",
        bias: "WAIT",
        summary: "فراخوانی Gemini ناموفق بود.",
        risks: [],
        confidence: 0,
        error: safeError(settled[0].reason)
      };

  const openrouter = settled[1].status === "fulfilled"
    ? settled[1].value
    : {
        status: "error",
        bias: "WAIT",
        summary: "فراخوانی OpenRouter ناموفق بود.",
        risks: [],
        confidence: 0,
        error: safeError(settled[1].reason)
      };

  return { gemini, openrouter };
}

function makeConsensus(technical, gemini, openrouter) {
  const technicalSignal = normalizeSignal(technical?.signal);
  const g = normalizeSignal(gemini?.bias);
  const o = normalizeSignal(openrouter?.bias);
  const conflicts = [];

  if (gemini.status !== "ok") conflicts.push("پاسخ معتبر از Gemini دریافت نشد.");
  if (openrouter.status !== "ok") conflicts.push("پاسخ معتبر از OpenRouter دریافت نشد.");
  if (g !== o) conflicts.push("Gemini و OpenRouter هم‌جهت نیستند.");
  if (g !== technicalSignal || o !== technicalSignal) {
    conflicts.push("خروجی مدل‌ها با سیگنال موتور تکنیکال یکسان نیست.");
  }
  if (technicalSignal === "WAIT") conflicts.push("موتور تکنیکال سیگنال ورود نداده است.");

  let decision = "WAIT";
  if (
    ["BUY", "SELL"].includes(technicalSignal) &&
    gemini.status === "ok" &&
    openrouter.status === "ok" &&
    g === o &&
    g === technicalSignal &&
    gemini.confidence >= 60 &&
    openrouter.confidence >= 60
  ) {
    decision = technicalSignal;
  }

  return { decision, technicalSignal, conflicts };
}

async function readRequestBody(request) {
  const declared = Number(request.headers.get("Content-Length") || 0);
  if (declared > MAX_BODY_BYTES) throw new Error("Request body too large");

  const raw = await request.text();
  if (new TextEncoder().encode(raw).length > MAX_BODY_BYTES) {
    throw new Error("Request body too large");
  }

  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("Invalid JSON body");
  }
}

function constantTimeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) {
    return false;
  }
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function authorizedForProviderTest(request, env) {
  if (!env.GATEWAY_TOKEN) return false;
  const header = request.headers.get("Authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  return constantTimeEqual(token, env.GATEWAY_TOKEN);
}

async function applyRateLimit(request, env) {
  if (!env.RATE_LIMITER) {
    return { allowed: false, reason: "RATE_LIMITER binding is missing" };
  }

  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  try {
    const result = await env.RATE_LIMITER.limit({ key: ip });
    return { allowed: Boolean(result?.success), reason: null };
  } catch (error) {
    return { allowed: false, reason: "Rate limiter binding failed" };
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = getAllowedOrigin(request, env);

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          "Access-Control-Allow-Origin": origin,
          "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
          "Access-Control-Max-Age": "86400",
          "Vary": "Origin"
        }
      });
    }

    if (origin === "null") {
      return responseJson({ ok: false, error: "Origin not allowed" }, 403, origin);
    }

    if (url.pathname === "/health" && request.method === "GET") {
      return responseJson({
        ok: true,
        service: "AI Crypto Analyst Gateway",
        mode: "FREE_PROVIDERS",
        configured: {
          gemini: Boolean(env.GEMINI_API_KEY),
          openrouter: Boolean(env.OPENROUTER_API_KEY),
          gateway: Boolean(env.GATEWAY_TOKEN),
          rateLimiter: Boolean(env.RATE_LIMITER)
        },
        models: {
          gemini: env.GEMINI_MODEL || GEMINI_DEFAULT,
          openrouter: env.OPENROUTER_MODEL || OPENROUTER_DEFAULT
        }
      }, 200, origin);
    }

    if (url.pathname === "/provider-test") {
      if (request.method !== "POST") {
        return responseJson({ ok: false, error: "Method not allowed" }, 405, origin);
      }
      if (!authorizedForProviderTest(request, env)) {
        return responseJson({ ok: false, error: "Unauthorized" }, 401, origin);
      }

      const testInput = {
        exchange: "TEST",
        symbol: "BTCUSDT",
        technicalAnalysis: {
          signal: "WAIT",
          note: "Connectivity test only. Do not produce a trade signal."
        }
      };

      const { gemini, openrouter } = await runProviders(testInput, env);
      const ok = gemini.status === "ok" && openrouter.status === "ok";

      return responseJson({
        ok,
        test: "provider-connectivity",
        providers: { gemini, openrouter }
      }, ok ? 200 : 502, origin);
    }

    if (url.pathname !== "/analyze") {
      return responseJson({ ok: false, error: "Not found" }, 404, origin);
    }

    if (request.method !== "POST") {
      return responseJson({ ok: false, error: "Method not allowed" }, 405, origin);
    }

    const rate = await applyRateLimit(request, env);
    if (!rate.allowed) {
      return responseJson({
        ok: false,
        error: rate.reason || "Rate limit exceeded",
        code: rate.reason ? "RATE_LIMITER_UNAVAILABLE" : "RATE_LIMITED"
      }, rate.reason ? 503 : 429, origin);
    }

    if (!env.GEMINI_API_KEY || !env.OPENROUTER_API_KEY) {
      return responseJson({
        ok: false,
        error: "Gemini or OpenRouter API secret is not configured"
      }, 503, origin);
    }

    try {
      const input = await readRequestBody(request);
      const technical = input?.technicalAnalysis || input?.technical;

      if (
        !input ||
        typeof input !== "object" ||
        Array.isArray(input) ||
        typeof input.exchange !== "string" ||
        typeof input.symbol !== "string" ||
        !technical ||
        typeof technical !== "object"
      ) {
        return responseJson({
          ok: false,
          error: "exchange, symbol and technicalAnalysis are required"
        }, 400, origin);
      }

      const { gemini, openrouter } = await runProviders({
        exchange: input.exchange.slice(0, 40),
        symbol: input.symbol.slice(0, 40),
        technicalAnalysis: technical
      }, env);

      if (gemini.status !== "ok" || openrouter.status !== "ok") {
        return responseJson({
          ok: false,
          decision: "WAIT",
          providers: { gemini, openrouter },
          gemini,
          openrouter,
          error: "One or more AI providers failed"
        }, 502, origin);
      }

      const consensus = makeConsensus(technical, gemini, openrouter);

      return responseJson({
        ok: true,
        decision: consensus.decision,
        consensus,
        conflicts: consensus.conflicts,
        providers: { gemini, openrouter },
        gemini,
        openrouter,
        priceLevelsSource: "TECHNICAL_ENGINE_ONLY"
      }, 200, origin);

    } catch (error) {
      const message = safeError(error);
      const status =
        message === "Request body too large" ? 413 :
        message === "Invalid JSON body" ? 400 : 502;

      return responseJson({
        ok: false,
        error: message,
        decision: "WAIT"
      }, status, origin);
    }
  }
};
