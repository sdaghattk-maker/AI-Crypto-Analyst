/**
 * AI Crypto Analyst Gateway - PHASE 7.7 ROOT-CAUSE FIX
 *
 * Cloudflare Worker Secrets:
 *   GEMINI_API_KEY       - Google AI Studio free-tier API key
 *   OPENROUTER_API_KEY   - OpenRouter API key (use a :free model/router)
 *   GROQ_API_KEY         - Groq API key (free-tier availability depends on account/model)
 *   GATEWAY_TOKEN        - protects /provider-test only
 *
 * Cloudflare Binding:
 *   RATE_LIMITER         - Rate Limiter binding, Limit 5, Period 60 seconds
 *
 * Routes:
 *   GET  /health
 *   POST /provider-test
 *   POST /analyze
 *
 * IMPORTANT:
 *   /analyze is protected by the RATE_LIMITER binding.
 *   No API key or gateway token is embedded in the app.
 */

const GEMINI_DEFAULT = "gemini-3.5-flash-lite";
const OPENROUTER_DEFAULT = "openrouter/free";
const GROQ_DEFAULT = "openai/gpt-oss-120b";
const PROVIDER_KEYS = { gemini: "GEMINI", openrouter: "OPENROUTER", groq: "GROQ" };
const MAX_AI_OVERLAYS = 3;
const MAX_BODY_BYTES = 1024 * 1024;
const PROVIDER_TIMEOUT_MS = 18000;

function responseJson(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Vary": "Origin"
    }
  });
}

function getAllowedOrigin(request, env) {
  const configured = (env.ALLOWED_ORIGIN || "*").trim();
  const incoming = request.headers.get("Origin");
  if (configured === "*") return "*";
  if (!incoming) return configured;
  return incoming === configured ? configured : "null";
}

function normalizeSignal(value) {
  const signal = String(value || "WAIT").trim().toUpperCase();
  if (["BUY", "LONG", "BULLISH", "STRONG_BUY"].includes(signal)) return "BUY";
  if (["SELL", "SHORT", "BEARISH", "STRONG_SELL"].includes(signal)) return "SELL";
  if (["WAIT", "HOLD", "NEUTRAL", "NO_TRADE"].includes(signal)) return "WAIT";
  return "WAIT";
}

function safeError(error) {
  return String(error?.message || error || "Unknown provider error")
    .replace(/(key|token|authorization)\s*[:=]\s*[^,\s]+/ig, "$1=[redacted]")
    .slice(0, 500);
}

async function fetchTimed(url, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), PROVIDER_TIMEOUT_MS);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function fetchProvider(url, options) {
  // HTTP errors (503/429/404) are returned immediately so the model fallback
  // can run. Only a transport-level failure gets one short retry.
  try {
    return await fetchTimed(url, options);
  } catch (firstError) {
    await new Promise(resolve => setTimeout(resolve, 300));
    try {
      return await fetchTimed(url, options);
    } catch (_) {
      throw firstError;
    }
  }
}

function openRouterErrorDetails(body) {
  const error = body?.error || {};
  const meta = error?.metadata || {};
  const router = body?.openrouter_metadata || {};
  const pipeline = Array.isArray(router.pipeline)
    ? router.pipeline.slice(0, 4).map(stage => {
        const parts = [stage?.type, stage?.name, stage?.summary].filter(Boolean);
        return parts.join("/");
      }).join(";")
    : "";
  const fields = [
    meta.error_type ? `error_type=${meta.error_type}` : "",
    meta.provider_name ? `provider=${meta.provider_name}` : "",
    meta.provider_code ? `provider_code=${meta.provider_code}` : "",
    meta.limit_source ? `limit_source=${meta.limit_source}` : "",
    meta.model_slug ? `model=${meta.model_slug}` : "",
    Array.isArray(meta.reasons) && meta.reasons.length ? `reasons=${meta.reasons.slice(0, 3).join(",")}` : "",
    router.region ? `region=${router.region}` : "",
    router.requested ? `requested=${router.requested}` : "",
    router.strategy ? `strategy=${router.strategy}` : "",
    pipeline ? `pipeline=${pipeline}` : ""
  ].filter(Boolean);
  return fields.join(" | ");
}

async function readJsonResponse(response, provider) {
  const raw = await response.text();
  let body;
  try {
    body = JSON.parse(raw);
  } catch {
    const plain = String(raw || "").replace(/\\s+/g, " ").slice(0, 240);
    throw new Error(`${provider} returned non-JSON HTTP ${response.status}: ${plain || "empty response"}`);
  }
  if (!response.ok) {
    const message = body?.error?.message || body?.message || raw;
    const details = provider === "OpenRouter" ? openRouterErrorDetails(body) : "";
    const hint = provider === "OpenRouter" && response.status === 403 && !details
      ? " | OpenRouter returned 403 but did not provide policy metadata; check API-key permissions/guardrails and provider-side access."
      : "";
    throw new Error(`${provider} HTTP ${response.status}: ${String(message).slice(0, 260)}${details ? ` | ${details}` : ""}${hint}`);
  }
  return body;
}

function extractJsonObject(raw, provider) {
  if (raw && typeof raw === "object" && !Array.isArray(raw)) return raw;
  const text = String(raw || "").trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "");

  try {
    return JSON.parse(text);
  } catch (_) {
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(text.slice(start, end + 1));
      } catch (_) {}
    }
    if (text.length >= 8) {
      return {
        bias: "WAIT",
        summary: text.slice(0, 260),
        observations: [],
        risks: ["پاسخ به‌صورت متن آزاد دریافت شد؛ برای جلوگیری از برداشت ساختاری اشتباه، سیگنال و سطوح معاملاتی از آن استخراج نشد."],
        confidence: 0,
        overlays: [],
        rawText: text.slice(0, 6000),
        responseFormat: "text"
      };
    }
    throw new Error(`${provider} response was empty or not usable`);
  }
}

function parseModelJson(raw, provider) {
  const value = extractJsonObject(raw, provider);
  const rawBias = String(value.bias || value.decision || value.signal || value.direction || "").trim().toUpperCase();
  const recognizedBias = ["BUY", "LONG", "BULLISH", "STRONG_BUY", "SELL", "SHORT", "BEARISH", "STRONG_SELL", "WAIT", "HOLD", "NEUTRAL", "NO_TRADE"];
  if (!recognizedBias.includes(rawBias)) throw new Error(`${provider} response is missing a recognized BUY/SELL/WAIT bias`);
  const bias = normalizeSignal(rawBias);
  const confidenceNumber = Number(value.confidence);
  if (!Number.isFinite(confidenceNumber) || confidenceNumber < 0 || confidenceNumber > 100) {
    throw new Error(`${provider} response has invalid confidence; expected a number from 0 to 100`);
  }

  return {
    status: "ok",
    bias,
    summary: String(value.summary || "خلاصه‌ای ارائه نشد.").slice(0, 260),
    observations: Array.isArray(value.observations)
      ? value.observations.slice(0, 3).map(item => String(item).slice(0, 180))
      : [],
    risks: Array.isArray(value.risks)
      ? value.risks.slice(0, 3).map(item => String(item).slice(0, 180))
      : Array.isArray(value.risk_factors)
        ? value.risk_factors.slice(0, 3).map(item => String(item).slice(0, 180))
        : [],
    confidence: Number.isFinite(confidenceNumber)
      ? Math.max(0, Math.min(100, Math.round(confidenceNumber)))
      : 0,
    overlays: normalizeAiOverlays(value.overlays),
    rawText: typeof value.rawText === "string" ? value.rawText.slice(0, 6000) : null,
    responseFormat: value.responseFormat === "text" ? "text" : "json"
  };
}

// AI POIs are accepted only as explicit structured levels. Entry/SL/TP are
// deliberately excluded: those remain technical-engine outputs in this phase.
function normalizeAiOverlays(raw) {
  if (!Array.isArray(raw)) return [];
  const allowedKinds = new Set(["Swing High", "Swing Low", "FVG", "Bullish FVG", "Bearish FVG", "Bullish OB", "Bearish OB", "EQH", "EQL", "BOS+", "BOS-", "CRT-H", "CRT-L", "EQ"]);
  const out = [];
  for (const item of raw.slice(0, MAX_AI_OVERLAYS)) {
    if (!item || typeof item !== "object") continue;
    const kind = String(item.kind || "").trim().slice(0, 32);
    const type = item.type === "zone" ? "zone" : item.type === "line" ? "line" : "";
    if (!["1h", "15m", "5m"].includes(item.timeframe)) continue;
    if (!["bullish", "bearish", "neutral"].includes(item.direction)) continue;
    const timeframe = item.timeframe;
    const direction = item.direction;
    const expectedType = ["FVG", "Bullish FVG", "Bearish FVG", "Bullish OB", "Bearish OB"].includes(kind) ? "zone" : "line";
    if (!type || !allowedKinds.has(kind) || type !== expectedType) continue;
    if (type === "line") {
      const price = Number(item.price);
      if (!Number.isFinite(price) || price <= 0) continue;
      out.push({type, kind, price, timeframe, direction});
    } else {
      const low = Number(item.low), high = Number(item.high);
      if (!Number.isFinite(low) || !Number.isFinite(high) || low <= 0 || high <= low) continue;
      out.push({type, kind, low, high, timeframe, direction});
    }
  }
  return out;
}


function openRouterOutputSchema() {
  return {
    type: "object",
    additionalProperties: false,
    properties: {
      bias: {type: "string", enum: ["BUY", "SELL", "WAIT"]},
      summary: {type: "string", maxLength: 260},
      observations: {type: "array", maxItems: 3, items: {type: "string", maxLength: 180}},
      risks: {type: "array", maxItems: 3, items: {type: "string", maxLength: 180}},
      confidence: {type: "integer", minimum: 0, maximum: 100},
      overlays: {
        type: "array",
        maxItems: 3,
        items: {
          type: "object",
          additionalProperties: false,
          properties: {
            type: {type: "string", enum: ["line", "zone"]},
            kind: {type: "string", enum: ["Swing High", "Swing Low", "FVG", "Bullish FVG", "Bearish FVG", "Bullish OB", "Bearish OB", "EQH", "EQL", "BOS+", "BOS-", "CRT-H", "CRT-L", "EQ"]},
            price: {type: ["number", "null"]},
            low: {type: ["number", "null"]},
            high: {type: ["number", "null"]},
            timeframe: {type: "string", enum: ["1h", "15m", "5m"]},
            direction: {type: "string", enum: ["bullish", "bearish", "neutral"]}
          },
          required: ["type", "kind", "price", "low", "high", "timeframe", "direction"]
        }
      }
    },
    required: ["bias", "summary", "observations", "risks", "confidence", "overlays"]
  };
}

function compressHistory(history, recentLimit, oldBuckets = 10) {
  const source = Array.isArray(history?.rows) ? history.rows : [];
  if (source.length <= recentLimit) return {...history, rows: source};
  const split = source.length - recentLimit;
  const basePrice = Number(history.basePrice);
  let previousClose = basePrice;
  let timestamp = Number(history.timeStart || 0);
  const decoded = [];
  for (const row of source) {
    timestamp += Number(row[0] || 0);
    const open = previousClose * (1 + Number(row[1] || 0) / 1000000);
    const high = previousClose * (1 + Number(row[2] || 0) / 1000000);
    const low = previousClose * (1 + Number(row[3] || 0) / 1000000);
    const close = previousClose * (1 + Number(row[4] || 0) / 1000000);
    decoded.push({time: timestamp, open, high, low, close, volume: Number(row[5] || 0)});
    previousClose = close;
  }
  const old = decoded.slice(0, split);
  const recent = source.slice(split);
  const bucketSize = Math.ceil(old.length / oldBuckets);
  const compact = [];
  let prevClose = basePrice;
  let prevTime = Number(history.timeStart || 0);
  for (let i = 0; i < old.length; i += bucketSize) {
    const group = old.slice(i, i + bucketSize);
    if (!group.length) continue;
    const first = group[0], last = group[group.length - 1];
    const values = [first.open, Math.max(...group.map(x => x.high)), Math.min(...group.map(x => x.low)), last.close];
    const delta = value => Math.round((value / prevClose - 1) * 1000000);
    compact.push([
      compact.length === 0 ? 0 : first.time - prevTime,
      delta(values[0]), delta(values[1]), delta(values[2]), delta(values[3]),
      Math.round(group.reduce((sum, x) => sum + x.volume, 0) / group.length)
    ]);
    prevClose = last.close;
    prevTime = last.time;
  }
  // The recent exact rows are still relative to the actual close at the end
  // of the old section, which is also the final compact bucket close.
  compact.push(...recent);
  return {
    timeStart: history.timeStart,
    intervalSeconds: history.intervalSeconds,
    basePrice: history.basePrice,
    baseVolumeMedian: history.baseVolumeMedian,
    originalCount: source.length,
    rows: compact
  };
}

function buildPrompt(input) {
  const history = input.marketHistory || {};
  // All original closed candles remain saved in the app. To respect free-tier
  // TPM/context limits, older history is OHLC-aggregated while recent candles
  // stay exact. This preserves range extremes and recent execution detail.
  const h1 = compressHistory(history["1h"], 48);
  const m15 = compressHistory(history["15m"], 64);
  const m5 = compressHistory(history["5m"], 80);
  const payload = {
    exchange: input.exchange,
    symbol: input.symbol,
    encoding: "rows=[delta_time_seconds, open/high/low/close_delta_ppm_from_previous_close, average_volume_ratio_x100]; older rows are OHLC-aggregated buckets preserving each bucket high/low; latest rows are exact candles",
    history: {
      "1h": h1,
      "15m": m15,
      "5m": m5
    }
  };
  return [
    "Act as an independent crypto market analyst. Analyze ONLY the supplied OHLCV market history. Do not receive or infer any technical-indicator engine decision; there is no technical opinion in this task.",
    "Reconstruct each timeframe sequentially from basePrice. Analyze 1h context, 15m structure and 5m execution. Consider trend, swings, displacement, volatility, volume, liquidity sweeps, range boundaries and alignment.",
    "Choose BUY, SELL or WAIT from your own evidence. Do not force a trade. Never invent numeric entry, stop-loss or take-profit prices. Return only concise JSON with bias, summary, observations (max 3), risks (max 3), confidence (0-100), overlays (max 3).",
    "Overlay schema: {type:line|zone,kind:Swing High|Swing Low|FVG|Bullish FVG|Bearish FVG|Bullish OB|Bearish OB|EQH|EQL|BOS+|BOS-|CRT-H|CRT-L|EQ,price:number|null,low:number|null,high:number|null,timeframe:1h|15m|5m,direction:bullish|bearish|neutral}. For line set price and null low/high; for zone set low/high and null price. No Entry/SL/TP overlays. No markdown or chain-of-thought.",
    JSON.stringify(payload)
  ].join("\n");
}

async function callGemini(prompt, env) {
  if (!env.GEMINI_API_KEY) {
    throw new Error("GEMINI_API_KEY is not configured");
  }

  const model = env.GEMINI_MODEL || GEMINI_DEFAULT;
  const endpoint =
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;

  const response = await fetchProvider(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": env.GEMINI_API_KEY
    },
    body: JSON.stringify({
      system_instruction: {
        parts: [{ text: "Independently analyze only the supplied OHLCV history. Return concise valid JSON only. Never invent trade prices." }]
      },
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: {
        responseMimeType: "application/json",
        temperature: 0.2,
        maxOutputTokens: 2200
      }
    })
  });

  const body = await readJsonResponse(response, "Gemini");
  const candidate = body?.candidates?.[0];
  if (!candidate) throw new Error("Gemini returned no candidate");
  const wasTruncated = candidate.finishReason === "MAX_TOKENS";
  if (candidate.finishReason === "SAFETY") throw new Error("Gemini response was blocked by safety filtering");
  const raw = candidate?.content?.parts?.map(part => part.text || "").join("");
  const parsed = parseModelJson(raw, "Gemini");
  if (wasTruncated) parsed.risks = [...(parsed.risks || []).slice(0, 2), "پاسخ مدل به محدودیت طول خروجی رسید؛ متن موجود حفظ شد و ممکن است کامل نباشد."];
  const usage = body?.usageMetadata || {};
  return {
    ...parsed,
    providerModel: model,
    finishReason: String(candidate.finishReason || "unknown"),
    promptTokens: Number.isFinite(Number(usage.promptTokenCount)) ? Number(usage.promptTokenCount) : null,
    completionTokens: Number.isFinite(Number(usage.candidatesTokenCount)) ? Number(usage.candidatesTokenCount) : null,
    reasoningTokens: Number.isFinite(Number(usage.thoughtsTokenCount)) ? Number(usage.thoughtsTokenCount) : null
  };
}

async function callOpenRouter(prompt, env) {
  if (!env.OPENROUTER_API_KEY) {
    throw new Error("OPENROUTER_API_KEY is not configured");
  }

  const model = env.OPENROUTER_MODEL || OPENROUTER_DEFAULT;

  const openRouterUrl = "https://openrouter.ai/api/v1/chat/completions";
  const headers = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${env.OPENROUTER_API_KEY}`,
    "X-OpenRouter-Metadata": "enabled",
    "X-OpenRouter-Experimental-Metadata": "enabled",
    "HTTP-Referer": "https://ai-crypto-analyst.app",
    "X-Title": "AI Crypto Analyst"
  };
  const payload = {
    model,
    messages: [
      { role: "system", content: "Independently analyze only the supplied OHLCV history. Return one concise valid JSON object. Never invent trade prices." },
      { role: "user", content: prompt }
    ],
    temperature: 0.1,
    reasoning: { effort: "none" },
    max_tokens: 1200,
    response_format: { type: "json_schema", json_schema: {name: "crypto_market_analysis", strict: true, schema: openRouterOutputSchema()} },
    plugins: [{ id: "response-healing" }],
    provider: { require_parameters: true, sort: "throughput", allow_fallbacks: true },
    stream: false
  };
  let response = await fetchProvider(openRouterUrl, {method:"POST", headers, body:JSON.stringify(payload)});
  // Some free endpoints do not implement JSON Schema or reasoning controls.
  // Retry once without those optional constraints; parse JSON if present, otherwise preserve plain text.
  if ([400, 422].includes(response.status)) {
    const errorText = await response.clone().text();
    if (/response_format|json_schema|reasoning|unsupported parameter|not supported/i.test(errorText)) {
      const fallbackPayload = {...payload};
      delete fallbackPayload.response_format;
      delete fallbackPayload.reasoning;
      fallbackPayload.provider = {sort:"throughput", allow_fallbacks:true};
      response = await fetchProvider(openRouterUrl, {method:"POST", headers, body:JSON.stringify(fallbackPayload)});
    }
  }
  const body = await readJsonResponse(response, "OpenRouter");
  const choice = body?.choices?.[0];
  const message = choice?.message;
  if (!choice || !message) throw new Error("OpenRouter returned no completion choice");
  const usage = body?.usage || {};
  const actualModel = String(body?.model || model);
  const wasTruncated = choice.finish_reason === "length";
  if (choice.finish_reason === "content_filter") throw new Error(`OpenRouter completion blocked by content filtering (model=${actualModel})`);
  let raw = message?.content;
  if (Array.isArray(raw)) {
    raw = raw.map(part => typeof part === "string" ? part : (part?.text || "")).join("\n");
  }
  if ((raw === null || raw === undefined || raw === "") && message?.parsed && typeof message.parsed === "object") {
    raw = message.parsed;
  }
  if ((raw === null || raw === undefined || raw === "") && message?.refusal) {
    throw new Error(`OpenRouter refused the request: ${String(message.refusal).slice(0, 220)}`);
  }
  const parsed = parseModelJson(raw, "OpenRouter");
  if (wasTruncated) parsed.risks = [...(parsed.risks || []).slice(0, 2), "پاسخ مدل به محدودیت طول خروجی رسید؛ متن موجود حفظ شد و ممکن است کامل نباشد."];
  return {
    ...parsed,
    providerModel: actualModel,
    finishReason: String(choice.finish_reason || "unknown"),
    nativeFinishReason: choice.native_finish_reason == null ? null : String(choice.native_finish_reason),
    promptTokens: Number.isFinite(Number(usage.prompt_tokens)) ? Number(usage.prompt_tokens) : null,
    completionTokens: Number.isFinite(Number(usage.completion_tokens)) ? Number(usage.completion_tokens) : null,
    reasoningTokens: Number.isFinite(Number(usage.completion_tokens_details?.reasoning_tokens))
      ? Number(usage.completion_tokens_details.reasoning_tokens) : null
  };
}

async function callGroq(prompt, env) {
  if (!env.GROQ_API_KEY) throw new Error("GROQ_API_KEY is not configured");
  const model = env.GROQ_MODEL || GROQ_DEFAULT;
  const response = await fetchProvider("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${env.GROQ_API_KEY}`
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: "Independently analyze only the supplied OHLCV history. Return concise JSON only with bias, summary, observations, risks, confidence and overlays. Never invent trade prices." },
        { role: "user", content: prompt }
      ],
      temperature: 0.1,
      max_completion_tokens: 1100,
      response_format: { type: "json_object" },
      stream: false
    })
  });
  const body = await readJsonResponse(response, "Groq");
  const choice = body?.choices?.[0];
  const message = choice?.message;
  if (!choice || !message) throw new Error("Groq returned no completion choice");
  const wasTruncated = choice.finish_reason === "length";
  if (choice.finish_reason === "content_filter") throw new Error("Groq completion blocked by content filtering");
  const raw = message.content;
  const parsed = parseModelJson(raw, "Groq");
  if (wasTruncated) parsed.risks = [...(parsed.risks || []).slice(0, 2), "پاسخ مدل به محدودیت طول خروجی رسید؛ متن موجود حفظ شد و ممکن است کامل نباشد."];
  const usage = body?.usage || {};
  return {
    ...parsed,
    providerModel: String(body?.model || model),
    finishReason: String(choice.finish_reason || "unknown"),
    promptTokens: Number.isFinite(Number(usage.prompt_tokens)) ? Number(usage.prompt_tokens) : null,
    completionTokens: Number.isFinite(Number(usage.completion_tokens)) ? Number(usage.completion_tokens) : null,
    reasoningTokens: null
  };
}

function historyPriceBounds(history) {
  let min = Infinity, max = 0;
  for (const tf of ["1h", "15m", "5m"]) {
    const item = history?.[tf];
    if (!item || !Array.isArray(item.rows)) continue;
    let previousClose = Number(item.basePrice);
    for (const row of item.rows) {
      const base = previousClose;
      const open = base * (1 + Number(row[1]) / 1000000);
      const high = base * (1 + Number(row[2]) / 1000000);
      const low = base * (1 + Number(row[3]) / 1000000);
      const close = base * (1 + Number(row[4]) / 1000000);
      if ([open, high, low, close].every(Number.isFinite) && low > 0 && high >= low) {
        min = Math.min(min, low);
        max = Math.max(max, high);
      }
      previousClose = close;
    }
  }
  return Number.isFinite(min) && max > 0 ? {min, max} : null;
}

function validateProviderOverlays(provider, history) {
  if (provider?.status !== "ok") return provider;
  const bounds = historyPriceBounds(history);
  if (!bounds) return {...provider, overlays: []};
  const floor = bounds.min * 0.95, ceiling = bounds.max * 1.05;
  const overlays = (provider.overlays || []).filter(item => item.type === "line"
    ? item.price >= floor && item.price <= ceiling
    : item.low >= floor && item.high <= ceiling);
  const rejected = (provider.overlays || []).length - overlays.length;
  return {
    ...provider,
    overlays,
    risks: rejected > 0
      ? [...(provider.risks || []).slice(0, 7), `${rejected} POI خارج از محدوده تاریخی قیمت بود و برای جلوگیری از ترسیم سطح ساختگی حذف شد.`]
      : provider.risks || []
  };
}

function configuredModelList(provider, env) {
  const key = PROVIDER_KEYS[provider];
  const fallback = env[`${key}_MODEL`] || ({gemini:GEMINI_DEFAULT,openrouter:OPENROUTER_DEFAULT,groq:GROQ_DEFAULT})[provider];
  const configured = String(env[`${key}_MODELS`] || fallback).split(",").map(x => x.trim()).filter(Boolean);
  return [...new Set(configured)].slice(0, 20);
}

function requestedModels(provider, input, env) {
  const available = configuredModelList(provider, env);
  const primaryRaw = input?.modelSelection?.[provider];
  const fallbackRaw = input?.fallbackSelection?.[provider];
  const values = [primaryRaw == null || primaryRaw === "" ? available[0] : primaryRaw, fallbackRaw];
  const models = [];
  for (const raw of values) {
    if (raw == null || raw === "") continue;
    const model = String(raw).trim();
    if (model.length > 140 || !/^[a-zA-Z0-9][a-zA-Z0-9._:/-]*$/.test(model)) {
      throw new Error(`Invalid ${provider} model identifier`);
    }
    if (!available.includes(model)) {
      throw new Error(`${provider} model is not in the Worker allow-list; add it to ${PROVIDER_KEYS[provider]}_MODELS`);
    }
    if (!models.includes(model)) models.push(model);
  }
  if (models.length === 0) throw new Error(`No ${provider} model is configured`);
  return models.slice(0, 2);
}

async function runProviders(input, env) {
  const prompt = buildPrompt(input);
  const definitions = [
    ["gemini", callGemini],
    ["openrouter", callOpenRouter],
    ["groq", callGroq]
  ];
  const requested = Array.isArray(input?.selectedProviders)
    ? new Set(input.selectedProviders.filter(x => ["gemini","openrouter","groq"].includes(x)))
    : new Set(definitions.filter(([name]) => Boolean(env[`${PROVIDER_KEYS[name]}_API_KEY`])).map(([name]) => name));
  const settled = await Promise.allSettled(definitions.map(async ([name, fn]) => {
    if (!requested.has(name)) return { skipped: true };
    const started = Date.now();
    try {
      if (!env[`${PROVIDER_KEYS[name]}_API_KEY`]) throw new Error(`${name} API key is not configured`);
      const models = requestedModels(name, input, env);
      const failures = [];
      for (let modelIndex = 0; modelIndex < models.length; modelIndex++) {
        const model = models[modelIndex];
        try {
          const modelEnv = { ...env, [`${PROVIDER_KEYS[name]}_MODEL`]: model };
          const value = await fn(prompt, modelEnv);
          return { ...value, status: "ok", provider: name, providerModel: value.providerModel || model,
            attemptedModels: models.slice(0, modelIndex + 1), fallbackUsed: modelIndex > 0,
            responseTimeMs: Date.now() - started };
        } catch (error) {
          failures.push(`${model}: ${safeError(error)}`);
        }
      }
      throw new Error(failures.join(" || ") || `${name} models failed`);
    } catch (error) {
      throw Object.assign(new Error(safeError(error)), {
        providerName: name,
        responseTimeMs: Date.now() - started
      });
    }
  }));

  const results = {};
  for (let i = 0; i < definitions.length; i++) {
    const [name] = definitions[i];
    const item = settled[i];
    if (item.status === "fulfilled" && item.value?.skipped) {
      results[name] = { status: "not_selected", provider: name, bias: "WAIT", summary: "این ارائه‌دهنده برای این درخواست انتخاب نشده است.", observations: [], risks: [], confidence: 0, overlays: [] };
    } else {
      results[name] = item.status === "fulfilled"
        ? item.value
        : {
            status: "error", provider: name, bias: "WAIT", summary: `فراخوانی ${name} ناموفق بود.`,
            observations: [], risks: [], confidence: 0, overlays: [],
            error: safeError(item.reason), responseTimeMs: Number(item.reason?.responseTimeMs || 0)
          };
    }
    results[name] = validateProviderOverlays(results[name], input.marketHistory);
  }
  return results;
}

function overlaysMatch(a, b) {
  if (a.type !== b.type || a.kind !== b.kind || a.direction !== b.direction || a.timeframe !== b.timeframe) return false;
  if (a.type === "line") {
    const mid = (a.price + b.price) / 2;
    return mid > 0 && Math.abs(a.price - b.price) / mid <= 0.0015;
  }
  const overlap = Math.min(a.high, b.high) - Math.max(a.low, b.low);
  const span = Math.max(a.high, b.high) - Math.min(a.low, b.low);
  return span > 0 && overlap / span >= 0.5;
}

function makeConsensus(providers) {
  const names = ["gemini", "openrouter", "groq"];
  const valid = names.filter(name => providers[name]?.status === "ok");
  const conflicts = [];
  if (valid.length === 1) conflicts.push("فقط یک مدل AI پاسخ معتبر داده است؛ جهت نمایش‌داده‌شده تصمیم مستقل همان مدل است، نه اجماع چندمدلی.");
  if (valid.length === 0) conflicts.push("هیچ مدل AI پاسخ معتبر نداده است.");
  const votes = { BUY: 0, SELL: 0, WAIT: 0 };
  for (const name of valid) votes[normalizeSignal(providers[name].bias)]++;
  const majority = valid.length >= 2 && Math.max(votes.BUY, votes.SELL, votes.WAIT) >= 2
    ? Object.keys(votes).find(key => votes[key] >= 2) : "WAIT";
  if (valid.length >= 2 && majority === "WAIT") conflicts.push("بین مدل‌های پاسخ‌گو اجماع جهت‌دار وجود ندارد.");
  if (valid.length >= 2 && valid.length < 3) conflicts.push("حداقل یکی از ارائه‌دهندگان AI پاسخ نداده است.");
  const agreeing = valid.filter(name => normalizeSignal(providers[name].bias) === majority);
  const confidenceOk = agreeing.length >= 2 && agreeing.every(name => Number(providers[name].confidence) >= 55);
  const singleModelDecision = valid.length === 1 ? normalizeSignal(providers[valid[0]].bias) : "WAIT";
  const decision = valid.length === 1
    ? singleModelDecision
    : (["BUY", "SELL"].includes(majority) && confidenceOk ? majority : "WAIT");

  const aiOverlays = [];
  const baseName = agreeing[0];
  if (baseName) {
    for (const a of (providers[baseName].overlays || [])) {
      const matching = agreeing.slice(1).map(name => (providers[name].overlays || []).find(b => overlaysMatch(a, b))).filter(Boolean);
      if (matching.length < 1) continue;
      if (a.type === "line") {
        const price = ([a.price, ...matching.map(x => x.price)].reduce((sum, value) => sum + value, 0)) / (matching.length + 1);
        aiOverlays.push({...a, price, color: a.direction === "bullish" ? "#22C99A" : a.direction === "bearish" ? "#F05D6C" : "#B58BE8", agreement: "multi"});
      } else {
        const low = Math.max(a.low, ...matching.map(x => x.low));
        const high = Math.min(a.high, ...matching.map(x => x.high));
        if (high > low) aiOverlays.push({...a, low, high, color: a.direction === "bullish" ? "#22C99A" : a.direction === "bearish" ? "#F05D6C" : "#B58BE8", agreement: "multi"});
      }
      if (aiOverlays.length >= MAX_AI_OVERLAYS) break;
    }
  }
  if (aiOverlays.length === 0) conflicts.push("برای ترسیم تجمیعی منبع AI، دو مدل باید POI هم‌نوع و هم‌محدوده تأیید کنند.");
  return { decision, majority, votes, validProviders: valid, conflicts, aiOverlays };
}

async function readRequestBody(request) {
  const declared = Number(request.headers.get("Content-Length") || 0);
  if (declared > MAX_BODY_BYTES) throw new Error("Request body too large");

  const raw = await request.text();
  if (new TextEncoder().encode(raw).length > MAX_BODY_BYTES) {
    throw new Error("Request body too large");
  }

  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("Invalid JSON body");
  }
}

function constantTimeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) {
    return false;
  }
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function authorizedForProviderTest(request, env) {
  if (!env.GATEWAY_TOKEN) return false;
  const header = request.headers.get("Authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  return constantTimeEqual(token, env.GATEWAY_TOKEN);
}

async function applyRateLimit(request, env) {
  if (!env.RATE_LIMITER) {
    return { allowed: false, reason: "RATE_LIMITER binding is missing" };
  }

  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  try {
    const result = await env.RATE_LIMITER.limit({ key: ip });
    return { allowed: Boolean(result?.success), reason: null };
  } catch (error) {
    return { allowed: false, reason: "Rate limiter binding failed" };
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = getAllowedOrigin(request, env);

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          "Access-Control-Allow-Origin": origin,
          "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
          "Access-Control-Max-Age": "86400",
          "Vary": "Origin"
        }
      });
    }

    if (origin === "null") {
      return responseJson({ ok: false, error: "Origin not allowed" }, 403, origin);
    }

    if (url.pathname === "/health" && request.method === "GET") {
      return responseJson({
        ok: true,
        service: "AI Crypto Analyst Gateway",
        mode: "FREE_PROVIDERS",
        configured: {
          gemini: Boolean(env.GEMINI_API_KEY),
          openrouter: Boolean(env.OPENROUTER_API_KEY),
          groq: Boolean(env.GROQ_API_KEY),
          gateway: Boolean(env.GATEWAY_TOKEN),
          rateLimiter: Boolean(env.RATE_LIMITER)
        },
        models: {
          gemini: configuredModelList("gemini", env),
          openrouter: configuredModelList("openrouter", env),
          groq: configuredModelList("groq", env)
        },
        modelSelectionSupported: true
      }, 200, origin);
    }

    if (url.pathname === "/models" && request.method === "GET") {
      return responseJson({ ok: true, source: "worker_allowlist", note: "مدل‌های قابل انتخاب از فهرست مجاز Worker خوانده می‌شوند؛ برای افزودن مدل جدید متغیر *_MODELS را به‌روزرسانی کنید.", providers: {
        gemini: { configured: Boolean(env.GEMINI_API_KEY), models: configuredModelList("gemini", env) },
        openrouter: { configured: Boolean(env.OPENROUTER_API_KEY), models: configuredModelList("openrouter", env) },
        groq: { configured: Boolean(env.GROQ_API_KEY), models: configuredModelList("groq", env) }
      }}, 200, origin);
    }

    if (url.pathname === "/provider-test") {
      if (request.method !== "POST") {
        return responseJson({ ok: false, error: "Method not allowed" }, 405, origin);
      }
      if (!authorizedForProviderTest(request, env)) {
        return responseJson({ ok: false, error: "Unauthorized" }, 401, origin);
      }

      let testOptions = {};
      try { const rawOptions = await request.text(); if (rawOptions) testOptions = JSON.parse(rawOptions); }
      catch { return responseJson({ ok: false, error: "Invalid JSON body" }, 400, origin); }
      const testInput = {
        modelSelection: testOptions.modelSelection || {},
        fallbackSelection: testOptions.fallbackSelection || {},
        selectedProviders: testOptions.selectedProviders,
        exchange: "TEST",
        symbol: "BTCUSDT",
        technicalAnalysis: {
          signal: "WAIT",
          note: "Connectivity test only. Do not produce a trade signal."
        },
        marketHistory: {
          format: "delta OHLCV; price deltas in 0.01 bps; volume ratio x100",
          "1h": {timeStart:1700000000,intervalSeconds:3600,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:3600,0,10000,-10000,5000,100])},
          "15m": {timeStart:1700000000,intervalSeconds:900,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:900,0,10000,-10000,5000,100])},
          "5m": {timeStart:1700000000,intervalSeconds:300,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:300,0,10000,-10000,5000,100])}
        }
      };

      const providers = await runProviders(testInput, env);
      const successCount = Object.values(providers).filter(item => item.status === "ok").length;
      const ok = successCount >= 1;

      return responseJson({
        ok, successCount, requiredForDisplay: 1, requiredForConsensus: 2,
        test: "provider-connectivity", providers
      }, ok ? 200 : 502, origin);
    }

    if (url.pathname !== "/analyze") {
      return responseJson({ ok: false, error: "Not found" }, 404, origin);
    }

    if (request.method !== "POST") {
      return responseJson({ ok: false, error: "Method not allowed" }, 405, origin);
    }

    const rate = await applyRateLimit(request, env);
    if (!rate.allowed) {
      return responseJson({
        ok: false,
        error: rate.reason || "Rate limit exceeded",
        code: rate.reason ? "RATE_LIMITER_UNAVAILABLE" : "RATE_LIMITED"
      }, rate.reason ? 503 : 429, origin);
    }

    if (!env.GEMINI_API_KEY && !env.OPENROUTER_API_KEY && !env.GROQ_API_KEY) {
      return responseJson({
        ok: false,
        error: "No AI provider API key is configured (GEMINI_API_KEY, OPENROUTER_API_KEY, GROQ_API_KEY)"
      }, 503, origin);
    }

    try {
      const input = await readRequestBody(request);
      const marketHistory = input?.marketHistory;
      const validHistory = (item) => item && typeof item === "object" &&
        Number.isFinite(Number(item.timeStart)) && Number(item.timeStart) > 0 &&
        Number.isFinite(Number(item.intervalSeconds)) && Number(item.intervalSeconds) > 0 &&
        Number.isFinite(Number(item.basePrice)) && Number(item.basePrice) > 0 &&
        Number.isFinite(Number(item.baseVolumeMedian)) && Number(item.baseVolumeMedian) >= 0 &&
        Array.isArray(item.rows) && item.rows.length >= 50 && item.rows.every((row) =>
          Array.isArray(row) && row.length === 6 && row.every((value) => Number.isFinite(Number(value))) &&
          Number(row[0]) >= 0 && Number(row[2]) >= Math.max(Number(row[1]), Number(row[4])) &&
          Number(row[3]) <= Math.min(Number(row[1]), Number(row[4])) && Number(row[2]) >= Number(row[3]) && Number(row[5]) >= 0
        );

      if (
        !input ||
        typeof input !== "object" ||
        Array.isArray(input) ||
        typeof input.exchange !== "string" ||
        typeof input.symbol !== "string" ||
        !marketHistory || typeof marketHistory !== "object" ||
        !validHistory(marketHistory["1h"]) || !validHistory(marketHistory["15m"]) || !validHistory(marketHistory["5m"])
      ) {
        return responseJson({
          ok: false,
          error: "exchange, symbol and valid 1h/15m/5m marketHistory are required"
        }, 400, origin);
      }

      const providers = await runProviders({
        exchange: input.exchange.slice(0, 40),
        symbol: input.symbol.slice(0, 40),
        marketHistory,
        snapshotId: typeof input.snapshotId === "string" ? input.snapshotId.slice(0, 100) : null,
        modelSelection: input.modelSelection && typeof input.modelSelection === "object" ? input.modelSelection : {},
        fallbackSelection: input.fallbackSelection && typeof input.fallbackSelection === "object" ? input.fallbackSelection : {},
        selectedProviders: input.selectedProviders
      }, env);
      const { gemini, openrouter, groq } = providers;
      const successfulProviders = Object.values(providers).filter(provider => provider.status === "ok").length;
      if (successfulProviders === 0) {
        return responseJson({
          ok: false, decision: "WAIT", providers, gemini, openrouter, groq,
          error: "All configured AI providers failed; no independent AI assessment is available"
        }, 502, origin);
      }

      const consensus = makeConsensus(providers);
      const partial = successfulProviders < 3;
      return responseJson({
        ok: true,
        decision: consensus.decision,
        consensus,
        conflicts: consensus.conflicts,
        providers,
        gemini,
        openrouter,
        groq,
        analysisMode: successfulProviders < 2 ? "SINGLE_PROVIDER_INDEPENDENT" : partial ? "PARTIAL_MULTI_PROVIDER" : "TRIPLE_PROVIDER",
        priceLevelsSource: "SOURCE_SELECTOR",
        aiOverlays: consensus.aiOverlays,
        snapshotId: typeof input.snapshotId === "string" ? input.snapshotId.slice(0, 100) : null,
        modelSelection: input.modelSelection || {},
        fallbackSelection: input.fallbackSelection || {},
        historyCounts: {
          "1h": marketHistory["1h"].rows.length,
          "15m": marketHistory["15m"].rows.length,
          "5m": marketHistory["5m"].rows.length
        }
      }, 200, origin);

    } catch (error) {
      const message = safeError(error);
      const status =
        message === "Request body too large" ? 413 :
        message === "Invalid JSON body" ? 400 : 502;

      return responseJson({
        ok: false,
        error: message,
        decision: "WAIT"
      }, status, origin);
    }
  }
};
