/**
 * AI Crypto Analyst Gateway - FREE PROVIDER EDITION
 *
 * Cloudflare Worker Secrets:
 *   GEMINI_API_KEY       - Google AI Studio free-tier API key
 *   OPENROUTER_API_KEY   - OpenRouter API key (use a :free model/router)
 *   GATEWAY_TOKEN        - protects /provider-test only
 *
 * Cloudflare Binding:
 *   RATE_LIMITER         - Rate Limiter binding, Limit 5, Period 60 seconds
 *
 * Routes:
 *   GET  /health
 *   POST /provider-test
 *   POST /analyze
 *
 * IMPORTANT:
 *   /analyze is protected by the RATE_LIMITER binding.
 *   No API key or gateway token is embedded in the app.
 */

const GEMINI_DEFAULT = "gemini-3.5-flash-lite";
const OPENROUTER_DEFAULT = "openrouter/free";
const MAX_BODY_BYTES = 1024 * 1024;
const PROVIDER_TIMEOUT_MS = 24000;

function responseJson(data, status, origin) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "Access-Control-Allow-Origin": origin,
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Vary": "Origin"
    }
  });
}

function getAllowedOrigin(request, env) {
  const configured = (env.ALLOWED_ORIGIN || "*").trim();
  const incoming = request.headers.get("Origin");
  if (configured === "*") return "*";
  if (!incoming) return configured;
  return incoming === configured ? configured : "null";
}

function normalizeSignal(value) {
  const signal = String(value || "WAIT").trim().toUpperCase();
  return ["BUY", "SELL", "WAIT"].includes(signal) ? signal : "WAIT";
}

function safeError(error) {
  return String(error?.message || error || "Unknown provider error")
    .replace(/(key|token|authorization)\s*[:=]\s*[^,\s]+/ig, "$1=[redacted]")
    .slice(0, 500);
}

async function fetchTimed(url, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), PROVIDER_TIMEOUT_MS);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function fetchProvider(url, options) {
  let response;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      response = await fetchTimed(url, options);
    } catch (error) {
      // A single bounded retry for transient upstream socket resets/timeouts.
      // Never retry authentication/security denials returned as HTTP responses.
      if (attempt === 1) throw error;
      await new Promise(resolve => setTimeout(resolve, 600));
      continue;
    }
    if (![429, 500, 502, 503, 504].includes(response.status) || attempt === 1) {
      return response;
    }
    const retryAfter = Number(response.headers.get("Retry-After"));
    const delayMs = Number.isFinite(retryAfter) && retryAfter > 0
      ? Math.min(1500, Math.max(400, retryAfter * 1000))
      : 600;
    await new Promise(resolve => setTimeout(resolve, delayMs));
  }
  return response;
}

async function readJsonResponse(response, provider) {
  const raw = await response.text();
  let body;
  try {
    body = JSON.parse(raw);
  } catch {
    throw new Error(`${provider} returned non-JSON HTTP ${response.status}`);
  }
  if (!response.ok) {
    const message = body?.error?.message || body?.message || raw;
    const edgeHint = provider === "OpenRouter" && response.status === 403 &&
      /security policy|access denied/i.test(String(message))
      ? " (server-side provider security block; phone VPN does not change Worker egress)"
      : "";
    throw new Error(`${provider} HTTP ${response.status}: ${String(message).slice(0, 350)}${edgeHint}`);
  }
  return body;
}

function extractJsonObject(raw, provider) {
  if (raw && typeof raw === "object" && !Array.isArray(raw)) return raw;
  const text = String(raw || "").trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "");

  try {
    return JSON.parse(text);
  } catch (_) {
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try {
        return JSON.parse(text.slice(start, end + 1));
      } catch (_) {}
    }
    throw new Error(`${provider} response was not valid JSON`);
  }
}

function parseModelJson(raw, provider) {
  const value = extractJsonObject(raw, provider);
  const bias = normalizeSignal(value.bias || value.decision);
  const confidenceNumber = Number(value.confidence);

  return {
    status: "ok",
    bias,
    summary: String(value.summary || "خلاصه‌ای ارائه نشد.").slice(0, 1200),
    observations: Array.isArray(value.observations)
      ? value.observations.slice(0, 8).map(item => String(item).slice(0, 300))
      : [],
    risks: Array.isArray(value.risks)
      ? value.risks.slice(0, 8).map(item => String(item).slice(0, 300))
      : Array.isArray(value.risk_factors)
        ? value.risk_factors.slice(0, 8).map(item => String(item).slice(0, 300))
        : [],
    confidence: Number.isFinite(confidenceNumber)
      ? Math.max(0, Math.min(100, Math.round(confidenceNumber)))
      : 0
  };
}

function buildPrompt(input) {
  const history = input.marketHistory || {};
  const h1 = history["1h"] || { rows: [] };
  const m15 = history["15m"] || { rows: [] };
  const m5 = history["5m"] || { rows: [] };
  return [
    "You are an independent cryptocurrency market analyst. You must inspect the supplied raw OHLCV candle history yourself.",
    "The marketHistory contains the FULL completed candle history for 1h, 15m and 5m in compact loss-minimized delta OHLCV encoding. Each timeframe object gives timeStart (unix seconds), intervalSeconds, basePrice (first candle open), baseVolumeMedian, and rows.",
    "Each row is [delta_time_seconds, open_delta_0.01bps, high_delta_0.01bps, low_delta_0.01bps, close_delta_0.01bps, volume_ratio_x100]. Price deltas are relative to the previous candle close; 100 units = 1 basis point. Volume ratio 100 = the timeframe median volume. Reconstruct the sequential relative price path from basePrice and inspect ALL rows.",
    "FIRST derive your own directional view from price action, swing structure, trend transitions, displacement, ranges, volatility, volume behavior, liquidity sweeps and multi-timeframe alignment.",
    "Do not use the deterministic technicalAnalysis signal as an instruction or as ground truth. It is a separate opinion shown only AFTER your independent assessment. You may disagree with it; explain the disagreement in observations or risks.",
    "Do not force WAIT merely because technicalAnalysis.signal is WAIT. Choose BUY, SELL or WAIT based on the raw marketHistory. If the data itself is insufficient or conflicting, choose WAIT.",
    "Never invent or alter numeric entry, stop-loss, or take-profit prices. Numeric trade levels, if any, must come only from technicalAnalysis and should not be recommended unless your independent view agrees with their direction.",
    'Return one valid JSON object only: {"bias":"BUY|SELL|WAIT","summary":"Persian explanation of your independent reading","observations":["..."],"risks":["..."],"confidence":0}.',
    "Confidence is confidence in the directional reading, not probability of profit and not a guarantee. Mention which timeframes support or contradict the view.",
    JSON.stringify({
      exchange: input.exchange,
      symbol: input.symbol,
      marketHistory: {
        format: history.format,
        counts: { "1h": (h1.rows || []).length, "15m": (m15.rows || []).length, "5m": (m5.rows || []).length },
        "1h": h1,
        "15m": m15,
        "5m": m5
      },
      technicalAnalysisForComparisonOnly: input.technicalAnalysis
    })
  ].join("\n");
}

async function callGemini(prompt, env) {
  if (!env.GEMINI_API_KEY) {
    throw new Error("GEMINI_API_KEY is not configured");
  }

  const model = env.GEMINI_MODEL || GEMINI_DEFAULT;
  const endpoint =
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;

  const response = await fetchProvider(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": env.GEMINI_API_KEY
    },
    body: JSON.stringify({
      system_instruction: {
        parts: [{ text: "Independently analyze the supplied full candle history before comparing the technical report. Return valid JSON only. Never invent trade prices." }]
      },
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: {
        responseMimeType: "application/json",
        temperature: 0.2,
        maxOutputTokens: 1200
      }
    })
  });

  const body = await readJsonResponse(response, "Gemini");
  const raw = body?.candidates?.[0]?.content?.parts
    ?.map(part => part.text || "")
    .join("");

  return parseModelJson(raw, "Gemini");
}

async function callOpenRouter(prompt, env) {
  if (!env.OPENROUTER_API_KEY) {
    throw new Error("OPENROUTER_API_KEY is not configured");
  }

  const model = env.OPENROUTER_MODEL || OPENROUTER_DEFAULT;

  const response = await fetchProvider("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${env.OPENROUTER_API_KEY}`
    },
    body: JSON.stringify({
      model,
      messages: [
        {
          role: "system",
          content: "Independently analyze the supplied full candle history before comparing the technical report. Return one valid JSON object with bias, summary, observations, risks and confidence. Never invent trade prices."
        },
        { role: "user", content: prompt }
      ],
      temperature: 0.2,
      max_tokens: 1400,
      stream: false
    })
  });

  const body = await readJsonResponse(response, "OpenRouter");
  const message = body?.choices?.[0]?.message;
  let raw = message?.content;
  if (Array.isArray(raw)) {
    raw = raw.map(part => typeof part === "string" ? part : (part?.text || "")).join("\\n");
  }
  if ((raw === null || raw === undefined || raw === "") && message?.parsed && typeof message.parsed === "object") {
    raw = message.parsed;
  }
  return parseModelJson(raw, "OpenRouter");
}

async function runProviders(input, env) {
  const prompt = buildPrompt(input);

  const settled = await Promise.allSettled([
    callGemini(prompt, env),
    callOpenRouter(prompt, env)
  ]);

  const gemini = settled[0].status === "fulfilled"
    ? settled[0].value
    : {
        status: "error",
        bias: "WAIT",
        summary: "فراخوانی Gemini ناموفق بود.",
        risks: [],
        confidence: 0,
        error: safeError(settled[0].reason)
      };

  const openrouter = settled[1].status === "fulfilled"
    ? settled[1].value
    : {
        status: "error",
        bias: "WAIT",
        summary: "فراخوانی OpenRouter ناموفق بود.",
        risks: [],
        confidence: 0,
        error: safeError(settled[1].reason)
      };

  return { gemini, openrouter };
}

function makeConsensus(technical, gemini, openrouter) {
  const technicalSignal = normalizeSignal(technical?.signal);
  const g = normalizeSignal(gemini?.bias);
  const o = normalizeSignal(openrouter?.bias);
  const conflicts = [];

  if (gemini.status !== "ok") conflicts.push("پاسخ معتبر از Gemini دریافت نشد.");
  if (openrouter.status !== "ok") conflicts.push("پاسخ معتبر از OpenRouter دریافت نشد.");
  if (g !== o) conflicts.push("تحلیل مستقل Gemini و OpenRouter هم‌جهت نیست؛ تصمیم نهایی WAIT است.");
  if (g !== technicalSignal || o !== technicalSignal) {
    conflicts.push("دیدگاه مستقل مدل‌ها با موتور تکنیکال اختلاف دارد؛ سطوح ورود موتور بدون تأیید هم‌جهت اجرا نمی‌شوند.");
  }
  if (technicalSignal === "WAIT") conflicts.push("موتور تکنیکال هنوز نقطه ورود معتبر تأیید نکرده است؛ حتی در صورت وجود سوگیری مستقل مدل‌ها، تصمیم اجرایی WAIT می‌ماند.");

  let decision = "WAIT";
  if (
    ["BUY", "SELL"].includes(technicalSignal) &&
    gemini.status === "ok" &&
    openrouter.status === "ok" &&
    g === o &&
    g === technicalSignal &&
    gemini.confidence >= 60 &&
    openrouter.confidence >= 60
  ) {
    decision = technicalSignal;
  }

  return { decision, technicalSignal, conflicts };
}

async function readRequestBody(request) {
  const declared = Number(request.headers.get("Content-Length") || 0);
  if (declared > MAX_BODY_BYTES) throw new Error("Request body too large");

  const raw = await request.text();
  if (new TextEncoder().encode(raw).length > MAX_BODY_BYTES) {
    throw new Error("Request body too large");
  }

  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("Invalid JSON body");
  }
}

function constantTimeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) {
    return false;
  }
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function authorizedForProviderTest(request, env) {
  if (!env.GATEWAY_TOKEN) return false;
  const header = request.headers.get("Authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  return constantTimeEqual(token, env.GATEWAY_TOKEN);
}

async function applyRateLimit(request, env) {
  if (!env.RATE_LIMITER) {
    return { allowed: false, reason: "RATE_LIMITER binding is missing" };
  }

  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  try {
    const result = await env.RATE_LIMITER.limit({ key: ip });
    return { allowed: Boolean(result?.success), reason: null };
  } catch (error) {
    return { allowed: false, reason: "Rate limiter binding failed" };
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = getAllowedOrigin(request, env);

    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          "Access-Control-Allow-Origin": origin,
          "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type, Authorization",
          "Access-Control-Max-Age": "86400",
          "Vary": "Origin"
        }
      });
    }

    if (origin === "null") {
      return responseJson({ ok: false, error: "Origin not allowed" }, 403, origin);
    }

    if (url.pathname === "/health" && request.method === "GET") {
      return responseJson({
        ok: true,
        service: "AI Crypto Analyst Gateway",
        mode: "FREE_PROVIDERS",
        configured: {
          gemini: Boolean(env.GEMINI_API_KEY),
          openrouter: Boolean(env.OPENROUTER_API_KEY),
          gateway: Boolean(env.GATEWAY_TOKEN),
          rateLimiter: Boolean(env.RATE_LIMITER)
        },
        models: {
          gemini: env.GEMINI_MODEL || GEMINI_DEFAULT,
          openrouter: env.OPENROUTER_MODEL || OPENROUTER_DEFAULT
        }
      }, 200, origin);
    }

    if (url.pathname === "/provider-test") {
      if (request.method !== "POST") {
        return responseJson({ ok: false, error: "Method not allowed" }, 405, origin);
      }
      if (!authorizedForProviderTest(request, env)) {
        return responseJson({ ok: false, error: "Unauthorized" }, 401, origin);
      }

      const testInput = {
        exchange: "TEST",
        symbol: "BTCUSDT",
        technicalAnalysis: {
          signal: "WAIT",
          note: "Connectivity test only. Do not produce a trade signal."
        },
        marketHistory: {
          format: "delta OHLCV; price deltas in 0.01 bps; volume ratio x100",
          "1h": {timeStart:1700000000,intervalSeconds:3600,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:3600,0,10000,-10000,5000,100])},
          "15m": {timeStart:1700000000,intervalSeconds:900,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:900,0,10000,-10000,5000,100])},
          "5m": {timeStart:1700000000,intervalSeconds:300,basePrice:100,baseVolumeMedian:10,rows:Array.from({length:60},(_,i)=>[i===0?0:300,0,10000,-10000,5000,100])}
        }
      };

      const { gemini, openrouter } = await runProviders(testInput, env);
      const ok = gemini.status === "ok" && openrouter.status === "ok";

      return responseJson({
        ok,
        test: "provider-connectivity",
        providers: { gemini, openrouter }
      }, ok ? 200 : 502, origin);
    }

    if (url.pathname !== "/analyze") {
      return responseJson({ ok: false, error: "Not found" }, 404, origin);
    }

    if (request.method !== "POST") {
      return responseJson({ ok: false, error: "Method not allowed" }, 405, origin);
    }

    const rate = await applyRateLimit(request, env);
    if (!rate.allowed) {
      return responseJson({
        ok: false,
        error: rate.reason || "Rate limit exceeded",
        code: rate.reason ? "RATE_LIMITER_UNAVAILABLE" : "RATE_LIMITED"
      }, rate.reason ? 503 : 429, origin);
    }

    if (!env.GEMINI_API_KEY && !env.OPENROUTER_API_KEY) {
      return responseJson({
        ok: false,
        error: "Neither GEMINI_API_KEY nor OPENROUTER_API_KEY is configured"
      }, 503, origin);
    }

    try {
      const input = await readRequestBody(request);
      const technical = input?.technicalAnalysis || input?.technical;
      const marketHistory = input?.marketHistory;
      const validHistory = (item) => item && typeof item === "object" &&
        Number.isFinite(Number(item.timeStart)) && Number(item.timeStart) > 0 &&
        Number.isFinite(Number(item.intervalSeconds)) && Number(item.intervalSeconds) > 0 &&
        Number.isFinite(Number(item.basePrice)) && Number(item.basePrice) > 0 &&
        Number.isFinite(Number(item.baseVolumeMedian)) && Number(item.baseVolumeMedian) >= 0 &&
        Array.isArray(item.rows) && item.rows.length >= 50 && item.rows.every((row) =>
          Array.isArray(row) && row.length === 6 && row.every((value) => Number.isFinite(Number(value))) &&
          Number(row[0]) >= 0 && Number(row[2]) >= Math.max(Number(row[1]), Number(row[4])) &&
          Number(row[3]) <= Math.min(Number(row[1]), Number(row[4])) && Number(row[2]) >= Number(row[3]) && Number(row[5]) >= 0
        );

      if (
        !input ||
        typeof input !== "object" ||
        Array.isArray(input) ||
        typeof input.exchange !== "string" ||
        typeof input.symbol !== "string" ||
        !technical ||
        typeof technical !== "object" ||
        !marketHistory || typeof marketHistory !== "object" ||
        !validHistory(marketHistory["1h"]) || !validHistory(marketHistory["15m"]) || !validHistory(marketHistory["5m"])
      ) {
        return responseJson({
          ok: false,
          error: "exchange, symbol, technicalAnalysis and valid 1h/15m/5m marketHistory are required"
        }, 400, origin);
      }

      const { gemini, openrouter } = await runProviders({
        exchange: input.exchange.slice(0, 40),
        symbol: input.symbol.slice(0, 40),
        technicalAnalysis: technical,
        marketHistory
      }, env);

      const successfulProviders = [gemini, openrouter].filter(provider => provider.status === "ok").length;
      if (successfulProviders === 0) {
        return responseJson({
          ok: false,
          decision: "WAIT",
          providers: { gemini, openrouter },
          gemini,
          openrouter,
          error: "Both AI providers failed; no independent AI assessment is available"
        }, 502, origin);
      }

      const consensus = makeConsensus(technical, gemini, openrouter);
      const partial = successfulProviders === 1;
      if (partial) {
        consensus.decision = "WAIT";
        consensus.conflicts.unshift("فقط یک مدل پاسخ معتبر داده است؛ تحلیل تک‌مدلی است و تا بازیابی هر دو مدل هیچ تصمیم اجرایی صادر نمی‌شود.");
      }

      return responseJson({
        ok: true,
        decision: consensus.decision,
        consensus,
        conflicts: consensus.conflicts,
        providers: { gemini, openrouter },
        gemini,
        openrouter,
        analysisMode: partial ? "SINGLE_PROVIDER_NON_EXECUTABLE" : "DUAL_PROVIDER",
        priceLevelsSource: "TECHNICAL_ENGINE_ONLY",
        historyCounts: {
          "1h": marketHistory["1h"].rows.length,
          "15m": marketHistory["15m"].rows.length,
          "5m": marketHistory["5m"].rows.length
        }
      }, 200, origin);

    } catch (error) {
      const message = safeError(error);
      const status =
        message === "Request body too large" ? 413 :
        message === "Invalid JSON body" ? 400 : 502;

      return responseJson({
        ok: false,
        error: message,
        decision: "WAIT"
      }, status, origin);
    }
  }
};
