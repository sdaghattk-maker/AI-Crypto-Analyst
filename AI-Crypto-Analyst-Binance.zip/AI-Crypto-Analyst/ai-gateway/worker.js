
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json; charset=utf-8"
};

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    if (new URL(request.url).pathname !== "/analyze") return json({ error: "Not found" }, 404);
    if (request.method !== "POST") return json({ error: "Method not allowed" }, 405);
    if (!env.GEMINI_API_KEY || !env.DEEPSEEK_API_KEY) {
      return json({ error: "Missing GEMINI_API_KEY or DEEPSEEK_API_KEY secret" }, 503);
    }

    try {
      const input = await request.json();
      if (!input || !input.technical || !input.symbol || !input.exchange) {
        return json({ error: "exchange, symbol and technical are required" }, 400);
      }

      const technical = input.technical;
      const prompt = [
        "You are a cautious crypto market analyst. Analyze the supplied structured technical report.",
        "Return ONLY valid JSON with keys: bias (BUY, SELL, WAIT), summary (string), risks (array of strings), confidence (integer 0-100).",
        "Do not invent market prices. Do not change or calculate entry, stop loss, or take profit. Treat the technical report as the only source of those values.",
        "If the evidence is mixed, insufficient, or conflicts with the technical signal, return WAIT.",
        "Do not treat this as a guaranteed prediction.",
        JSON.stringify({ exchange: input.exchange, symbol: input.symbol, technical })
      ].join("\n");

      const [gemini, deepseek] = await Promise.all([
        callGemini(prompt, env),
        callDeepSeek(prompt, env)
      ]);

      const technicalSignal = String(technical.signal || "wait").toUpperCase();
      const g = String(gemini.bias || "WAIT").toUpperCase();
      const d = String(deepseek.bias || "WAIT").toUpperCase();
      let decision = "WAIT";
      const conflicts = [];
      if (g !== d) conflicts.push("Gemini و DeepSeek هم‌جهت نیستند.");
      if (g !== technicalSignal || d !== technicalSignal) {
        conflicts.push("حداقل یکی از مدل‌ها با خروجی موتور تکنیکال هم‌جهت نیست.");
      }
      if (["BUY", "SELL"].includes(technicalSignal) &&
          gemini.status === "ok" && deepseek.status === "ok" &&
          Number(gemini.confidence) >= 60 && Number(deepseek.confidence) >= 60 &&
          g === d && g === technicalSignal) {
        decision = technicalSignal;
      } else if (technicalSignal === "WAIT") {
        conflicts.push("موتور تکنیکال سیگنال ورود نداده است.");
      }
      return json({ gemini, deepseek, decision, conflicts });
    } catch (error) {
      return json({ error: String(error?.message || error) }, 502);
    }
  }
};

async function callGemini(prompt, env) {
  const model = env.GEMINI_MODEL || "gemini-3.8-flash";
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.15, responseMimeType: "application/json" }
    })
  });
  const body = await response.json();
  if (!response.ok) throw new Error(`Gemini HTTP ${response.status}: ${JSON.stringify(body).slice(0, 300)}`);
  const text = body?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "";
  return normalizeModel("Gemini", text);
}

async function callDeepSeek(prompt, env) {
  const response = await fetch("https://api.deepseek.com/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${env.DEEPSEEK_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: env.DEEPSEEK_MODEL || "deepseek-flash",
      messages: [
        { role: "system", content: "Return only valid JSON: bias, summary, risks, confidence. Never invent prices." },
        { role: "user", content: prompt }
      ],
      temperature: 0.15,
      response_format: { type: "json_object" }
    })
  });
  const body = await response.json();
  if (!response.ok) throw new Error(`DeepSeek HTTP ${response.status}: ${JSON.stringify(body).slice(0, 300)}`);
  return normalizeModel("DeepSeek", body?.choices?.[0]?.message?.content || "");
}

function normalizeModel(name, raw) {
  let value;
  try {
    const cleaned = String(raw).trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
    value = JSON.parse(cleaned);
  } catch {
    return { status: "invalid_json", bias: "WAIT", summary: `${name}: پاسخ JSON قابل‌خواندن نبود.`, risks: ["پاسخ مدل قابل‌اعتبارسنجی نیست."] };
  }
  const bias = ["BUY", "SELL", "WAIT"].includes(String(value.bias).toUpperCase())
    ? String(value.bias).toUpperCase() : "WAIT";
  return {
    status: "ok",
    bias,
    summary: String(value.summary || "خلاصه‌ای ارائه نشد.").slice(0, 1200),
    risks: Array.isArray(value.risks) ? value.risks.slice(0, 8).map(x => String(x).slice(0, 300)) : [],
    confidence: Math.max(0, Math.min(100, Number(value.confidence) || 0))
  };
}

function json(value, status = 200) {
  return new Response(JSON.stringify(value), { status, headers: cors });
}
