
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../models/app_state.dart';
import '../services/market_api.dart';

class ChartScreen extends StatefulWidget {
  const ChartScreen({super.key,required this.state});
  final AppState state;
  @override State<ChartScreen> createState()=>_ChartScreenState();
}
class _ChartScreenState extends State<ChartScreen>{
  int _timeframeSeconds(String tf)=>const {'1m':60,'5m':300,'15m':900,'30m':1800,'1h':3600,'4h':14400,'1d':86400}[tf]??300;
  final MarketApi api=MarketApi();
  Timer? _refreshTimer;
  bool _requestInFlight=false;
  late final WebViewController controller;
  String status='در حال آماده‌سازی نمودار...';
  String? error;
  double? price;
  bool loading=false,webReady=false;
  int requestId=0;

  @override void initState(){
    super.initState();
    widget.state.addListener(_selectionChanged);
    _refreshTimer=Timer.periodic(const Duration(seconds:5), (_) {
      if(mounted && webReady && !_requestInFlight) _loadMarketData(silent:true);
    });
    controller=WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished:(_){
        webReady=true;
        controller.runJavaScript('window.setCandleDurationSeconds(${_timeframeSeconds(widget.state.timeframe)});');
        _loadMarketData();
      }))
      ..loadFlutterAsset('assets/chart.html');
  }
  void _selectionChanged(){
    requestId++;
    if(!mounted)return;
    if(webReady) controller.runJavaScript('window.setCandleDurationSeconds(${_timeframeSeconds(widget.state.timeframe)});');
    setState(() { price=null; error=null; status='در حال دریافت داده نماد و تایم‌فریم جدید...'; });
    if(webReady && !_requestInFlight)_loadMarketData();
  }

  Future<void> _loadMarketData({bool silent=false}) async {
    if(!webReady || _requestInFlight)return;
    _requestInFlight=true;
    final id=++requestId;
    final exchange=widget.state.exchange,symbol=widget.state.symbol,tf=widget.state.timeframe;
    try{
    if(!silent){
      setState(() {
        loading=true; error=null; price=null; status='در حال دریافت داده واقعی $exchange برای $symbol ($tf)...';
      });
      await controller.runJavaScript('window.clearMarketCandles(${jsonEncode('در حال دریافت داده $exchange...')});');
    }
      final candles=await api.getKlines(
        exchange:exchange,symbol:symbol,interval:tf,limit:silent?2:500,
      );
      if(!mounted||id!=requestId)return;
      // The latest candle close is the freshest available price during incremental updates.
      final lastPrice=silent?candles.last.close:await api.getPrice(exchange:exchange,symbol:symbol);
      if(!mounted||id!=requestId)return;
      final payload=jsonEncode(candles.map((c)=>c.toChartJson()).toList());
      final chartMethod = silent ? 'updateMarketCandles' : 'setMarketCandles';
      final accepted=await controller.runJavaScriptReturningResult('window.$chartMethod($payload)');
      if(!mounted||id!=requestId)return;
      setState((){
        price=lastPrice;loading=false;error=null;
        status=silent
          ? 'داده زنده • به‌روزرسانی خودکار هر ۵ ثانیه • ${TimeOfDay.now().format(context)}'
          : '${candles.length} کندل از $exchange • به‌روزرسانی خودکار فعال است';
        if(accepted.toString()=='false')error='نمودار داده را نپذیرفت.';
      });
    }catch(e){
      if(!mounted||id!=requestId)return;
      setState(() {
        loading=false; error=e.toString(); status=silent?'به‌روزرسانی خودکار ناموفق بود؛ تلاش بعدی انجام می‌شود.':'دریافت داده ناموفق بود.';
      });
      if(!silent) await controller.runJavaScript('window.setChartMessage(${jsonEncode(error)});');
    }finally{
      _requestInFlight=false;
      // If the user changed symbol/timeframe during a request, immediately load the new selection.
      if(mounted && id!=requestId) {
        Future<void>.microtask(() => _loadMarketData());
      }
    }
  }

  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:widget.state,
    builder:(context,_){
      final exchange=widget.state.exchange,symbol=widget.state.symbol,tf=widget.state.timeframe;
      return Column(children:[
        Padding(padding:const EdgeInsets.fromLTRB(14,14,14,8),child:Row(children:[
          Expanded(child:Text('نمودار ${exchange=='Nobitex'?'نوبیتکس':'Binance'}',style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold))),
          DropdownButton<String>(
            value:tf,items:const ['1m','5m','15m','1h','4h','1d'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),
            onChanged:(v){if(v!=null)widget.state.selectTimeframe(v);},
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal:10, vertical:6),
            decoration: BoxDecoration(
              color: const Color(0xFF163B36),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF46D6B3).withOpacity(.45)),
            ),
            child: Row(mainAxisSize:MainAxisSize.min, children:[
              Container(width:7,height:7,decoration:const BoxDecoration(color:Color(0xFF46D6B3),shape:BoxShape.circle)),
              const SizedBox(width:6),
              Text(error!=null?'اختلال':loading?'اتصال...':'زنده',style:const TextStyle(fontSize:11,color:Color(0xFF8CE5CF))),
            ]),
          ),
        ])),
        Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:4),child:Row(children:[
          Text('$symbol  •  $exchange',style:const TextStyle(color:Colors.white70)),
          const Spacer(),
          if(price!=null)Text(price!.toStringAsFixed(2),style:const TextStyle(fontWeight:FontWeight.bold,color:Color(0xFF46D6B3))),
        ])),
        Expanded(child:ClipRRect(borderRadius:BorderRadius.circular(14),child:WebViewWidget(controller:controller))),
        Padding(padding:const EdgeInsets.fromLTRB(12,8,12,12),child:Column(children:[
          Text(status,textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:error==null?Colors.white70:Colors.orangeAccent)),
          if(error!=null)TextButton(onPressed:loading?null:_loadMarketData,child:const Text('تلاش مجدد')),
        ])),
      ]);
    },
  );

  @override void dispose(){
    widget.state.removeListener(_selectionChanged);
    _refreshTimer?.cancel();
    requestId++;
    super.dispose();
  }
}
