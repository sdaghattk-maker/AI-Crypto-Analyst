
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../models/app_state.dart';
import '../services/market_api.dart';

class ChartScreen extends StatefulWidget {
  const ChartScreen({super.key,required this.state});
  final AppState state;
  @override State<ChartScreen> createState()=>_ChartScreenState();
}
class _ChartScreenState extends State<ChartScreen>{
  final MarketApi api=MarketApi();
  Timer? _refreshTimer;
  bool _requestInFlight=false;
  late final WebViewController controller;
  String status='در حال آماده‌سازی نمودار...';
  String? error;
  double? price;
  bool loading=false,webReady=false;
  int requestId=0;

  @override void initState(){
    super.initState();
    widget.state.addListener(_selectionChanged);
    _refreshTimer=Timer.periodic(const Duration(seconds:10), (_) {
      if(mounted && webReady && !_requestInFlight) _loadMarketData(silent:true);
    });
    controller=WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(onPageFinished:(_){
        webReady=true;
        _loadMarketData();
      }))
      ..loadFlutterAsset('assets/chart.html');
  }
  void _selectionChanged(){
    if(!mounted)return;
    setState(()=>price=null);
    if(webReady)_loadMarketData();
  }

  Future<void> _loadMarketData({bool silent=false}) async {
    if(!webReady || _requestInFlight)return;
    _requestInFlight=true;
    final id=++requestId;
    final exchange=widget.state.exchange,symbol=widget.state.symbol,tf=widget.state.timeframe;
    try{
    if(!silent){
      setState(() {
        loading=true; error=null; price=null; status='در حال دریافت داده واقعی $exchange برای $symbol ($tf)...';
      });
      await controller.runJavaScript('window.clearMarketCandles(${jsonEncode('در حال دریافت داده $exchange...')});');
    }
      final results=await Future.wait([
        api.getKlines(exchange:exchange,symbol:symbol,interval:tf,limit:500),
        api.getPrice(exchange:exchange,symbol:symbol),
      ]);
      if(!mounted||id!=requestId)return;
      final candles=results[0] as List<MarketCandle>;
      final lastPrice=results[1] as double;
      final payload=jsonEncode(candles.map((c)=>c.toChartJson()).toList());
      final accepted=await controller.runJavaScriptReturningResult('window.setMarketCandles($payload)');
      if(!mounted||id!=requestId)return;
      setState((){
        price=lastPrice;loading=false;error=null;
        status='${candles.length} کندل از $exchange • آخرین به‌روزرسانی: ${TimeOfDay.now().format(context)}';
        if(accepted.toString()=='false')error='نمودار داده را نپذیرفت.';
      });
    }catch(e){
      if(!mounted||id!=requestId)return;
      setState(() {
        loading=false; error=e.toString(); status=silent?'به‌روزرسانی خودکار ناموفق بود؛ تلاش بعدی انجام می‌شود.':'دریافت داده ناموفق بود.';
      });
      if(!silent) await controller.runJavaScript('window.setChartMessage(${jsonEncode(error)});');
    }finally{
      _requestInFlight=false;
    }
  }

  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:widget.state,
    builder:(context,_){
      final exchange=widget.state.exchange,symbol=widget.state.symbol,tf=widget.state.timeframe;
      return Column(children:[
        Padding(padding:const EdgeInsets.fromLTRB(14,14,14,8),child:Row(children:[
          Expanded(child:Text('نمودار ${exchange=='Nobitex'?'نوبیتکس':'Binance'}',style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold))),
          DropdownButton<String>(
            value:tf,items:const ['1m','5m','15m','1h','4h','1d'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),
            onChanged:(v){if(v!=null)widget.state.selectTimeframe(v);},
          ),
          IconButton(tooltip:'به‌روزرسانی',onPressed:loading?null:_loadMarketData,icon:loading?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.refresh)),
        ])),
        Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:4),child:Row(children:[
          Text('$symbol  •  $exchange',style:const TextStyle(color:Colors.white70)),
          const Spacer(),
          if(price!=null)Text(price!.toStringAsFixed(2),style:const TextStyle(fontWeight:FontWeight.bold,color:Color(0xFF46D6B3))),
        ])),
        Expanded(child:ClipRRect(borderRadius:BorderRadius.circular(14),child:WebViewWidget(controller:controller))),
        Padding(padding:const EdgeInsets.fromLTRB(12,8,12,12),child:Column(children:[
          Text(status,textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:error==null?Colors.white70:Colors.orangeAccent)),
          if(error!=null)TextButton(onPressed:loading?null:_loadMarketData,child:const Text('تلاش مجدد')),
        ])),
      ]);
    },
  );

  @override void dispose(){
    widget.state.removeListener(_selectionChanged);
    _refreshTimer?.cancel();
    requestId++;
    super.dispose();
  }
}
