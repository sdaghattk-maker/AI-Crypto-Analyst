import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../services/market_api.dart';

class ChartScreen extends StatefulWidget {
  const ChartScreen({super.key});

  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  final MarketApi api = MarketApi();
  late final WebViewController controller;

  String timeframe = '5m';
  String symbol = 'BTCUSDT';
  String status = 'در حال آماده‌سازی نمودار...';
  String? error;
  double? price;
  bool loading = false;
  bool webReady = false;

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) {
          webReady = true;
          _loadMarketData();
        },
      ))
      ..loadFlutterAsset('assets/chart.html');
  }

  Future<void> _loadMarketData() async {
    if (loading || !webReady) return;
    setState(() {
      loading = true;
      error = null;
      status = 'در حال دریافت کندل‌های واقعی از Binance...';
    });

    try {
      await api.ping();
      final results = await Future.wait([
        api.getKlines(symbol: symbol, interval: timeframe, limit: 500),
        api.getPrice(symbol),
      ]);
      final candles = results[0] as List<MarketCandle>;
      final lastPrice = results[1] as double;

      await controller.runJavaScript(
        'setMarketCandles(${jsonEncode(candles.map((c) => c.toChartJson()).toList())});',
      );

      if (!mounted) return;
      setState(() {
        price = lastPrice;
        status = '${candles.length} کندل بسته‌شده از Binance دریافت شد.';
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        status = 'دریافت داده ناموفق بود';
        loading = false;
      });
      if (webReady) {
        await controller.runJavaScript(
          'setChartMessage(${jsonEncode(error)});',
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
          child: Row(
            children: [
              const Expanded(
                child: Text('نمودار Binance', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              ),
              DropdownButton<String>(
                value: timeframe,
                items: const ['5m', '15m', '1h']
                    .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                    .toList(),
                onChanged: loading
                    ? null
                    : (v) {
                        if (v == null) return;
                        setState(() => timeframe = v);
                        _loadMarketData();
                      },
              ),
              IconButton(
                tooltip: 'به‌روزرسانی',
                onPressed: loading ? null : _loadMarketData,
                icon: loading
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.refresh),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Row(
            children: [
              const Text('BTCUSDT  •  Binance', style: TextStyle(color: Colors.white70)),
              const Spacer(),
              if (price != null)
                Text(
                  price!.toStringAsFixed(2),
                  style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF46D6B3)),
                ),
            ],
          ),
        ),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: WebViewWidget(controller: controller),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          child: Column(
            children: [
              Text(status, textAlign: TextAlign.center, style: TextStyle(
                fontSize: 12,
                color: error == null ? Colors.white70 : Colors.orangeAccent,
              )),
              if (error != null)
                TextButton(onPressed: loading ? null : _loadMarketData, child: const Text('تلاش مجدد')),
            ],
          ),
        ),
      ],
    );
  }
}
