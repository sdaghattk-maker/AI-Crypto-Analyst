
import 'package:flutter/material.dart';
import '../models/app_state.dart';
import '../services/analysis_controller.dart';
import '../services/technical_engine.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  static const symbols=['BTCUSDT','ETHUSDT','SOLUSDT','BNBUSDT','XRPUSDT'];

  @override
  Widget build(BuildContext context)=>AnimatedBuilder(
    animation:Listenable.merge([state,analysis]),
    builder:(context,_){
      final r=analysis.report;
      return ListView(padding:const EdgeInsets.all(18),children:[
        const SizedBox(height:8),
        const Text('AI Crypto Analyst',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
        const SizedBox(height:5),
        Text('تحلیل چندتایم‌فریمی بازار رمزارز',style:TextStyle(color:Colors.white.withValues(alpha:.65))),
        const SizedBox(height:22),
        _heading('انتخاب بازار'),
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
          DropdownButtonFormField<String>(
            value:state.exchange,
            decoration:const InputDecoration(labelText:'صرافی',border:OutlineInputBorder()),
            items:const[
              DropdownMenuItem(value:'Nobitex',child:Text('نوبیتکس')),
              DropdownMenuItem(value:'Binance',child:Text('Binance')),
            ],
            onChanged:(v){if(v!=null)state.selectExchange(v);},
          ),
          const SizedBox(height:14),
          DropdownButtonFormField<String>(
            value:state.symbol,
            decoration:const InputDecoration(labelText:'نماد',border:OutlineInputBorder()),
            items:symbols.map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(),
            onChanged:(v){if(v!=null)state.selectSymbol(v);},
          ),
          const SizedBox(height:8),
          Align(alignment:Alignment.centerRight,child:Text(
            state.exchange=='Nobitex'?'داده عمومی بازار نوبیتکس؛ بدون نیاز به توکن':'داده بازار از Binance Worker',
            style:const TextStyle(color:Colors.white60,fontSize:11),
          )),
        ]))),
        const SizedBox(height:18),
        _heading('موتور تحلیل تکنیکال'),
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[
            const Icon(Icons.analytics_outlined,color:Color(0xFF46D6B3)),
            const SizedBox(width:8),
            const Expanded(child:Text('1H Bias  →  15M Structure  →  5M Entry',style:TextStyle(fontWeight:FontWeight.bold))),
            if(analysis.loading)const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)),
          ]),
          const SizedBox(height:10),
          Text(analysis.status,style:const TextStyle(color:Colors.white70)),
          if(analysis.error!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(analysis.error!,style:const TextStyle(color:Colors.orangeAccent))),
          const SizedBox(height:12),
          SizedBox(width:double.infinity,child:FilledButton.icon(
            onPressed:analysis.loading?null:analysis.run,
            icon:const Icon(Icons.play_arrow),label:const Text('اجرای تحلیل چندتایم‌فریمی'),
          )),
          if(r!=null)...[
            const Divider(height:24),
            Row(children:[
              _signalBadge(r.state),
              const Spacer(),
              Text('امتیاز شواهد: ${r.score}/100',style:const TextStyle(fontWeight:FontWeight.w600)),
            ]),
            const SizedBox(height:12),
            _metricRow('سوگیری 1H',_biasFa(r.bias1h)),
            _metricRow('ساختار 15M',_biasFa(r.bias15m)),
            _metricRow('وضعیت 5M',_biasFa(r.bias5m)),
            _metricRow('قدرت خریدار / فروشنده','${r.buyerPower}% / ${r.sellerPower}%'),
            _metricRow('RSI 5M',r.rsi.toStringAsFixed(1)),
            _metricRow('محدوده CRT 15M','${r.rangeLow.toStringAsFixed(2)} – ${r.rangeHigh.toStringAsFixed(2)}'),
            if(r.entry!=null)...[
              const Divider(height:20),
              _metricRow('Entry',_p(r.entry)),
              _metricRow('Stop Loss',_p(r.stopLoss)),
              _metricRow('TP1 / TP2 / TP3','${_p(r.tp1)} / ${_p(r.tp2)} / ${_p(r.tp3)}'),
            ],
            ...r.reasons.map((x)=>_bullet(x,Colors.greenAccent)),
            ...r.warnings.map((x)=>_bullet(x,Colors.orangeAccent)),
          ],
        ]))),
        const SizedBox(height:18),
        _heading('مرحله هوش مصنوعی'),
        const _StepTile(number:'01',title:'Technical Engine',subtitle:'محاسبه مستقل داده، روند، نقدینگی، ساختار و سطوح معاملاتی'),
        const _StepTile(number:'02',title:'Gemini + DeepSeek',subtitle:'دو تحلیل مستقل از طریق درگاه امن سمت سرور'),
        const _StepTile(number:'03',title:'AI Coordinator',subtitle:'مقایسه شواهد؛ اختلاف مدل‌ها یا داده ناکافی = WAIT'),
      ]);
    },
  );

  static Widget _heading(String s)=>Padding(padding:const EdgeInsets.only(bottom:9),child:Text(s,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w700)));
  static Widget _metricRow(String a,String b)=>Padding(padding:const EdgeInsets.symmetric(vertical:4),child:Row(children:[Expanded(child:Text(a,style:const TextStyle(color:Colors.white60))),Flexible(child:Text(b,textAlign:TextAlign.end,style:const TextStyle(fontWeight:FontWeight.w600)))]));
  static String _biasFa(TradeBias b)=>switch(b){TradeBias.bullish=>'صعودی',TradeBias.bearish=>'نزولی',TradeBias.neutral=>'خنثی'};
  static String _p(double? v)=>v==null?'—':v.toStringAsFixed(2);
  static Widget _signalBadge(SignalState s){
    final color=s==SignalState.buy?Colors.green:s==SignalState.sell?Colors.red:Colors.amber;
    final label=s==SignalState.buy?'BUY':s==SignalState.sell?'SELL':'WAIT';
    return Container(padding:const EdgeInsets.symmetric(horizontal:14,vertical:7),decoration:BoxDecoration(color:color.withValues(alpha:.15),borderRadius:BorderRadius.circular(20)),child:Text(label,style:TextStyle(color:color,fontWeight:FontWeight.bold)));
  }
  static Widget _bullet(String s,Color c)=>Padding(padding:const EdgeInsets.only(top:6),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(Icons.circle,size:6,color:c),const SizedBox(width:8),Expanded(child:Text(s,style:const TextStyle(fontSize:12,color:Colors.white70)))]));
}
class _StepTile extends StatelessWidget{
  const _StepTile({required this.number,required this.title,required this.subtitle});
  final String number,title,subtitle;
  @override Widget build(BuildContext context)=>Card(child:ListTile(
    leading:CircleAvatar(backgroundColor:const Color(0xFF24443F),child:Text(number,style:const TextStyle(fontSize:12))),
    title:Text(title,style:const TextStyle(fontWeight:FontWeight.w600)),subtitle:Text(subtitle),
  ));
}
