
import 'package:flutter/material.dart';
import '../models/app_state.dart';
import '../services/analysis_controller.dart';
import '../services/ai_service.dart';

class AiAnalysisScreen extends StatefulWidget{
  const AiAnalysisScreen({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  @override State<AiAnalysisScreen> createState()=>_AiAnalysisScreenState();
}
class _AiAnalysisScreenState extends State<AiAnalysisScreen>{
  final AiService ai=AiService();
  bool aiLoading=false;
  String status='برای شروع، ابتدا تحلیل تکنیکال سه تایم‌فریم اجرا می‌شود.';
  String? error;
  AiConsensus? get consensus => widget.analysis.consensus;

  Future<void> _runFullAnalysis() async{
    final requestedExchange=widget.state.exchange;
    final requestedSymbol=widget.state.symbol;
    setState(() {
      aiLoading=true; error=null; status='در حال اجرای موتور تکنیکال...';
    });
    final completed = await widget.analysis.run();
    if(!mounted)return;
    if(!completed){
      setState(() { aiLoading=false; error=widget.analysis.error??'تحلیل جدید تکمیل نشد؛ تحلیل قبلی حفظ شده است.'; status='درخواست AI ارسال نشد تا تحلیل قدیمی به‌اشتباه دوباره پردازش نشود.'; });
      return;
    }
    final report=widget.analysis.report;
    if(report==null){
      setState(() {
        aiLoading=false; error=widget.analysis.error??'تحلیل تکنیکال انجام نشد.'; status='تحلیل AI متوقف شد.';
      });
      return;
    }
    if(!ai.isConfigured){
      setState(() {
        aiLoading=false; status='موتور تکنیکال آماده است؛ اتصال Gemini و OpenRouter در انتظار تنظیم AI Gateway است.';
      });
      return;
    }
    setState(() { status='ارسال تاریخچه واقعی کندل‌ها و گزارش مستقل موتور به Gemini و OpenRouter...'; });
    try{
      final result=await ai.analyze(
        report, exchange:requestedExchange, symbol:requestedSymbol,
        history1h:widget.analysis.history1h,
        history15m:widget.analysis.history15m,
        history5m:widget.analysis.history5m,
      );
      if(!mounted)return;
      if(widget.state.exchange!=requestedExchange || widget.state.symbol!=requestedSymbol || widget.analysis.report!=report){
        setState(() { aiLoading=false; status='بازار هنگام تحلیل تغییر کرد؛ نتیجه قبلی کنار گذاشته شد.'; });
        return;
      }
      await widget.analysis.saveConsensus(result);
      if(!mounted)return;
      setState(() {
        aiLoading=false; status='پاسخ مدل‌ها دریافت و ذخیره شد.';
      });
    }catch(e){
      if(!mounted)return;
      setState(() {
        aiLoading=false; error=e.toString(); status='ارتباط با AI Gateway ناموفق بود.';
      });
    }
  }

  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:Listenable.merge([widget.state,widget.analysis]),
    builder:(context,_){
      final report=widget.analysis.report;
      return ListView(padding:const EdgeInsets.all(18),children:[
        const SizedBox(height:8),
        const Text('گزارش تحلیل AI',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        Text('${widget.state.symbol} • ${widget.state.exchange}',style:const TextStyle(color:Colors.white60)),
        const SizedBox(height:8),
        if(widget.analysis.report!=null) Card(child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[
          Icon(widget.analysis.isStale?Icons.warning_amber_rounded:Icons.check_circle_outline,
            color:widget.analysis.isStale?Colors.orangeAccent:const Color(0xFF46D6B3)),
          const SizedBox(width:8),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(widget.analysis.isStale?'تحلیل ذخیره‌شده قدیمی است':'آخرین تحلیل ذخیره و بازیابی شده',style:const TextStyle(fontWeight:FontWeight.bold)),
            Text('زمان تحلیل: ${widget.analysis.technicalAt?.toLocal().toString().substring(0,16) ?? '—'}',style:const TextStyle(fontSize:11,color:Colors.white60)),
            if(widget.analysis.technicalAt!=null) Text('سن تحلیل: ${_age(widget.analysis.technicalAt!)}',style:const TextStyle(fontSize:11,color:Colors.white60)),
            if(widget.analysis.aiAt!=null) Text('پاسخ AI: ${widget.analysis.aiAt!.toLocal().toString().substring(0,16)}',style:const TextStyle(fontSize:11,color:Colors.white60)),
            Text('تاریخچه کندل بسته‌شده: 1H ${widget.analysis.historyCount1h} • 15M ${widget.analysis.historyCount15m} • 5M ${widget.analysis.historyCount5m}',style:const TextStyle(fontSize:11,color:Colors.white60)),
          ])),
          Text(widget.analysis.isStale?'قدیمی':'تازه',style:TextStyle(color:widget.analysis.isStale?Colors.orangeAccent:const Color(0xFF46D6B3))),
        ]))),
        const SizedBox(height:14),
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('اجرای تحلیل کامل',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),
          const Text('تاریخچه کامل کندل‌های بسته‌شده 1H، 15M و 5M مستقیماً و مستقل برای هر دو مدل ارسال می‌شود؛ گزارش موتور تکنیکال فقط مرجع مقایسه است. POIهای AI فقط از توافق مستقل دو مدل رسم می‌شوند؛ Entry/SL/TP همچنان فقط از موتور تکنیکال می‌آیند و در حالت منبع AI جایگزین یا کپی نمی‌شوند.'),
          const SizedBox(height:12),
          SizedBox(width:double.infinity,child:FilledButton.icon(
            onPressed:aiLoading?null:_runFullAnalysis,
            icon:aiLoading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.psychology),
            label:Text(aiLoading?'در حال تحلیل...':'اجرای موتور + Gemini + OpenRouter'),
          )),
          const SizedBox(height:8),
          Text(status,style:const TextStyle(color:Colors.white70,fontSize:12)),
          if(widget.analysis.restoring) const Padding(padding:EdgeInsets.only(top:6),child:LinearProgressIndicator()),
          if(error!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(error!,style:const TextStyle(color:Colors.orangeAccent))),
        ]))),
        if(report!=null)...[
          _section('گزارش فنی مبنا'),
          Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('سیگنال تکنیکال: ${report.state.name.toUpperCase()}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
            Text('سوگیری 1H: ${report.bias1h.name} | 15M: ${report.bias15m.name} | 5M: ${report.bias5m.name}'),
            const SizedBox(height:8),
            Text('برآورد قدرت کندلی خریدار ${report.buyerPower}% • فروشنده ${report.sellerPower}%'),
            if(report.entry!=null)Text('Entry ${_p(report.entry)} | SL ${_p(report.stopLoss)} | TP ${_p(report.tp1)} / ${_p(report.tp2)} / ${_p(report.tp3)}'),
            ...report.reasons.map((x)=>Text('• $x')),
            if(report.poiSummary.isNotEmpty)const Padding(padding:EdgeInsets.only(top:10),child:Text('ساختار و نواحی مهم بازار',style:TextStyle(fontWeight:FontWeight.bold))),
            ...report.poiSummary.map((x)=>Text('• $x',style:const TextStyle(color:Color(0xFF8CE5CF)))),
            ...report.warnings.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent))),
          ]))),
        ],
        _section('وضعیت مدل‌ها'),
        _modelCard('Gemini','تحلیل مستقل تاریخچه 1H/15M/5M و سناریوها',consensus?.gemini),
        _modelCard('OpenRouter','تحلیل مستقل همان تاریخچه؛ مقایسه جداگانه با Gemini',consensus?.openrouter),
        if(consensus!=null)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('نتیجه هماهنگ‌کننده',style:TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
          const SizedBox(height:8),
          Text(consensus!.decision.toUpperCase(),style:TextStyle(fontSize:24,fontWeight:FontWeight.bold,color:consensus!.decision.toUpperCase()=='WAIT'?Colors.amber:const Color(0xFF46D6B3))),
          ...consensus!.conflicts.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent))),
        ]))),
        if(!ai.isConfigured)Card(child:Padding(padding:const EdgeInsets.all(14),child:const Text(
          'اتصال واقعی Gemini و OpenRouter هنوز فعال نیست: آدرس AI Gateway باید در GitHub Actions با Secret به نام AI_GATEWAY_BASE_URL تنظیم شود و کلیدهای هر دو سرویس فقط به‌صورت Secret در Cloudflare Worker قرار گیرند. قرار دادن کلید API داخل APK ناامن است.',
          style:TextStyle(color:Colors.amber),
        ))),
        const SizedBox(height:12),
        const Text('سیاست ایمنی: هر مدل تاریخچه کندل‌ها را مستقل تحلیل می‌کند؛ POIهای AI فقط در صورت توافق هر دو مدل نمایش داده می‌شوند. قیمت ورود، حد ضرر و اهداف فقط از موتور تکنیکال گرفته می‌شوند. اختلاف مدل‌ها یا نبود تأیید ساختاری معتبر، تصمیم اجرایی را WAIT می‌کند.'),
      ]);
    },
  );

  Widget _section(String s)=>Padding(padding:const EdgeInsets.only(top:18,bottom:8),child:Text(s,style:const TextStyle(fontSize:16,fontWeight:FontWeight.bold)));
  Widget _modelCard(String name,String role,AiModelResult? result)=>Card(child:Padding(
    padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[const Icon(Icons.memory,size:19),const SizedBox(width:8),Expanded(child:Text(name,style:const TextStyle(fontWeight:FontWeight.bold))),
        Text(result?.status??(ai.isConfigured?'آماده':'تنظیم نشده'),style:const TextStyle(color:Colors.amber,fontSize:10))]),
      const SizedBox(height:8),
      Text(result?.bias==null?role:'سوگیری مستقل: ${result!.bias} • اطمینان ${result!.confidence}%',style:const TextStyle(color:Color(0xFF8CE5CF))),
      if((result?.error??'').isNotEmpty)Padding(padding:const EdgeInsets.only(top:6),child:Text('خطای ارائه‌دهنده: ${result!.error}',style:const TextStyle(color:Colors.orangeAccent,fontSize:12))),
      if((result?.summary??'').isNotEmpty)Padding(padding:const EdgeInsets.only(top:6),child:Text(result!.summary!)),
      if(result?.observations.isNotEmpty==true)...[const Padding(padding:EdgeInsets.only(top:8),child:Text('شواهد مشاهده‌شده',style:TextStyle(fontWeight:FontWeight.bold))),...result!.observations.map((x)=>Text('• $x'))],
      if(result?.risks.isNotEmpty==true)...[const Padding(padding:EdgeInsets.only(top:8),child:Text('ریسک‌ها',style:TextStyle(fontWeight:FontWeight.bold,color:Colors.orangeAccent))),...result!.risks.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent)))],
    ])));
  String _p(double? x)=>x==null?'—':x.toStringAsFixed(2);
  String _age(DateTime value){final d=DateTime.now().difference(value);if(d.inDays>0)return '${d.inDays} روز و ${d.inHours%24} ساعت';if(d.inHours>0)return '${d.inHours} ساعت و ${d.inMinutes%60} دقیقه';return '${d.inMinutes} دقیقه';}
}
