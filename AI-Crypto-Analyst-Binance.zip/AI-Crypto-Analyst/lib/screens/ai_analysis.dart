
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import '../services/analysis_controller.dart';
import '../services/ai_service.dart';

class AiAnalysisScreen extends StatefulWidget{
  const AiAnalysisScreen({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  @override State<AiAnalysisScreen> createState()=>_AiAnalysisScreenState();
}
class _AiAnalysisScreenState extends State<AiAnalysisScreen>{
  final AiService ai=AiService();
  bool aiLoading=false;
  String status='برای شروع، ابتدا تحلیل تکنیکال سه تایم‌فریم اجرا می‌شود.';
  String? error;
  final Map<String, TextEditingController> _modelControllers = {
    'gemini': TextEditingController(text: 'gemini-3.5-flash-lite'),
    'openrouter': TextEditingController(text: 'openrouter/free'),
    'groq': TextEditingController(text: 'openai/gpt-oss-120b'),
  };
  final Map<String, TextEditingController> _fallbackControllers = {
    'gemini': TextEditingController(text: 'gemini-3.8-flash'),
    'openrouter': TextEditingController(text: 'inclusionai/ling-3.2-flash:free'),
    'groq': TextEditingController(text: 'openai/gpt-oss-20b'),
  };
  final Map<String, bool> _providerEnabled = {'gemini': true, 'openrouter': true, 'groq': false};
  bool _settingsLoaded = false;
  final Map<String,List<String>> _availableModels = {};
  String? _catalogError;
  AiConsensus? get consensus => widget.analysis.consensus;

  @override void initState(){ super.initState(); _loadAiSettings(); _loadModelCatalog(); }
  @override void dispose(){ for(final c in _modelControllers.values){c.dispose();} for(final c in _fallbackControllers.values){c.dispose();} super.dispose(); }
  Future<void> _loadAiSettings() async {
    final prefs=await SharedPreferences.getInstance();
    if(!mounted)return;
    setState((){
      for(final key in _modelControllers.keys){
        _modelControllers[key]!.text=prefs.getString('ai_model_$key')??_modelControllers[key]!.text;
        _fallbackControllers[key]!.text=prefs.getString('ai_fallback_model_$key')??_fallbackControllers[key]!.text;
        _providerEnabled[key]=prefs.getBool('ai_provider_$key')??(_providerEnabled[key]??true);
      }
      _settingsLoaded=true;
    });
  }
  Future<void> _loadModelCatalog() async {
    try { final models=await ai.fetchModelCatalog(); if(!mounted)return; setState((){_availableModels.addAll(models);_catalogError=null;}); }
    catch(e){ if(!mounted)return; setState(()=>_catalogError=e.toString()); }
  }
  Future<void> _saveAiSettings() async {
    final prefs=await SharedPreferences.getInstance();
    for(final key in _modelControllers.keys){
      final model=_modelControllers[key]!.text.trim();
      if(model.isNotEmpty) await prefs.setString('ai_model_$key',model);
      final fallback=_fallbackControllers[key]!.text.trim();
      if(fallback.isNotEmpty) await prefs.setString('ai_fallback_model_$key',fallback);
      await prefs.setBool('ai_provider_$key',_providerEnabled[key]??false);
    }
  }

  Future<void> _runFullAnalysis() async{
    final requestedExchange=widget.state.exchange;
    final requestedSymbol=widget.state.symbol;
    setState(() {
      aiLoading=true; error=null; status='در حال اجرای موتور تکنیکال...';
    });
    final completed = await widget.analysis.run();
    if(!mounted)return;
    if(!completed){
      setState(() { aiLoading=false; error=widget.analysis.error??'تحلیل جدید تکمیل نشد؛ تحلیل قبلی حفظ شده است.'; status='درخواست AI ارسال نشد تا تحلیل قدیمی به‌اشتباه دوباره پردازش نشود.'; });
      return;
    }
    final report=widget.analysis.report;
    if(report==null){
      setState(() {
        aiLoading=false; error=widget.analysis.error??'تحلیل تکنیکال انجام نشد.'; status='تحلیل AI متوقف شد.';
      });
      return;
    }
    if(!ai.isConfigured){
      setState(() {
        aiLoading=false; status='موتور تکنیکال آماده است؛ اتصال AI Gateway در انتظار تنظیم است.';
      });
      return;
    }
    await _saveAiSettings();
    final selectedProviders=_providerEnabled.entries.where((e)=>e.value).map((e)=>e.key).toList();
    if(selectedProviders.isEmpty){setState((){aiLoading=false;error='حداقل یک ارائه‌دهنده را انتخاب کنید.';});return;}
    final selectedModels={for(final e in _modelControllers.entries)e.key:e.value.text.trim()};
    final selectedFallbacks={for(final e in _fallbackControllers.entries)e.key:e.value.text.trim()};
    setState(() { status='ارسال Snapshot ذخیره‌شده کندل‌ها به مدل‌های انتخاب‌شده به‌صورت مستقل...'; });
    try{
      final result=await ai.analyze(
        exchange:requestedExchange, symbol:requestedSymbol,
        history1h:widget.analysis.history1h,
        history15m:widget.analysis.history15m,
        history5m:widget.analysis.history5m,
        modelSelection:selectedModels,
        fallbackSelection:selectedFallbacks,
        selectedProviders:selectedProviders,
        snapshotId:widget.analysis.snapshotId,
      );
      if(!mounted)return;
      if(widget.state.exchange!=requestedExchange || widget.state.symbol!=requestedSymbol || widget.analysis.report!=report){
        setState(() { aiLoading=false; status='بازار هنگام تحلیل تغییر کرد؛ نتیجه قبلی کنار گذاشته شد.'; });
        return;
      }
      await widget.analysis.saveConsensus(result);
      if(!mounted)return;
      setState(() {
        aiLoading=false; status='پاسخ مدل‌ها دریافت و ذخیره شد.';
      });
    }catch(e){
      if(!mounted)return;
      setState(() {
        aiLoading=false; error=e.toString(); status='ارتباط با AI Gateway ناموفق بود.';
      });
    }
  }

  @override Widget build(BuildContext context)=>AnimatedBuilder(
    animation:Listenable.merge([widget.state,widget.analysis]),
    builder:(context,_){
      final report=widget.analysis.report;
      return ListView(padding:const EdgeInsets.all(18),children:[
        const SizedBox(height:8),
        const Text('گزارش تحلیل AI',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        Text('${widget.state.symbol} • ${widget.state.exchange}',style:const TextStyle(color:Colors.white60)),
        const SizedBox(height:8),
        if(widget.analysis.report!=null) Card(child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[
          Icon(widget.analysis.isStale?Icons.warning_amber_rounded:Icons.check_circle_outline,
            color:widget.analysis.isStale?Colors.orangeAccent:const Color(0xFF46D6B3)),
          const SizedBox(width:8),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(widget.analysis.isStale?'تحلیل ذخیره‌شده قدیمی است':'آخرین تحلیل ذخیره و بازیابی شده',style:const TextStyle(fontWeight:FontWeight.bold)),
            Text('زمان تحلیل: ${widget.analysis.technicalAt?.toLocal().toString().substring(0,16) ?? '—'}',style:const TextStyle(fontSize:11,color:Colors.white60)),
            if(widget.analysis.technicalAt!=null) Text('سن تحلیل: ${_age(widget.analysis.technicalAt!)}',style:const TextStyle(fontSize:11,color:Colors.white60)),
            if(widget.analysis.aiAt!=null) Text('پاسخ AI: ${widget.analysis.aiAt!.toLocal().toString().substring(0,16)} • ${widget.analysis.isAiStale ? 'قدیمی' : 'تازه'}',style:TextStyle(fontSize:11,color:widget.analysis.isAiStale?Colors.orangeAccent:Colors.white60)),
            Text('تاریخچه کندل بسته‌شده: 1H ${widget.analysis.historyCount1h} • 15M ${widget.analysis.historyCount15m} • 5M ${widget.analysis.historyCount5m}',style:const TextStyle(fontSize:11,color:Colors.white60)),
          ])),
          Text(widget.analysis.isStale?'قدیمی':'تازه',style:TextStyle(color:widget.analysis.isStale?Colors.orangeAccent:const Color(0xFF46D6B3))),
        ]))),
        const SizedBox(height:14),
        Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('اجرای تحلیل کامل',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),
          const Text('کندل‌های بسته‌شده 1H، 15M و 5M پس از ذخیره در یک Snapshot ثابت، مستقل برای هر مدل ارسال می‌شوند. پاسخ هر مدل جداگانه نگهداری می‌شود. تحلیل تکنیکال مستقل باقی می‌ماند و منبع رسم چارت طبق انتخاب شما فقط تکنیکال یا AI است.'),
          const SizedBox(height:10),
          if(!_settingsLoaded) const LinearProgressIndicator(),
          ..._modelControllers.entries.map((entry)=>_modelSetting(entry.key,entry.value,_fallbackControllers[entry.key]!)),
          if(_catalogError!=null) Padding(padding:const EdgeInsets.only(top:4),child:Text('فهرست مدل‌ها دریافت نشد؛ شناسه را دستی وارد کنید. $_catalogError',style:const TextStyle(fontSize:11,color:Colors.orangeAccent))),
          Align(alignment:Alignment.centerLeft,child:TextButton.icon(onPressed:_loadModelCatalog,icon:const Icon(Icons.refresh,size:16),label:const Text('به‌روزرسانی فهرست مدل‌های مجاز'))),
          const SizedBox(height:12),
          SizedBox(width:double.infinity,child:FilledButton.icon(
            onPressed:aiLoading?null:_runFullAnalysis,
            icon:aiLoading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.psychology),
            label:Text(aiLoading?'در حال تحلیل...':'اجرای تحلیل با مدل‌های انتخاب‌شده'),
          )),
          const SizedBox(height:8),
          Text(status,style:const TextStyle(color:Colors.white70,fontSize:12)),
          if(widget.analysis.restoring) const Padding(padding:EdgeInsets.only(top:6),child:LinearProgressIndicator()),
          if(error!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(error!,style:const TextStyle(color:Colors.orangeAccent))),
        ]))),
        if(report!=null)...[
          _section('گزارش فنی مبنا'),
          Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text('سیگنال تکنیکال: ${report.state.name.toUpperCase()}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
            Text('سوگیری 1H: ${report.bias1h.name} | 15M: ${report.bias15m.name} | 5M: ${report.bias5m.name}'),
            const SizedBox(height:8),
            Text('برآورد قدرت کندلی خریدار ${report.buyerPower}% • فروشنده ${report.sellerPower}%'),
            if(report.entry!=null)Text('Entry ${_p(report.entry)} | SL ${_p(report.stopLoss)} | TP ${_p(report.tp1)} / ${_p(report.tp2)} / ${_p(report.tp3)}'),
            ...report.reasons.map((x)=>Text('• $x')),
            if(report.poiSummary.isNotEmpty)const Padding(padding:EdgeInsets.only(top:10),child:Text('ساختار و نواحی مهم بازار',style:TextStyle(fontWeight:FontWeight.bold))),
            ...report.poiSummary.map((x)=>Text('• $x',style:const TextStyle(color:Color(0xFF8CE5CF)))),
            ...report.warnings.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent))),
          ]))),
        ],
        _section('وضعیت مدل‌ها'),
        _modelCard('Gemini','تحلیل مستقل تاریخچه 1H/15M/5M و سناریوها',consensus?.gemini),
        _modelCard('OpenRouter','تحلیل مستقل همان Snapshot',consensus?.openrouter),
        _modelCard('Groq','تحلیل مستقل همان Snapshot',consensus?.groq),
        if(consensus?.snapshotId!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text('شناسه Snapshot: ${consensus!.snapshotId}',style:const TextStyle(fontSize:10,color:Colors.white38))),
        if(consensus!=null)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('اجماع مستقل مدل‌های هوش مصنوعی',style:TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
          const SizedBox(height:8),
          Text(consensus!.decision.toUpperCase(),style:TextStyle(fontSize:24,fontWeight:FontWeight.bold,color:consensus!.decision.toUpperCase()=='WAIT'?Colors.amber:const Color(0xFF46D6B3))),
          ...consensus!.conflicts.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent))),
        ]))),
        if(!ai.isConfigured)Card(child:Padding(padding:const EdgeInsets.all(14),child:const Text(
          'اتصال AI Gateway فعال نیست: آدرس Worker باید در GitHub Actions با Secret به نام AI_GATEWAY_BASE_URL تنظیم شود و کلیدهای Gemini، Groq و OpenRouter فقط به‌صورت Secret در Cloudflare نگهداری شوند. کلید API نباید داخل APK قرار گیرد.',
          style:TextStyle(color:Colors.amber),
        ))),
        const SizedBox(height:12),
        const Text('سیاست ایمنی: هر مدل تاریخچه کندل‌ها را مستقل تحلیل می‌کند؛ POIهای AI فقط در صورت توافق هر دو مدل نمایش داده می‌شوند. قیمت ورود، حد ضرر و اهداف فقط از موتور تکنیکال گرفته می‌شوند. اختلاف مدل‌ها یا نبود تأیید ساختاری معتبر، تصمیم اجرایی را WAIT می‌کند.'),
      ]);
    },
  );

  Widget _modelSetting(String key,TextEditingController controller,TextEditingController fallbackController){
    final labels={'gemini':'Google Gemini','openrouter':'OpenRouter','groq':'Groq'};
    final models=_availableModels[key]??const <String>[];
    return Card(color:const Color(0xFF10182A),child:Padding(padding:const EdgeInsets.all(10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      SwitchListTile(contentPadding:EdgeInsets.zero,dense:true,title:Text(labels[key]??key),value:_providerEnabled[key]??false,onChanged:(v)=>setState(()=>_providerEnabled[key]=v)),
      if(models.isNotEmpty) DropdownButtonFormField<String>(value:models.contains(controller.text)?controller.text:null,decoration:const InputDecoration(labelText:'انتخاب از مدل‌های مجاز Worker',isDense:true,border:OutlineInputBorder()),items:models.map((m)=>DropdownMenuItem(value:m,child:Text(m,textDirection:TextDirection.ltr,overflow:TextOverflow.ellipsis))).toList(),onChanged:(_providerEnabled[key]??false)?(v){if(v!=null)setState(()=>controller.text=v);}:null),
      const SizedBox(height:8),
      TextField(controller:controller,enabled:_providerEnabled[key]??false,decoration:const InputDecoration(labelText:'مدل اصلی (ورود دستی)',hintText:'Primary Model ID',isDense:true,border:OutlineInputBorder()),textDirection:TextDirection.ltr),
      const SizedBox(height:8),
      if(models.isNotEmpty) DropdownButtonFormField<String>(value:models.contains(fallbackController.text)?fallbackController.text:null,decoration:const InputDecoration(labelText:'مدل جایگزین از فهرست مجاز',isDense:true,border:OutlineInputBorder()),items:models.map((m)=>DropdownMenuItem(value:m,child:Text(m,textDirection:TextDirection.ltr,overflow:TextOverflow.ellipsis))).toList(),onChanged:(_providerEnabled[key]??false)?(v){if(v!=null)setState(()=>fallbackController.text=v);}:null),
      TextField(controller:fallbackController,enabled:_providerEnabled[key]??false,decoration:const InputDecoration(labelText:'مدل جایگزین (ورود دستی)',hintText:'Fallback Model ID',isDense:true,border:OutlineInputBorder()),textDirection:TextDirection.ltr),
    ])));
  }
  Widget _section(String s)=>Padding(padding:const EdgeInsets.only(top:18,bottom:8),child:Text(s,style:const TextStyle(fontSize:16,fontWeight:FontWeight.bold)));
  Widget _modelCard(String name,String role,AiModelResult? result)=>Card(child:Padding(
    padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[const Icon(Icons.memory,size:19),const SizedBox(width:8),Expanded(child:Text(name,style:const TextStyle(fontWeight:FontWeight.bold))),
        Text(result?.status??(ai.isConfigured?'آماده':'تنظیم نشده'),style:const TextStyle(color:Colors.amber,fontSize:10))]),
      const SizedBox(height:8),
      if(result?.bias!=null) Row(children:[
        Chip(label:Text(result!.bias!),backgroundColor:result!.bias=='BUY'?const Color(0x3322C99A):result!.bias=='SELL'?const Color(0x33F05D6C):const Color(0x33E5B84B)),
        const SizedBox(width:8),Text('اطمینان ${result!.confidence}%',style:const TextStyle(color:Color(0xFF8CE5CF))),
      ]) else Text(role,style:const TextStyle(color:Color(0xFF8CE5CF))),
      if(result?.bias!=null) Padding(padding:const EdgeInsets.only(top:3,bottom:5),child:LinearProgressIndicator(value:result!.confidence/100,minHeight:5)),
      if((result?.providerModel??'').isNotEmpty)Padding(padding:const EdgeInsets.only(top:5),child:Text('مدل واقعی: ${result!.providerModel}',style:const TextStyle(fontSize:11,color:Colors.white54))),
      if(result?.fallbackUsed==true)Padding(padding:const EdgeInsets.only(top:3),child:Text('مدل جایگزین استفاده شد: ${result!.attemptedModels.join(' ← ')}',style:const TextStyle(fontSize:11,color:Colors.orangeAccent))),
      if(result?.responseTimeMs!=null)Padding(padding:const EdgeInsets.only(top:3),child:Text('زمان پاسخ: ${(result!.responseTimeMs!/1000).toStringAsFixed(1)} ثانیه',style:const TextStyle(fontSize:11,color:Colors.white54))),
      if(result?.finishReason!=null)Padding(padding:const EdgeInsets.only(top:3),child:Text('پایان پاسخ: ${result!.finishReason}${result!.nativeFinishReason==null?'':' • ${result!.nativeFinishReason}'}',style:const TextStyle(fontSize:11,color:Colors.white54))),
      if(result?.completionTokens!=null)Padding(padding:const EdgeInsets.only(top:3),child:Text('توکن خروجی: ${result!.completionTokens}${result!.reasoningTokens==null?'':' • استدلال: ${result!.reasoningTokens}'}',style:const TextStyle(fontSize:11,color:Colors.white54))),
      if((result?.error??'').isNotEmpty)Padding(padding:const EdgeInsets.only(top:6),child:Text('خطای ارائه‌دهنده: ${result!.error}',style:const TextStyle(color:Colors.orangeAccent,fontSize:12))),
      if((result?.summary??'').isNotEmpty)Padding(padding:const EdgeInsets.only(top:6),child:Text(result!.summary!)),
      if((result?.rawText??'').isNotEmpty)Padding(padding:const EdgeInsets.only(top:8),child:Container(width:double.infinity,padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFF0B1020),borderRadius:BorderRadius.circular(10)),child:SelectableText(result!.rawText!,textDirection:TextDirection.rtl,style:const TextStyle(fontSize:12)))),
      if(result?.observations.isNotEmpty==true)...[const Padding(padding:EdgeInsets.only(top:8),child:Text('شواهد مشاهده‌شده',style:TextStyle(fontWeight:FontWeight.bold))),...result!.observations.map((x)=>Text('• $x'))],
      if(result?.risks.isNotEmpty==true)...[const Padding(padding:EdgeInsets.only(top:8),child:Text('ریسک‌ها',style:TextStyle(fontWeight:FontWeight.bold,color:Colors.orangeAccent))),...result!.risks.map((x)=>Text('• $x',style:const TextStyle(color:Colors.orangeAccent)))],
    ])));
  String _p(double? x)=>x==null?'—':x.toStringAsFixed(2);
  String _age(DateTime value){final d=DateTime.now().difference(value);if(d.inDays>0)return '${d.inDays} روز و ${d.inHours%24} ساعت';if(d.inHours>0)return '${d.inHours} ساعت و ${d.inMinutes%60} دقیقه';return '${d.inMinutes} دقیقه';}
}
