
import 'package:flutter/material.dart';
import 'models/app_state.dart';
import 'services/analysis_controller.dart';
import 'screens/dashboard.dart';
import 'screens/chart_screen.dart';
import 'screens/ai_analysis.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  final state=AppState();
  final analysis=AnalysisController(state);
  state.addListener(analysis.invalidate);
  runApp(CryptoAnalystApp(state:state,analysis:analysis));
}

class CryptoAnalystApp extends StatelessWidget {
  const CryptoAnalystApp({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;

  @override
  Widget build(BuildContext context) {
    const bg=Color(0xFF0B1020);
    return MaterialApp(
      debugShowCheckedModeBanner:false,title:'AI Crypto Analyst',
      // The app UI is Persian-first. Keep the whole Flutter widget tree RTL;
      // Flutter's bidi algorithm will still render Latin symbols and numbers correctly.
      builder:(context,child)=>Directionality(
        textDirection:TextDirection.rtl,
        child:child??const SizedBox.shrink(),
      ),
      theme:ThemeData(
        brightness:Brightness.dark,scaffoldBackgroundColor:bg,
        colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFF46D6B3),brightness:Brightness.dark,surface:const Color(0xFF151D31)),
        useMaterial3:true,
        cardTheme:CardThemeData(color:const Color(0xFF151D31),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18))),
      ),
      home:AppShell(state:state,analysis:analysis),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key,required this.state,required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  @override State<AppShell> createState()=>_AppShellState();
}
class _AppShellState extends State<AppShell>{
  int index=0;
  @override
  Widget build(BuildContext context)=>Scaffold(
    body:SafeArea(child:IndexedStack(index:index,children:[
      DashboardScreen(state:widget.state,analysis:widget.analysis),
      ChartScreen(state:widget.state),
      AiAnalysisScreen(state:widget.state,analysis:widget.analysis),
    ])),
    bottomNavigationBar:NavigationBar(
      selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'بازار'),
        NavigationDestination(icon:Icon(Icons.candlestick_chart_outlined),selectedIcon:Icon(Icons.candlestick_chart),label:'نمودار'),
        NavigationDestination(icon:Icon(Icons.psychology_outlined),selectedIcon:Icon(Icons.psychology),label:'تحلیل AI'),
      ],
    ),
  );
}
