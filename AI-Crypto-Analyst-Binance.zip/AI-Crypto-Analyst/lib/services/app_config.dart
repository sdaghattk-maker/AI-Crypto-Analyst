
class AppConfig {
  static const String binanceWorkerBaseUrl =
      'https://hrs-binance-proxy.sdaghat-tk.workers.dev';
  // Set this to the HTTPS URL of the AI gateway Worker. Never put provider API keys in the APK.
  // Public Worker endpoint only (no provider credentials are embedded in the APK).
  // A GitHub Actions dart-define can override this URL for another deployment.
  static const String aiGatewayBaseUrl = String.fromEnvironment(
    'AI_GATEWAY_BASE_URL',
    defaultValue: 'https://hrs-ai-crypto-gateway.sdaghat-tk.workers.dev',
  );
  static const Duration requestTimeout = Duration(seconds: 45);
  // AI providers may take longer than market-data requests.
  static const Duration aiRequestTimeout = Duration(seconds: 75);
}
