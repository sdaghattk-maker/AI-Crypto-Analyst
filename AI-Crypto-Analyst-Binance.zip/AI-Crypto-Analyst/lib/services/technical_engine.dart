
import 'market_api.dart';

enum TradeBias { bullish, bearish, neutral }
enum SignalState { buy, sell, wait }

class TechnicalReport {
  const TechnicalReport({
    required this.state, required this.bias1h, required this.bias15m,
    required this.bias5m, required this.entry, required this.stopLoss,
    required this.tp1, required this.tp2, required this.tp3,
    required this.score, required this.buyerPower, required this.sellerPower,
    required this.rangeHigh, required this.rangeLow, required this.rsi,
    required this.atr, required this.reasons, required this.warnings,
  });
  final SignalState state;
  final TradeBias bias1h, bias15m, bias5m;
  final double? entry, stopLoss, tp1, tp2, tp3;
  final int score, buyerPower, sellerPower;
  final double rangeHigh, rangeLow, rsi, atr;
  final List<String> reasons, warnings;

  Map<String,dynamic> toJson() => {
    'signal':state.name,'bias1h':bias1h.name,'bias15m':bias15m.name,'bias5m':bias5m.name,
    'entry':entry,'stopLoss':stopLoss,'tp1':tp1,'tp2':tp2,'tp3':tp3,
    'score':score,'buyerPower':buyerPower,'sellerPower':sellerPower,
    'crt15m':{'high':rangeHigh,'low':rangeLow},'rsi5m':rsi,'atr5m':atr,
    'reasons':reasons,'warnings':warnings,
  };
}

class TechnicalEngine {
  TechnicalReport analyze({
    required List<MarketCandle> h1,
    required List<MarketCandle> m15,
    required List<MarketCandle> m5,
  }) {
    if (h1.length < 60 || m15.length < 60 || m5.length < 60) {
      throw const MarketApiException('برای تحلیل معتبر حداقل ۶۰ کندل بسته‌شده در هر تایم‌فریم لازم است.');
    }
    final b1=_bias(h1), b15=_bias(m15), b5=_bias(m5);
    final rsi=_rsi(m5,14), atr=_atr(m5,14);
    final last=m5.last;
    final range=m15.sublist(m15.length-20);
    final rangeHigh=range.map((c)=>c.high).reduce((a,b)=>a>b?a:b);
    final rangeLow=range.map((c)=>c.low).reduce((a,b)=>a<b?a:b);
    final recent=m5.sublist(m5.length-12,m5.length-1);
    final priorLow=recent.map((c)=>c.low).reduce((a,b)=>a<b?a:b);
    final priorHigh=recent.map((c)=>c.high).reduce((a,b)=>a>b?a:b);
    final bullishSweep=last.low<priorLow && last.close>priorLow && last.close>last.open;
    final bearishSweep=last.high>priorHigh && last.close<priorHigh && last.close<last.open;
    final bullishDisplacement=last.close>last.open && (last.close-last.open)>atr*0.65;
    final bearishDisplacement=last.open>last.close && (last.open-last.close)>atr*0.65;
    final bullMss=last.close>priorHigh;
    final bearMss=last.close<priorLow;
    final buyer=_power(m5), seller=100-buyer;
    final reasons=<String>[], warnings=<String>[];
    var buyScore=0, sellScore=0;
    if(b1==TradeBias.bullish){buyScore+=25;reasons.add('سوگیری 1H صعودی');}
    if(b1==TradeBias.bearish){sellScore+=25;reasons.add('سوگیری 1H نزولی');}
    if(b15==TradeBias.bullish){buyScore+=18;reasons.add('ساختار 15M صعودی');}
    if(b15==TradeBias.bearish){sellScore+=18;reasons.add('ساختار 15M نزولی');}
    if(bullishSweep){buyScore+=15;reasons.add('جمع‌آوری نقدینگی زیر کف کوتاه‌مدت');}
    if(bearishSweep){sellScore+=15;reasons.add('جمع‌آوری نقدینگی بالای سقف کوتاه‌مدت');}
    if(bullMss){buyScore+=15;reasons.add('شکست ساختار 5M به بالا');}
    if(bearMss){sellScore+=15;reasons.add('شکست ساختار 5M به پایین');}
    if(bullishDisplacement){buyScore+=12;reasons.add('جابجایی قدرتمند صعودی');}
    if(bearishDisplacement){sellScore+=12;reasons.add('جابجایی قدرتمند نزولی');}
    if(buyer>=58){buyScore+=8;reasons.add('قدرت خریدار غالب');}
    if(seller>=58){sellScore+=8;reasons.add('قدرت فروشنده غالب');}
    if(rsi>=52&&rsi<=72) buyScore+=7;
    if(rsi<=48&&rsi>=28) sellScore+=7;
    final insideRange=last.close<rangeHigh && last.close>rangeLow;
    if(insideRange && !bullishSweep && !bearishSweep){
      warnings.add('قیمت داخل محدوده ۲۰ کندل اخیر 15M است؛ احتمال نوسان خنثی وجود دارد.');
      buyScore-=8;sellScore-=8;
    }
    if((b1==TradeBias.bearish && buyScore>sellScore)||(b1==TradeBias.bullish&&sellScore>buyScore)){
      warnings.add('جهت ورود با سوگیری تایم‌فریم 1H در تضاد است؛ سیگنال مسدود شد.');
    }
    SignalState state=SignalState.wait;
    double? entry, sl, t1,t2,t3;
    final buyAllowed=b1==TradeBias.bullish && b15!=TradeBias.bearish && buyScore>=65 && buyScore-sellScore>=15 && (bullishSweep||bullMss) && bullishDisplacement;
    final sellAllowed=b1==TradeBias.bearish && b15!=TradeBias.bullish && sellScore>=65 && sellScore-buyScore>=15 && (bearishSweep||bearMss) && bearishDisplacement;
    if(buyAllowed){
      state=SignalState.buy;entry=last.close;
      sl=(last.low-atr*0.25);
      final risk=entry-sl;
      if(risk>0){t1=entry+risk;t2=entry+risk*2;t3=entry+risk*3;}
      reasons.add('تأیید ورود خرید؛ حدضرر پشت کف کندل و بافر ATR');
    } else if(sellAllowed){
      state=SignalState.sell;entry=last.close;
      sl=(last.high+atr*0.25);
      final risk=sl-entry;
      if(risk>0){t1=entry-risk;t2=entry-risk*2;t3=entry-risk*3;}
      reasons.add('تأیید ورود فروش؛ حدضرر پشت سقف کندل و بافر ATR');
    } else {
      warnings.add('شرایط کامل ورود تأیید نشده؛ خروجی WAIT است.');
    }
    return TechnicalReport(
      state:state,bias1h:b1,bias15m:b15,bias5m:b5,entry:entry,stopLoss:sl,
      tp1:t1,tp2:t2,tp3:t3,score:buyScore>sellScore?buyScore:sellScore,
      buyerPower:buyer,sellerPower:seller,rangeHigh:rangeHigh,rangeLow:rangeLow,
      rsi:rsi,atr:atr,reasons:reasons,warnings:warnings,
    );
  }

  TradeBias _bias(List<MarketCandle> c){
    final closes=c.map((x)=>x.close).toList();
    final e20=_ema(closes,20), e50=_ema(closes,50);
    final last=closes.last;
    if(last>e20 && e20>e50)return TradeBias.bullish;
    if(last<e20 && e20<e50)return TradeBias.bearish;
    return TradeBias.neutral;
  }
  double _ema(List<double> v,int period){
    final k=2/(period+1);var e=v.take(period).reduce((a,b)=>a+b)/period;
    for(var i=period;i<v.length;i++){e=v[i]*k+e*(1-k);}
    return e;
  }
  double _rsi(List<MarketCandle> c,int n){
    var gain=0.0,loss=0.0;
    for(var i=c.length-n;i<c.length;i++){final d=c[i].close-c[i-1].close;if(d>=0)gain+=d;else loss-=d;}
    if(loss==0)return 100;
    final rs=(gain/n)/(loss/n);return 100-(100/(1+rs));
  }
  double _atr(List<MarketCandle> c,int n){
    var sum=0.0;
    for(var i=c.length-n;i<c.length;i++){
      final p=c[i-1].close;
      final tr=[c[i].high-c[i].low,(c[i].high-p).abs(),(c[i].low-p).abs()].reduce((a,b)=>a>b?a:b);
      sum+=tr;
    }
    return sum/n;
  }
  int _power(List<MarketCandle> c){
    final recent=c.sublist(c.length-20);
    var buy=0.0,sell=0.0;
    for(final x in recent){
      final range=(x.high-x.low).abs();if(range==0)continue;
      final closeLocation=((x.close-x.low)/range).clamp(0.0,1.0);
      final weighted=x.volume>0?x.volume:1.0;
      buy+=closeLocation*weighted;sell+=(1-closeLocation)*weighted;
    }
    final total=buy+sell;if(total==0)return 50;
    return ((buy/total)*100).round().clamp(0,100).toInt();
  }
}
