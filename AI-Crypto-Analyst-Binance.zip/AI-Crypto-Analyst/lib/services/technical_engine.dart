import 'market_api.dart';

double _min(double a,double b)=>a<b?a:b;
double _max(double a,double b)=>a>b?a:b;

enum TradeBias { bullish, bearish, neutral }
enum SignalState { buy, sell, wait }

class TechnicalReport {
  const TechnicalReport({
    required this.state, required this.bias1h, required this.bias15m,
    required this.bias5m, required this.entry, required this.stopLoss,
    required this.tp1, required this.tp2, required this.tp3,
    required this.score, required this.buyerPower, required this.sellerPower,
    required this.rangeHigh, required this.rangeLow, required this.rsi,
    required this.atr, required this.reasons, required this.warnings,
    required this.poiSummary, required this.overlays,
  });
  final SignalState state;
  final TradeBias bias1h, bias15m, bias5m;
  final double? entry, stopLoss, tp1, tp2, tp3;
  final int score, buyerPower, sellerPower;
  final double rangeHigh, rangeLow, rsi, atr;
  final List<String> reasons, warnings, poiSummary;
  final List<Map<String,dynamic>> overlays;

  Map<String,dynamic> toJson() => {
    'signal':state.name,'bias1h':bias1h.name,'bias15m':bias15m.name,'bias5m':bias5m.name,
    'entry':entry,'stopLoss':stopLoss,'tp1':tp1,'tp2':tp2,'tp3':tp3,
    'score':score,'buyerPower':buyerPower,'sellerPower':sellerPower,
    'crt15m':{'high':rangeHigh,'low':rangeLow},'rsi5m':rsi,'atr5m':atr,
    'reasons':reasons,'warnings':warnings,'poiSummary':poiSummary,'overlays':overlays,
  };
}

class TechnicalEngine {
  TechnicalReport analyze({
    required List<MarketCandle> h1,
    required List<MarketCandle> m15,
    required List<MarketCandle> m5,
  }) {
    if (h1.length<60 || m15.length<60 || m5.length<60) {
      throw const MarketApiException('برای تحلیل معتبر حداقل ۶۰ کندل در هر تایم‌فریم لازم است.');
    }
    // Exclude the still-forming last candle from all calculations.
    final c1=h1.length>1?h1.sublist(0,h1.length-1):h1;
    final c15=m15.length>1?m15.sublist(0,m15.length-1):m15;
    final c5=m5.length>1?m5.sublist(0,m5.length-1):m5;
    final b1=_bias(c1), b15=_bias(c15), b5=_bias(c5);
    final rsi=_rsi(c5,14), atr=_atr(c5,14);
    final last=c5.last;
    final range=c15.sublist(c15.length-20);
    final rangeHigh=range.map((c)=>c.high).reduce(_max);
    final rangeLow=range.map((c)=>c.low).reduce(_min);
    final recent=c5.sublist(c5.length-13,c5.length-1);
    final priorLow=recent.map((c)=>c.low).reduce(_min);
    final priorHigh=recent.map((c)=>c.high).reduce(_max);
    final bullishSweep=last.low<priorLow && last.close>priorLow && last.close>last.open;
    final bearishSweep=last.high>priorHigh && last.close<priorHigh && last.close<last.open;
    final bullishDisplacement=last.close>last.open && (last.close-last.open)>atr*0.65;
    final bearishDisplacement=last.open>last.close && (last.open-last.close)>atr*0.65;
    final bullMss=last.close>priorHigh;
    final bearMss=last.close<priorLow;
    final buyer=_power(c5), seller=100-buyer;

    final reasons=<String>[], warnings=<String>[], poiSummary=<String>[];
    var buyScore=0, sellScore=0;
    final overlays=<Map<String,dynamic>>[];
    // Confirmed swing pivots from completed candles only (2 bars left/right).
    final structStart=c5.length-61>0?c5.length-61:0;
    final struct=c5.sublist(structStart,c5.length-1);
    double? swingHigh, swingLow;
    for(var i=2;i<struct.length-2;i++){
      final v=struct[i];
      final isHigh=v.high>struct[i-1].high && v.high>struct[i-2].high &&
          v.high>=struct[i+1].high && v.high>=struct[i+2].high;
      final isLow=v.low<struct[i-1].low && v.low<struct[i-2].low &&
          v.low<=struct[i+1].low && v.low<=struct[i+2].low;
      if(isHigh){swingHigh=v.high;}
      if(isLow){swingLow=v.low;}
    }
    // Fallback to recent extremes only when no confirmed pivot exists.
    swingHigh??=struct.map((c)=>c.high).reduce(_max);
    swingLow??=struct.map((c)=>c.low).reduce(_min);
    overlays.add({'type':'line','kind':'Swing High','price':swingHigh,'color':'#D6A84B'});
    overlays.add({'type':'line','kind':'Swing Low','price':swingLow,'color':'#D6A84B'});
    poiSummary.add('Swing High ${swingHigh.toStringAsFixed(2)} | Swing Low ${swingLow.toStringAsFixed(2)}');
    final bullishBos=last.close>swingHigh;
    final bearishBos=last.close<swingLow;
    if(bullishBos) poiSummary.add('BOS صعودی');
    if(bearishBos) poiSummary.add('BOS نزولی');

    // Search recent completed history for the latest unmitigated FVG in each direction.
    final fvgStart=c5.length-42>2?c5.length-42:2;
    Map<String,dynamic>? latestBullFvg, latestBearFvg;
    String? bullFvgSummary, bearFvgSummary;
    for(var i=c5.length-2;i>=fvgStart;i--){
      final a=c5[i-2], b=c5[i];
      if(latestBullFvg==null && b.low>a.high && (b.low-a.high)>=atr*0.05){
        final lo=a.high, hi=b.low;
        var mitigated=false;
        for(var j=i+1;j<c5.length-1;j++){if(c5[j].low<=lo){mitigated=true;break;}}
        if(!mitigated){latestBullFvg={'type':'zone','kind':'Bullish FVG','low':lo,'high':hi,'color':'rgba(34,201,154,0.20)'};bullFvgSummary='FVG صعودی: ${lo.toStringAsFixed(2)} تا ${hi.toStringAsFixed(2)}';}
      }
      if(latestBearFvg==null && b.high<a.low && (a.low-b.high)>=atr*0.05){
        final lo=b.high, hi=a.low;
        var mitigated=false;
        for(var j=i+1;j<c5.length-1;j++){if(c5[j].high>=hi){mitigated=true;break;}}
        if(!mitigated){latestBearFvg={'type':'zone','kind':'Bearish FVG','low':lo,'high':hi,'color':'rgba(240,93,108,0.20)'};bearFvgSummary='FVG نزولی: ${lo.toStringAsFixed(2)} تا ${hi.toStringAsFixed(2)}';}
      }
      if(latestBullFvg!=null && latestBearFvg!=null)break;
    }
    if(latestBullFvg!=null){overlays.add(latestBullFvg);poiSummary.add(bullFvgSummary!);}
    if(latestBearFvg!=null){overlays.add(latestBearFvg);poiSummary.add(bearFvgSummary!);}

    // Detect a recent displacement candle that breaks a prior local structure,
    // then mark the last opposing candle as the order block.
    MarketCandle? bullOb, bearOb;
    final obStart=c5.length-24>10?c5.length-24:10;
    for(var i=c5.length-2;i>=obStart;i--){
      final impulse=c5[i], body=(impulse.close-impulse.open).abs();
      final prior=c5.sublist(i-10,i);
      final priorHigh=prior.map((c)=>c.high).reduce(_max);
      final priorLow=prior.map((c)=>c.low).reduce(_min);
      if(bullOb==null && impulse.close>impulse.open && body>=atr*0.70 && impulse.close>priorHigh){
        for(var j=i-1;j>=i-6 && j>=0;j--){if(c5[j].close<c5[j].open){bullOb=c5[j];break;}}
      }
      if(bearOb==null && impulse.close<impulse.open && body>=atr*0.70 && impulse.close<priorLow){
        for(var j=i-1;j>=i-6 && j>=0;j--){if(c5[j].close>c5[j].open){bearOb=c5[j];break;}}
      }
    }
    if(bullOb!=null){
      final lo=bullOb.low, hi=bullOb.high;
      overlays.add({'type':'zone','kind':'Bullish OB','low':lo,'high':hi,'color':'rgba(34,201,154,0.24)'});
      poiSummary.add('OB صعودی ${lo.toStringAsFixed(2)} تا ${hi.toStringAsFixed(2)}');
    }
    if(bearOb!=null){
      final lo=bearOb.low, hi=bearOb.high;
      overlays.add({'type':'zone','kind':'Bearish OB','low':lo,'high':hi,'color':'rgba(240,93,108,0.24)'});
      poiSummary.add('OB نزولی ${lo.toStringAsFixed(2)} تا ${hi.toStringAsFixed(2)}');
    }

    if(b1==TradeBias.bullish){buyScore+=25;reasons.add('سوگیری 1H صعودی');}
    if(b1==TradeBias.bearish){sellScore+=25;reasons.add('سوگیری 1H نزولی');}
    if(b15==TradeBias.bullish){buyScore+=18;reasons.add('ساختار 15M صعودی');}
    if(b15==TradeBias.bearish){sellScore+=18;reasons.add('ساختار 15M نزولی');}
    if(bullishSweep){buyScore+=15;reasons.add('جمع‌آوری نقدینگی زیر کف کوتاه‌مدت');}
    if(bearishSweep){sellScore+=15;reasons.add('جمع‌آوری نقدینگی بالای سقف کوتاه‌مدت');}
    if(bullMss){buyScore+=15;reasons.add('شکست ساختار 5M به بالا');}
    if(bearMss){sellScore+=15;reasons.add('شکست ساختار 5M به پایین');}
    if(bullishDisplacement){buyScore+=12;reasons.add('جابجایی قدرتمند صعودی');}
    if(bearishDisplacement){sellScore+=12;reasons.add('جابجایی قدرتمند نزولی');}
    if(buyer>=58){buyScore+=8;reasons.add('قدرت خریدار غالب');}
    if(seller>=58){sellScore+=8;reasons.add('قدرت فروشنده غالب');}
    if(rsi>=52&&rsi<=72) buyScore+=7;
    if(rsi<=48&&rsi>=28) sellScore+=7;
    final insideRange=last.close<rangeHigh && last.close>rangeLow;
    if(insideRange&&!bullishSweep&&!bearishSweep){
      warnings.add('قیمت داخل محدوده ۲۰ کندل اخیر 15M است؛ احتمال نوسان خنثی وجود دارد.');
      buyScore-=8; sellScore-=8;
    }
    if((b1==TradeBias.bearish&&buyScore>sellScore)||(b1==TradeBias.bullish&&sellScore>buyScore)){
      warnings.add('جهت ورود با سوگیری تایم‌فریم 1H در تضاد است؛ سیگنال مسدود شد.');
    }

    var state=SignalState.wait;
    double? entry, sl, t1, t2, t3;
    final buyAllowed=b1==TradeBias.bullish&&b15!=TradeBias.bearish&&buyScore>=65&&buyScore-sellScore>=15&&(bullishSweep||bullMss)&&bullishDisplacement;
    final sellAllowed=b1==TradeBias.bearish&&b15!=TradeBias.bullish&&sellScore>=65&&sellScore-buyScore>=15&&(bearishSweep||bearMss)&&bearishDisplacement;
    if(buyAllowed){
      entry=last.close;
      final structuralLow=bullOb==null?swingLow:_min(bullOb.low,swingLow);
      sl=structuralLow-atr*0.20;
      final risk=entry-sl;
      if(risk>0){state=SignalState.buy;t1=entry+risk;t2=entry+risk*2;t3=entry+risk*3;}
      reasons.add('تأیید خرید؛ حدضرر پشت ساختار و بافر ATR');
    }else if(sellAllowed){
      entry=last.close;
      final structuralHigh=bearOb==null?swingHigh:_max(bearOb.high,swingHigh);
      sl=structuralHigh+atr*0.20;
      final risk=sl-entry;
      if(risk>0){state=SignalState.sell;t1=entry-risk;t2=entry-risk*2;t3=entry-risk*3;}
      reasons.add('تأیید فروش؛ حدضرر پشت ساختار و بافر ATR');
    }else{
      warnings.add('شرایط کامل ورود تأیید نشده؛ خروجی WAIT است.');
    }
    if(state!=SignalState.wait){
      overlays.add({'type':'line','kind':'Entry','price':entry,'color':'#46D6B3'});
      overlays.add({'type':'line','kind':'SL','price':sl,'color':'#F05D6C'});
      overlays.add({'type':'line','kind':'TP1','price':t1,'color':'#22C99A'});
      overlays.add({'type':'line','kind':'TP2','price':t2,'color':'#22C99A'});
      overlays.add({'type':'line','kind':'TP3','price':t3,'color':'#22C99A'});
    }
    return TechnicalReport(
      state:state,bias1h:b1,bias15m:b15,bias5m:b5,entry:entry,stopLoss:sl,
      tp1:t1,tp2:t2,tp3:t3,score:buyScore>sellScore?buyScore:sellScore,
      buyerPower:buyer,sellerPower:seller,rangeHigh:rangeHigh,rangeLow:rangeLow,
      rsi:rsi,atr:atr,reasons:reasons,warnings:warnings,poiSummary:poiSummary,overlays:overlays,
    );
  }

  TradeBias _bias(List<MarketCandle> c){
    final closes=c.map((x)=>x.close).toList();
    final e20=_ema(closes,20), e50=_ema(closes,50), last=closes.last;
    if(last>e20&&e20>e50)return TradeBias.bullish;
    if(last<e20&&e20<e50)return TradeBias.bearish;
    return TradeBias.neutral;
  }
  double _ema(List<double> v,int period){
    final k=2/(period+1);var e=v.take(period).reduce((a,b)=>a+b)/period;
    for(var i=period;i<v.length;i++){e=v[i]*k+e*(1-k);}
    return e;
  }
  double _rsi(List<MarketCandle> c,int n){
    var gain=0.0,loss=0.0;
    for(var i=c.length-n;i<c.length;i++){final d=c[i].close-c[i-1].close;if(d>=0)gain+=d;else loss-=d;}
    if(loss==0)return 100;
    final rs=gain/loss;return 100-(100/(1+rs));
  }
  double _atr(List<MarketCandle> c,int n){
    var sum=0.0;
    for(var i=c.length-n;i<c.length;i++){
      final p=c[i-1].close;
      final tr=[c[i].high-c[i].low,(c[i].high-p).abs(),(c[i].low-p).abs()].reduce(_max);
      sum+=tr;
    }
    return sum/n;
  }
  int _power(List<MarketCandle> c){
    final recent=c.sublist(c.length-20);var buy=0.0,sell=0.0;
    for(final x in recent){
      final range=x.high-x.low;if(range<=0)continue;
      final closeLocation=((x.close-x.low)/range).clamp(0.0,1.0);
      final weighted=x.volume>0?x.volume:1.0;
      buy+=closeLocation*weighted;sell+=(1-closeLocation)*weighted;
    }
    final total=buy+sell;if(total==0)return 50;
    return ((buy/total)*100).round().clamp(0,100).toInt();
  }
}
