
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'app_config.dart';
import 'technical_engine.dart';

class AiModelResult {
  const AiModelResult({required this.model, required this.status, this.bias, this.summary, this.risks});
  final String model, status;
  final String? bias, summary;
  final List<String>? risks;
  factory AiModelResult.fromJson(String model, dynamic raw) {
    if (raw is! Map) return AiModelResult(model:model,status:'پاسخ نامعتبر');
    return AiModelResult(
      model:model,
      status:(raw['status'] ?? 'ok').toString(),
      bias:raw['bias']?.toString(),
      summary:raw['summary']?.toString(),
      risks:(raw['risks'] is List) ? (raw['risks'] as List).map((e)=>e.toString()).toList() : const [],
    );
  }
}

class AiConsensus {
  const AiConsensus({required this.gemini, required this.deepseek, required this.decision, required this.conflicts});
  final AiModelResult gemini, deepseek;
  final String decision;
  final List<String> conflicts;
}

class AiService {
  bool get isConfigured => AppConfig.aiGatewayBaseUrl.startsWith('https://') &&
      !AppConfig.aiGatewayBaseUrl.contains('YOUR_');

  Future<AiConsensus> analyze(TechnicalReport report, {
    required String exchange, required String symbol,
  }) async {
    if (!isConfigured) {
      throw const AiServiceException(
        'درگاه امن هوش مصنوعی هنوز تنظیم نشده است. برای فعال‌سازی Gemini و DeepSeek باید AI Gateway روی Worker مستقر و آدرس آن در Build تنظیم شود.',
      );
    }
    final base=AppConfig.aiGatewayBaseUrl.replaceFirst(RegExp(r'/+$'), '');
    final uri=Uri.parse('$base/analyze');
    final response=await http.post(uri,
      headers:const {'Content-Type':'application/json','Accept':'application/json'},
      body:jsonEncode({
        'exchange':exchange,'symbol':symbol,
        'technical':report.toJson(),
        'policy':'Do not invent prices or override technical entry, stop loss, or targets. Return WAIT if evidence is insufficient.',
      }),
    ).timeout(AppConfig.requestTimeout);
    if(response.statusCode<200||response.statusCode>=300){
      throw AiServiceException('AI Gateway خطای HTTP ${response.statusCode}: ${response.body.length>220?response.body.substring(0,220):response.body}');
    }
    final decoded=jsonDecode(response.body);
    if(decoded is! Map) throw const AiServiceException('ساختار پاسخ AI Gateway معتبر نیست.');
    final gemini=AiModelResult.fromJson('Gemini',decoded['gemini']);
    final deepseek=AiModelResult.fromJson('DeepSeek',decoded['deepseek']);
    final decision=(decoded['decision']??'WAIT').toString();
    final conflicts=decoded['conflicts'] is List?(decoded['conflicts'] as List).map((e)=>e.toString()).toList():<String>[];
    return AiConsensus(gemini:gemini,deepseek:deepseek,decision:decision,conflicts:conflicts);
  }
}
class AiServiceException implements Exception {
  const AiServiceException(this.message);
  final String message;
  @override String toString()=>message;
}
