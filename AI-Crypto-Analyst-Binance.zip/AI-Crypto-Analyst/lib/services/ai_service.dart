import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'app_config.dart';
import 'technical_engine.dart';
import 'market_api.dart';

class AiModelResult {
  const AiModelResult({
    required this.model,
    required this.status,
    this.bias,
    this.summary,
    this.risks = const [],
    this.observations = const [],
    this.confidence = 0,
  });

  final String model;
  final String status;
  final String? bias;
  final String? summary;
  final List<String> risks;
  final List<String> observations;
  final int confidence;

  Map<String, dynamic> toJson() => {
    'model': model, 'status': status, 'bias': bias, 'summary': summary,
    'risks': risks, 'observations': observations, 'confidence': confidence,
  };

  factory AiModelResult.fromJson(String model, dynamic raw) {
    if (raw is! Map) {
      return AiModelResult(model: model, status: 'پاسخ نامعتبر');
    }
    final confidenceValue = raw['confidence'];
    final parsedConfidence = confidenceValue is num
        ? confidenceValue.round().clamp(0, 100).toInt()
        : int.tryParse('$confidenceValue') ?? 0;
    return AiModelResult(
      model: model,
      status: (raw['status'] ?? 'ok').toString(),
      bias: raw['bias']?.toString(),
      summary: raw['summary']?.toString(),
      risks: raw['risks'] is List
          ? (raw['risks'] as List).map((e) => e.toString()).toList()
          : const [],
      observations: raw['observations'] is List
          ? (raw['observations'] as List).map((e) => e.toString()).toList()
          : const [],
      confidence: parsedConfidence,
    );
  }
}

class AiConsensus {
  const AiConsensus({
    required this.gemini,
    required this.openrouter,
    required this.decision,
    required this.conflicts,
  });

  final AiModelResult gemini;
  final AiModelResult openrouter;
  final String decision;
  final List<String> conflicts;

  Map<String, dynamic> toJson() => {
    'gemini': gemini.toJson(), 'openrouter': openrouter.toJson(),
    'decision': decision, 'conflicts': conflicts,
  };

  factory AiConsensus.fromJson(Map<String, dynamic> json) {
    final conflictsRaw = json['conflicts'];
    return AiConsensus(
      gemini: AiModelResult.fromJson('Gemini', json['gemini']),
      openrouter: AiModelResult.fromJson('OpenRouter', json['openrouter']),
      decision: const {'BUY', 'SELL', 'WAIT'}.contains('${json['decision']}'.toUpperCase())
          ? '${json['decision']}'.toUpperCase() : 'WAIT',
      conflicts: conflictsRaw is List ? conflictsRaw.map((e) => e.toString()).toList() : const [],
    );
  }
}

class AiService {
  bool get isConfigured =>
      AppConfig.aiGatewayBaseUrl.startsWith('https://') &&
      !AppConfig.aiGatewayBaseUrl.contains('YOUR_');

  Map<String, dynamic> _encodeHistory(List<MarketCandle> candles, int intervalSeconds) {
    if (candles.isEmpty) return {'rows': <List<int>>[]};
    final positiveVolumes = candles.map((c) => c.volume).where((v) => v > 0).toList()..sort();
    final medianVolume = positiveVolumes.isEmpty
        ? 1.0
        : positiveVolumes[positiveVolumes.length ~/ 2];
    var previousClose = candles.first.open;
    var previousTime = candles.first.time;
    final rows = <List<int>>[];
    for (var i = 0; i < candles.length; i++) {
      final c = candles[i];
      int delta(double value) => (((value / previousClose) - 1) * 1000000).round();
      final timeDelta = i == 0 ? 0 : c.time - previousTime;
      rows.add([
        timeDelta,
        delta(c.open),
        delta(c.high),
        delta(c.low),
        delta(c.close),
        ((c.volume / medianVolume) * 100).round().clamp(0, 1000000).toInt(),
      ]);
      previousClose = c.close;
      previousTime = c.time;
    }
    return {
      'timeStart': candles.first.time,
      'intervalSeconds': intervalSeconds,
      'basePrice': candles.first.open,
      'baseVolumeMedian': medianVolume,
      'rows': rows,
    };
  }

  Future<AiConsensus> analyze(
    TechnicalReport report, {
    required String exchange,
    required String symbol,
    required List<MarketCandle> history1h,
    required List<MarketCandle> history15m,
    required List<MarketCandle> history5m,
  }) async {
    if (!isConfigured) {
      throw const AiServiceException(
        'آدرس AI Gateway در تنظیمات Build تعریف نشده است. '
        'مقدار AI_GATEWAY_BASE_URL را در GitHub Actions Secret بررسی کنید.',
      );
    }

    final base = AppConfig.aiGatewayBaseUrl.replaceFirst(RegExp(r'/+$'), '');
    final uri = Uri.parse('$base/analyze');

    final requestBody = jsonEncode({
            'exchange': exchange,
            'symbol': symbol,
            // Full completed history is preserved in compact delta-OHLCV form to fit free-model context limits.
            'marketHistory': {
              'format': 'rows=[delta_time_seconds, open_delta_0.01bps, high_delta_0.01bps, low_delta_0.01bps, close_delta_0.01bps, volume_ratio_x100]; price deltas reference previous close; volume ratio references timeframe median',
              '1h': _encodeHistory(history1h, 3600),
              '15m': _encodeHistory(history15m, 900),
              '5m': _encodeHistory(history5m, 300),
            },
            'technicalAnalysis': report.toJson(),
            'policy': 'Analyze marketHistory independently first. technicalAnalysis is a separate deterministic opinion for comparison only. Do not copy its signal blindly. Never invent numeric entry, stop-loss or take-profit prices.',
          });
    if (utf8.encode(requestBody).length > 900 * 1024) {
      throw const AiServiceException('حجم تاریخچه کندل‌ها برای ارسال به AI بیش از حد مجاز است.');
    }

    late final http.Response response;
    try {
      response = await http
          .post(
            uri,
            headers: const {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: requestBody,
          )
          .timeout(AppConfig.aiRequestTimeout);
    } on http.ClientException catch (e) {
      throw AiServiceException(
        'اتصال برنامه به AI Gateway قطع شد و پاسخی از سرور دریافت نشد. '
        'این خطا به معنی رد تحلیل توسط مدل‌ها نیست. از تکرار پشت‌سرهم خودداری کنید؛ '
        'اتصال Worker و گزارش‌های Cloudflare را بررسی کنید. (${e.message})',
      );
    } on TimeoutException {
      throw const AiServiceException(
        'پاسخ AI Gateway در مهلت تعیین‌شده نرسید. ممکن است ارائه‌دهنده‌ها شلوغ باشند؛ '
        'آخرین تحلیل ذخیره‌شده حفظ می‌شود.',
      );
    }

    final decoded = _decodeResponse(response.body);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = decoded is Map
          ? (decoded['error'] ?? decoded['message'] ?? response.body).toString()
          : response.body;
      final providerMap = decoded is Map && decoded['providers'] is Map
          ? decoded['providers'] as Map
          : decoded is Map ? decoded : const <dynamic, dynamic>{};
      String providerDiagnostic(String key, String label) {
        final raw = providerMap[key];
        if (raw is! Map) return '';
        final providerStatus = (raw['status'] ?? '').toString();
        final detail = (raw['error'] ?? raw['message'] ?? '').toString().trim();
        if (providerStatus == 'ok' && detail.isEmpty) return '';
        final text = detail.isEmpty ? (providerStatus.isEmpty ? 'پاسخ نامشخص' : providerStatus) : detail;
        return '$label: ${text.length > 260 ? text.substring(0, 260) : text}';
      }
      final diagnostics = <String>[
        providerDiagnostic('gemini', 'Gemini'),
        providerDiagnostic('openrouter', 'OpenRouter'),
      ].where((x) => x.isNotEmpty).toList();
      final shortMessage = message.length > 220 ? message.substring(0, 220) : message;
      throw AiServiceException(
        'AI Gateway خطای HTTP ${response.statusCode}: $shortMessage'
        '${diagnostics.isEmpty ? '' : '\n${diagnostics.join('\n')}'}',
      );
    }

    if (decoded is! Map || decoded['ok'] == false) {
      throw const AiServiceException('ساختار پاسخ AI Gateway معتبر نیست.');
    }

    // Support both the current nested contract and the previous flat response.
    final providers = decoded['providers'] is Map
        ? decoded['providers'] as Map
        : decoded;
    final gemini = AiModelResult.fromJson(
      'Gemini',
      providers['gemini'] ?? decoded['gemini'],
    );
    final openrouter = AiModelResult.fromJson(
      'OpenRouter',
      providers['openrouter'] ?? decoded['openrouter'],
    );

    final consensus = decoded['consensus'] is Map
        ? decoded['consensus'] as Map
        : const <dynamic, dynamic>{};

    final decision =
        (consensus['decision'] ?? decoded['decision'] ?? 'WAIT')
            .toString()
            .toUpperCase();
    final conflicts = decoded['conflicts'] is List
        ? (decoded['conflicts'] as List).map((e) => e.toString()).toList()
        : <String>[];

    return AiConsensus(
      gemini: gemini,
      openrouter: openrouter,
      decision: const {'BUY', 'SELL', 'WAIT'}.contains(decision)
          ? decision
          : 'WAIT',
      conflicts: conflicts,
    );
  }

  dynamic _decodeResponse(String body) {
    try {
      return jsonDecode(body);
    } on FormatException {
      throw const AiServiceException(
        'پاسخ Worker JSON معتبر نیست؛ کد یا مسیر API را بررسی کنید.',
      );
    }
  }
}

class AiServiceException implements Exception {
  const AiServiceException(this.message);
  final String message;

  @override
  String toString() => message;
}
