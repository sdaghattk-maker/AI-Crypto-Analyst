import 'dart:convert';
import 'package:http/http.dart' as http;
import 'app_config.dart';
import 'technical_engine.dart';

class AiModelResult {
  const AiModelResult({
    required this.model,
    required this.status,
    this.bias,
    this.summary,
    this.risks = const [],
    this.confidence = 0,
  });

  final String model;
  final String status;
  final String? bias;
  final String? summary;
  final List<String> risks;
  final int confidence;

  factory AiModelResult.fromJson(String model, dynamic raw) {
    if (raw is! Map) {
      return AiModelResult(model: model, status: 'پاسخ نامعتبر');
    }
    final confidenceValue = raw['confidence'];
    final parsedConfidence = confidenceValue is num
        ? confidenceValue.round().clamp(0, 100)
        : int.tryParse('$confidenceValue') ?? 0;
    return AiModelResult(
      model: model,
      status: (raw['status'] ?? 'ok').toString(),
      bias: raw['bias']?.toString(),
      summary: raw['summary']?.toString(),
      risks: raw['risks'] is List
          ? (raw['risks'] as List).map((e) => e.toString()).toList()
          : const [],
      confidence: parsedConfidence,
    );
  }
}

class AiConsensus {
  const AiConsensus({
    required this.gemini,
    required this.deepseek,
    required this.decision,
    required this.conflicts,
  });

  final AiModelResult gemini;
  final AiModelResult deepseek;
  final String decision;
  final List<String> conflicts;
}

class AiService {
  bool get isConfigured =>
      AppConfig.aiGatewayBaseUrl.startsWith('https://') &&
      !AppConfig.aiGatewayBaseUrl.contains('YOUR_');

  Future<AiConsensus> analyze(
    TechnicalReport report, {
    required String exchange,
    required String symbol,
  }) async {
    if (!isConfigured) {
      throw const AiServiceException(
        'آدرس AI Gateway در تنظیمات Build تعریف نشده است. '
        'مقدار AI_GATEWAY_BASE_URL را در GitHub Actions Secret بررسی کنید.',
      );
    }

    final base = AppConfig.aiGatewayBaseUrl.replaceFirst(RegExp(r'/+$'), '');
    final uri = Uri.parse('$base/analyze');

    final response = await http
        .post(
          uri,
          headers: const {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
          body: jsonEncode({
            'exchange': exchange,
            'symbol': symbol,
            // This key matches the Worker contract.
            'technicalAnalysis': report.toJson(),
            'policy':
                'Do not invent prices or override technical entry, stop loss, '
                'or targets. Return WAIT if evidence is insufficient.',
          }),
        )
        .timeout(AppConfig.aiRequestTimeout);

    final decoded = _decodeResponse(response.body);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = decoded is Map
          ? (decoded['error'] ?? decoded['message'] ?? response.body).toString()
          : response.body;
      throw AiServiceException(
        'AI Gateway خطای HTTP ${response.statusCode}: '
        '${message.length > 240 ? message.substring(0, 240) : message}',
      );
    }

    if (decoded is! Map || decoded['ok'] == false) {
      throw const AiServiceException('ساختار پاسخ AI Gateway معتبر نیست.');
    }

    // Support both the current nested contract and the previous flat response.
    final providers = decoded['providers'] is Map
        ? decoded['providers'] as Map
        : decoded;
    final gemini = AiModelResult.fromJson(
      'Gemini',
      providers['gemini'] ?? decoded['gemini'],
    );
    final deepseek = AiModelResult.fromJson(
      'DeepSeek',
      providers['deepseek'] ?? decoded['deepseek'],
    );

    final consensus = decoded['consensus'] is Map
        ? decoded['consensus'] as Map
        : const <dynamic, dynamic>{};

    final decision =
        (consensus['decision'] ?? decoded['decision'] ?? 'WAIT')
            .toString()
            .toUpperCase();
    final conflicts = decoded['conflicts'] is List
        ? (decoded['conflicts'] as List).map((e) => e.toString()).toList()
        : <String>[];

    return AiConsensus(
      gemini: gemini,
      deepseek: deepseek,
      decision: const {'BUY', 'SELL', 'WAIT'}.contains(decision)
          ? decision
          : 'WAIT',
      conflicts: conflicts,
    );
  }

  dynamic _decodeResponse(String body) {
    try {
      return jsonDecode(body);
    } on FormatException {
      throw const AiServiceException(
        'پاسخ Worker JSON معتبر نیست؛ کد یا مسیر API را بررسی کنید.',
      );
    }
  }
}

class AiServiceException implements Exception {
  const AiServiceException(this.message);
  final String message;

  @override
  String toString() => message;
}
