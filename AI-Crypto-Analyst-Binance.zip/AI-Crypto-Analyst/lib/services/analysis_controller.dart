
import 'package:flutter/foundation.dart';
import '../models/app_state.dart';
import 'market_api.dart';
import 'technical_engine.dart';

class AnalysisController extends ChangeNotifier {
  AnalysisController(this.appState);
  final AppState appState;
  final MarketApi api=MarketApi();
  final TechnicalEngine engine=TechnicalEngine();

  bool loading=false;
  String status='هنوز تحلیلی اجرا نشده است.';
  String? error;
  TechnicalReport? report;
  int _requestId=0;

  Future<void> run() async {
    final id=++_requestId;
    loading=true;error=null;status='دریافت داده‌های 1H، 15M و 5M...';report=null;notifyListeners();
    final exchange=appState.exchange, symbol=appState.symbol;
    try {
      final responses=await Future.wait([
        api.getKlines(exchange:exchange,symbol:symbol,interval:'1h',limit:1000),
        api.getKlines(exchange:exchange,symbol:symbol,interval:'15m',limit:1500),
        api.getKlines(exchange:exchange,symbol:symbol,interval:'5m',limit:2000),
      ]);
      if(id!=_requestId)return;
      status='محاسبه روند، ساختار، نقدینگی و قدرت خریدار/فروشنده...';notifyListeners();
      final result=engine.analyze(h1:responses[0],m15:responses[1],m5:responses[2]);
      if(id!=_requestId)return;
      report=result;status='تحلیل تکنیکال با ${responses[0].length}/${responses[1].length}/${responses[2].length} کندل بسته‌شده تکمیل شد.';
    } catch(e) {
      if(id!=_requestId)return;
      error=e.toString();status='تحلیل کامل نشد.';
    } finally {
      if(id==_requestId){loading=false;notifyListeners();}
    }
  }

  void invalidate() {
    _requestId++;
    loading=false;report=null;error=null;status='بازار یا نماد تغییر کرد؛ تحلیل قبلی باطل شد.';
    notifyListeners();
  }
}
