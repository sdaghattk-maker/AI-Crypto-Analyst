import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import 'ai_service.dart';
import 'market_api.dart';
import 'technical_engine.dart';

class AnalysisController extends ChangeNotifier {
  AnalysisController(this.appState)
      : _lastExchange = appState.exchange,
        _lastSymbol = appState.symbol;
  final AppState appState;
  final MarketApi api = MarketApi();
  final TechnicalEngine engine = TechnicalEngine();

  bool loading = false;
  bool restoring = true;
  String status = 'در حال بازیابی آخرین تحلیل ذخیره‌شده...';
  String? error;
  TechnicalReport? report;
  AiConsensus? consensus;
  DateTime? technicalAt;
  DateTime? aiAt;
  String _lastExchange;
  String _lastSymbol;
  int _requestId = 0;

  String get cacheKey => 'analysis_cache_${appState.exchange}_${appState.symbol}';
  bool get isStale => technicalAt == null ||
      DateTime.now().difference(technicalAt!) > const Duration(minutes: 15);

  Future<void> restore() async {
    final requestedExchange = appState.exchange;
    final requestedSymbol = appState.symbol;
    restoring = true;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('analysis_cache_${requestedExchange}_$requestedSymbol');
      if (requestedExchange != appState.exchange || requestedSymbol != appState.symbol) return;
      if (raw != null) {
        final decoded = jsonDecode(raw);
        if (decoded is Map) {
          final map = Map<String, dynamic>.from(decoded);
          if (map['report'] is Map) {
            report = TechnicalReport.fromJson(Map<String, dynamic>.from(map['report']));
            technicalAt = DateTime.tryParse('${map['technicalAt'] ?? ''}');
            if (map['consensus'] is Map) {
              consensus = AiConsensus.fromJson(Map<String, dynamic>.from(map['consensus']));
              aiAt = DateTime.tryParse('${map['aiAt'] ?? ''}');
            }
            status = 'آخرین تحلیل ذخیره‌شده بازیابی شد؛ ${isStale ? 'قدیمی' : 'تازه'}.';
          }
        }
      } else {
        status = 'هنوز تحلیلی برای این نماد ذخیره نشده است.';
      }
    } catch (e) {
      error = 'بازیابی تحلیل ذخیره‌شده ناموفق بود: $e';
      status = 'خطا در بازیابی تحلیل قبلی.';
    } finally {
      restoring = false;
      notifyListeners();
    }
  }

  Future<void> _persist({String? exchange, String? symbol}) async {
    if (report == null || technicalAt == null) return;
    final targetExchange = exchange ?? appState.exchange;
    final targetSymbol = symbol ?? appState.symbol;
    final prefs = await SharedPreferences.getInstance();
    if (targetExchange != appState.exchange || targetSymbol != appState.symbol) return;
    final data = <String, dynamic>{
      'exchange': targetExchange,
      'symbol': targetSymbol,
      'technicalAt': technicalAt!.toIso8601String(),
      'aiAt': aiAt?.toIso8601String(),
      'report': report!.toJson(),
      'consensus': consensus?.toJson(),
    };
    await prefs.setString('analysis_cache_${targetExchange}_$targetSymbol', jsonEncode(data));
  }

  Future<void> saveConsensus(AiConsensus value) async {
    consensus = value;
    aiAt = DateTime.now();
    await _persist();
    notifyListeners();
  }

  Future<void> onStateChanged() async {
    if (_lastExchange == appState.exchange && _lastSymbol == appState.symbol) return;
    _lastExchange = appState.exchange;
    _lastSymbol = appState.symbol;
    _requestId++;
    loading = false;
    report = null;
    consensus = null;
    technicalAt = null;
    aiAt = null;
    error = null;
    status = 'در حال بازیابی تحلیل ذخیره‌شده برای نماد جدید...';
    notifyListeners();
    await restore();
  }

  Future<bool> run() async {
    final id = ++_requestId;
    loading = true;
    error = null;
    status = 'دریافت داده‌های 1H، 15M و 5M...';
    notifyListeners();
    final exchange = appState.exchange, symbol = appState.symbol;
    try {
      final responses = await Future.wait([
        api.getKlines(exchange: exchange, symbol: symbol, interval: '1h', limit: 1000),
        api.getKlines(exchange: exchange, symbol: symbol, interval: '15m', limit: 1500),
        api.getKlines(exchange: exchange, symbol: symbol, interval: '5m', limit: 2000),
      ]);
      if (id != _requestId) return false;
      status = 'محاسبه روند، ساختار، نقدینگی و قدرت خریدار/فروشنده...';
      notifyListeners();
      final result = engine.analyze(h1: responses[0], m15: responses[1], m5: responses[2]);
      if (id != _requestId) return false;
      report = result;
      consensus = null;
      aiAt = null;
      technicalAt = DateTime.now();
      status = 'تحلیل تکنیکال تکمیل و ذخیره شد (${responses[0].length}/${responses[1].length}/${responses[2].length} کندل).';
      await _persist(exchange: exchange, symbol: symbol);
      return true;
    } catch (e) {
      if (id != _requestId) return false;
      error = e.toString();
      status = 'تحلیل کامل نشد؛ آخرین تحلیل ذخیره‌شده حفظ شده است.';
      return false;
    } finally {
      if (id == _requestId) {
        loading = false;
        notifyListeners();
      }
    }
  }
}
