
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/app_state.dart';
import 'app_config.dart';

class MarketCandle {
  const MarketCandle({required this.time, required this.open, required this.high,
    required this.low, required this.close, this.volume = 0});
  final int time;
  final double open, high, low, close, volume;
  Map<String, dynamic> toChartJson() => {
    'time': time, 'open': open, 'high': high, 'low': low, 'close': close, 'volume': volume,
  };
}

class MarketApi {
  Future<double> getPrice({required String exchange, required String symbol}) async {
    if (exchange == 'Binance') {
      final json = await _getJson(_binance({'endpoint':'price','symbol':symbol.toUpperCase()}));
      _ensureBinance(json, 'دریافت قیمت');
      final data = json['data'];
      final raw = data is Map ? (data['price'] ?? data['lastPrice']) : (data ?? json['price']);
      final value = _number(raw);
      if (value == null || value <= 0) throw const MarketApiException('قیمت معتبر از Binance دریافت نشد.');
      return value;
    }
    final pair = _nobitexPair(symbol);
    final parts = _splitPair(pair);
    final uri = Uri.https('apiv2.nobitex.ir', '/market/stats', {
      'srcCurrency': parts.$1.toLowerCase(), 'dstCurrency': parts.$2.toLowerCase(),
    });
    final json = await _getJson(uri);
    if (json['status'] != 'ok' || json['stats'] is! Map) {
      throw MarketApiException('پاسخ آمار نوبیتکس معتبر نیست: ${_short(json)}');
    }
    final stats = json['stats'] as Map;
    final row = stats['${parts.$1.toLowerCase()}-${parts.$2.toLowerCase()}'];
    final value = row is Map ? _number(row['latest']) : null;
    if (value == null || value <= 0) {
      throw MarketApiException('بازار $pair در نوبیتکس موجود نیست یا قیمت ندارد.');
    }
    return value;
  }

  Future<List<MarketCandle>> getKlines({
    required String exchange, required String symbol, required String interval, int limit = 500,
  }) async {
    if (exchange == 'Binance') {
      final json = await _getJson(_binance({
        'endpoint':'klines','symbol':symbol.toUpperCase(),'interval':interval,'limit':limit.toString(),
      }));
      _ensureBinance(json, 'دریافت کندل');
      return _parseBinance(json['data'], limit);
    }
    final pair = _nobitexPair(symbol);
    final seconds = _intervalSeconds(interval);
    final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final uri = Uri.https('apiv2.nobitex.ir', '/market/udf/history', {
      'symbol':pair,
      'resolution':_nobitexResolution(interval),
      'to':now.toString(),
      'countback':limit.toString(),
      'from':(now - seconds * (limit + 5)).toString(),
    });
    final json = await _getJson(uri);
    if (json['s'] == 'no_data') throw MarketApiException('برای $pair در نوبیتکس کندلی موجود نیست.');
    if (json['s'] != 'ok') throw MarketApiException('خطای تاریخچه نوبیتکس: ${json['errmsg'] ?? _short(json)}');
    return _parseUdf(json, interval, limit);
  }

  Uri _binance(Map<String,String> query) => Uri.parse(AppConfig.binanceWorkerBaseUrl).replace(queryParameters: query);

  Future<Map<String,dynamic>> _getJson(Uri uri) async {
    try {
      final response = await http.get(uri, headers: const {'Accept':'application/json'}).timeout(AppConfig.requestTimeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw MarketApiException('HTTP ${response.statusCode}: ${_short(response.body)}');
      }
      final decoded = jsonDecode(response.body);
      if (decoded is! Map) throw const MarketApiException('پاسخ سرور JSON object نیست.');
      return Map<String,dynamic>.from(decoded);
    } on MarketApiException { rethrow; }
    catch (e) { throw MarketApiException('خطا در اتصال به ${uri.host}: $e'); }
  }

  void _ensureBinance(Map<String,dynamic> json, String action) {
    if (json['ok'] == false) throw MarketApiException('$action ناموفق: ${json['error'] ?? _short(json)}');
  }

  List<MarketCandle> _parseBinance(dynamic raw, int limit) {
    if (raw is Map) raw = raw['klines'] ?? raw['data'];
    if (raw is! List) throw const MarketApiException('ساختار کندل Binance نامعتبر است.');
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    final map = <int,MarketCandle>{};
    for (final item in raw) {
      if (item is! List || item.length < 7) continue;
      final t=_int(item[0]), o=_number(item[1]), h=_number(item[2]), l=_number(item[3]), c=_number(item[4]);
      final v=_number(item[5]) ?? 0, closeTime=_int(item[6]);
      if (t==null || o==null || h==null || l==null || c==null || closeTime==null || closeTime>=nowMs || !_valid(o,h,l,c)) continue;
      map[t~/1000]=MarketCandle(time:t~/1000,open:o,high:h,low:l,close:c,volume:v);
    }
    return _finish(map.values.toList(),limit);
  }

  List<MarketCandle> _parseUdf(Map<String,dynamic> data, String interval, int limit) {
    final t=data['t'], o=data['o'], h=data['h'], l=data['l'], c=data['c'], v=data['v'];
    if ([t,o,h,l,c].any((x)=>x is! List)) throw const MarketApiException('آرایه‌های OHLC نوبیتکس ناقص‌اند.');
    final ts=t as List, os=o as List, hs=h as List, ls=l as List, cs=c as List;
    if ([os,hs,ls,cs].any((x)=>x.length!=ts.length)) throw const MarketApiException('طول آرایه‌های OHLC برابر نیست.');
    final duration=_intervalSeconds(interval), now=DateTime.now().millisecondsSinceEpoch~/1000;
    final map=<int,MarketCandle>{};
    for(var i=0;i<ts.length;i++){
      final time=_int(ts[i]), op=_number(os[i]), hi=_number(hs[i]), lo=_number(ls[i]), cl=_number(cs[i]);
      if(time==null||op==null||hi==null||lo==null||cl==null||time+duration>now||!_valid(op,hi,lo,cl)) continue;
      map[time]=MarketCandle(time:time,open:op,high:hi,low:lo,close:cl,volume:v is List&&i<v.length?(_number(v[i])??0):0);
    }
    return _finish(map.values.toList(),limit);
  }

  List<MarketCandle> _finish(List<MarketCandle> list,int limit) {
    list.sort((a,b)=>a.time.compareTo(b.time));
    final unique=<int,MarketCandle>{for(final c in list)c.time:c};
    final result=unique.values.toList()..sort((a,b)=>a.time.compareTo(b.time));
    if(result.isEmpty) throw const MarketApiException('هیچ کندل بسته‌شده و معتبری دریافت نشد.');
    return result.length>limit?result.sublist(result.length-limit):result;
  }

  String _nobitexPair(String symbol) {
    final s=symbol.toUpperCase().replaceAll('/','');
    if (!s.endsWith('USDT') && !s.endsWith('IRT')) {
      throw MarketApiException('نماد $symbol برای نوبیتکس قابل تبدیل نیست.');
    }
    return s;
  }
  (String,String) _splitPair(String pair) => pair.endsWith('USDT')
      ? (pair.substring(0,pair.length-4),'usdt')
      : (pair.substring(0,pair.length-3),'rls');
  String _nobitexResolution(String tf) => const {'1m':'1','5m':'5','15m':'15','30m':'30','1h':'60','4h':'240','1d':'D'}[tf] ?? '5';
  int _intervalSeconds(String tf) => const {'1m':60,'5m':300,'15m':900,'30m':1800,'1h':3600,'4h':14400,'1d':86400}[tf] ?? 300;
  bool _valid(double o,double h,double l,double c)=>[o,h,l,c].every((x)=>x.isFinite&&x>0)&&h>=o&&h>=c&&l<=o&&l<=c&&h>=l;
  int? _int(dynamic x)=>x is num?x.toInt():int.tryParse('$x');
  double? _number(dynamic x)=>x is num?x.toDouble():double.tryParse('$x');
  String _short(dynamic x){final s=x.toString();return s.length>220?'${s.substring(0,220)}…':s;}
}
class MarketApiException implements Exception {
  const MarketApiException(this.message);
  final String message;
  @override String toString()=>message;
}
