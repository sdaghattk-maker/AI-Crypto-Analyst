import 'dart:convert';

import 'package:http/http.dart' as http;

import 'app_config.dart';

class MarketCandle {
  const MarketCandle({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
  });

  final int time;
  final double open;
  final double high;
  final double low;
  final double close;

  Map<String, dynamic> toChartJson() => {
        'time': time,
        'open': open,
        'high': high,
        'low': low,
        'close': close,
      };
}

class MarketApi {
  Uri _uri(Map<String, String> query) => Uri.parse(
        AppConfig.binanceWorkerBaseUrl,
      ).replace(queryParameters: query);

  Future<Map<String, dynamic>> ping() async {
    final json = await _getJson(_uri({'endpoint': 'ping'}));
    if (json['ok'] == false) {
      throw MarketApiException('Worker بایننس پاسخ ناموفق داد: ${json['error'] ?? json}');
    }
    return json;
  }

  Future<double> getPrice(String symbol) async {
    final json = await _getJson(_uri({
      'endpoint': 'price',
      'symbol': symbol.toUpperCase(),
    }));
    final data = json['data'];
    final raw = data is Map ? data['price'] : json['price'];
    final price = double.tryParse(raw?.toString() ?? '');
    if (json['ok'] == false || price == null || !price.isFinite) {
      throw MarketApiException('قیمت معتبر از Worker دریافت نشد: $json');
    }
    return price;
  }

  Future<List<MarketCandle>> getKlines({
    required String symbol,
    required String interval,
    int limit = 500,
  }) async {
    final json = await _getJson(_uri({
      'endpoint': 'klines',
      'symbol': symbol.toUpperCase(),
      'interval': interval,
      'limit': limit.toString(),
    }));

    if (json['ok'] == false) {
      throw MarketApiException('دریافت کندل ناموفق بود: ${json['error'] ?? json}');
    }

    dynamic raw = json['data'];
    if (raw is Map) {
      raw = raw['klines'] ?? raw['data'];
    }
    if (raw is! List) {
      throw MarketApiException('ساختار پاسخ کندل قابل شناسایی نیست: ${json.keys.toList()}');
    }

    final nowMs = DateTime.now().millisecondsSinceEpoch;
    final candles = <MarketCandle>[];
    for (final item in raw) {
      if (item is! List || item.length < 7) continue;
      final openTime = _asInt(item[0]);
      final open = _asDouble(item[1]);
      final high = _asDouble(item[2]);
      final low = _asDouble(item[3]);
      final close = _asDouble(item[4]);
      final closeTime = _asInt(item[6]);

      // Use closed candles only to avoid repainting from the still-forming candle.
      if (openTime == null ||
          open == null ||
          high == null ||
          low == null ||
          close == null ||
          closeTime == null ||
          closeTime >= nowMs) {
        continue;
      }
      candles.add(MarketCandle(
        time: (openTime / 1000).floor(),
        open: open,
        high: high,
        low: low,
        close: close,
      ));
    }

    candles.sort((a, b) => a.time.compareTo(b.time));
    if (candles.isEmpty) {
      throw const MarketApiException('هیچ کندل بسته‌شده‌ای دریافت نشد.');
    }
    return candles;
  }

  Future<Map<String, dynamic>> _getJson(Uri uri) async {
    try {
      final response = await http
          .get(uri, headers: const {'Accept': 'application/json'})
          .timeout(AppConfig.requestTimeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw MarketApiException(
          'Worker خطای HTTP ${response.statusCode} برگرداند: ${_short(response.body)}',
        );
      }
      final decoded = jsonDecode(response.body);
      if (decoded is! Map<String, dynamic>) {
        throw const MarketApiException('پاسخ Worker از نوع JSON object نیست.');
      }
      return decoded;
    } on MarketApiException {
      rethrow;
    } catch (e) {
      throw MarketApiException('اتصال به Binance Worker ناموفق بود: $e');
    }
  }

  static int? _asInt(dynamic value) {
    if (value is int) return value;
    return int.tryParse(value?.toString() ?? '');
  }

  static double? _asDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse(value?.toString() ?? '');
  }

  static String _short(String value) =>
      value.length > 240 ? '${value.substring(0, 240)}…' : value;
}

class MarketApiException implements Exception {
  const MarketApiException(this.message);
  final String message;

  @override
  String toString() => message;
}
