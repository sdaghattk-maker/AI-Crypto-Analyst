
'use strict';
const $=id=>document.getElementById(id);
const SOURCE_NAMES=['تکنیکال اپ','Gemini','OpenRouter','Groq','altFINS'];
function safeText(v){if(v===null)return 'null';if(v===undefined)return '—';if(typeof v==='string'||typeof v==='number'||typeof v==='boolean')return String(v);return JSON.stringify(v,null,2)}
function flatten(value,prefix='',out={}){
  if(value&&typeof value==='object'&&!Array.isArray(value)){
    const keys=Object.keys(value);
    if(!keys.length){out[prefix||'(empty)']=value;return out;}
    for(const key of keys)flatten(value[key],prefix?prefix+'.'+key:key,out);
  }else out[prefix||'(value)']=value;
  return out;
}
function renderCell(value){
  if(value===undefined)return '<span class="cellmuted">در خروجی این منبع وجود ندارد</span>';
  if(value===null)return '<span class="cellmuted">null</span>';
  if(typeof value==='object'){
    const json=JSON.stringify(value,null,2);
    const title=Array.isArray(value)?`آرایه · ${value.length} مورد`:'مشاهده جزئیات';
    return `<details><summary>${title}</summary><pre class="details">${escapeHtml(json)}</pre></details>`;
  }
  const s=String(value),u=s.toUpperCase();
  const cls=/BUY|BULLISH|AVAILABLE|VALID|^OK$/.test(u)?'good':/SELL|BEARISH|ERROR|INVALID|UNAVAILABLE/.test(u)?'bad':/WAIT|RANGE|NEUTRAL|STALE|DEGRADED|NOT_FETCHED|UNSUPPORTED/.test(u)?'warn':'neutral';
  return `<span class="${cls}">${escapeHtml(s)}</span>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function addCard(label,value,hint=''){$('cards').insertAdjacentHTML('beforeend',`<div class="card"><div class="k">${escapeHtml(label)}</div><div class="v">${escapeHtml(value??'—')}</div>${hint?`<div class="hint">${escapeHtml(hint)}</div>`:''}</div>`)}
function statusPill(label,value,good){$('statusbar').insertAdjacentHTML('beforeend',`<span class="pill"><i class="dot ${good?'ok':'bad'}"></i>${escapeHtml(label)} <b>${escapeHtml(value??'—')}</b></span>`)}
function render(snapshot){
  if(snapshot?.schema!=='ai_crypto_analyst_exact_snapshot_v1')throw new Error('قالب فایل معتبر نیست. باید خروجی مستقیم اپ با schema نسخه exact_snapshot_v1 باشد.');
  const id=snapshot.identity||{},ai=snapshot.ai||{},alt=snapshot.altfins||{},hybrid=snapshot.hybrid||{};
  $('empty').classList.add('hidden');$('content').classList.remove('hidden');$('statusbar').innerHTML='';$('cards').innerHTML='';$('tbody').innerHTML='';
  statusPill('نماد',id.symbol,true);statusPill('صرافی',id.exchange,true);statusPill('Snapshot',id.snapshotId?String(id.snapshotId).slice(-18):'ارائه نشده',!!id.snapshotId);
  statusPill('اعتبار تکنیکال',id.technicalStale?'قدیمی / نامعتبر':'تازه',!id.technicalStale);
  statusPill('اعتبار AI',id.aiStale?'قدیمی / نامعتبر':ai?'تازه':'اجرا نشده',!id.aiStale&&!!ai);
  addCard('قیمت مرجع اپ',id.referencePrice??'ارائه نشده','عین مقدار خروجی اپ');
  addCard('تصمیم نهایی اپ',hybrid.decision??'ارائه نشده','بدون محاسبه مجدد');
  addCard('اجماع مستقل AI',ai.decision??'اجرا نشده','خروجی ذخیره‌شده سه مدل');
  addCard('مدل‌های معتبر',hybrid.validProviderCount??0,'از ۳ مدل');
  addCard('زمان تکنیکال',id.technicalAt??'ارائه نشده');
  addCard('زمان AI',id.aiAt??'ارائه نشده');
  addCard('زمان خروجی',snapshot.exportedAt??'ارائه نشده');
  addCard('تعداد کندل 1H / 15M / 5M',`${id.historyCount1h??0} / ${id.historyCount15m??0} / ${id.historyCount5m??0}`,'تاریخچه استفاده‌شده در اپ');
  const sources=[
    snapshot.technical??null,
    ai.gemini??null,
    ai.openrouter??null,
    ai.groq??null,
    {quota:alt.quota??null,timeframes:alt.timeframes??{}}
  ];
  // Reuse the AI Data Engine's canonical, already-normalized fields.
  // This layer only presents those fields; it does not translate raw prose or infer market facts.
  const sectionLabels={regime:'رژیم بازار',structure:'ساختار بازار',liquidity:'نقدینگی',poi:'نواحی مهم (POI)',premiumDiscount:'پرمیوم / دیسکانت',volumeMomentum:'حجم و مومنتوم',scenarios:'سناریوها',execution:'اجرای معامله',dataQuality:'کیفیت داده'};
  const categoryLabels={orderBook:'دفتر سفارش و عمق بازار',derivatives:'مشتقات (Funding / OI)',liquidations:'لیکوییدیشن‌ها',onChain:'آن‌چین و جریان صرافی',newsSentiment:'اخبار و احساسات بازار',providerSpecific:'شاخص‌های اختصاصی مدل'};
  const timeframeLabels={trend:'روند',structure:'ساختار',structureEvent:'رویداد ساختاری',phase:'فاز بازار',buyerStrength:'قدرت خریداران',sellerStrength:'قدرت فروشندگان',liquidity:'وضعیت نقدینگی',evidence:'شواهد'};
  function providerReadable(p){
    if(!p)return {};
    const out={};
    if(p.status)out['وضعیت پاسخ']=p.status;
    if(p.contractStatus)out['اعتبار استاندارد تحلیل']=p.contractStatus==='VALID'?'کامل و معتبر':p.contractStatus==='NORMALIZED'?'استخراج‌شده؛ فاقد شرایط رأی اجماع':'ناقص؛ فاقد شرایط رأی اجماع';
    if(p.bias)out['جهت تحلیل مدل']=p.bias;
    if(p.summary)out['خلاصه تحلیل']=p.summary;
    if(p.confidence!==undefined)out['اطمینان اعلام‌شده مدل (درصد)']=p.confidence;
    if(p.analysisSections&&typeof p.analysisSections==='object')for(const [k,v] of Object.entries(p.analysisSections)){
      if(!v||typeof v!=='object')continue;
      const state=({AVAILABLE:'قابل ارزیابی',NOT_AVAILABLE:'داده ارائه نشده',NOT_APPLICABLE:'نامرتبط',INSUFFICIENT_DATA:'داده ناکافی'})[v.status]||v.status||'وضعیت نامشخص';
      const findings=Array.isArray(v.findings)?v.findings.filter(Boolean):[];
      out[sectionLabels[k]||k]=[state,...findings].join(' · ');
    }
    if(p.timeframeAnalysis&&typeof p.timeframeAnalysis==='object')for(const tf of ['1h','15m','5m']){
      const t=p.timeframeAnalysis[tf];if(!t||typeof t!=='object')continue;
      if(t.provided===false){out[`تایم‌فریم ${tf.toUpperCase()}`]='اطلاعات این تایم‌فریم در پاسخ مدل ارائه نشده';continue;}
      const parts=[];for(const [k,label] of Object.entries(timeframeLabels)){const val=t[k];if(val===undefined||val===null||val===''||k==='evidence')continue;parts.push(`${label}: ${Array.isArray(val)?val.join('، '):typeof val==='object'?JSON.stringify(val):val}`);}
      if(Array.isArray(t.evidence)&&t.evidence.length)parts.push('شواهد: '+t.evidence.join('؛ '));
      if(parts.length)out[`تحلیل ${tf.toUpperCase()}`]=parts.join(' | ');
    }
    if(Array.isArray(p.observations)&&p.observations.length)out['مشاهدات مدل']=p.observations.join(' · ');
    if(Array.isArray(p.risks)&&p.risks.length)out['ریسک‌ها و هشدارها']=p.risks.join(' · ');
    if(p.invalidation)out['شرط ابطال سناریو']=p.invalidation;
    if(p.dataCategories&&typeof p.dataCategories==='object')for(const [k,items] of Object.entries(p.dataCategories)){
      if(!Array.isArray(items)||!items.length)continue;
      out[categoryLabels[k]||k]=items.map(x=>typeof x==='object'?(x.text||''):String(x)).filter(Boolean).join(' · ');
    }
    return out;
  }
  const techMap=flatten(sources[0]||{});
  const altMap=flatten(sources[4]||{});
  const maps=[techMap,providerReadable(ai.gemini),providerReadable(ai.openrouter),providerReadable(ai.groq),altMap];
  const labelPath=path=>{const leaf=path.split('.').pop();const labels={decision:'تصمیم',bias:'جهت بازار',confidence:'اطمینان',summary:'خلاصه',status:'وضعیت',findings:'یافته‌ها',trend:'روند',structure:'ساختار',phase:'فاز بازار',liquidity:'نقدینگی',entry:'نقطه ورود',stopLoss:'حد ضرر',takeProfit:'حد سود',price:'قیمت',timeframe:'تایم‌فریم',signal:'سیگنال',strength:'قدرت',volume:'حجم',rsi:'RSI',macd:'MACD',ema:'EMA',atr:'ATR',quota:'سهمیه'};return labels[leaf]||path.replaceAll('.',' / ')};
  const normalizedMaps=maps.map((map,i)=>i===1||i===2||i===3?map:Object.fromEntries(Object.entries(map).map(([k,v])=>[labelPath(k),v])));
  const keys=[...new Set(normalizedMaps.flatMap(x=>Object.keys(x)))];
  const groups=[['خلاصه و وضعیت',['وضعیت پاسخ','اعتبار استاندارد تحلیل','جهت تحلیل مدل','خلاصه تحلیل','اطمینان اعلام‌شده مدل (درصد)','تصمیم','bias','decision','summary']],['تحلیل ساختاریافته بازار',['رژیم بازار','ساختار بازار','نقدینگی','نواحی مهم (POI)','پرمیوم / دیسکانت','حجم و مومنتوم','سناریوها','اجرای معامله','کیفیت داده']],['تایم‌فریم‌ها',['تحلیل 1H','تحلیل 15M','تحلیل 5M']],['شواهد، ریسک و داده‌های تکمیلی',['مشاهدات مدل','ریسک‌ها و هشدارها','شرط ابطال سناریو',...keys.filter(k=>/دفتر سفارش|مشتقات|لیکوییدیشن|آن‌چین|اخبار|شاخص‌های اختصاصی/.test(k))]],['سایر داده‌های فنی',['*']]];
  let rowTotal=0;
  for(const [group,requested] of groups){const groupKeys=requested[0]==='*'?keys.filter(k=>!groups.slice(0,4).some(g=>g[1].includes(k))):requested.filter(k=>keys.includes(k));if(!groupKeys.length)continue;
    const g=document.createElement('tr');g.className='group';const td=document.createElement('td');td.colSpan=6;td.textContent=group;g.appendChild(td);$('tbody').appendChild(g);
    for(const key of groupKeys){const tr=document.createElement('tr');const name=document.createElement('td');name.textContent=key;tr.appendChild(name);for(const map of normalizedMaps){const cell=document.createElement('td');cell.innerHTML=renderCell(Object.prototype.hasOwnProperty.call(map,key)?map[key]:undefined);tr.appendChild(cell);} $('tbody').appendChild(tr);rowTotal++;}
  }
  $('rowCount').textContent=`${rowTotal} ردیف خوانا · بر پایه فیلدهای استانداردشده موتور تحلیل`;
  $('consensusMeta').textContent=JSON.stringify({decision:ai.decision??null,conflicts:ai.conflicts??null,aiOverlays:ai.aiOverlays??null,snapshotId:ai.snapshotId??null},null,2);
  $('hybridMeta').textContent=JSON.stringify(hybrid,null,2);
  $('raw').textContent=JSON.stringify(snapshot,null,2);
}
window.loadSnapshotFromApp = function(snapshot){
  document.body.classList.add('app-mode');
  render(snapshot);
  const subtitle=document.querySelector('.sub');
  if(subtitle) subtitle.textContent='اتصال مستقیم به اپلیکیشن · داده‌های همان Snapshot بدون محاسبه مجدد';
};
$('snapshotFile').addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;try{const parsed=JSON.parse(await file.text());render(parsed);}catch(err){alert('فایل بارگذاری نشد: '+err.message);}finally{e.target.value='';}});
$('clearBtn').addEventListener('click',()=>{$('content').classList.add('hidden');$('empty').classList.remove('hidden');$('statusbar').innerHTML='';$('cards').innerHTML='';$('tbody').innerHTML='';$('raw').textContent='';$('consensusMeta').textContent='';$('hybridMeta').textContent='';});
