# AI Auto Model Selection Repair — V6.3.3.0

## Root causes fixed
- Flutter previously filtered Gemini and Groq live catalogs through a hard-coded local shortlist, hiding account-available models not present in that shortlist. Flutter now preserves the complete Worker-ranked live catalog for every provider.
- Provider health previously returned only the first inference-probed model to the full analysis request. A user-selected fallback could therefore be discarded after the primary passed the tiny health probe but failed on the larger analysis prompt. Health now returns the primary plus at most one live-catalog-eligible fallback; the primary is explicitly marked `PROBED` and the fallback `CATALOG_ELIGIBLE_UNPROBED`.
- Full analysis now receives the bounded primary/fallback candidate sequence and can attempt the fallback if the primary fails. Provider-wide rate limits still stop retries to avoid amplifying quota errors.
- Smart Connectivity now displays the selected model, fallback candidate, and attempted model IDs rather than hiding model-selection behavior.
- Worker ranking version updated to `2026-11-22.3-live-catalog-fallback`.

## Validation
- `node --check ai-gateway/worker.js`
- Full Node suite: 150 passed, 0 failed.
- Added coverage for live catalog preservation and fallback use after primary analysis failure.

## Not claimed
- No Cloudflare deployment was performed.
- No live Gemini/OpenRouter/Groq credentials or provider requests were available to this local test run.
- Flutter/Dart SDK build and APK validation were not performed in this environment.
