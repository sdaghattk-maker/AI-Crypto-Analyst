# Navigation and AI page reorganization — 2026-11-20

## Navigation
- Renamed the Dashboard destination from «بازار» to «داشبورد».
- Added a dedicated «اتصال هوشمند» destination backed by `SmartConnectivityScreen`.
- Added a dedicated «منابع بازار» destination backed by `MarketSourcesScreen`.
- Existing Dashboard, Chart, and AI Analysis destinations remain available.

## AI Analysis page
- Removed the Smart Connectivity status panel and its connectivity probe lifecycle.
- Removed altFINS quota, cache, validation, and Market Intelligence panels and their lifecycle from AI Analysis.
- Kept AI provider analysis, model comparison, hybrid evaluation, and technical context.
- Moved provider/model selection and fallback controls into the final «تنظیمات هوشمند» card at the bottom of the AI Analysis page.

## New pages
- Smart Connectivity owns gateway/provider route diagnostics and refresh action.
- Market Sources owns altFINS quota/cache/15m+1h validation and Market Intelligence comparison.
- Market Intelligence continues to treat altFINS as external corroboration only; it does not cast an AI vote or alter Technical/Hybrid decisions.

## Request lifecycle and data safety
- altFINS quota is no longer probed by Smart Connectivity because quota belongs to Market Sources; this avoids duplicate quota requests.
- altFINS cache remains context-keyed by exchange/symbol. Fresh validation uses the existing service cache/rate-limit behavior.
- Market Intelligence reads the existing AnalysisController report and current-snapshot AI consensus; it does not issue new AI model requests.
- Existing Gateway, Binance Proxy, and Chart Analyzer routing is unchanged.

## Validation limits
- Flutter/Dart SDK is not installed in this environment. Flutter analyze, Dart formatting/tests, Android build, and device UI verification were not run.
