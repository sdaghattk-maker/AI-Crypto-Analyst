# Index HTML — AI Data Engine readable output

- Replaced raw recursive flattening of AI provider payloads with presentation of the existing normalized AI Data Engine fields: `analysisSections`, `timeframeAnalysis`, `dataCategories`, summary, observations, risks and invalidation.
- Preserved source separation for Technical, Gemini, OpenRouter, Groq and altFINS. Missing source values remain missing; no cross-source substitution or new market inference is performed.
- Added Persian labels and readable section statuses while preserving original provider text and the complete raw snapshot in the audit section.
- Reduced table minimum width and per-column widths for mobile screens.
- Updated both `assets/index.html` (in-app WebView) and root `index.html` (standalone copy) identically.

## Validation
- JavaScript syntax check (`node --check`): passed.
- ZIP integrity check: passed.
- Flutter analyze, Android APK build and on-device visual verification: not run in this environment.
