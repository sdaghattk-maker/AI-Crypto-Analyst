# AI Crypto Analyst — Post Data Engine Pipeline Audit

Date: 2026-11-21
Baseline: `AI-Crypto-Analyst-DATA-ENGINE-QUALITY-REPAIR-FINAL-2026-11-21.zip`

## Stage 2 — Model response extraction and normalization

- Hardened persisted confidence parsing: only finite values in the inclusive 0–100 range remain declared; malformed or out-of-range values become unavailable.
- Hardened numeric analytical-weight/factor-score restoration: all five keys, integer 0–100 values, and the exact 100-point weight total are validated before `weightsProvided` can remain true.
- Kept the raw provider envelope and extracted response fields intact.

## Stage 3 — Semantic and evidence validation

- A directional model plan must agree with its own 5m trend, or have a matching candle-validated bullish/bearish BOS, CHOCH, or MSS event on 5m.
- If both 1h and 15m oppose the proposed trade, a matching candle-validated reversal event on 1h or 15m is required. A naked 5m counter-move is not enough.
- Inconsistent directional model output is downgraded to WAIT and its execution levels are removed. Confirmed evidence types outside the candle-backed BOS/CHOCH/MSS and sweep validators remain unverified instead of silently passing.
- AI buyer/seller percentages are now explicitly tagged as provider-declared values (`MODEL_RESPONSE`) rather than being mislabeled as independently computed OHLCV pressure. The UI and HTML index describe their provenance accurately. Technical Engine OHLCV pressure remains a separate calculation.

## Stage 4 — Consensus integrity

- Partial provider merges no longer union all individual model overlays into an aggregate AI overlay list.
- Aggregate AI overlays now require matching type, kind, direction, timeframe and price/zone overlap from at least two eligible agreeing providers. A single model cannot create a consensus overlay, and a third model cannot veto an otherwise valid pair.
- The same merge path now excludes directional provider responses whose own 5m Entry/SL/TP1/TP2/TP3 plan is incomplete, directionally inconsistent, or below the minimum 1R/1.5R/2R target requirements.

## Stage 5–6 — Technical comparison and Final Decision

- AI remains an independent source and its consensus is computed without reading the Technical Engine direction.
- Final Decision now treats AI strictly as confirmation: a directional Technical Engine decision with a complete, correctly ordered and minimum-R/R execution plan is required; at least two eligible AI providers must agree with the AI consensus; and the AI consensus must match the Technical direction. Technical WAIT, invalid Technical levels, AI WAIT, missing qualified votes, or directional conflict all produce WAIT.
- Per-provider Hybrid cards are also prevented from showing a directional result when the provider response is not `ok`, the V3 contract/evidence is not valid, confidence is undeclared/below 55, or its execution plan is invalid.
- The dashboard's timeframe consensus excludes incomplete, stale, or evidence-unverified AI providers. AI buyer/seller percentage cards distinguish model-declared percentages from the Technical Engine's OHLCV estimate.
- Market Intelligence now compares altFINS 15m/1h against the matching Technical and AI timeframe, not the overall trade bias; stale or incomplete sources are excluded and AI timeframe consensus still requires two matching models.

## Stage 7 — Presentation and provenance

- Unified dashboard provider eligibility with Hybrid voting and retry selection; incomplete or unqualified successful HTTP responses can now be retried. Updated the dashboard reason text to explain whether WAIT is caused by a neutral Technical Engine, invalid Technical execution levels, absent AI consensus, insufficient qualified models, or directional disagreement.
- Updated the exact HTML index labels and kept `index.html` and `assets/index.html` byte-identical.
- Synced both root and nested legacy-named Worker text snapshots to the current `ai-gateway/worker.js` source and added automated mirror tests.

## Verification

- Worker and browser-script syntax checks passed.
- Node test suite: **85 passed, 0 failed, 0 skipped** (including Worker/HTML mirror integrity checks).
- The new Worker regression tests cover 5m trend disagreement, fully opposing 1h/15m structure without validated reversal, and correct provenance for model-declared buyer/seller percentages.
- Existing tests continue to cover provider independence, same immutable prompt/snapshot, response normalization, evidence validation, POI/OB/FVG checks, coherent Entry/SL/TP plans, consensus confidence rules, candle quality, altFINS limitations, and chart export.

## Verification boundary

- Flutter/Dart SDK is unavailable in this environment. Dart unit tests, `dart format`, `flutter analyze`, and Android APK build could not be executed. Dart changes and regression tests are included but require the repository's Flutter CI/device build for compilation confirmation.
- No live Gemini/OpenRouter/Groq or altFINS requests were made.
- No Cloudflare Worker was deployed and no GitHub repository content was changed.
- No API keys, secrets, or deployed services were modified.


## Follow-up audit — dashboard/consensus consistency

A second end-to-end pass found gaps not covered by the original 83 JavaScript tests:

- Dashboard provider cards used a weaker validity predicate than Hybrid final-decision logic. A provider could appear valid in the UI despite missing declared confidence or a coherent execution plan. A shared Dart eligibility predicate now gates Hybrid votes, provider cards, and retry selection consistently.
- Persisted `weightsProvided=true` could be trusted even when analytical-weight/factor-score maps were malformed or incomplete. Deserialization now validates all five required keys, numeric integer ranges, and the 100-point analytical-weight total before preserving the flag.
- Flutter-side aggregate overlays required every agreeing provider to match the same overlay. Pairwise corroboration now follows the specified minimum-two-independent-providers rule; a third agreeing model cannot veto a valid pair. The pair provenance is retained on each aggregate overlay.
- A direct partial merge could mix provider results from different Snapshot IDs. Mismatched identified snapshots now return the incoming snapshot without mixing providers.
- A transport error during a same-snapshot retry could overwrite a previously successful provider answer. The successful answer is now retained and the failed retry is surfaced as a conflict diagnostic.
- The retry list previously omitted HTTP-successful but semantically degraded/unqualified provider responses. It now includes any selected response that fails the shared consensus-eligibility rule.

Regression tests were added for malformed factor evidence, pairwise overlay agreement with a third non-matching provider, cross-snapshot merge rejection, preservation of a successful answer after a failed retry, invalid Technical execution plans, and altFINS timestamp freshness (missing, stale and fresh source timestamps).

## Follow-up audit — optional strength data and route-level protection

- Buyer/seller OHLCV pressure is now optional per timeframe. When the provider cannot derive a reliable pair because volume is absent or unusable, both fields remain null and that sub-section is marked `INSUFFICIENT_DATA`; the missing pair alone no longer downgrades an otherwise complete timeframe contract. Two supplied numeric scores that are not complementary remain `UNVERIFIED` and do not qualify the timeframe contract.
- Updated the model instruction and nullable numeric schema definition so unavailable strength is represented as JSON null, never a fabricated percentage or the string `UNKNOWN`.
- Added route-scoped Cloudflare rate-limit buckets for `/models`, `/altfins/quota`, `/altfins/diagnostics`, `/altfins/validation`, authenticated `/provider-test`, and `/analyze`. Catalog/quota/connectivity requests cannot consume the primary analysis bucket. New externally costly routes fail closed when the binding is absent or fails.
- Added regression coverage for missing strength, preserved rejection of non-complementary independent scores, rate-limit denial before upstream calls, route-key isolation, and missing-binding behavior.
- Updated both distributable Worker text mirrors to match `ai-gateway/worker.js` exactly.

## Final local verification after follow-up

- JavaScript syntax checks passed for both Workers and the HTML check script.
- Node regression suite: **90 passed, 0 failed, 0 skipped, 0 todo**.
- Worker text mirrors and root/Android HTML mirrors are byte-identical.
- Flutter/Dart SDK is not available in this environment; Dart tests, formatter, analyzer and APK build remain unverified locally and must be confirmed by Flutter CI or a Flutter development environment.
- No live provider/altFINS calls, GitHub changes, or Worker deployment were performed.


## اصلاحات موتور تبدیل داده — نسخه تکمیلی

- مقادیر buyerStrength/sellerStrength در خروجی AI، درصدهای اعلام‌شده توسط خود مدل هستند؛ نباید با برآورد مستقل فشار کندلی OHLCV در Technical Engine یکی یا با آن برچسب‌گذاری شوند.
- Worker اکنون `rawTextTruncated` و `rawTextOriginalLength` را برای متن استخراج‌شده و `rawProviderResponseTruncated` و `rawProviderResponseOriginalLength` را برای بدنه خام HTTP برمی‌گرداند. سقف متن استخراج‌شده ۲۰٬۰۰۰ نویسه و سقف بدنه خام HTTP برابر ۱۰۰٬۰۰۰ نویسه است.
- قرارداد `normalization` باید بدون حذف فیلدها به Flutter منتقل شود؛ شامل قالب منبع، ناقص بودن ساختار، وضعیت برنامه معاملاتی، فهرست موارد مفقود، ناسازگاری سطوح و وضعیت قطع‌شدن متن خام و رسیدن خود مدل به سقف تولید.
- کدگذاری تاریخچه OHLCV «Lossless» نیست: تغییرات قیمت به نزدیک‌ترین عدد صحیح ppm گرد می‌شوند (مقیاس ۱٬۰۰۰٬۰۰۰) و نسبت حجم به نزدیک‌ترین ۰٫۰۱ گرد و در ۱۰٬۰۰۰ برابر میانه حجم سقف‌گذاری می‌شود. یک ردیف برای هر کندل و ترتیب زمانی حفظ می‌شود، اما مقادیر اصلی دقیقاً بازسازی‌پذیر نیستند.

- Regression coverage after this repair: **95 Node tests passed, 0 failed**. Added coverage for explicit raw-text truncation metadata, quantized OHLCV metadata and volume-ratio cap, model-declared strength labeling, normalization serialization in Dart tests, and source/documentation mirrors. Dart tests are authored but could not be executed without Flutter/Dart SDK.
