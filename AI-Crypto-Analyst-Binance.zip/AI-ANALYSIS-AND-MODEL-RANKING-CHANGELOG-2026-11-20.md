# AI Analysis Contract v2 + Model Catalog Expansion — 2026-11-20

## Implemented

1. Expanded the provider-specific ordered candidate lists in both Flutter and Worker.
2. Gemini list expanded from 2 to 7 Flash/Flash-Lite candidates.
3. OpenRouter list expanded from 1 to 9 candidates, including low-cost models and free variants that support structured output.
4. Groq list expanded from 2 to 5 candidates, subject to live catalog availability.
5. OpenRouter no longer filters exclusively to zero-price models. It now requires text input/output, >=32K context, structured_outputs support, and either zero price or <=$2/M input and <=$6/M output.
6. OpenRouter free variants without structured_outputs are excluded even if they are $0. This avoids choosing a free model that cannot satisfy the common response contract.
7. Worker fallback tries selected primary, selected secondary, then ranked remaining candidates; max 4 attempts/provider.
8. Added shared AI Analysis Contract v2 prompt fields: three timeframe summaries, evidence, invalidation, standardized bias/summary/risk/weights/scores/overlays.
9. Added Worker contract normalizer and VALID/DEGRADED status. Missing/invalid v2 fields set `weightsProvided=false`, so incomplete legacy responses cannot supply qualified Hybrid weights.
10. Flutter parses and displays contract status, 1h/15m/5m structured analysis, evidence and invalidation.
11. Worker scans narrative fields for price-like numbers outside the submitted historical envelope; such claims are sanitized and downgrade the model to WAIT/DEGRADED with no qualified Hybrid weight.
11. Added regression tests for low-cost OpenRouter models, filtering unsupported/expensive models, >2-step fallback and degraded contract behavior.

## Model order and cost policy

See `MODEL-QUALITY-RANKING-2026-11-20.md`. The order is a provisional capability/availability priority, not a measured trading-performance rank. OpenRouter low-cost threshold is USD 2/M input and USD 6/M output. Provider catalogs determine actual availability.

## Tests

- AI Gateway Node tests: 32/32 pass.
- Binance Proxy Node tests: see delivery report.
- Flutter/Dart tests and APK build are not claimed unless run in an environment with Flutter/Dart installed.

## Not done / requires deployment validation

- No Cloudflare deployment performed.
- No GitHub push or PR created.
- No APK built in this environment.
- No live calls against the user's API keys or provider accounts.
- The new v2 output contract needs a real-device test against all three currently connected provider accounts. A model may fail strict schema or Persian-field requirements; that response should remain DEGRADED/INVALID rather than being silently accepted as qualified.
