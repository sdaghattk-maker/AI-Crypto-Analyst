# AI Timeframe Narrative Recovery Repair — 2026-11-21

## Verified baseline
- Input archive: `AI-Crypto-Analyst-GROQ-PRICE-VALIDATION-REPAIR-FINAL-2026-11-21-V4.zip`
- Input SHA256: `f059ee9d3ede5215cc70476537f7293090b1918e237c88156f6096132cf6dd5a`
- Input size: 468,438 bytes; ZIP integrity verified before extraction.

## Root causes confirmed in source
1. Plain-text model replies were retained in `rawText`, but `normalizeTimeframeContractV3` did not inspect that complete text. The short `summary` field was capped at 420 characters, so timeframe details later in the report were invisible to the timeframe parser.
2. Persian/Arabic digit normalization converted ۱۵ and ۵ to ASCII digits, while minute aliases did not consistently accept the normalized `15 دقیقه` and `5 دقیقه` forms.
3. The normalizer preferred one structured timeframe root as a whole. If that root contained only 1H, explicitly described 15M/5M trends in the same provider's narrative were discarded.
4. Dashboard structure cells required the provider's entire three-timeframe contract and evidence validation to be globally VALIDATED. One incomplete timeframe therefore hid usable information from other timeframes.
5. Simply extracting narrative across all JSON branches could incorrectly stitch distinct timeframe branches. This was caught by the existing Groq split-branch regression and explicitly prevented.

## Implemented in this repair
- Timeframe narrative extraction now reads the complete `rawText` and relevant narrative fields, rather than relying on the short summary.
- Added Persian/English aliases for 1H, 15M and 5M, including hourly wording and Persian minute descriptions after digit normalization.
- Structured data remains authoritative. Narrative data fills only missing timeframes from the same provider response; it never overwrites a structured field.
- Narrative-derived trends are tagged with `source=NARRATIVE` and `narrativeOnly=true`; combined frames are tagged `STRUCTURED_WITH_NARRATIVE`.
- Narrative text never fabricates a confirmed BOS/CHOCH/MSS event: `structureEvent` remains UNKNOWN unless independently structured and validated.
- Separate Groq branches are not stitched together through evidence text or raw HTTP envelopes.
- Dashboard timeframe cells now show each available provider timeframe independently. Narrative-only trends are explicitly labelled and excluded from consensus votes. Consensus still requires a complete valid contract and validated evidence.
- The normalization diagnostics now report recovered timeframes, narrative-only timeframes, and each timeframe's source. Flutter's conversion report explains that narrative recovery is not candle confirmation.
- Worker snapshots `AI-GATEWAY-WORKER.txt` and `ai-gateway/AI-GATEWAY-WORKER.txt` are synchronized with `ai-gateway/worker.js`.

## Regression coverage
- Long Persian plain-text report where all timeframe sections occur after the 420-character summary limit.
- Independent 1H/15M/5M trend extraction from Persian narrative.
- Structured 1H plus narrative-only 15M/5M supplementation.
- Same Persian prose delivered through Gemini, OpenRouter and Groq provider envelopes.
- Narrative-only trend does not become a confirmed structure event or consensus vote.
- Existing Groq test confirms that 1H and 5M in separate structured branches are not stitched into a false complete timeframe contract.
- Existing BOS/CHOCH, evidence validation, price validation, raw response, and Worker mirror tests remain passing.

## Verification result
- JavaScript syntax checks: passed.
- Node regression suite: **103 passed, 0 failed, 0 skipped**.
- Both Worker text snapshots match the canonical Worker byte-for-byte.
- `index.html` and `assets/index.html` match byte-for-byte.
- ZIP integrity checked after packaging.

## Explicit limitations
- Flutter and Dart SDK are unavailable in the execution environment; `dart format`, `flutter analyze`, Dart/Flutter tests, and APK build were not run.
- Gemini, OpenRouter and Groq were tested with deterministic mocked provider envelopes, not live API requests.
- No Cloudflare Worker deployment, GitHub push, or APK publication was performed.
- Narrative-only trend recovery is display-only; it does not make an incomplete provider eligible for AI consensus or a trade decision.
