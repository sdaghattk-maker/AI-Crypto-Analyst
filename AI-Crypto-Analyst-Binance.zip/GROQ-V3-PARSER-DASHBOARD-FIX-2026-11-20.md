# Groq V3 Parser + Dashboard Fix — 2026-11-20

## Root cause addressed
Some Groq responses can place the complete V3 JSON object inside a string field such as `summary` or `analysis`. The gateway previously treated that serialized object as narrative summary text, so the app displayed raw JSON and the actual structured fields were not extracted.

## Changes
- Added a guarded nested-payload unwrapping step in `ai-gateway/worker.js`. It only unwraps JSON strings when the parsed object contains known analysis-contract keys (`contractVersion`, `analysisSections`, `timeframeAnalysis`, `bias`, or `overlays`).
- The unwrapped object is passed through the existing V3 normalizers and validators; the validity gates and consensus requirements are not weakened.
- JSON-shaped summary text is no longer used as the user-facing summary. A neutral Persian summary is shown while structured findings are rendered separately.
- Dashboard provider details now display available `analysisSections` findings even when a provider is structurally incomplete and therefore not eligible for consensus.
- The dashboard's source-level structure card can show the provider's own `structure` findings, while explicitly stating that per-timeframe 1H/15M/5M structure was not provided. It does not substitute Technical Engine values.
- Provider status labels distinguish a received partial/normalized report from a valid consensus-eligible answer.
- Synchronized the deployable Worker text copies with `ai-gateway/worker.js`.

## Safety / decision behavior
- No fabricated timeframe values are created.
- No Technical Engine or peer-model values are copied into Groq.
- Partial/normalized Groq reports remain excluded from consensus unless they pass the existing `VALID` + weights + bias requirements.
- Raw provider response remains available in `rawText` for diagnostics; it is not used as the main dashboard narrative.

## Validation
- `node --check ai-gateway/worker.js`: passed.
- ZIP integrity: validated after packaging.
- Flutter/Dart SDK is not available in this environment; Flutter analyze/build and device runtime validation were not performed.
