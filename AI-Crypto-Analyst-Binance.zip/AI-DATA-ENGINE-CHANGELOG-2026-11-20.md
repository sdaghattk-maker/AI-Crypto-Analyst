# AI Data Engine change log — 2026-11-20

- Removed mandatory provider-wide V3 JSON Schema from Gemini, OpenRouter and Groq requests.
- Updated provider instructions to request rich, evidence-based analysis in each provider's best supported response format.
- Added tolerant ingestion for plain-text responses and common JSON aliases.
- Preserved raw provider responses (up to 12,000 characters) for inspection rather than discarding unrecognized fields.
- Missing canonical sections now become explicit `INSUFFICIENT_DATA`; no missing facts are fabricated.
- Optional weights/scores no longer cause an otherwise useful analysis to be discarded.
- Incomplete/inconsistent execution plans are retained as analysis but are not allowed to become executable trades; price, POI, reference-anchor and historical-envelope checks remain.
- Updated worker tests for provider-native formats.

Validation: Node syntax check and 42 Worker/Binance proxy tests pass. Flutter/Android build, live API calls and Cloudflare deployment were not available in this environment.
