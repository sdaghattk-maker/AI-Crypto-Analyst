# Chart Candle Visibility Fix — 2026-11-20

## Root cause
`assets/chart.html` rendered the selected-source POI zones after the candle layer with `globalAlpha=1`. The full-width OB/FVG rectangles therefore painted opaque red/green fills over candle bodies and wicks. In addition, every overlay was allowed to expand the visible price range, including distant levels, which could compress candle height.

## Changes
- Render POI zone fills before the candle layer.
- Reduce zone fill opacity to 0.13 and retain a dashed boundary.
- Render candles after zones so candle bodies and wicks remain legible.
- Keep trade level lines and their labels above candles.
- Allow only overlays near the visible candle range (within 35% of candle-range span) to influence autoscale; distant overlays no longer flatten the chart.
- Preserve the selected-source rule: only the chosen Technical or AI source is passed to the chart.

## Validation
- Extracted inline JavaScript from `assets/chart.html` and passed `node --check`.
- ZIP integrity checked after packaging.
- Flutter build/device rendering was not run in this environment; visual confirmation on the Android app is still required.
