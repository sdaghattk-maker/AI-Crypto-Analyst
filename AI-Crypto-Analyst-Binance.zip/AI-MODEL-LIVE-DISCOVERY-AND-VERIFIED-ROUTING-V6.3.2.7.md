# AI Model Live Discovery & Verified Routing — V6.3.2.7

## Scope
Only model discovery, eligibility, ranking, health probing, and carrying the exact probed candidates into the analysis request were changed. No market-data, technical-analysis, consensus, UI, Cloudflare production configuration, secrets, or API keys were changed.

## Root cause addressed
The previous Worker treated a static curated model shortlist as authoritative for Gemini and Groq and only fetched live catalogs in selected circumstances. A model name present in source code was therefore treated as eligible even when the current provider account did not expose it. Newly released/renamed models could also be omitted. The health check could probe one model while the full analysis request later selected a different model or repeated a failed candidate.

## Changes
- Fetch each selected provider's live account catalog during health selection, including IDs already present in the local shortlist.
- Gemini: retain live `generateContent` text-generation Gemini/Gemma models with a usable context window; exclude audio, image, embedding, transcription, moderation, and specialized non-chat model families.
- Groq: retain active text models with at least 16K context; exclude speech, transcription, moderation, guard, embedding, preview/playground families.
- OpenRouter: use the account-filtered `/api/v1/models/user` catalog (provider preferences, privacy settings and guardrails), then retain concrete text-in/text-out models with free/zero pricing and at least 16K context; no router alias.
- Rank live candidates by curated capability preference first, then retain newly discovered live candidates instead of dropping everything outside the static list.
- A stale saved model ID no longer blocks automatic selection; only IDs actually present in the current live catalog can be chosen.
- Probe ranked candidates using the existing tiny real text inference probe. Only a model that actually returned a non-empty inference response is passed to analysis as verified; an unprobed second catalog entry is never mislabeled as a verified fallback. Provider-wide 429/TPM still stops further probes.
- Health returns the exact successful model and remaining verified fallback sequence. Flutter forwards that exact sequence to `/analyze`.
- `/analyze` rechecks that the exact verified model still exists in the live catalog. It will not silently substitute an unprobed model if the catalog changed between health and analysis. If a provider catalog cannot be fetched, selection fails closed with `MODEL_CATALOG_UNAVAILABLE` rather than reverting to stale hard-coded IDs.
- Circuit breaker state is keyed per provider (`provider:auto`) so health and analysis share the same provider-level circuit state, including when the second candidate becomes the successful model.
- Worker source mirrors are byte-identical.

## Validation
- `node --check ai-gateway/worker.js`: passed.
- `node --test test/*.test.mjs ai-gateway/tests/*.test.mjs binance-proxy/tests/*.test.mjs`: 147 tests passed, 0 failed (final run recorded separately below).
- Flutter/Dart SDK is not installed in this environment; Flutter analyzer/tests and APK build were not run.
- No live provider account/API inference was run. OpenRouter `/models/user` is account-filtered according to the API documentation; actual eligibility is still confirmed only by the runtime inference probe. Actual available models remain account-dependent and are verified by the deployed Worker at runtime.
- No Cloudflare deployment was performed. Production Worker, bindings, secrets, and API keys remain untouched.
