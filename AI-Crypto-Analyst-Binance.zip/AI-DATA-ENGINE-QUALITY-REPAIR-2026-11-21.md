# AI Data Engine Quality Repair — 2026-11-21

## Scope

This repair is based on `AI-Crypto-Analyst-AI-DATA-ENGINE-VALIDATION-FIX-2026-11-21.zip`. It addresses data integrity, semantic validation, independent provider handling, and source consistency. Existing Technical BUY/SELL signal rules were not intentionally redesigned.

## Stage 1 — Candle integrity and history preservation

- Removed the destructive 10-bucket OHLC aggregation. Every original closed candle remains in chronological order in the compact quantized delta-OHLCV history sent to the models.
- Added strict Worker checks for the expected 1h/15m/5m interval, row encoding, OHLC bounds, volume, duplicate/missing intervals, stale/future history, and minimum history length.
- Added app-side validation for closed candles, OHLCV correctness, strict interval continuity, UTC interval-boundary alignment, and per-timeframe freshness.
- Tightened raw exchange-page parsing: duplicate/out-of-order rows, malformed/non-integer timestamps, malformed OHLCV, invalid Binance close times, and misaligned candle opens are rejected before map-based normalization can hide them. Cross-page overlap is accepted only when values are identical at an unchanged historical timestamp; only the newest tail candle may be revised during refresh. Integrity failures are never swallowed by the chart's stale-cache fallback.
- The Worker reconstructs the last 5m close and verifies that it matches `lastClosed5mClose`; it also checks the live reference price against that reconstructed close.
- Missing candles are rejected; no synthetic candles are interpolated.

## Stage 2 — Semantic extraction and raw response retention

- BSL/SSL are now liquidity-pool labels. They are not converted into sweep events unless a sweep is explicitly reported.
- Negated/unconfirmed/rejected BOS, CHOCH, and MSS statements cannot be normalized into confirmed directional events.
- POI overlays preserve status, timestamp, provider evidence, and provenance. Mitigated/invalidated zones are visually distinguished.
- The provider HTTP response envelope is retained separately from extracted model text and the normalized contract. The response is capped at 100,000 characters with an explicit truncation flag and original length; extracted raw text is capped at 20,000 characters with its own truncation flag and original length.
- Raw provider responses and the full normalization diagnostics are carried through the Dart model/cache and exposed in collapsed diagnostic sections.

## Stage 3 — Candle-backed market evidence validation

- Schema completeness and market-evidence validity are separate (`contractStatus` / `schemaStatus` versus `evidenceStatus`).
- Confirmed BOS/CHOCH/MSS claims require a matching timeframe, exact candle timestamp, event price, reference level, swing break, and the relevant trend/displacement checks.
- Confirmed liquidity sweeps require a prior liquidity pool, wick penetration, and close reclaim across the level.
- OB/FVG zones are checked against the source timeframe's actual candle pattern. OB candidates require a directionally correct source candle and subsequent displacement; FVG boundaries must match the three-candle gap. Later overlap downgrades an active zone to mitigated.
- Swing levels are checked against actual pivot candles. Unsupported POIs remain visible as unverified diagnostics but cannot qualify an execution plan.
- Overlay distance limits use timeframe ATR plus the historical envelope rather than a single fixed percentage for every asset/volatility regime.
- Narrative price checking now supports decimal/low-priced assets, including Persian digits and decimal separators.
- Directional provider output is downgraded to WAIT when its evidence or active POI cannot be validated. AI consensus and Hybrid eligibility require `evidenceStatus=VALIDATED`.
- Technical buyer/seller pressure is explicitly an OHLCV estimate. Zero-volume candles are excluded; the estimate is hidden when fewer than five usable samples exist. No order-flow/delta claim is made.

## Stage 4 — Independent providers and source consistency

- Gemini, OpenRouter, and Groq receive the same prompt built once from the same immutable `snapshotId`, market type, reference price, and compact quantized candle history. Automated tests compare the exact prompt strings.
- The AI prompt explicitly states that altFINS, Technical Engine outputs, order book, funding, OI, liquidation, taker delta, and news are not provided to the model in that request.
- Current Binance and Nobitex candle/ticker paths are spot sources. The app now declares `marketType=SPOT`; altFINS validation uses `tradingType=SPOT` and a versioned spot-only cache key.
- Unsupported altFINS exchanges are rejected instead of silently falling back to Binance. The 5m altFINS limitation remains explicit and altFINS does not gate trade decisions.
- Gateway candle-quality diagnostics are returned with the AI result and preserved in the Dart consensus/snapshot export.
- Consensus remains independent: only complete, candle-validated providers with explicitly declared confidence can vote; fewer than two eligible agreeing models means WAIT.

## Verification

Executed successfully:

- `node --check ai-gateway/worker.js`
- `node --check binance-proxy/worker.js`
- `node --check .html-check.js`
- `node --test ai-gateway/tests/worker.test.mjs binance-proxy/tests/worker.test.mjs test/chart_analyzer_export.test.mjs`
- Result after the final boundary-alignment regression test: **80 tests passed, 0 failed** in the original Data Engine quality repair; the subsequent pipeline audit adds further regressions and reaches 83 passing Node tests.
- Added a regression test proving the Gateway rejects a timeframe history whose first candle timestamp is not aligned to its UTC interval boundary.
- `index.html` and `assets/index.html` are byte-identical.

Not executed in this environment:

- `flutter analyze`, Flutter unit tests, and Android APK build (Flutter/Dart SDK are not installed here).
- Cloudflare Worker deployment, live Gemini/OpenRouter/Groq calls, and live altFINS validation (Wrangler is not installed and no live deployment was requested).

No GitHub repository or deployed Worker was modified. This ZIP is a source package for the user's next build/test cycle.


## Follow-up pipeline audit

See `AI-POST-DATA-ENGINE-PIPELINE-AUDIT-2026-11-21.md` for the subsequent model-normalization, semantic consistency, consensus overlay, Hybrid Final Decision, and UI provenance fixes. The current source-of-truth Worker is `ai-gateway/worker.js`; the two Worker text snapshots are synchronized to it.


## Follow-up precision correction

The compact OHLCV representation is **not lossless**. Every original candle remains a separate row in chronological order, but price deltas are rounded to 1 ppm and volume ratios to 0.01 with a 10,000x median-volume cap. The encoder uses the conventional median of positive volumes (average of the two middle values for an even sample). The Worker payload carries explicit encoding metadata so downstream models cannot be told that exact source values are preserved.
