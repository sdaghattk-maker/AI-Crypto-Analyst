import 'package:flutter_test/flutter_test.dart';
import 'package:ai_crypto_analyst/services/ai_service.dart';

AiModelResult result(String model, String status, {String? bias, String? error, int confidence = 70}) =>
    AiModelResult(model: model, status: status, bias: bias, error: error, confidence: confidence);

void main() {
  group('AiConsensus snapshot-safe reconstruction', () {
    test('restored aggregate decision is recalculated and cannot trust stale single-model BUY', () {
      final restored = AiConsensus.fromJson({
        'gemini': {'model':'Gemini','status':'ok','bias':'BUY','confidence':90},
        'openrouter': {'model':'OpenRouter','status':'error','error':'timeout'},
        'groq': {'model':'Groq','status':'not_selected'},
        'decision':'BUY',
        'snapshotId':'snapshot-safe',
      });
      expect(restored.decision, 'WAIT');
      expect(restored.conflicts.any((x)=>x.contains('کمتر از دو پاسخ معتبر')), isTrue);
    });

    test('out-of-range or incomplete factor values are not silently clamped into valid weights', () {
      final parsed = AiModelResult.fromJson('Gemini', {
        'status':'ok','bias':'BUY','confidence':80,'weightsProvided':true,
        'analyticalWeights': {'trend':140,'marketStructure':0,'liquidity':0,'entryConfirmation':0,'riskReward':0},
        'factorScores': {'trend':80,'marketStructure':70,'liquidity':60,'entryConfirmation':70,'riskReward':80},
      });
      expect(parsed.status, 'ok');
      expect(parsed.weightsProvided, isFalse);
    });
  });

  group('AiConsensus partial retry merge', () {
    test('keeps successful answers when other providers are retried', () {
      final previous = AiConsensus(
        gemini: result('Gemini', 'ok', bias: 'BUY'),
        openrouter: result('OpenRouter', 'error', error: 'rate limit'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-1',
      );
      final retry = AiConsensus(
        gemini: result('Gemini', 'not_selected'),
        openrouter: result('OpenRouter', 'ok', bias: 'BUY'),
        groq: result('Groq', 'not_selected'),
        decision: 'BUY', conflicts: const [], snapshotId: 'snapshot-1',
      );

      final merged = previous.mergePartial(retry);
      expect(merged.gemini.status, 'ok');
      expect(merged.gemini.bias, 'BUY');
      expect(merged.openrouter.status, 'ok');
      expect(merged.groq.status, 'not_selected');
      expect(merged.decision, 'BUY');
      expect(merged.snapshotId, 'snapshot-1');
    });


    test('one successful model cannot create a consensus decision', () {
      final previous = AiConsensus(
        gemini: result('Gemini', 'ok', bias: 'BUY'),
        openrouter: result('OpenRouter', 'error', error: 'timeout'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-3',
      );
      final retry = AiConsensus(
        gemini: result('Gemini', 'not_selected'),
        openrouter: result('OpenRouter', 'error', error: 'still unavailable'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-3',
      );
      final merged = previous.mergePartial(retry);
      expect(merged.decision, 'WAIT');
      expect(merged.conflicts.any((x) => x.contains('کمتر از دو پاسخ معتبر')), isTrue);
    });

    test('returns WAIT when successful providers conflict', () {
      final previous = AiConsensus(
        gemini: result('Gemini', 'ok', bias: 'BUY'),
        openrouter: result('OpenRouter', 'error', error: 'temporary'),
        groq: result('Groq', 'not_selected'),
        decision: 'WAIT', conflicts: const [], snapshotId: 'snapshot-2',
      );
      final retry = AiConsensus(
        gemini: result('Gemini', 'not_selected'),
        openrouter: result('OpenRouter', 'ok', bias: 'SELL'),
        groq: result('Groq', 'not_selected'),
        decision: 'SELL', conflicts: const [], snapshotId: 'snapshot-2',
      );
      expect(previous.mergePartial(retry).decision, 'WAIT');
    });
  });
}
