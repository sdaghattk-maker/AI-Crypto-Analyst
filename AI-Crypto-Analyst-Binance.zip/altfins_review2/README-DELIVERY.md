# AI Crypto Analyst — Source Package

This is the latest source package available in the conversation, with a verified
archive and executed Worker tests. Read `DELIVERY-STATUS-2026-11-20.txt` before
deployment; it distinguishes verified items from work that remains incomplete.

The package includes Flutter source, AI Gateway Worker, Binance Proxy Worker,
tests, assets, and GitHub Actions workflow.
