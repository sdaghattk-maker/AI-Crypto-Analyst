import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_state.dart';
import 'ai_service.dart';
import 'market_api.dart';
import 'technical_engine.dart';

class AnalysisController extends ChangeNotifier {
  AnalysisController(this.appState)
      : _lastExchange = appState.exchange,
        _lastSymbol = appState.symbol;
  final AppState appState;
  final MarketApi api = MarketApi();
  final TechnicalEngine engine = TechnicalEngine();

  bool loading = false;
  bool restoring = true;
  String status = 'در حال بازیابی آخرین تحلیل ذخیره‌شده...';
  String? error;
  TechnicalReport? report;
  AiConsensus? consensus;
  DateTime? technicalAt;
  DateTime? aiAt;
  List<MarketCandle> history1h = const [];
  List<MarketCandle> history15m = const [];
  List<MarketCandle> history5m = const [];
  int historyCount1h = 0, historyCount15m = 0, historyCount5m = 0;
  String? snapshotId;
  String _lastExchange;
  String _lastSymbol;
  int _requestId = 0;

  String get cacheKey => 'analysis_cache_${appState.exchange}_${appState.symbol}';
  bool get isStale => technicalAt == null ||
      DateTime.now().difference(technicalAt!) > const Duration(minutes: 15);
  bool get isAiStale => aiAt == null ||
      DateTime.now().difference(aiAt!) > const Duration(minutes: 15);

  Future<void> restore() async {
    final requestedExchange = appState.exchange;
    final requestedSymbol = appState.symbol;
    restoring = true;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('analysis_cache_${requestedExchange}_$requestedSymbol');
      if (requestedExchange != appState.exchange || requestedSymbol != appState.symbol) return;
      if (raw != null) {
        final decoded = jsonDecode(raw);
        if (decoded is Map) {
          final map = Map<String, dynamic>.from(decoded);
          if (map['report'] is Map) {
            report = TechnicalReport.fromJson(Map<String, dynamic>.from(map['report']));
            technicalAt = DateTime.tryParse('${map['technicalAt'] ?? ''}');
            historyCount1h = (map['historyCount1h'] as num?)?.toInt() ?? 0;
            historyCount15m = (map['historyCount15m'] as num?)?.toInt() ?? 0;
            historyCount5m = (map['historyCount5m'] as num?)?.toInt() ?? 0;
            snapshotId = map['snapshotId']?.toString();
            history1h = _restoreCandles(map['snapshot1h']);
            history15m = _restoreCandles(map['snapshot15m']);
            history5m = _restoreCandles(map['snapshot5m']);
            // Invalidate pre-Persian / pre-independent-plan AI cache while preserving
            // the technical report and its saved market snapshot.
            if (map['aiSchemaVersion'] == 3 && map['consensus'] is Map) {
              final restoredConsensus = AiConsensus.fromJson(Map<String, dynamic>.from(map['consensus']));
              if (restoredConsensus.snapshotId != null && restoredConsensus.snapshotId == snapshotId) {
                consensus = restoredConsensus;
                aiAt = DateTime.tryParse('${map['aiAt'] ?? ''}');
              } else {
                consensus = null;
                aiAt = null;
              }
            } else {
              consensus = null;
              aiAt = null;
            }
            status = 'آخرین تحلیل ذخیره‌شده بازیابی شد؛ ${isStale ? 'قدیمی' : 'تازه'}.';
          }
        }
      } else {
        status = 'هنوز تحلیلی برای این نماد ذخیره نشده است.';
      }
    } catch (e) {
      error = 'بازیابی تحلیل ذخیره‌شده ناموفق بود: $e';
      status = 'خطا در بازیابی تحلیل قبلی.';
    } finally {
      restoring = false;
      notifyListeners();
    }
  }

  Future<void> _persist({String? exchange, String? symbol}) async {
    if (report == null || technicalAt == null) return;
    final targetExchange = exchange ?? appState.exchange;
    final targetSymbol = symbol ?? appState.symbol;
    final prefs = await SharedPreferences.getInstance();
    if (targetExchange != appState.exchange || targetSymbol != appState.symbol) return;
    final data = <String, dynamic>{
      'exchange': targetExchange,
      'symbol': targetSymbol,
      'technicalAt': technicalAt!.toIso8601String(),
      'historyCount1h': historyCount1h,
      'historyCount15m': historyCount15m,
      'historyCount5m': historyCount5m,
      'snapshotId': snapshotId,
      'snapshot1h': history1h.map((c)=>c.toJson()).toList(),
      'snapshot15m': history15m.map((c)=>c.toJson()).toList(),
      'snapshot5m': history5m.map((c)=>c.toJson()).toList(),
      'aiAt': aiAt?.toIso8601String(),
      'aiSchemaVersion': 3,
      'report': report!.toJson(),
      'consensus': consensus?.toJson(),
    };
    await prefs.setString('analysis_cache_${targetExchange}_$targetSymbol', jsonEncode(data));
  }

  List<MarketCandle> _restoreCandles(dynamic raw) {
    if(raw is! List)return const [];
    final out=<MarketCandle>[];
    for(final item in raw){if(item is Map){try{out.add(MarketCandle.fromJson(Map<String,dynamic>.from(item)));}catch(_){}}}
    return List.unmodifiable(out);
  }


  Future<void> saveConsensus(AiConsensus value, {bool mergeSameSnapshot = true}) async {
    if (snapshotId == null || value.snapshotId == null || value.snapshotId != snapshotId) {
      throw StateError('پاسخ AI متعلق به Snapshot فعلی نیست و ذخیره نشد.');
    }
    final sameSnapshot = consensus != null &&
        consensus!.snapshotId != null &&
        consensus!.snapshotId == value.snapshotId;
    consensus = mergeSameSnapshot && sameSnapshot
        ? consensus!.mergePartial(value)
        : value.recalculate();
    aiAt = DateTime.now();
    await _persist();
    notifyListeners();
  }

  Future<void> onStateChanged() async {
    if (_lastExchange == appState.exchange && _lastSymbol == appState.symbol) return;
    _lastExchange = appState.exchange;
    _lastSymbol = appState.symbol;
    _requestId++;
    loading = false;
    report = null;
    consensus = null;
    technicalAt = null;
    aiAt = null;
    history1h = const [];
    history15m = const [];
    history5m = const [];
    historyCount1h = historyCount15m = historyCount5m = 0;
    snapshotId = null;
    error = null;
    status = 'در حال بازیابی تحلیل ذخیره‌شده برای نماد جدید...';
    notifyListeners();
    await restore();
  }

  List<MarketCandle> _closedHistory(List<MarketCandle> candles, int intervalSeconds, int targetCount) {
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final closed = candles.where((c) => c.time + intervalSeconds <= now).toList()
      ..sort((a,b)=>a.time.compareTo(b.time));
    return List.unmodifiable(closed.length > targetCount
        ? closed.sublist(closed.length-targetCount) : closed);
  }

  // Deterministic content fingerprint: timestamps alone are not enough to
  // identify a snapshot if an exchange revises historical OHLCV values.
  String _historyFingerprint(List<MarketCandle> candles) {
    var hash = 0x811c9dc5;
    for (final byte in utf8.encode(jsonEncode(candles.map((c) => c.toJson()).toList()))) {
      hash = ((hash ^ byte) * 0x01000193) & 0xffffffff;
    }
    return hash.toRadixString(16).padLeft(8, '0');
  }


  void _validateFreshCandles(List<MarketCandle> candles, int intervalSeconds, String label) {
    if (candles.isEmpty) throw MarketApiException('تاریخچه $label خالی است.');
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final latest = candles.last;
    final age = now - (latest.time + intervalSeconds);
    // Never run a new analysis from a cache that is more than 2.5 candles old.
    if (age > intervalSeconds * 2.5) {
      throw MarketApiException('داده $label قدیمی است (${(age / 60).round()} دقیقه). دریافت تازه از صرافی ناموفق بود؛ تحلیل با داده قدیمی اجرا نشد.');
    }
  }

  Future<bool> run() async {
    final id = ++_requestId;
    loading = true;
    error = null;
    status = 'دریافت داده‌های 1H، 15M و 5M...';
    notifyListeners();
    final exchange = appState.exchange, symbol = appState.symbol;
    try {
      final responses = await Future.wait([
        api.getKlines(exchange: exchange, symbol: symbol, interval: '1h', limit: 1001, refreshInterval: const Duration(seconds: 15)),
        api.getKlines(exchange: exchange, symbol: symbol, interval: '15m', limit: 1501, refreshInterval: const Duration(seconds: 15)),
        api.getKlines(exchange: exchange, symbol: symbol, interval: '5m', limit: 2001, refreshInterval: const Duration(seconds: 15)),
      ]);
      if (id != _requestId) return false;
      // Build the canonical closed-candle snapshot BEFORE either engine runs.
      // Technical and AI must consume these exact same immutable candle lists.
      final closed1h = _closedHistory(responses[0], 3600, 1000);
      final closed15m = _closedHistory(responses[1], 900, 1500);
      final closed5m = _closedHistory(responses[2], 300, 2000);
      _validateFreshCandles(closed1h, 3600, '1H');
      _validateFreshCandles(closed15m, 900, '15M');
      _validateFreshCandles(closed5m, 300, '5M');
      if (closed1h.isEmpty || closed15m.isEmpty || closed5m.isEmpty) {
        throw const MarketApiException('Snapshot کندل بسته‌شده برای هر سه تایم‌فریم کامل نیست.');
      }
      status = 'محاسبه روند، ساختار، نقدینگی و قدرت خریدار/فروشنده از Snapshot مشترک...';
      notifyListeners();
      final result = engine.analyze(h1: closed1h, m15: closed15m, m5: closed5m);
      if (id != _requestId) return false;
      history1h = closed1h;
      history15m = closed15m;
      history5m = closed5m;
      historyCount1h = history1h.length;
      historyCount15m = history15m.length;
      historyCount5m = history5m.length;
      final previousSnapshotId = snapshotId;
      final nextSnapshotId = '${exchange}_${symbol}_${history1h.last.time}_${history15m.last.time}_${history5m.last.time}_${_historyFingerprint(history1h)}_${_historyFingerprint(history15m)}_${_historyFingerprint(history5m)}';
      snapshotId = nextSnapshotId;
      report = result;
      // Never combine AI answers from an older market snapshot with a newer
      // technical report. Partial retries are preserved only within one ID.
      if (previousSnapshotId != nextSnapshotId) {
        consensus = null;
        aiAt = null;
      }
      technicalAt = DateTime.now();
      final historyShort = historyCount1h < 1000 || historyCount15m < 1500 || historyCount5m < 2000;
      status = historyShort
          ? 'تحلیل با تاریخچه کمتر از هدف تکمیل شد: 1H=$historyCount1h/1000، 15M=$historyCount15m/1500، 5M=$historyCount5m/2000. صفحه‌بندی پروکسی را بررسی کنید.'
          : 'تحلیل تکمیل و ذخیره شد؛ کندل بسته‌شده: 1H=$historyCount1h، 15M=$historyCount15m، 5M=$historyCount5m.';
      await _persist(exchange: exchange, symbol: symbol);
      return true;
    } catch (e) {
      if (id != _requestId) return false;
      error = e.toString();
      status = 'تحلیل کامل نشد؛ آخرین تحلیل ذخیره‌شده حفظ شده است.';
      return false;
    } finally {
      if (id == _requestId) {
        loading = false;
        notifyListeners();
      }
    }
  }
}
