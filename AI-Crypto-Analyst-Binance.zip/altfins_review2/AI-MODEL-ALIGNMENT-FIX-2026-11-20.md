# AI Model Alignment Fix — 2026-11-20

## Findings from the installed-version source review

- The three providers are independent, receive the same serialized closed-candle Snapshot, and do not receive the Technical Engine decision. This separation is preserved.
- The Gateway already requires two agreeing providers for BUY/SELL consensus. A single successful provider is not a consensus. This is preserved.
- Partial retries merge provider records only when the Snapshot ID is identical. This is preserved.
- The UI compares altFINS 15m/1h with same-timeframe Technical, but AI is a multi-timeframe opinion. The UI explicitly labels AI as an overall direction and warns that it is not a same-timeframe comparison. altFINS remains auxiliary and never votes.

## Corrections in this package

1. **No silent numeric repair:** the Flutter parser no longer clamps invalid AI weights/scores into the 0–100 range. A malformed value is marked invalid for Hybrid use instead of being cosmetically converted into a valid-looking result.
2. **Exact factor contract:** Hybrid requires exactly the five expected factor keys, weights totaling 100, and scores in range. Missing or malformed evidence produces WAIT, not an inferred score.
3. **Rebuild aggregate decisions from provider records:** cached `decision`, `conflicts`, and aggregate overlays are no longer trusted when restoring. They are reconstructed from the individual Gemini/OpenRouter/Groq records using the current two-provider consensus rule.
4. **Cache schema bumped to v3:** old aggregate cache is invalidated so a previously stored decision cannot survive under the new validation rules. Technical snapshot/history remain available.
5. **First save also recalculates:** a newly received aggregate is rebuilt from its provider records before persistence, matching the same logic used by partial retry and cache restore.

## Preserved architecture

- Gemini, Groq and OpenRouter remain independent.
- Technical + each AI Hybrid remains independent; no AI sees another model's answer.
- AI consensus requires at least two agreeing valid providers with confidence >=55.
- Hybrid requires Technical and that provider to agree directionally and a complete coherent Entry/SL/TP1/TP2/TP3 plan.
- altFINS is validation-only; it does not vote or change Technical/AI/Hybrid.
- Binance Proxy, Chart Analyzer WebView routing, Worker URLs, and secret placement are unchanged.

## Validation

- `node --check ai-gateway/worker.js`: passed.
- `node --test ai-gateway/tests/worker.test.mjs binance-proxy/tests/worker.test.mjs`: 31 passed, 0 failed.
- Flutter/Dart tests and Android build were not run because Flutter/Dart SDK is unavailable in this environment. GitHub Actions must build the APK before installation.
