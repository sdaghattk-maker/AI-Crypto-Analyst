# Dashboard independent sources and hybrid decision fix — 2026-11-20

## Changes
- Dashboard Market Structure now presents Technical Engine, Gemini, OpenRouter and Groq as separate source sections.
- AI timeframe structure is rendered only from that provider's own `timeframeAnalysis` (1h/15m/5m). Missing/invalid provider data is explicitly shown as not provided; no technical fallback is used.
- Buyer/seller power is explicitly labeled as Technical Engine data. No AI buyer/seller percentages are fabricated where the provider schema does not supply them.
- Dashboard BUY/SELL/WAIT now requires fresh technical and AI snapshots, at least two valid AI provider reports, and at least two matching directional results from the existing per-provider HybridEngine evaluation. Conflicting/insufficient hybrid votes produce WAIT.
- Raw AI consensus is labeled separately from the final hybrid decision.
- Existing altFINS and Chart Analyzer screens/services are not removed or replaced by this dashboard change.

## Important limitations
- Provider validity continues to use the existing V3 contract gate (`status=ok`, `contractStatus=VALID`, `weightsProvided`, and non-null bias).
- Existing HybridEngine requirements, including its trade-plan overlay checks, remain in force.
- AI buyer/seller power is not displayed unless the model schema actually provides it; current dashboard does not infer it from trend or bias.
- Flutter/Dart SDK is not installed in the build environment, so `flutter analyze`, Dart formatting, Flutter tests and APK build could not be run. This package has not been device-runtime verified.
