import 'dart:convert';

import 'package:http/http.dart' as http;

import 'app_config.dart';

class MarketCandle {
  const MarketCandle({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    this.volume = 0,
  });

  final int time;
  final double open;
  final double high;
  final double low;
  final double close;
  final double volume;

  Map<String, dynamic> toChartJson() => {
        'time': time,
        'open': open,
        'high': high,
        'low': low,
        'close': close,
        'volume': volume,
      };
}

class MarketApi {
  Uri _uri(Map<String, String> query) => Uri.parse(
        AppConfig.binanceWorkerBaseUrl,
      ).replace(queryParameters: query);

  Future<Map<String, dynamic>> ping() async {
    final json = await _getJson(_uri({'endpoint': 'ping'}));
    _ensureOk(json, 'آزمایش اتصال');
    return json;
  }

  Future<double> getPrice(String symbol) async {
    final json = await _getJson(_uri({
      'endpoint': 'price',
      'symbol': symbol.toUpperCase(),
    }));
    _ensureOk(json, 'دریافت قیمت');
    final data = json['data'];
    dynamic raw;
    if (data is Map) {
      raw = data['price'] ?? data['lastPrice'];
    } else {
      raw = data ?? json['price'] ?? json['lastPrice'];
    }
    final price = _asDouble(raw);
    if (price == null || !price.isFinite || price <= 0) {
      throw MarketApiException('قیمت معتبر از Worker دریافت نشد. پاسخ: ${_short(json)}');
    }
    return price;
  }

  Future<List<MarketCandle>> getKlines({
    required String symbol,
    required String interval,
    int limit = 500,
  }) async {
    final json = await _getJson(_uri({
      'endpoint': 'klines',
      'symbol': symbol.toUpperCase(),
      'interval': interval,
      'limit': limit.toString(),
    }));
    _ensureOk(json, 'دریافت کندل');

    dynamic raw = json['data'];
    if (raw is Map) {
      // Compatibility with Workers that wrap the original Binance array.
      if (raw['klines'] is List) {
        raw = raw['klines'];
      } else if (raw['data'] is List) {
        raw = raw['data'];
      } else if (raw['t'] is List && raw['o'] is List) {
        return _parseUdfCandles(raw, interval, limit);
      }
    }
    if (raw is! List) {
      throw MarketApiException('ساختار پاسخ کندل قابل شناسایی نیست. کلیدها: ${json.keys.toList()}');
    }

    final nowMs = DateTime.now().millisecondsSinceEpoch;
    final byTime = <int, MarketCandle>{};
    for (final item in raw) {
      if (item is! List || item.length < 7) continue;
      final openTime = _asInt(item[0]);
      final open = _asDouble(item[1]);
      final high = _asDouble(item[2]);
      final low = _asDouble(item[3]);
      final close = _asDouble(item[4]);
      final volume = item.length > 5 ? (_asDouble(item[5]) ?? 0) : 0.0;
      final closeTime = _asInt(item[6]);
      if (openTime == null || open == null || high == null || low == null ||
          close == null || closeTime == null || closeTime >= nowMs) {
        continue;
      }
      if (!_validOhlc(open, high, low, close)) continue;
      final candle = MarketCandle(
        time: (openTime / 1000).floor(),
        open: open,
        high: high,
        low: low,
        close: close,
        volume: volume,
      );
      byTime[candle.time] = candle;
    }

    final candles = byTime.values.toList()..sort((a, b) => a.time.compareTo(b.time));
    if (candles.isEmpty) {
      throw MarketApiException('پاسخ Worker رسید، اما کندل بسته‌شده و معتبر در آن پیدا نشد.');
    }
    return candles.length > limit ? candles.sublist(candles.length - limit) : candles;
  }

  List<MarketCandle> _parseUdfCandles(Map data, String interval, int limit) {
    final times = data['t'] as List;
    final opens = data['o'] as List?;
    final highs = data['h'] as List?;
    final lows = data['l'] as List?;
    final closes = data['c'] as List?;
    final volumes = data['v'] as List?;
    if (opens == null || highs == null || lows == null || closes == null ||
        [opens.length, highs.length, lows.length, closes.length].any((n) => n != times.length)) {
      throw const MarketApiException('آرایه‌های زمانی و OHLC در پاسخ Worker هم‌اندازه نیستند.');
    }
    final duration = _intervalSeconds(interval);
    final nowSeconds = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final byTime = <int, MarketCandle>{};
    for (var i = 0; i < times.length; i++) {
      final t = _asInt(times[i]);
      final o = _asDouble(opens[i]);
      final h = _asDouble(highs[i]);
      final l = _asDouble(lows[i]);
      final c = _asDouble(closes[i]);
      if (t == null || o == null || h == null || l == null || c == null ||
          t + duration > nowSeconds || !_validOhlc(o, h, l, c)) continue;
      byTime[t] = MarketCandle(
        time: t, open: o, high: h, low: l, close: c,
        volume: volumes != null && i < volumes.length ? (_asDouble(volumes[i]) ?? 0) : 0,
      );
    }
    final candles = byTime.values.toList()..sort((a, b) => a.time.compareTo(b.time));
    if (candles.isEmpty) throw const MarketApiException('هیچ کندل بسته‌شده‌ای دریافت نشد.');
    return candles.length > limit ? candles.sublist(candles.length - limit) : candles;
  }

  Future<Map<String, dynamic>> _getJson(Uri uri) async {
    try {
      final response = await http
          .get(uri, headers: const {'Accept': 'application/json'})
          .timeout(AppConfig.requestTimeout);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw MarketApiException(
          'Worker خطای HTTP ${response.statusCode} برگرداند: ${_short(response.body)}',
        );
      }
      final decoded = jsonDecode(response.body);
      if (decoded is! Map) {
        throw const MarketApiException('پاسخ Worker از نوع JSON object نیست.');
      }
      return Map<String, dynamic>.from(decoded);
    } on MarketApiException {
      rethrow;
    } catch (e) {
      throw MarketApiException('خطا در ارتباط با Binance Worker: $e');
    }
  }

  void _ensureOk(Map<String, dynamic> json, String action) {
    if (json['ok'] == false) {
      throw MarketApiException('$action ناموفق بود: ${json['error'] ?? json['data'] ?? _short(json)}');
    }
  }

  static bool _validOhlc(double o, double h, double l, double c) =>
      [o, h, l, c].every((v) => v.isFinite && v > 0) && h >= o && h >= c && l <= o && l <= c && h >= l;

  static int _intervalSeconds(String interval) {
    const values = {'1m': 60, '3m': 180, '5m': 300, '15m': 900, '30m': 1800,
      '1h': 3600, '2h': 7200, '4h': 14400, '6h': 21600, '8h': 28800,
      '12h': 43200, '1d': 86400, '3d': 259200, '1w': 604800};
    return values[interval] ?? 300;
  }

  static int? _asInt(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value?.toString() ?? '');
  }

  static double? _asDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse(value?.toString() ?? '');
  }

  static String _short(dynamic value) {
    final text = value is String ? value : value.toString();
    return text.length > 240 ? '${text.substring(0, 240)}…' : text;
  }
}

class MarketApiException implements Exception {
  const MarketApiException(this.message);
  final String message;

  @override
  String toString() => message;
}
