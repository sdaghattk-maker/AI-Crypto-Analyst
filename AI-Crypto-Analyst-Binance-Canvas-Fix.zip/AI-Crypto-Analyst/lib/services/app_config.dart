class AppConfig {
  // Public market data only. No AI secrets are stored in the APK.
  static const String binanceWorkerBaseUrl =
      'https://hrs-binance-proxy.sdaghat-tk.workers.dev';

  static const Duration requestTimeout = Duration(seconds: 20);
}
