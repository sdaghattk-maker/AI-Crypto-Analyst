import 'package:flutter/material.dart';

class AiAnalysisScreen extends StatelessWidget {
  const AiAnalysisScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const SizedBox(height: 8),
        const Text('گزارش تحلیل AI', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        const _ModelCard(name: 'Gemini', role: 'تحلیل اصلی روند و سناریوها', status: 'در انتظار اتصال'),
        const _ModelCard(name: 'DeepSeek', role: 'تحلیل مستقل و نقد سناریوی اول', status: 'در انتظار اتصال'),
        const _ModelCard(name: 'Llama (Local)', role: 'مدل محلی پشتیبان از طریق سرور امن', status: 'اختیاری'),
        const SizedBox(height: 12),
        Card(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
            Text('نتیجه هماهنگ‌کننده', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            SizedBox(height: 10),
            Text('WAIT', style: TextStyle(color: Colors.amber, fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('تا زمانی که داده واقعی، موتور تکنیکال و سرویس‌های AI متصل و اعتبارسنجی نشده‌اند، هیچ سیگنال معاملاتی تولید نمی‌شود.'),
          ]),
        )),
        const SizedBox(height: 12),
        const Text('قالب گزارش نهایی: جهت 1H، محدوده CRT در 15M، تأیید ورود 5M، Entry، SL، TP1 تا TP3، شواهد، شرط ابطال و میزان اختلاف مدل‌ها.'),
      ],
    );
  }
}

class _ModelCard extends StatelessWidget {
  const _ModelCard({required this.name, required this.role, required this.status});
  final String name, role, status;
  @override
  Widget build(BuildContext context) => Card(child: ListTile(
    leading: const Icon(Icons.memory),
    title: Text(name),
    subtitle: Text(role),
    trailing: Text(status, style: const TextStyle(color: Colors.amber, fontSize: 11)),
  ));
}
