import 'package:flutter/material.dart';
import 'screens/dashboard.dart';
import 'screens/chart_screen.dart';
import 'screens/ai_analysis.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CryptoAnalystApp());
}

class CryptoAnalystApp extends StatelessWidget {
  const CryptoAnalystApp({super.key});

  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF0B1020);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AI Crypto Analyst',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF46D6B3),
          brightness: Brightness.dark,
          surface: const Color(0xFF151D31),
        ),
        useMaterial3: true,
        cardTheme: CardThemeData(
          color: const Color(0xFF151D31),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
      ),
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  final pages = const [DashboardScreen(), ChartScreen(), AiAnalysisScreen()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'بازار'),
          NavigationDestination(icon: Icon(Icons.candlestick_chart_outlined), selectedIcon: Icon(Icons.candlestick_chart), label: 'نمودار'),
          NavigationDestination(icon: Icon(Icons.psychology_outlined), selectedIcon: Icon(Icons.psychology), label: 'تحلیل AI'),
        ],
      ),
    );
  }
}
