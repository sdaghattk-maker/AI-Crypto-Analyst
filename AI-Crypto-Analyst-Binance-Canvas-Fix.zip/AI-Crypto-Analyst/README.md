# AI Crypto Analyst — Binance Live Chart

این نسخه از Worker عمومی Binance استفاده می‌کند:
`https://hrs-binance-proxy.sdaghat-tk.workers.dev`

- صرافی پیش‌فرض: Binance
- مسیرهای داده: `ping`، `price` و `klines`
- تایم‌فریم نمودار: 5m، 15m و 1h
- کندل‌های در حال تشکیل از نمودار حذف می‌شوند.
- رسم نمودار با Canvas داخلی انجام می‌شود و به CDN یا کتابخانه JavaScript خارجی وابسته نیست.
- موتور تحلیل AI و ارسال سفارش در این نسخه فعال نیستند.

برای ساخت در محیط دارای Flutter SDK: `flutter pub get`، سپس `flutter analyze` و `flutter build apk --release`.
