import 'ai_service.dart';
import 'technical_engine.dart';

class HybridDecision {
  const HybridDecision({required this.provider, required this.decision, required this.score,
    required this.technicalScore, required this.aiScore, required this.technicalWeights,
    required this.aiWeights, required this.reasons, required this.calibration});
  final String provider, decision;
  final double score, technicalScore, aiScore;
  final Map<String,int> technicalWeights, aiWeights;
  final List<String> reasons;
  final String calibration;
}

class HybridEngine {
  static const keys = ['trend','marketStructure','liquidity','entryConfirmation','riskReward'];
  static const labels = {'trend':'روند','marketStructure':'ساختار بازار','liquidity':'نقدینگی','entryConfirmation':'تأیید ورود','riskReward':'ریسک به بازده'};

  bool _directional(TradeBias bias) => bias == TradeBias.bullish || bias == TradeBias.bearish;
  bool _sameDirectional(TradeBias a, TradeBias b) => _directional(a) && a == b;

  Map<String,int> _normalize(Map<String,int> source) {
    final vals = keys.map((k) => (source[k] ?? 0).clamp(0,100).toInt()).toList();
    final sum = vals.fold<int>(0,(a,b)=>a+b);
    if (sum == 0) return {for(final k in keys) k:20};
    final out = <String,int>{};
    for(var i=0;i<keys.length;i++) { out[keys[i]] = (vals[i]*100/sum).round(); }
    final drift = 100-out.values.fold<int>(0,(a,b)=>a+b);
    out[keys.first] = (out[keys.first]!+drift).clamp(0,100).toInt();
    return out;
  }

  bool _hasStructure(TechnicalReport r) => r.overlays.any((o) {
    final kind = (o['kind'] ?? '').toString().toUpperCase();
    return kind.contains('BOS') || kind.contains('MSS') || kind.contains('ORDER BLOCK') ||
        kind == 'BULLISH OB' || kind == 'BEARISH OB' || kind.contains('FVG');
  }) || r.reasons.any((x) => x.toLowerCase().contains('bos') ||
      x.toLowerCase().contains('mss') || x.contains('شکست ساختار') || x.contains('تغییر ساختار'));

  bool _hasLiquidity(TechnicalReport r) => r.reasons.any((x) =>
      x.contains('نقدینگی') || x.toLowerCase().contains('sweep'));

  int _trendAgreement(TechnicalReport r) =>
      (_sameDirectional(r.bias1h,r.bias15m) ? 1 : 0) +
      (_sameDirectional(r.bias15m,r.bias5m) ? 1 : 0) +
      (_sameDirectional(r.bias1h,r.bias5m) ? 1 : 0);

  Map<String,int> _technicalWeights(TechnicalReport r) {
    final agreement = _trendAgreement(r);
    final aligned = 8 + agreement * 9;
    final structure = _hasStructure(r) ? 65 : 25;
    final liquidity = _hasLiquidity(r) ? 65 : 25;
    final entry = r.state == SignalState.wait ? 15 : (r.score * .75).round().clamp(0,75).toInt();
    final rr = r.entry!=null && r.stopLoss!=null && r.tp1!=null ? 65 : 15;
    return _normalize({'trend':aligned,'marketStructure':structure,'liquidity':liquidity,'entryConfirmation':entry,'riskReward':rr});
  }

  Map<String,int> _technicalScores(TechnicalReport r) => {
    'trend': (35 + _trendAgreement(r) * 20).clamp(0,95).toInt(),
    'marketStructure': _hasStructure(r) ? 75 : 30,
    'liquidity': _hasLiquidity(r) ? 80 : 30,
    'entryConfirmation': r.state==SignalState.wait ? 20 : r.score.clamp(0,100).toInt(),
    'riskReward': r.entry!=null&&r.stopLoss!=null&&r.tp1!=null ? 75 : 20,
  };

  double _weighted(Map<String,int> weights, Map<String,int> scores) =>
    keys.fold<double>(0,(sum,k)=>sum+(weights[k]??0)*(scores[k]??0)/10000)*100;

  HybridDecision evaluate(TechnicalReport technical, AiModelResult ai,
      {String? technicalSnapshotId, String? aiSnapshotId}) {
    final tw = _technicalWeights(technical);
    final aw = _normalize(ai.analyticalWeights);
    final ts = _weighted(tw,_technicalScores(technical));
    final ascore = _weighted(aw,ai.factorScores);
    final tDir = technical.state==SignalState.buy?1:technical.state==SignalState.sell?-1:0;
    final bias = (ai.bias ?? '').toUpperCase();
    final aDir = bias=='BUY'?1:bias=='SELL'?-1:0;
    final tStrength = ts*(technical.score.clamp(0,100)/100);
    final aStrength = ascore*(ai.confidence.clamp(0,100)/100);
    final combined = (tDir*tStrength*0.5)+(aDir*aStrength*0.5);
    final conflict = tDir!=0 && aDir!=0 && tDir!=aDir;
    final hasAllWeights = ai.weightsProvided && keys.every((k) => ai.analyticalWeights.containsKey(k) && ai.factorScores.containsKey(k));
    final validPlan = ai.overlays.any((o)=>o['kind']=='Entry' && o['price'] is num) &&
        ai.overlays.any((o)=>o['kind']=='SL' && o['price'] is num) &&
        ai.overlays.any((o)=>o['kind']=='TP1' && o['price'] is num);
    final snapshotMatches = technicalSnapshotId == null || aiSnapshotId == null || technicalSnapshotId == aiSnapshotId;
    var decision = 'WAIT';
    if (ai.status == 'ok' && snapshotMatches && hasAllWeights && ai.confidence >= 55 &&
        !conflict && tDir != 0 && aDir != 0 && tDir == aDir && validPlan && combined.abs() >= 18) {
      decision = combined>0?'BUY':'SELL';
    }
    final reasons=<String>[];
    if (ai.status != 'ok') reasons.add('پاسخ این AI معتبر یا در دسترس نیست؛ Hybrid صادر نشد.');
    if (!snapshotMatches) reasons.add('Snapshot تحلیل تکنیکال و AI یکسان نیست؛ مقایسه متوقف شد.');
    if (!hasAllWeights) reasons.add('وزن‌ها یا امتیازهای پنج معیار کامل نیستند.');
    if (ai.confidence < 55) reasons.add('اطمینان AI کمتر از حداقل ۵۵ است.');
    if (conflict) reasons.add('تعارض جهت بین تکنیکال و AI؛ تصمیم به WAIT محدود شد.');
    if (tDir == 0 || aDir == 0) reasons.add('هر دو موتور باید جهت صعودی یا نزولی معتبر داشته باشند؛ WAIT رأی مخالف نیست.');
    if (!validPlan && bias != 'WAIT') reasons.add('نقشه معامله AI شامل Entry، SL و TP1 معتبر نیست.');
    if (decision=='WAIT' && reasons.isEmpty) reasons.add('قدرت شواهد ترکیبی به حداقل آستانه تصمیم نرسید.');
    reasons.add('سهم تکنیکال: ${tStrength.toStringAsFixed(1)} از ۱۰۰');
    reasons.add('سهم شواهد AI (${ai.model}): ${aStrength.toStringAsFixed(1)} از ۱۰۰');
    return HybridDecision(provider:ai.model,decision:decision,score:combined,technicalScore:ts,aiScore:ascore,
      technicalWeights:tw,aiWeights:aw,reasons:reasons,calibration:'وزن اعتماد عملکردی فعلاً خنثی است؛ تا ثبت نمونه‌های خارج از نمونه و ارزیابی نتیجه واقعی، وزن عملکردی اعمال نمی‌شود.');
  }
}
