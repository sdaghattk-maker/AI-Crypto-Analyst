# AI Analysis Contract V3 — 2026-11-20

## Purpose
V3 replaces the minimal V2 response with a shared, mandatory, Persian-language market-analysis report for Gemini, OpenRouter and Groq. It does not claim calibrated trading probability.

## Required report
1. **Market regime:** trend/range/accumulation/distribution and volatility context.
2. **Multi-timeframe structure:** 1h context, 15m setup and 5m execution; BOS/CHOCH/MSS/displacement and protected swings where evidenced.
3. **Liquidity:** buy-side/sell-side liquidity, equal highs/lows, sweep and reclaim evidence.
4. **POI:** OB/Breaker/FVG or a directionally relevant swing/equal-level retest; one valid POI is enough, both OB and FVG are not required.
5. **Premium/Discount:** dealing range, equilibrium and current location; mark insufficient when a valid range cannot be derived.
6. **Volume/momentum/volatility:** candle-volume expansion, impulse and volatility using supplied OHLCV only.
7. **Scenarios:** bullish and bearish alternatives with activation and invalidation conditions.
8. **Execution:** entry quality, trigger, stop logic, targets and R multiples. The executable decision remains WAIT unless a coherent plan exists; the separately retained market direction may still be BUY/SELL for directional consensus.
9. **Data quality:** supplied coverage, stale/missing inputs and limitations.

Each section is `{status, findings}`. Status is one of `AVAILABLE`, `NOT_AVAILABLE`, `NOT_APPLICABLE`, `INSUFFICIENT_DATA`. Each finding is Persian. `AVAILABLE` requires at least one finding. For `NOT_AVAILABLE`, `NOT_APPLICABLE` and `INSUFFICIENT_DATA`, an empty `findings` array is valid and must not invalidate the whole contract. Missing order book, funding, open interest, delta, news and liquidation data must be disclosed as not supplied, never inferred from OHLCV.

## Shared supporting fields
- `timeframeAnalysis` for exactly `1h`, `15m`, `5m`; each timeframe separates directional `structure` from `structureEvent` (`BOS_*`, `CHOCH_*`, `MSS_*`, `NONE`, `UNKNOWN`). BOS/CHOCH/MSS require closed-candle evidence against confirmed protected swings; a wick-only sweep is not a structure break.
- Structured evidence with timeframe, type, event, status and Persian explanation.
- Scenario invalidation.
- Persian summary, observations and risks.
- Optional analytical weights and evidence factor scores (not model reliability or win probability); their absence does not invalidate a market-direction vote. Model confidence is optional and is not a calibrated probability.
- Independent overlays and, only for a valid directional setup, Entry/SL/TP1-TP3.

## Qualification rules
- Worker marks a response `VALID` only when the timeframe/evidence contract and all nine V3 sections are present and well-formed. Small buyer/seller strength rounding drift is normalized to 100. Empty findings are valid for explicitly non-available/inapplicable/insufficient sections; `AVAILABLE` with no findings remains malformed. Missing sections or malformed required fields remain `DEGRADED`.
- A truncated response is downgraded to WAIT and execution overlays are removed.
- Directional market votes require a valid structured BUY/SELL direction, a `VALID` V3 contract, candle-validated evidence and coherent timeframe direction. Missing confidence, analytical weights, factor scores or execution overlays do not by themselves remove a directional vote.
- Trade-plan eligibility is separate: a directional execution plan requires a valid OB OR FVG OR directionally relevant swing/equal-level retest, plus coherent Entry/SL/TP prices and historical-envelope/reference-price validation. A valid market-direction consensus may therefore coexist with a final executable decision of WAIT.
- At least two of the three available providers must have valid same-direction market votes; unavailable providers are not opposing votes. Worker vote eligibility is authoritative and Flutter consumes the returned eligibility/reason metadata.

## Limitations
The OHLCV `historyStartPrice` is only the first candle open used to decode delta rows; it is not the live price and must not be compared across timeframes. Live price validation uses `referencePrice` and `lastClosed5mClose`. V3 is an OHLCV-only report unless additional feeds are actually supplied. It cannot truthfully report order-book imbalance, funding, open interest, liquidation clusters, news or exchange delta without those inputs. Model confidence is not a calibrated probability. A real performance ranking requires identical snapshots and forward-labelled outcomes; the current curated list is only a capability/availability shortlist.
