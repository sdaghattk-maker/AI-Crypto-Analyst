# AI Crypto Analyst — V6.3.0 Factor Independence Repair

Date: 2026-11-21  
Base archive: `AI-Crypto-Analyst-AI-CONSENSUS-V3-TRADEPLAN-SEPARATION-REPAIR-FINAL-2026-11-21-V6.2.2.zip`  
Base SHA256: `8ee6a70c5ecfc8d1173d55661fca024196b9f5745f38f36cb7bc0744e741117d`

## Architecture rule

Every analysis factor owns its own data availability, normalization, evidence status, and contribution status. An invalid or missing factor must not invalidate sibling factors. Cross-factor combination is allowed only in the final decision layer, with explicit provenance and reasons.

## Work completed in order

1. **V3 section isolation**
   - Each of the nine contract sections now has a separate `analysisSectionStatus` with `valid`, status, and a machine-readable reason.
   - An invalid `AVAILABLE` section is marked `INVALID` locally; valid sibling sections remain intact.
   - Overall `contractStatus` can be `NORMALIZED` while independently valid timeframe votes remain eligible.
   - Explicit `NOT_AVAILABLE`, `NOT_APPLICABLE`, and `INSUFFICIENT_DATA` sections may keep empty findings; `AVAILABLE` requires at least one finding.

2. **Timeframe and evidence isolation**
   - Evidence validation now returns per-timeframe status and per-timeframe/per-factor status.
   - A bad 5m event does not invalidate a valid 1h structure vote.
   - A bad liquidity Sweep claim does not invalidate market-structure evidence in the same timeframe.
   - Per-timeframe vote eligibility is computed from the timeframe's own structured trend, its regime section availability, and its own market-structure evidence status.

3. **Factor independence**
   - The nine V3 factors are surfaced separately: regime/trend, market structure, liquidity, POI, Premium/Discount, volume/momentum, scenarios, execution, and data quality.
   - Aggregate structure narrative status no longer suppresses separately validated timeframe structure data.
   - A non-directional factor failure (liquidity, POI, Premium/Discount, volume/momentum, scenarios, execution, data quality) cannot suppress an otherwise eligible 1h/15m market-direction vote.
   - Trade-plan checks use 5m execution evidence and the plan's own POI/price/RR checks, not a global evidence status from unrelated factors.

4. **No synthetic factor scores**
   - Missing `factorScores` and `analyticalWeights` remain empty with `NOT_PROVIDED` status.
   - They are normalized independently; providing one does not require the other.
   - Unselected/failed providers no longer receive fabricated 0 or neutral 20/50 values.
   - Flutter rejects incomplete numeric maps rather than silently filling missing values.

5. **Hybrid factor scoring**
   - Technical factor scores are derived from explicit Technical Engine state, not keyword searches in free-text `reasons`.
   - Technical factors without observations are marked `NOT_CONFIRMED` / `NOT_APPLICABLE` and omitted from weighting.
   - AI factors are weighted only when a score exists and the factor has an eligible status.
   - If one side has no available factor scores, its absence is not treated as a zero-confidence penalty in the diagnostic combined score.

6. **Decision-layer separation**
   - Worker directional market consensus is based on eligible provider market-direction votes.
   - Trade-plan eligibility remains independent; an incomplete/invalid Entry/SL/TP plan can leave executable bias at WAIT without deleting an evidenced market-direction vote.
   - Per-timeframe consensus in Flutter consumes Worker-provided timeframe-local eligibility rather than global provider contract/evidence status.

7. **UI diagnostics**
   - AI Analysis shows each V3 section's local status and failure reason.
   - It displays independent factor evidence statuses, per-timeframe structure/liquidity evidence statuses, and per-timeframe vote eligibility/reason.
   - Dashboard and Market Intelligence use timeframe-local eligibility. Buyer/seller strength display is no longer hidden by unrelated global evidence failures.

8. **Regression / fault-injection tests**
   - Added Worker tests for local V3 section failure, 5m-vs-1h evidence isolation, liquidity-vs-structure isolation, missing/partial factor scores, unselected providers, and seven non-directional factor-section failures.
   - Added Dart regression tests for independent technical/AI factor weights and invalid score-map rejection.
   - Updated source-contract tests to enforce timeframe-local gates and Worker/Flutter separation.

## Validation results

- Full Node suite: **130 passed, 0 failed**.
- AI Gateway Worker syntax: passed.
- Binance Proxy Worker syntax: passed.
- Both distributable Worker snapshots exactly match `ai-gateway/worker.js`.
- `index.html` and `assets/index.html` remain byte-identical.
- Inline JavaScript in `assets/index.html` and `assets/chart.html`: syntax checks passed.
- ZIP integrity: verified after packaging.

## Not performed / verification boundary

- Flutter/Dart SDK is unavailable in this environment. Dart tests, `dart format`, `flutter analyze`, and APK compilation were not executed.
- No Android device/WebView runtime test or live Gemini/OpenRouter/Groq request was performed.
- No GitHub push and no Cloudflare Worker deployment were performed.

This package is a complete source ZIP, not a compiled APK. Deploying the updated Worker source is required before the app receives the new Worker-side factor metadata.
