# Provider Eligibility Policy — 2026-11-21

## Scope

This change tightens the OpenRouter model catalog and the Flutter default selection so the application only offers concrete text-only language models for market/trading analysis.

## Enforced rules

- OpenRouter input modalities must be exactly `["text"]`.
- OpenRouter output modalities must be exactly `["text"]`.
- Multimodal models (including text+image) are excluded, not just image-only models.
- `openrouter/free` is excluded because it is a routing alias rather than a concrete model ID; it cannot be used as a concrete health-check target.
- OpenRouter model selection defaults to `qwen/qwen3.8-27b:free` when that model is available in the live catalog.
- The Worker remains authoritative: a manually submitted model outside the current eligible catalog is rejected before an upstream model call.
- Flutter defaults and curated priority no longer include `openrouter/free`.

This is a capability eligibility filter, not a claim that a model is profitable or accurate at trading. Models still require semantic response validation.

## API key expiration reporting

GitHub Actions Secrets are opaque secret values; their names/values do not carry a trustworthy expiry timestamp that the app can read. Provider APIs may expose key metadata differently, and many keys have no fixed expiry date. Therefore the application must not infer or invent expiration dates. A later health-status implementation should report an exact date only when returned by an authoritative provider API or supplied as explicit non-secret metadata (for example, a GitHub Actions Variable mirrored to a Worker variable). Otherwise it must report `NOT_AVAILABLE` / «اطلاعات تاریخ انقضا در دسترس نیست».

## Validation

- Worker provider catalog tests cover multimodal rejection and router-alias exclusion.
- Full Node regression suite: 131 passed, 0 failed.
