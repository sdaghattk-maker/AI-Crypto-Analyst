# AI Crypto Analyst — Provider Health & Smart Routing Delivery

Version: V6.3.1.3  
Baseline: `AI-Crypto-Analyst-PROVIDER-ELIGIBILITY-POLICY-2026-11-21-V6.3.1.2.zip`

## Scope completed

1. Removed API-key expiry reporting and all expiry-related work per user instruction.
2. No standalone API-key validation is performed. Credentials remain in Cloudflare Worker Secrets.
3. Added a real low-token inference health probe for Gemini, OpenRouter and Groq.
4. Only allow-listed text-only models eligible for structured trading analysis are probed. Multimodal models and router aliases are excluded.
5. Provider checks run independently and concurrently. Up to two eligible concrete models per provider are tried to allow a verified fallback.
6. Flutter performs the health preflight before full analysis, then submits only routable providers and pins the concrete model that passed the probe.
7. Connectivity UI now distinguishes successful catalog retrieval from successful real model inference.
8. Error reporting distinguishes authentication, access denied, model unavailable, rate limited, timeout/network, upstream failure, empty response and circuit open.
9. Added an exponential cooldown circuit breaker that records both failed preflight probes and failed full provider inference calls, with a half-open recovery probe.
10. OpenRouter compatibility retry remains pinned to the selected concrete eligible model and disables provider fallback; it cannot silently switch to `openrouter/free`.
11. Both Worker text snapshots are synchronized with the executable Worker source.

## Circuit-breaker limitation

The circuit-breaker state is isolate-local in this build. Cloudflare can run multiple isolates, so this is best-effort and is not a globally persistent breaker. Durable cross-isolate persistence requires provisioning a KV namespace or Durable Object and binding it during deployment. This package does not invent a namespace ID or claim that persistent breaker state is deployed. The normal Flutter analysis path is protected by a fresh real inference preflight on each analysis.

## Verification

- `node --check ai-gateway/worker.js`: passed.
- Full Node regression suite: **135 passed, 0 failed**.
- Includes tests for tiny inference probe, 429 classification, circuit open behavior, independent provider outcomes, OpenRouter concrete-model retry, existing Worker behavior, Binance proxy, HTML rendering and source mirror consistency.
- Flutter/Dart SDK is not installed in the build environment. Flutter compilation, Dart analyzer, APK build and Flutter widget/unit tests could not be run. Dart changes are therefore source-reviewed but not compiler-verified.

## Not included

- API-key expiry reporting (explicitly removed by user).
- Standalone API-key test.
- Any provider secret in Flutter, APK, HTML or response payload.
