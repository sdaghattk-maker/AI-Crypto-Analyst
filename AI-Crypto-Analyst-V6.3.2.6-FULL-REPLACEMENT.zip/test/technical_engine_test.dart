import 'package:flutter_test/flutter_test.dart';
import 'package:ai_crypto_analyst/services/market_api.dart';
import 'package:ai_crypto_analyst/services/technical_engine.dart';

void main() {
  final engine = TechnicalEngine();

  List<MarketCandle> trendCandles({
    required int count,
    required int seconds,
    required bool bullish,
  }) {
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    return List.generate(count, (i) {
      final base = bullish ? 100.0 + i * 0.12 : 200.0 - i * 0.12;
      final open = bullish ? base - 0.12 : base + 0.12;
      final close = bullish ? base + 0.12 : base - 0.12;
      return MarketCandle(
        time: now - seconds * (count - i + 2),
        open: open,
        high: (open > close ? open : close) + 0.18,
        low: (open < close ? open : close) - 0.18,
        close: close,
        volume: 100 + i.toDouble(),
      );
    });
  }

  List<MarketCandle> reactionCandles({required bool bullish}) {
    final rows = trendCandles(count: 180, seconds: 300, bullish: bullish);
    final index = rows.length - 2;
    final before = rows.sublist(index - 12, index);
    if (bullish) {
      final localLow = before.map((c) => c.low).reduce((a, b) => a < b ? a : b);
      rows[index] = MarketCandle(
        time: rows[index].time,
        open: localLow + 0.10,
        low: localLow - 1.0,
        high: localLow + 0.65,
        close: localLow + 0.50,
        volume: 500,
      );
      final priorHigh = rows.sublist(index - 11, index + 0)
          .map((c) => c.high).reduce((a, b) => a > b ? a : b);
      final open = priorHigh + 0.05;
      rows[index + 1] = MarketCandle(
        time: rows[index + 1].time,
        open: open,
        low: open - 0.20,
        high: open + 3.0,
        close: open + 2.8,
        volume: 700,
      );
    } else {
      final localHigh = before.map((c) => c.high).reduce((a, b) => a > b ? a : b);
      rows[index] = MarketCandle(
        time: rows[index].time,
        open: localHigh - 0.10,
        high: localHigh + 1.0,
        low: localHigh - 0.65,
        close: localHigh - 0.50,
        volume: 500,
      );
      final priorLow = rows.sublist(index - 11, index + 0)
          .map((c) => c.low).reduce((a, b) => a < b ? a : b);
      final open = priorLow - 0.05;
      rows[index + 1] = MarketCandle(
        time: rows[index + 1].time,
        open: open,
        high: open + 0.20,
        low: open - 3.0,
        close: open - 2.8,
        volume: 700,
      );
    }
    return rows;
  }

  test('flat market does not fabricate a directional signal', () {
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    List<MarketCandle> flat(int count, int seconds) => List.generate(count, (i) {
      final time = now - seconds * (count - i + 2);
      return MarketCandle(time: time, open: 100, high: 100.2, low: 99.8,
          close: 100, volume: 100);
    });
    final report = engine.analyze(
      h1: flat(100, 3600), m15: flat(120, 900), m5: flat(180, 300));
    expect(report.state, SignalState.wait);
    expect(report.entry, isNull);
    expect(report.stopLoss, isNull);
    expect(report.factorStatus['trend'], 'AVAILABLE');
    expect(report.factorStatus['marketStructure'], 'AVAILABLE');
    expect(report.factorStatus['liquidity'], 'NOT_CONFIRMED');
    expect(report.factorStatus['entryConfirmation'], 'NOT_CONFIRMED');
    expect(report.factorStatus['riskReward'], 'NOT_APPLICABLE');
    expect(report.factorScores.containsKey('liquidity'), isFalse);
  });

  test('zero-volume candles do not fabricate estimated buyer/seller pressure', () {
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    List<MarketCandle> noVolume(int count, int seconds) => List.generate(count, (i) {
      final time = now - seconds * (count - i + 2);
      return MarketCandle(time: time, open: 100, high: 101, low: 99,
          close: 100, volume: 0);
    });
    final report = engine.analyze(
      h1: noVolume(100, 3600), m15: noVolume(120, 900), m5: noVolume(180, 300));
    expect(report.powerAvailable, isFalse);
    expect(report.powerSampleCount, 0);
    expect(report.factorStatus['liquidity'], 'NOT_CONFIRMED');
  });

  test('confirmed bullish sweep then displacement can produce a buy', () {
    final report = engine.analyze(
      h1: trendCandles(count: 100, seconds: 3600, bullish: true),
      m15: trendCandles(count: 120, seconds: 900, bullish: true),
      m5: reactionCandles(bullish: true),
    );
    expect(report.state, SignalState.buy);
    expect(report.powerAvailable, isTrue);
    expect(report.entry, isNotNull);
    expect(report.stopLoss, lessThan(report.entry!));
    expect(report.tp1, greaterThan(report.entry!));
    expect(report.score, inInclusiveRange(62, 100));
  });

  test('confirmed bearish sweep then displacement can produce a sell', () {
    final report = engine.analyze(
      h1: trendCandles(count: 100, seconds: 3600, bullish: false),
      m15: trendCandles(count: 120, seconds: 900, bullish: false),
      m5: reactionCandles(bullish: false),
    );
    expect(report.state, SignalState.sell);
    expect(report.entry, isNotNull);
    expect(report.stopLoss, greaterThan(report.entry!));
    expect(report.tp1, lessThan(report.entry!));
    expect(report.score, inInclusiveRange(62, 100));
  });
}
