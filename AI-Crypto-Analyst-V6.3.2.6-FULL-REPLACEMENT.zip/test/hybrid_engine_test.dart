import 'package:flutter_test/flutter_test.dart';
import 'package:ai_crypto_analyst/services/ai_service.dart';
import 'package:ai_crypto_analyst/services/hybrid_engine.dart';
import 'package:ai_crypto_analyst/services/technical_engine.dart';

TechnicalReport technicalReport() => const TechnicalReport(
  state: SignalState.buy,
  bias1h: TradeBias.bullish,
  bias15m: TradeBias.bullish,
  bias5m: TradeBias.bullish,
  entry: 100,
  stopLoss: 99,
  tp1: 102,
  tp2: 103,
  tp3: 104,
  score: 80,
  buyerPower: 65,
  sellerPower: 35,
  rangeHigh: 105,
  rangeLow: 95,
  rsi: 60,
  atr: 1,
  reasons: ['MSS صعودی', 'نقدینگی خرید تأیید شد'],
  warnings: [],
  poiSummary: ['Bullish OB'],
  overlays: [],
  factorScores: const {'trend':100,'marketStructure':55},
  factorStatus: const {'trend':'AVAILABLE','marketStructure':'AVAILABLE','liquidity':'NOT_CONFIRMED','entryConfirmation':'NOT_CONFIRMED','riskReward':'NOT_APPLICABLE'},
);

AiModelResult provider(String name, {int? confidence, bool declared = false}) => AiModelResult(
  model: name,
  status: 'ok',
  bias: 'BUY',
  marketBias: 'BUY',
  directionalVoteEligible: true,
  tradePlanEligible: true,
  confidence: confidence,
  confidenceDeclared: declared,
  weightsProvided: true,
  analyticalWeights: const {'trend':20,'marketStructure':20,'liquidity':20,'entryConfirmation':20,'riskReward':20},
  contractStatus: 'VALID',
  evidenceStatus: 'VALIDATED',
  factorScores: const {'trend':80,'marketStructure':80,'liquidity':80,'entryConfirmation':80,'riskReward':80},
  overlays: const [
    {'type':'line','kind':'Entry','price':100.0,'timeframe':'5m','direction':'bullish'},
    {'type':'line','kind':'SL','price':99.0,'timeframe':'5m','direction':'bullish'},
    {'type':'line','kind':'TP1','price':101.0,'timeframe':'5m','direction':'bullish'},
    {'type':'line','kind':'TP2','price':101.5,'timeframe':'5m','direction':'bullish'},
    {'type':'line','kind':'TP3','price':102.0,'timeframe':'5m','direction':'bullish'},
  ],
);

void main() {
  test('Hybrid factor labels cover every supported factor key', () {
    expect(HybridEngine.labels.keys.toSet(), HybridEngine.keys.toSet());
    expect(HybridEngine.labels.values.every((label) => label.isNotEmpty), isTrue);
  });

  test('Hybrid technical factor weights always total exactly 100', () {
    final decision = HybridEngine().evaluate(
      technicalReport(),
      provider('Gemini', confidence: 80, declared: true),
    );
    expect(decision.technicalWeights.values.fold<int>(0, (sum, value) => sum + value), 100);
  });


  test('Hybrid factor weighting excludes factors without independent evidence instead of inventing neutral scores', () {
    final report = TechnicalReport(
      state: SignalState.wait, bias1h: TradeBias.bullish, bias15m: TradeBias.bullish,
      bias5m: TradeBias.neutral, entry: null, stopLoss: null, tp1: null, tp2: null, tp3: null,
      score: 40, buyerPower: 55, sellerPower: 45, rangeHigh: 105, rangeLow: 95,
      rsi: 52, atr: 1, reasons: const ['متن نقدینگی نباید به‌تنهایی امتیاز بسازد.'], warnings: const [],
      poiSummary: const [], overlays: const [],
      factorScores: const {'trend':66},
      factorStatus: const {'trend':'AVAILABLE','marketStructure':'INSUFFICIENT_DATA','liquidity':'NOT_CONFIRMED','entryConfirmation':'NOT_CONFIRMED','riskReward':'NOT_APPLICABLE'},
    );
    final decision = HybridEngine().evaluate(report, provider('Gemini'));
    expect(decision.technicalWeights['trend'], 100);
    expect(decision.technicalWeights['liquidity'], 0);
    expect(decision.technicalScore, 66);
  });


  test('AI Hybrid scoring excludes only the invalid factor and keeps valid sibling factors', () {
    final ai = AiModelResult(
      model:'Gemini', status:'ok', bias:'BUY', marketBias:'BUY', directionalVoteEligible:true,
      tradePlanEligible:true, factorScores:const {'trend':80,'marketStructure':70,'liquidity':99,'entryConfirmation':60,'riskReward':50},
      factorEvidenceValidation:const {'trend':'AVAILABLE','marketStructure':'VALIDATED','liquidity':'INVALID','entryConfirmation':'AVAILABLE','riskReward':'NOT_AVAILABLE'},
      overlays:provider('fixture').overlays,
    );
    final result=HybridEngine().evaluate(technicalReport(),ai);
    expect(result.aiWeights['trend'], greaterThan(0));
    expect(result.aiWeights['marketStructure'], greaterThan(0));
    expect(result.aiWeights['entryConfirmation'], greaterThan(0));
    expect(result.aiWeights['liquidity'], 0);
    expect(result.aiWeights['riskReward'], 0);
    expect(result.aiScore, closeTo(70, 0.01));
  });


  test('Flutter parser rejects incomplete factor-score maps instead of filling missing factors with zero', () {
    final parsed = AiModelResult.fromJson('Gemini', {
      'status':'ok','bias':'BUY','marketBias':'BUY','directionalVoteEligible':true,
      'factorScores':{'trend':80,'liquidity':70},
      'factorEvidenceValidation':{'trend':'AVAILABLE','liquidity':'AVAILABLE'},
    });
    expect(parsed.factorScores, isEmpty);
    expect(parsed.factorScoresStatus, 'INVALID_OPTIONAL_METADATA');
    expect(parsed.weightsProvided, isFalse);
  });


  test('missing AI factor scores are omitted from Hybrid weighting, not treated as zero or neutral evidence', () {
    final ai = AiModelResult(
      model:'Gemini', status:'ok', bias:'BUY', marketBias:'BUY', directionalVoteEligible:true,
      tradePlanEligible:true, factorScores:const {}, factorEvidenceValidation:const {},
      overlays:provider('fixture').overlays,
    );
    final result=HybridEngine().evaluate(technicalReport(),ai);
    expect(result.aiWeights, isEmpty);
    expect(result.aiScore, 0);
    expect(result.score, closeTo(result.technicalScore, 0.01));
    expect(result.reasons.any((reason)=>reason.contains('از ترکیب امتیاز کنار گذاشته شد')), isTrue);
  });

  test('Hybrid final decision requires two explicitly confident AI providers', () {
    final missing = provider('Gemini');
    final low = provider('OpenRouter', confidence: 40, declared: true);
    final consensus = AiConsensus(
      gemini: missing,
      openrouter: low,
      groq: AiModelResult(model: 'Groq', status: 'not_selected'),
      decision: 'WAIT',
      conflicts: const [],
    );
    final result = HybridEngine().evaluateDashboard(
      technical: technicalReport(),
      consensus: consensus,
      technicalStale: false,
      aiStale: false,
    );
    expect(result.validProviders.length, 2);
    expect(result.decision, 'WAIT');
  });

  test('two complete providers with explicit confidence can confirm the Hybrid direction', () {
    final consensus = AiConsensus(
      gemini: provider('Gemini', confidence: 80, declared: true),
      openrouter: provider('OpenRouter', confidence: 76, declared: true),
      groq: AiModelResult(model: 'Groq', status: 'not_selected'),
      decision: 'BUY',
      conflicts: const [],
    );
    final result = HybridEngine().evaluateDashboard(
      technical: technicalReport(),
      consensus: consensus,
      technicalStale: false,
      aiStale: false,
    );
    expect(result.validProviders.length, 2);
    expect(result.decision, 'BUY');
  });
  test('Final Decision rejects a directional Technical signal with an incomplete execution plan', () {
    final invalidTechnical = TechnicalReport(
      state: SignalState.buy, bias1h: TradeBias.bullish, bias15m: TradeBias.bullish,
      bias5m: TradeBias.bullish, entry: 100, stopLoss: 99, tp1: 101, tp2: null, tp3: 103,
      score: 80, buyerPower: 65, sellerPower: 35, rangeHigh: 105, rangeLow: 95,
      rsi: 60, atr: 1, reasons: const [], warnings: const [], poiSummary: const ['Bullish OB'], overlays: const [],
    );
    final consensus = AiConsensus(
      gemini: provider('Gemini', confidence: 80, declared: true),
      openrouter: provider('OpenRouter', confidence: 76, declared: true),
      groq: AiModelResult(model: 'Groq', status: 'not_selected'),
      decision: 'BUY', conflicts: const [],
    );
    final result = HybridEngine().evaluateDashboard(
      technical: invalidTechnical, consensus: consensus,
      technicalStale: false, aiStale: false,
    );
    expect(result.technicalPlanInvalid, isTrue);
    expect(result.decision, 'WAIT');
  });

  test('AI cannot trigger a BUY while Technical Engine is neutral', () {
    final neutralTechnical = TechnicalReport(
      state: SignalState.wait, bias1h: TradeBias.neutral, bias15m: TradeBias.neutral,
      bias5m: TradeBias.neutral, entry: null, stopLoss: null, tp1: null, tp2: null, tp3: null,
      score: 20, buyerPower: 50, sellerPower: 50, rangeHigh: 105, rangeLow: 95,
      rsi: 50, atr: 1, reasons: const [], warnings: const [], poiSummary: const [], overlays: const [],
    );
    final consensus = AiConsensus(
      gemini: provider('Gemini', confidence: 80, declared: true),
      openrouter: provider('OpenRouter', confidence: 76, declared: true),
      groq: AiModelResult(model: 'Groq', status: 'not_selected'),
      decision: 'BUY', conflicts: const [],
    );
    final result = HybridEngine().evaluateDashboard(technical: neutralTechnical, consensus: consensus, technicalStale: false, aiStale: false);
    expect(result.decision, 'WAIT');
  });

  test('AI and Technical directional conflict always produces WAIT', () {
    final bearishTechnical = TechnicalReport(
      state: SignalState.sell, bias1h: TradeBias.bearish, bias15m: TradeBias.bearish,
      bias5m: TradeBias.bearish, entry: 100, stopLoss: 101, tp1: 98, tp2: 97, tp3: 96,
      score: 80, buyerPower: 35, sellerPower: 65, rangeHigh: 105, rangeLow: 95,
      rsi: 40, atr: 1, reasons: const ['MSS نزولی'], warnings: const [], poiSummary: const ['Bearish OB'], overlays: const [],
    );
    final consensus = AiConsensus(
      gemini: provider('Gemini', confidence: 80, declared: true),
      openrouter: provider('OpenRouter', confidence: 76, declared: true),
      groq: AiModelResult(model: 'Groq', status: 'not_selected'),
      decision: 'BUY', conflicts: const [],
    );
    final result = HybridEngine().evaluateDashboard(technical: bearishTechnical, consensus: consensus, technicalStale: false, aiStale: false);
    expect(result.decision, 'WAIT');
  });

  test('directional AI votes survive an incomplete plan but final execution remains WAIT', () {
    final incomplete = AiModelResult(
      model:'Gemini', status:'ok', bias:'WAIT', marketBias:'BUY', directionalVoteEligible:true, confidence:80, confidenceDeclared:true,
      weightsProvided:true, contractStatus:'VALID', evidenceStatus:'VALIDATED',
      overlays: const [
        {'type':'line','kind':'Entry','price':100.0,'timeframe':'5m','direction':'bullish'},
        {'type':'line','kind':'SL','price':99.0,'timeframe':'5m','direction':'bullish'},
        {'type':'line','kind':'TP1','price':101.0,'timeframe':'5m','direction':'bullish'},
      ],
    );
    final consensus = AiConsensus(
      gemini:incomplete, openrouter:AiModelResult(model:'OpenRouter', status:'ok', bias:'WAIT', marketBias:'BUY', directionalVoteEligible:true, confidence:76, confidenceDeclared:true, weightsProvided:true, contractStatus:'VALID', evidenceStatus:'VALIDATED', overlays:incomplete.overlays),
      groq:AiModelResult(model:'Groq',status:'not_selected'), decision:'BUY', conflicts:const [],
    );
    final result = HybridEngine().evaluateDashboard(technical:technicalReport(),consensus:consensus,technicalStale:false,aiStale:false);
    expect(result.validProviders, isEmpty);
    expect(result.decision, 'WAIT');
  });


  test('directional consensus eligibility does not depend on optional factor scores', () {
    final missingFactors = AiModelResult(
      model: 'Gemini', status: 'ok', bias: 'BUY', confidence: 80,
      confidenceDeclared: true, weightsProvided: true, directionalVoteEligible:true, marketBias:'BUY', tradePlanEligible:true,
      contractStatus: 'VALID', evidenceStatus: 'VALIDATED',
      overlays: provider('fixture', confidence: 80, declared: true).overlays,
    );
    expect(aiModelIsConsensusEligible(missingFactors), isTrue);
    final valid = provider('OpenRouter', confidence: 80, declared: true);
    expect(aiModelIsConsensusEligible(valid), isTrue);
  });

  test('per-provider Hybrid card cannot promote a normalized or unverified response', () {
    final unqualified = AiModelResult(
      model:'Gemini', status:'ok', bias:'BUY', confidence:90, confidenceDeclared:true,
      weightsProvided:true, contractStatus:'NORMALIZED', evidenceStatus:'VALIDATED',
      factorScores:const {'trend':90,'marketStructure':90,'liquidity':90,'entryConfirmation':90,'riskReward':90},
      overlays:provider('fixture',confidence:90,declared:true).overlays,
    );
    final result = HybridEngine().evaluate(technicalReport(), unqualified);
    expect(result.decision, 'WAIT');
    expect(result.reasons.any((reason) => reason.contains('قرارداد V3')), isTrue);
  });

}
