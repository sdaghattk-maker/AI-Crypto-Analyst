# Provider Health Check & Smart Routing — 2026-11-21

Baseline: V6.3.1.2 provider eligibility policy build.

## Implemented
- Added `POST /providers/health`, independently probing only selected, allow-listed text-only trading-analysis models.
- Probe uses one real, tiny text inference request (8 output tokens); it does not run a separate API-key validation step.
- Provider secrets remain in Cloudflare Worker. No credential is returned to Flutter.
- Gemini, OpenRouter and Groq are probed concurrently. A provider failure does not fail other provider checks.
- The probe validates a non-empty text response and reports READY / DEGRADED / UNAVAILABLE, routability, concrete model, latency, HTTP status and normalized error code.
- 401/403, 404, 429, upstream errors, timeouts, empty responses and missing configuration are classified separately.
- Up to two eligible models per provider may be probed; a successful fallback model is returned as `selectedModel`.
- Flutter runs preflight before full analysis and submits only providers that passed real inference. It pins the verified concrete model for the full analysis.
- Connectivity reporting now uses real inference health rather than treating a successful model-catalog request as proof that inference works.
- Added isolate-local exponential circuit breaker; both failed health probes and failed full provider inference calls contribute to cooldown, with half-open recovery probes. This is best-effort only: Cloudflare isolates do not share this in-memory state. Durable cross-isolate breaker persistence requires a KV or Durable Object binding and is not claimed here.
- OpenRouter compatibility retry no longer switches to the `openrouter/free` router alias; it retries the exact concrete, eligible model with provider fallback disabled.
- Updated both distributable Worker snapshots to match `ai-gateway/worker.js` exactly.

## Explicitly not implemented / limitations
- No API-key expiry reporting or expiry lookup.
- No standalone API-key validation test.
- No persistent cross-isolate circuit-breaker storage. The app preflight still protects normal Flutter analysis flows; direct callers of `/analyze` can bypass preflight.
- Flutter/Dart toolchain was unavailable in this build environment, so Dart compilation and Flutter tests could not be executed here.

## Verification
- Worker syntax: `node --check ai-gateway/worker.js`
- Worker tests: 106 passed, 0 failed.
- Full Node regression suite: see delivery report; source-mirror test requires both Worker snapshots to be identical.
