import 'ai_service.dart';
import 'technical_engine.dart';

class HybridDecision {
  const HybridDecision({required this.provider, required this.decision, required this.score,
    required this.technicalScore, required this.aiScore, required this.technicalWeights,
    required this.aiWeights, required this.reasons, required this.calibration});
  final String provider, decision;
  final double score, technicalScore, aiScore;
  final Map<String,int> technicalWeights, aiWeights;
  final List<String> reasons;
  final String calibration;
}

class HybridDashboardSnapshot {
  const HybridDashboardSnapshot({
    required this.providers,
    required this.validProviders,
    required this.providerResults,
    required this.hybridVotes,
    required this.buyVotes,
    required this.sellVotes,
    required this.technicalInvalid,
    required this.technicalPlanInvalid,
    required this.aiInvalid,
    required this.decision,
  });
  final List<AiModelResult> providers;
  final List<AiModelResult> validProviders;
  final Map<String, HybridDecision> providerResults;
  final List<String> hybridVotes;
  final int buyVotes;
  final int sellVotes;
  final bool technicalInvalid;
  final bool technicalPlanInvalid;
  final bool aiInvalid;
  final String decision;
}

class HybridEngine {
  static const keys = ['trend','marketStructure','liquidity','entryConfirmation','riskReward'];
  // Shared factor labels used by the AI analysis UI when rendering weight maps.
  static const Map<String, String> labels = {
    'trend': 'روند',
    'marketStructure': 'ساختار بازار',
    'liquidity': 'نقدینگی',
    'entryConfirmation': 'تأیید ورود',
    'riskReward': 'ریسک به بازده',
  };

  bool _technicalHasValidExecutionPlan(TechnicalReport report) {
    if (report.state == SignalState.wait) return true;
    final entry = report.entry, stop = report.stopLoss;
    final tp1 = report.tp1, tp2 = report.tp2, tp3 = report.tp3;
    final levels = [entry, stop, tp1, tp2, tp3];
    if (levels.any((value) => value == null || !value.isFinite || value <= 0)) return false;
    final e = entry!, sl = stop!, t1 = tp1!, t2 = tp2!, t3 = tp3!;
    final risk = (e - sl).abs();
    if (risk <= 0) return false;
    if (report.state == SignalState.buy) {
      return sl < e && t1 > e && t2 > t1 && t3 > t2 &&
          (t1 - e) / risk >= 1 && (t2 - e) / risk >= 1.5 && (t3 - e) / risk >= 2;
    }
    return sl > e && t1 < e && t2 < t1 && t3 < t2 &&
        (e - t1) / risk >= 1 && (e - t2) / risk >= 1.5 && (e - t3) / risk >= 2;
  }
  Map<String,int> _equalWeightsForAvailable(Iterable<String> available) {
    final selected = keys.where(available.toSet().contains).toList();
    if (selected.isEmpty) return const {};
    final base = 100 ~/ selected.length;
    var remainder = 100 - base * selected.length;
    return {for (final key in keys) key: selected.contains(key) ? base + (remainder-- > 0 ? 1 : 0) : 0};
  }

  Map<String,int> _technicalWeights(TechnicalReport report) =>
      _equalWeightsForAvailable(keys.where((key) => report.factorStatus[key] == 'AVAILABLE' && report.factorScores.containsKey(key)));

  Map<String,int> _technicalScores(TechnicalReport report) => Map.fromEntries(
      report.factorScores.entries.where((entry) => report.factorStatus[entry.key] == 'AVAILABLE'));

  Map<String,int> _aiWeights(AiModelResult ai) => _equalWeightsForAvailable(keys.where((key) {
    final status = ai.factorEvidenceValidation[key]?.toString();
    return ai.factorScores.containsKey(key) && (status == 'AVAILABLE' || status == 'VALIDATED');
  }));

  Map<String,int> _aiScores(AiModelResult ai) => Map.fromEntries(ai.factorScores.entries.where((entry) {
    final status = ai.factorEvidenceValidation[entry.key]?.toString();
    return status == 'AVAILABLE' || status == 'VALIDATED';
  }));

  double _weighted(Map<String,int> weights, Map<String,int> scores) =>
    keys.fold<double>(0,(sum,k)=>sum+(weights[k]??0)*(scores[k]??0)/10000)*100;


  /// Single source of truth for the dashboard's final decision and its export.
  /// Both Flutter UI and the HTML snapshot exporter call this exact method.
  HybridDashboardSnapshot evaluateDashboard({
    required TechnicalReport? technical,
    required AiConsensus? consensus,
    required bool technicalStale,
    required bool aiStale,
  }) {
    final providers = consensus == null
        ? <AiModelResult>[]
        : [consensus.gemini, consensus.openrouter, consensus.groq];
    final valid = providers.where(aiModelIsConsensusEligible).toList();
    final technicalInvalid = technicalStale || technical == null;
    final technicalPlanInvalid = technical != null && !_technicalHasValidExecutionPlan(technical);
    // An AI response tied to an expired technical snapshot is invalid too.
    final aiInvalid = aiStale || technicalStale || consensus == null;
    final results = <String, HybridDecision>{};
    final votes = <String>[];
    if (technical != null) {
      for (final provider in valid) {
        final result = evaluate(technical, provider);
        results[provider.model.toLowerCase()] = result;
        if (result.decision == 'BUY' || result.decision == 'SELL') votes.add(result.decision);
      }
    }
    final buyVotes = votes.where((v) => v == 'BUY').length;
    final sellVotes = votes.where((v) => v == 'SELL').length;
    final technicalDirection = technical?.state == SignalState.buy ? 'BUY'
        : technical?.state == SignalState.sell ? 'SELL' : 'WAIT';
    final aiDirection = consensus?.decision.toUpperCase() ?? 'WAIT';
    final aiAgreeing = valid.where((provider) => (provider.marketBias ?? provider.bias)?.toUpperCase() == aiDirection).length;
    final aiPlanEligible = valid.any((provider) => (provider.marketBias ?? provider.bias)?.toUpperCase() == aiDirection && aiModelHasValidExecutionPlan(provider));
    final invalidSources = <String>[
      if (technicalInvalid) 'تکنیکال',
      if (aiInvalid) 'AI',
    ];
    // AI is a confirmation layer, never an independent trigger. The final
    // decision requires a directional technical setup AND a two-model AI
    // consensus in exactly the same direction. Neutral technical state,
    // missing consensus, or any directional disagreement must remain WAIT.
    final decision = invalidSources.isNotEmpty
        ? '${invalidSources.join(' / ')} نامعتبر'
        : (technicalPlanInvalid || !aiPlanEligible || valid.length < 2 || aiAgreeing < 2 ||
            !['BUY', 'SELL'].contains(technicalDirection) ||
            !['BUY', 'SELL'].contains(aiDirection) ||
            technicalDirection != aiDirection)
            ? 'WAIT' : technicalDirection;
    return HybridDashboardSnapshot(
      providers: providers,
      validProviders: valid,
      providerResults: results,
      hybridVotes: votes,
      buyVotes: buyVotes,
      sellVotes: sellVotes,
      technicalInvalid: technicalInvalid,
      technicalPlanInvalid: technicalPlanInvalid,
      aiInvalid: aiInvalid,
      decision: decision,
    );
  }

  HybridDecision evaluate(TechnicalReport technical, AiModelResult ai) {
    final tw = _technicalWeights(technical);
    // Until forward-tested calibration exists, model-authored importance weights
    // are not trusted as reliability weights. Use equal factor weights.
    final aw = _aiWeights(ai);
    final ts = _weighted(tw,_technicalScores(technical));
    final ascore = _weighted(aw,_aiScores(ai));
    final tDir = technical.state==SignalState.buy?1:technical.state==SignalState.sell?-1:0;
    final aiBias = (ai.marketBias ?? ai.bias)?.toUpperCase();
    final aDir = aiBias=='BUY'?1:aiBias=='SELL'?-1:0;
    final tStrength = ts*(technical.score.clamp(0,100)/100);
    // Confidence is model self-assessment, not a calibrated probability.
    // Keep the evidence score visible but do not multiply it by that claim.
    final aStrength = ascore;
    // Until sufficient out-of-sample records exist, engine-level reliability is neutral (50/50).
    final hasTechnicalFactorScores = tw.isNotEmpty;
    final hasAiFactorScores = aw.isNotEmpty;
    final combined = hasTechnicalFactorScores && hasAiFactorScores
        ? (tDir*tStrength*0.5)+(aDir*aStrength*0.5)
        : hasTechnicalFactorScores ? tDir*tStrength
        : hasAiFactorScores ? aDir*aStrength : 0.0;
    final conflict = tDir!=0 && aDir!=0 && tDir!=aDir;
    final validPlan = aiModelHasValidExecutionPlan(ai);
    final providerEligible = aiModelIsConsensusEligible(ai);
    var decision = 'WAIT';
    final directionMatches = tDir != 0 && tDir == aDir;
    if (providerEligible && validPlan && !conflict && directionMatches) decision = tDir > 0 ? 'BUY' : 'SELL';
    final reasons=<String>[];
    if (!providerEligible) {
      reasons.add(ai.directionalVoteReason ?? 'پاسخ این مدل از نظر قرارداد V3 یا شواهد کندلی واجد شرایط رأی جهت بازار نیست.');
    }
    if (ai.directionalVoteReason != null && ai.directionalVoteReason!.isNotEmpty) reasons.add(ai.directionalVoteReason!);
    reasons.add(hasTechnicalFactorScores
        ? 'امتیاز عوامل تکنیکالِ دارای داده: ${tStrength.toStringAsFixed(1)} از ۱۰۰'
        : 'امتیاز عوامل تکنیکال: داده معتبر برای امتیازدهی ارائه نشده؛ از ترکیب امتیاز کنار گذاشته شد.');
    reasons.add(hasAiFactorScores
        ? 'امتیاز عوامل AI (${ai.model}) دارای شواهد: ${aStrength.toStringAsFixed(1)} از ۱۰۰'
        : 'امتیاز عوامل AI (${ai.model}): ارائه نشده یا فاقد شواهد مستقل؛ از ترکیب امتیاز کنار گذاشته شد.');
    if(conflict) reasons.add('تعارض جهت بین تکنیکال و AI؛ تصمیم به WAIT محدود شد.');
    if(tDir==0||aDir==0) reasons.add('موتور تکنیکال یا مدل AI جهت معاملاتی ندارد؛ AI به‌تنهایی محرک ورود نیست.');
    if(!validPlan && aiBias!='WAIT') reasons.add('نقشه معامله AI کامل یا از نظر R/R معتبر نیست؛ ورود ترکیبی صادر نشد.');
    return HybridDecision(provider:ai.model,decision:decision,score:combined,technicalScore:ts,aiScore:ascore,
      technicalWeights:tw,aiWeights:aw,reasons:reasons,calibration:'امتیاز فقط از عوامل دارای داده و اعتبار مستقل محاسبه می‌شود؛ عامل فاقد داده از محاسبه کنار گذاشته می‌شود و اعتمادبه‌نفس مدل احتمال کالیبره‌شده نیست.');
  }
}
