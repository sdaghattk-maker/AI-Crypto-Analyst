import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/app_state.dart';
import '../services/analysis_controller.dart';
import '../services/technical_engine.dart';
import '../services/ai_service.dart';
import '../services/hybrid_engine.dart';
import 'connectivity_and_sources.dart';
import 'exact_snapshot_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.state, required this.analysis});
  final AppState state;
  final AnalysisController analysis;
  static const symbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT'];
  static const _mint = Color(0xFF46D6B3);
  static const _muted = Color(0xFF9AA8BD);
  static final HybridEngine _hybrid = HybridEngine();

  Future<void> _openExactSnapshot(BuildContext context) async {
    try {
      final snapshot = await analysis.buildExactExportSnapshot();
      if (!context.mounted) return;
      await Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => ExactSnapshotScreen(snapshot: snapshot),
      ));
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('باز کردن گزارش دقیق ناموفق بود: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: Listenable.merge([state, analysis]),
    builder: (context, _) {
      final report = analysis.report;
      final consensus = analysis.consensus;
      final technicalStale = analysis.isStale;
      final decisionState = _hybrid.evaluateDashboard(
        technical: report,
        consensus: consensus,
        technicalStale: technicalStale,
        aiStale: analysis.isAiStale,
      );
      final providers = decisionState.providers;
      final valid = decisionState.validProviders;
      final technicalInvalid = decisionState.technicalInvalid;
      final technicalPlanInvalid = decisionState.technicalPlanInvalid;
      final aiInvalid = decisionState.aiInvalid;
      final decision = decisionState.decision;
      final isActionable = decision == 'BUY' || decision == 'SELL';
      final decisionColor = isActionable
          ? (decision == 'BUY' ? const Color(0xFF36D69A) : const Color(0xFFFF647C))
          : const Color(0xFFFFC45C);
      final technicalDirection = report?.state == SignalState.buy ? 'BUY'
          : report?.state == SignalState.sell ? 'SELL' : 'WAIT';
      final aiDirection = consensus?.decision.toUpperCase() ?? 'WAIT';
      final reason = technicalInvalid && aiInvalid
          ? 'گزارش تکنیکال و تحلیل AI وجود ندارد یا از محدوده اعتبار ۱۵ دقیقه‌ای خارج شده‌اند. برای تصمیم جدید، داده‌ها را تازه‌سازی و تحلیل AI را جداگانه اجرا کنید.'
          : technicalInvalid ? 'گزارش تکنیکال وجود ندارد یا بیش از ۱۵ دقیقه قدیمی است؛ تا دریافت گزارش تازه، تصمیم معاملاتی معتبر نیست.'
          : aiInvalid ? 'تحلیل AI وجود ندارد یا بیش از ۱۵ دقیقه قدیمی است؛ تا دریافت پاسخ تازه از مدل‌ها، تصمیم معاملاتی معتبر نیست.'
          : technicalPlanInvalid ? 'نقشه ورود تکنیکال ناقص یا از نظر ترتیب قیمت و نسبت ریسک به بازده نامعتبر است؛ تصمیم نهایی به WAIT محدود شد.'
          : valid.length < 2 ? 'حداقل دو مدل AI با قرارداد کامل، شواهد معتبر و اطمینان اعلام‌شده لازم است.'
          : technicalDirection == 'WAIT' ? 'موتور تکنیکال هنوز جهت معاملاتی معتبر صادر نکرده است؛ AI به‌تنهایی مجاز به ایجاد سیگنال ورود نیست.'
          : !['BUY', 'SELL'].contains(aiDirection) ? 'حداقل دو مدل AI روی یک جهت معاملاتی معتبر توافق نکرده‌اند؛ اجماع AI برابر WAIT است.'
          : technicalDirection != aiDirection ? 'تعارض جهت وجود دارد: تکنیکال $technicalDirection و اجماع AI $aiDirection است؛ تصمیم نهایی به WAIT محدود شده است.'
          : 'تصمیم تکنیکال و اجماع حداقل دو مدل AI هر دو $decision هستند؛ این نتیجه تضمین سود یا احتمال برد نیست.';

      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 22),
        children: [
          Row(children: [
            Container(width: 42, height: 42, decoration: BoxDecoration(color: _mint.withValues(alpha: .13), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.insights_rounded, color: _mint)),
            const SizedBox(width: 11),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('AI Crypto Analyst', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              SizedBox(height: 2), Text('مرکز تصمیم‌گیری بازار', style: TextStyle(color: _muted, fontSize: 12)),
            ])),
            _livePill(analysis.workflowBusy),
          ]),
          const SizedBox(height: 16),
          _marketSelector(),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(
            onPressed: analysis.loading || analysis.report == null ? null : () => _openExactSnapshot(context),
            icon: const Icon(Icons.table_chart_rounded, size: 17),
            label: const Text('نمایش زنده و دقیق در Index HTML'),
          )),
          const SizedBox(height: 14),
          _decisionCard(
            decision: decision,
            color: decisionColor,
            actionable: isActionable,
            consensus: consensus,
            validCount: valid.length,
            reason: reason,
          ),
          const SizedBox(height: 14),
          _sectionTitle('ساختار بازار', trailing: '۴ منبع مستقل • 1H / 15M / 5M'),
          _structureCard(report, providers, decision, decisionColor),
          const SizedBox(height: 14),
          _sectionTitle('قدرت خریداران و فروشندگان', trailing: '۴ منبع مستقل • 5M'),
          _buyerSellerStrengthCard(report, providers),
          const SizedBox(height: 14),
          _sectionTitle('عوامل مؤثر بر تصمیم', trailing: 'خلاصه'),
          _factorsCard(report, consensus, valid),
          const SizedBox(height: 14),
          _sectionTitle('تحلیل و جزئیات', trailing: 'قابل باز شدن'),
          _detailsCard(report, consensus, providers),
          const SizedBox(height: 14),
          _marketIntelligenceEntry(context),
          const SizedBox(height: 14),
          SizedBox(height: 50, child: FilledButton.icon(
            onPressed: analysis.workflowBusy ? null : analysis.run,
            icon: analysis.workflowBusy
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.refresh_rounded),
            label: Text(analysis.workflowBusy ? 'در حال اجرای تحلیل…' : 'به‌روزرسانی داده‌های بازار و تکنیکال'),
            style: FilledButton.styleFrom(backgroundColor: _mint, foregroundColor: const Color(0xFF071B19), textStyle: const TextStyle(fontWeight: FontWeight.w800)),
          )),
          if (analysis.error != null) Padding(padding: const EdgeInsets.only(top: 9), child: Text(analysis.error!, style: const TextStyle(color: Colors.orangeAccent, fontSize: 12))),
          if (analysis.status.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 7), child: Text(analysis.status, textAlign: TextAlign.center, style: const TextStyle(color: _muted, fontSize: 11))),
        ],
      );
    },
  );

  Widget _marketIntelligenceEntry(BuildContext context) => Card(
    margin: EdgeInsets.zero,
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      leading: Container(
        width: 42, height: 42,
        decoration: BoxDecoration(color: const Color(0xFF8CE5CF).withValues(alpha: .12), borderRadius: BorderRadius.circular(13)),
        child: const Icon(Icons.insights_rounded, color: Color(0xFF8CE5CF)),
      ),
      title: const Text('Market Intelligence و altFINS', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
      subtitle: const Text('اعتبارسنجی منابع، شاخص‌های 15M و 1H و مقایسه مستقل بازار', style: TextStyle(color: _muted, fontSize: 10, height: 1.4)),
      trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 15, color: _muted),
      onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => Scaffold(
          appBar: AppBar(title: const Text('Market Intelligence و altFINS')),
          body: MarketSourcesScreen(state: state, analysis: analysis),
        ),
      )),
    ),
  );

  Widget _marketSelector() => Card(
    margin: EdgeInsets.zero,
    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), child: Row(children: [
      const Icon(Icons.currency_bitcoin, color: _mint, size: 20),
      const SizedBox(width: 8),
      Expanded(child: DropdownButtonFormField<String>(
        value: state.symbol,
        isDense: true,
        decoration: const InputDecoration(labelText: 'بازار', border: InputBorder.none, contentPadding: EdgeInsets.zero),
        items: symbols.map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(fontWeight: FontWeight.w700)))).toList(),
        onChanged: (v) { if (v != null) state.selectSymbol(v); },
      )),
      const SizedBox(width: 10),
      Container(width: 1, height: 35, color: Colors.white12),
      const SizedBox(width: 10),
      DropdownButtonHideUnderline(child: DropdownButton<String>(
        value: state.exchange,
        isDense: true,
        items: const [DropdownMenuItem(value: 'Binance', child: Text('Binance')), DropdownMenuItem(value: 'Nobitex', child: Text('نوبیتکس'))],
        onChanged: (v) { if (v != null) state.selectExchange(v); },
      )),
    ])),
  );

  Widget _decisionCard({required String decision, required Color color, required bool actionable, required AiConsensus? consensus, required int validCount, required String reason}) {
    final invalid = decision.contains('نامعتبر');
    final label = invalid ? 'داده غیرقابل استفاده' : consensus == null ? 'تحلیل AI هنوز اجرا نشده' : actionable ? 'تصمیم ترکیبی تأییدشده' : 'ورود ترکیبی تأیید نشده';
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [color.withValues(alpha: .19), const Color(0xFF151D31), const Color(0xFF11192B)]),
        border: Border.all(color: color.withValues(alpha: .48)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Expanded(child: Text('تصمیم فعلی', style: TextStyle(color: _muted, fontSize: 13, fontWeight: FontWeight.w600))),
          _statusPill(label, color),
        ]),
        const SizedBox(height: 7),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Flexible(child: Text(decision, textAlign: TextAlign.start, style: TextStyle(fontSize: decision.length > 8 ? 20 : 42, height: 1.15, letterSpacing: .3, fontWeight: FontWeight.w900, color: color))),
          const Spacer(),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(invalid ? 'داده ذخیره‌شده قدیمی / نامعتبر' : '$validCount از ۳ مدل معتبر', style: const TextStyle(color: Colors.white70, fontSize: 11)),
            if (analysis.aiAt != null) Text('آخرین تحلیل: ${_date(analysis.aiAt!)}', style: const TextStyle(color: _muted, fontSize: 10)),
          ]),
        ]),
        const SizedBox(height: 12),
        Container(height: 1, color: Colors.white12),
        const SizedBox(height: 11),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.info_outline_rounded, color: color, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(reason, style: const TextStyle(fontSize: 13, height: 1.6, color: Colors.white))),
        ]),
        if (consensus == null) const Padding(padding: EdgeInsets.only(top: 9), child: Text('برای دریافت نظر مدل‌ها، از بخش «تحلیل AI» تحلیل را اجرا کنید.', style: TextStyle(color: _muted, fontSize: 11))),
        if (invalid) const Padding(padding: EdgeInsets.only(top: 9), child: Row(children: [Icon(Icons.warning_amber_rounded, size: 14, color: Colors.orangeAccent), SizedBox(width: 5), Expanded(child: Text('داده ذخیره‌شده فقط برای مشاهده سابقه است و مبنای تصمیم معاملاتی نیست.', style: TextStyle(color: Colors.orangeAccent, fontSize: 11)))])),
      ]),
    );
  }

  Widget _structureCard(TechnicalReport? r, List<AiModelResult> providers, String finalDecision, Color finalDecisionColor) {
    const timeframes = ['1h', '15m', '5m'];
    final byName = <String, AiModelResult>{
      for (final p in providers) p.model.toLowerCase(): p,
    };

    Map<String, dynamic>? aiFrame(String name, String tf) {
      final p = byName[name.toLowerCase()];
      // Render each provider's available timeframe independently. A missing
      // 15m field must not hide a usable 1h or 5m result; consensus applies
      // stricter contract/evidence gates separately below.
      if (p == null || p.status != 'ok' || analysis.isAiStale || analysis.isStale) return null;
      final raw = p.timeframeAnalysis[tf];
      if (raw is! Map || raw['provided'] != true) return null;
      return Map<String, dynamic>.from(raw);
    }

    String technicalTrend(String tf) {
      if (r == null || analysis.isStale) return 'UNKNOWN';
      final bias = switch (tf) {
        '1h' => r.bias1h,
        '15m' => r.bias15m,
        _ => r.bias5m,
      };
      return switch (bias) {
        TradeBias.bullish => 'BULLISH',
        TradeBias.bearish => 'BEARISH',
        TradeBias.neutral => 'RANGE',
      };
    }

    String trendFor(Map<String, dynamic>? item) {
      if (item == null) return 'UNKNOWN';
      final trend = (item['trend'] ?? item['structure'] ?? 'UNKNOWN').toString().toUpperCase();
      if (const ['BULLISH', 'BEARISH', 'RANGE', 'TRANSITION'].contains(trend)) return trend;
      return 'UNKNOWN';
    }

    String phaseFor(Map<String, dynamic>? item) {
      if (item == null) return '';
      final phase = (item['phase'] ?? '').toString();
      return phase.isEmpty || phase == 'UNKNOWN' ? '' : _enumFa(phase);
    }

    Color colorFor(String trend) => switch (trend) {
      'BULLISH' => const Color(0xFF36D69A),
      'BEARISH' => const Color(0xFFFF647C),
      'RANGE' => const Color(0xFFFFC45C),
      'TRANSITION' => const Color(0xFF8C9EFF),
      _ => _muted,
    };

    String trendFa(String trend) => trend == 'UNKNOWN' ? 'ارائه نشده' : _enumFa(trend);

    Widget cell(String trend, String phase) => Expanded(
      child: Container(
        constraints: const BoxConstraints(minHeight: 48),
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 6),
        decoration: BoxDecoration(
          color: colorFor(trend).withValues(alpha: trend == 'UNKNOWN' ? .045 : .10),
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: colorFor(trend).withValues(alpha: .22)),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(trendFa(trend), textAlign: TextAlign.center,
            style: TextStyle(color: colorFor(trend), fontSize: 10, fontWeight: FontWeight.w800)),
          if (phase.isNotEmpty) Text(phase, textAlign: TextAlign.center,
            maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _muted, fontSize: 8)),
        ]),
      ),
    );

    Widget sourceRow(String name, String sourceKey) {
      return Padding(
        padding: const EdgeInsets.only(top: 7),
        child: Row(children: [
          SizedBox(width: 76, child: Text(name, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700))),
          for (final tf in timeframes)
            if (sourceKey == 'technical')
              cell(technicalTrend(tf), '')
            else
              cell(trendFor(aiFrame(sourceKey, tf)), phaseFor(aiFrame(sourceKey, tf))),
        ]),
      );
    }

    String aiTfConsensus(String tf) {
      final votes = <String, int>{'BULLISH': 0, 'BEARISH': 0, 'RANGE': 0, 'TRANSITION': 0};
      var eligibleCount = 0;
      for (final name in const ['Gemini', 'OpenRouter', 'Groq']) {
        final provider = byName[name.toLowerCase()];
        // Each timeframe has its own validation. A defect in 5m evidence or
        // another analysis factor must not suppress a valid 1h/15m vote.
        if (provider == null) continue;
        final frame = aiFrame(name, tf);
        if (frame == null || frame['narrativeOnly'] == true) continue;
        final voteMap = provider.timeframeVoteEligibility[tf.toLowerCase()];
        final eligible = voteMap is Map && voteMap['eligible'] == true;
        if (!eligible) continue;
        eligibleCount++;
        final trend = trendFor(frame);
        if (votes.containsKey(trend)) votes[trend] = votes[trend]! + 1;
      }
      final ranked = votes.entries.where((e) => e.value > 0).toList()
        ..sort((a, b) => b.value.compareTo(a.value));
      if (ranked.isEmpty || ranked.first.value < 2 ||
          (ranked.length > 1 && ranked[0].value == ranked[1].value)) return 'بدون اجماع • رأی معتبر ${eligibleCount}/۳';
      return '${trendFa(ranked.first.key)} (${ranked.first.value}/۳)';
    }

    final technicalDecision = r == null || analysis.isStale
        ? 'نامعتبر / قدیمی'
        : r.state == SignalState.buy ? 'خرید' : r.state == SignalState.sell ? 'فروش' : 'انتظار';
    final technicalDecisionColor = r == null || analysis.isStale ? Colors.orangeAccent
        : r.state == SignalState.buy ? const Color(0xFF36D69A)
        : r.state == SignalState.sell ? const Color(0xFFFF647C) : const Color(0xFFFFC45C);
    final aiDecision = analysis.isAiStale || analysis.isStale || analysis.consensus == null
        ? 'نامعتبر / موجود نیست'
        : _decisionFa(analysis.consensus!.decision);
    final aiDecisionColor = analysis.isAiStale || analysis.isStale || analysis.consensus == null
        ? Colors.orangeAccent
        : analysis.consensus!.decision == 'BUY' ? const Color(0xFF36D69A)
        : analysis.consensus!.decision == 'SELL' ? const Color(0xFFFF647C) : const Color(0xFFFFC45C);

    return Card(margin: EdgeInsets.zero, child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: const [
          SizedBox(width: 76, child: Text('منبع', style: TextStyle(color: _muted, fontSize: 9, fontWeight: FontWeight.w700))),
          Expanded(child: Center(child: Text('1H', style: TextStyle(color: _muted, fontSize: 10, fontWeight: FontWeight.w800)))),
          Expanded(child: Center(child: Text('15M', style: TextStyle(color: _muted, fontSize: 10, fontWeight: FontWeight.w800)))),
          Expanded(child: Center(child: Text('5M', style: TextStyle(color: _muted, fontSize: 10, fontWeight: FontWeight.w800)))),
        ]),
        sourceRow('Technical', 'technical'),
        sourceRow('Gemini', 'Gemini'),
        sourceRow('OpenRouter', 'OpenRouter'),
        sourceRow('Groq', 'Groq'),
        const SizedBox(height: 12),
        const Divider(height: 1),
        const Padding(padding: EdgeInsets.only(top: 9, bottom: 5), child: Text('اجماع ساختار بازار AI به تفکیک تایم‌فریم', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800))),
        for (final tf in timeframes)
          Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [
            SizedBox(width: 44, child: Text(tf.toUpperCase(), style: const TextStyle(color: _muted, fontSize: 10))),
            Expanded(child: Text(aiTfConsensus(tf), textAlign: TextAlign.end, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700))),
          ])),
        const SizedBox(height: 8),
        const Divider(height: 1),
        const Padding(padding: EdgeInsets.only(top: 9, bottom: 7), child: Text('سه لایه تصمیم‌گیری مستقل', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800))),
        _decisionSourceLine('تصمیم تکنیکال', technicalDecision, technicalDecisionColor),
        _decisionSourceLine('اجماع AI (سه مدل)', aiDecision, aiDecisionColor),
        _decisionSourceLine('تصمیم نهایی ترکیبی', finalDecision, finalDecisionColor),
        const SizedBox(height: 7),
        Text('هر خانه فقط داده همان منبع را نشان می‌دهد. روند استخراج‌شده از متن گزارش قابل مشاهده است، اما تا اعتبارسنجی ساختار و شواهد رأی اجماع محسوب نمی‌شود. «ارائه نشده» به معنی خنثی یا خلاف جهت نیست؛ اجماع فقط با حداقل دو نظر معتبر نمایش داده می‌شود.',
          style: const TextStyle(color: _muted, fontSize: 9, height: 1.5)),
        if (analysis.technicalAt != null) _detailLine('به‌روزرسانی تکنیکال', _date(analysis.technicalAt!)),
        _detailLine('آخرین تحلیل AI', analysis.aiAt == null ? 'ثبت نشده' : _date(analysis.aiAt!)),
      ]),
    ));
  }

  Widget _buyerSellerStrengthCard(TechnicalReport? report, List<AiModelResult> providers) {
    const buyerColor = Color(0xFF36D6A0);
    const sellerColor = Color(0xFFFF687F);
    final byName = <String, AiModelResult>{
      for (final provider in providers) provider.model.toLowerCase(): provider,
    };

    ({int buyer, int seller, String status})? aiStrength(String key) {
      if (analysis.isAiStale || analysis.isStale) return null;
      final provider = byName[key.toLowerCase()];
      if (provider == null || provider.status != 'ok') return null;
      dynamic rawValue;
      for (final entry in provider.timeframeAnalysis.entries) {
        final key = entry.key.toString().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
        if (const {'5m', '5min', '5minute'}.contains(key)) {
          rawValue = entry.value;
          break;
        }
      }
      if (rawValue is! Map) return null;
      final raw = Map<String, dynamic>.from(rawValue);
      if (raw['provided'] == false || raw['strengthMethod'] != 'PROVIDER_DECLARED_COMPLEMENTARY_PERCENT' || raw['strengthSource'] != 'MODEL_RESPONSE' || raw['strengthComparable'] != true) return null;
      final buyerRaw = raw['buyerStrength'] ?? raw['buyersStrength'] ?? raw['buyStrength'];
      final sellerRaw = raw['sellerStrength'] ?? raw['sellersStrength'] ?? raw['sellStrength'];
      if (buyerRaw is! num || sellerRaw is! num) return null;
      final buyer = buyerRaw.round();
      final seller = sellerRaw.round();
      if (buyer < 0 || buyer > 100 || seller < 0 || seller > 100 || (buyer + seller - 100).abs() > 2) return null;
      const status = 'درصد اعلامی مدل';
      return (buyer: buyer, seller: seller, status: status);
    }

    Widget strengthTile({required String title, required int? buyer, required int? seller, required String status}) {
      final available = buyer != null && seller != null;
      final buyerValue = available ? '$buyer٪' : '—';
      final sellerValue = available ? '$seller٪' : '—';
      final statusColor = !available ? _muted : status == 'معتبر' ? _mint : const Color(0xFFFFC45C);
      return Container(
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
          color: const Color(0xFF151F33),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: statusColor.withValues(alpha: .22)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800))),
            Container(width: 6, height: 6, decoration: BoxDecoration(color: statusColor, shape: BoxShape.circle)),
          ]),
          const SizedBox(height: 9),
          Row(children: [
            Expanded(child: Text('خریدار  $buyerValue', style: TextStyle(color: available ? buyerColor : _muted, fontSize: 10, fontWeight: FontWeight.w800))),
            Expanded(child: Text('فروشنده  $sellerValue', textAlign: TextAlign.end, style: TextStyle(color: available ? sellerColor : _muted, fontSize: 10, fontWeight: FontWeight.w800))),
          ]),
          const SizedBox(height: 7),
          ClipRRect(borderRadius: BorderRadius.circular(20), child: SizedBox(height: 9, child: Row(children: [
            if (available) ...[
              Expanded(flex: buyer!, child: Container(color: buyerColor)),
              Expanded(flex: seller!, child: Container(color: sellerColor)),
            ] else
              Expanded(child: Container(color: Colors.white10)),
          ]))),
          const SizedBox(height: 6),
          Text(available ? status : 'قدرت 5M ارائه نشده', style: TextStyle(color: statusColor, fontSize: 8, fontWeight: FontWeight.w600)),
        ]),
      );
    }

    final technicalAvailable = report != null && !analysis.isStale;
    final gemini = aiStrength('Gemini');
    final openrouter = aiStrength('OpenRouter');
    final groq = aiStrength('Groq');
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('مقادیر هر منبع مستقل نمایش داده می‌شود؛ درصدهای AI با محاسبه TECHNICAL ادغام نمی‌شوند.',
            style: TextStyle(color: _muted, fontSize: 9, height: 1.45)),
          const SizedBox(height: 9),
          LayoutBuilder(builder: (context, constraints) {
            final width = (constraints.maxWidth - 8) / 2;
            return Wrap(spacing: 8, runSpacing: 8, children: [
              SizedBox(width: width, child: strengthTile(title: 'TECHNICAL', buyer: technicalAvailable && report!.powerAvailable ? report!.buyerPower : null, seller: technicalAvailable && report!.powerAvailable ? report!.sellerPower : null, status: report?.powerAvailable == true ? 'برآورد OHLCV' : 'حجم کافی نیست')),
              SizedBox(width: width, child: strengthTile(title: 'GEMINI', buyer: gemini?.buyer, seller: gemini?.seller, status: gemini?.status ?? '')),
              SizedBox(width: width, child: strengthTile(title: 'OPENROUTER', buyer: openrouter?.buyer, seller: openrouter?.seller, status: openrouter?.status ?? '')),
              SizedBox(width: width, child: strengthTile(title: 'GROQ', buyer: groq?.buyer, seller: groq?.seller, status: groq?.status ?? '')),
            ]);
          }),
          const SizedBox(height: 7),
          const Text('TECHNICAL برآورد مستقل OHLCV است؛ درصدهای AI مقادیر اعلام‌شده توسط خود مدل‌اند و محاسبه مستقل فشار سفارش نیستند. هیچ‌کدام جریان سفارش واقعی را اندازه‌گیری نمی‌کنند.',
            style: TextStyle(color: _muted, fontSize: 8, height: 1.4)),
        ]),
      ),
    );
  }

  Widget _decisionSourceLine(String label, String value, Color color) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(children: [
      Expanded(child: Text(label, style: const TextStyle(color: _muted, fontSize: 10))),
      Text(value, textAlign: TextAlign.end, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w800)),
    ]),
  );

  Widget _factorsCard(TechnicalReport? r, AiConsensus? c, List<AiModelResult> valid) {
    final hasEntry = r?.entry != null && r?.stopLoss != null;
    final modelAgreement = valid.length >= 2 && c != null && (c.decision == 'BUY' || c.decision == 'SELL');
    final structureAligned = r != null && r.bias1h == r.bias15m && r.bias15m == r.bias5m && r.bias1h != TradeBias.neutral;
    return Card(margin: EdgeInsets.zero, child: Column(children: [
      _factorRow(Icons.account_tree_outlined, 'جهت تایم‌فریم‌ها', analysis.isStale ? 'تکنیکال نامعتبر' : structureAligned ? 'هم‌جهت' : r == null ? 'داده موجود نیست' : 'ناهمسو / خنثی', !analysis.isStale && structureAligned ? _mint : Colors.orangeAccent),
      const Divider(height: 1, indent: 14, endIndent: 14),
      _factorRow(Icons.groups_2_outlined, 'اجماع خام AI', (analysis.isAiStale || analysis.isStale) ? 'AI نامعتبر' : modelAgreement ? 'اجماع ${_decisionFa(c!.decision)}' : '${valid.length} مدل معتبر؛ بدون اجماع', !(analysis.isAiStale || analysis.isStale) && modelAgreement ? _mint : Colors.orangeAccent),
      const Divider(height: 1, indent: 14, endIndent: 14),
      _factorRow(Icons.my_location_outlined, 'نقشه ورود تکنیکال', analysis.isStale ? 'تکنیکال نامعتبر' : hasEntry ? 'سطوح محاسبه شده' : 'ورود مشخص نشده', !analysis.isStale && hasEntry ? _mint : _muted),
      const Divider(height: 1, indent: 14, endIndent: 14),
      _factorRow(Icons.verified_outlined, 'کیفیت پاسخ AI', (analysis.isAiStale || analysis.isStale) ? 'AI نامعتبر' : c == null ? 'تحلیلی دریافت نشده' : '${valid.length} پاسخ با قرارداد معتبر', !(analysis.isAiStale || analysis.isStale) && valid.length >= 2 ? _mint : Colors.orangeAccent),
    ]));
  }

  Widget _detailsCard(TechnicalReport? r, AiConsensus? c, List<AiModelResult> providers) => Card(
    margin: EdgeInsets.zero,
    child: Column(children: [
      ExpansionTile(leading: const Icon(Icons.tune_rounded, color: _mint), title: const Text('جزئیات تکنیکال', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('RSI، CRT، Entry، حد ضرر و اهداف', style: TextStyle(color: _muted, fontSize: 11)), children: [
        if (r == null) const Padding(padding: EdgeInsets.all(14), child: Text('هنوز گزارش تکنیکال وجود ندارد.')) else Padding(padding: const EdgeInsets.fromLTRB(15, 0, 15, 14), child: Column(children: [
          _detailLine('امتیاز شواهد', '${r.score}/100'), _detailLine('RSI پنج‌دقیقه', r.rsi.toStringAsFixed(1)),
          _detailLine('محدوده CRT', '${_p(r.rangeLow)} تا ${_p(r.rangeHigh)}'),
          _detailLine('Entry', _p(r.entry)), _detailLine('Stop Loss', _p(r.stopLoss)),
          _detailLine('TP1 / TP2 / TP3', '${_p(r.tp1)} / ${_p(r.tp2)} / ${_p(r.tp3)}'),
          ...r.reasons.take(5).map((x) => _bullet(x, _mint)),
          ...r.warnings.take(5).map((x) => _bullet(x, Colors.orangeAccent)),
        ])),
      ]),
      const Divider(height: 1, indent: 14, endIndent: 14),
      ExpansionTile(leading: const Icon(Icons.hub_outlined, color: _mint), title: const Text('وضعیت سه مدل AI', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('جزئیات، اختلاف‌ها و خطاها', style: TextStyle(color: _muted, fontSize: 11)), children: [
        if (c == null) const Padding(padding: EdgeInsets.all(14), child: Text('نتیجه‌ای از مدل‌ها ذخیره نشده است.')) else Padding(padding: const EdgeInsets.fromLTRB(15, 0, 15, 14), child: Column(children: [
          for (final p in providers) _providerTile(p),
          if (c.conflicts.isNotEmpty) ...[
            const Align(alignment: Alignment.centerRight, child: Text('اختلاف‌ها و محدودیت‌ها', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orangeAccent))),
            ...c.conflicts.take(8).map((x) => _bullet(x, Colors.orangeAccent)),
          ],
        ])),
      ]),
      const Divider(height: 1, indent: 14, endIndent: 14),
      ExpansionTile(leading: const Icon(Icons.dataset_outlined, color: _mint), title: const Text('داده‌های تکمیلی', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('فقط داده‌های واقعاً گزارش‌شده توسط مدل‌ها', style: TextStyle(color: _muted, fontSize: 11)), children: [
        if (c == null) const Padding(padding: EdgeInsets.all(14), child: Text('داده‌ای در دسترس نیست.')) else Padding(padding: const EdgeInsets.fromLTRB(15, 0, 15, 14), child: _dataSummary(providers)),
      ]),
    ]),
  );

  Widget _dataSummary(List<AiModelResult> providers) {
    const labels = {'orderBook':'دفتر سفارش','derivatives':'مشتقات','liquidations':'لیکوییدیشن','onChain':'آن‌چین','news':'اخبار و احساسات','externalIndicators':'شاخص‌های بیرونی'};
    final rows = <Widget>[];
    for (final p in providers.where(_isValid)) {
      for (final entry in p.dataCategories.entries) {
        final key = entry.key;
        final value = entry.value;
        final title = labels[key] ?? key;
        final text = value is Map ? (value['status'] ?? value['availability'] ?? value['summary'] ?? 'گزارش شده').toString() : value.toString();
        rows.add(_detailLine('${p.model} • $title', text));
      }
    }
    if (rows.isEmpty) return const Align(alignment: Alignment.centerRight, child: Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('مدل‌ها داده تکمیلی قابل‌استنادی گزارش نکرده‌اند؛ چیزی از روی حدس پر نشده است.', style: TextStyle(color: _muted, fontSize: 12))));
    return Column(children: rows.take(18).toList());
  }

  Widget _providerTile(AiModelResult p) {
    final ok = _isValid(p);
    final hasReport = p.analysisSections.isNotEmpty || p.timeframeAnalysis.isNotEmpty || (p.summary ?? '').trim().isNotEmpty;
    final color = ok ? _mint : Colors.orangeAccent;
    final rawSummary = (p.summary ?? '').trim();
    final summary = rawSummary.startsWith('{') && rawSummary.endsWith('}')
        ? 'متن ساختاریافته دریافت شد؛ جزئیات در بخش‌های زیر نمایش داده می‌شود.'
        : rawSummary;
    return Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(p.model, style: const TextStyle(fontWeight: FontWeight.w700))), _statusPill(ok ? 'معتبر و قابل‌اجماع' : hasReport ? 'گزارش دریافت شد • غیرقابل‌اجماع' : _statusFa(p), color)]),
      const SizedBox(height: 4),
      _detailLine('جهت بازار / اطمینان', '${p.marketBias ?? p.bias ?? '—'} • ${p.confidenceDeclared && p.confidence != null ? '${p.confidence}%' : 'اطمینان اعلام نشده'}'),
      _detailLine('اعتبار برنامه ورود', aiModelHasValidExecutionPlan(p) ? 'معتبر' : 'ناقص / غیرقابل اجرا'),
      if (summary.isNotEmpty) Text(summary, style: const TextStyle(color: Colors.white70, fontSize: 12, height: 1.5)),
      if (p.analysisSections.isNotEmpty) ...[
        const SizedBox(height: 8),
        const Align(alignment: Alignment.centerRight, child: Text('بخش‌های تحلیل ساختاریافته مدل', style: TextStyle(color: _mint, fontSize: 11, fontWeight: FontWeight.w800))),
        const SizedBox(height: 4),
        for (final entry in p.analysisSections.entries)
          if (entry.value is Map && (entry.value['findings'] is List) && (entry.value['findings'] as List).isNotEmpty)
            _detailLine(_sectionFa(entry.key), (entry.value['findings'] as List).take(2).join(' • ')),
      ],
      if (p.timeframeAnalysis.isNotEmpty) ...[
        const SizedBox(height: 8),
        const Align(alignment: Alignment.centerRight, child: Text('Market Structure مدل', style: TextStyle(color: _mint, fontSize: 11, fontWeight: FontWeight.w800))),
        const SizedBox(height: 4),
        for (final tf in const ['1h', '15m', '5m'])
          if (p.timeframeAnalysis[tf] is Map) _aiTimeframeRow(tf, Map<String, dynamic>.from(p.timeframeAnalysis[tf] as Map)),
      ],
      if ((p.error ?? '').isNotEmpty) Text(p.error!, style: const TextStyle(color: Colors.orangeAccent, fontSize: 11)),
    ]));
  }

  Widget _aiTimeframeRow(String tf, Map<String, dynamic> data) {
    final structure = _enumFa(data['structure']?.toString() ?? 'UNKNOWN');
    final trend = _enumFa(data['trend']?.toString() ?? 'UNKNOWN');
    final event = _eventFa(data['structureEvent']?.toString() ?? 'UNKNOWN');
    final phase = _enumFa(data['phase']?.toString() ?? 'UNKNOWN');
    final liquidity = _enumFa(data['liquidity']?.toString() ?? 'UNKNOWN');
    final evidence = data['evidence'] is List ? (data['evidence'] as List).map((e) => e.toString()).take(2).join(' • ') : '';
    return Container(margin: const EdgeInsets.only(top: 5), padding: const EdgeInsets.all(9), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .035), borderRadius: BorderRadius.circular(10)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Text(tf.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 10, color: _mint)), const SizedBox(width: 8), Expanded(child: Text('ساختار: $structure  |  روند: $trend', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600))),]),
      const SizedBox(height: 3),
      Text('رویداد: $event  •  فاز: $phase  •  نقدینگی: $liquidity', style: const TextStyle(fontSize: 10, color: _muted)),
      if (data['narrativeOnly'] == true)
        const Padding(padding: EdgeInsets.only(top: 3), child: Text('روند استخراج‌شده از متن گزارش • رویداد ساختاری هنوز تأیید نشده', style: TextStyle(fontSize: 9, color: Colors.orangeAccent)))
      else if (data['narrativeSupplemented'] == true)
        const Padding(padding: EdgeInsets.only(top: 3), child: Text('داده ساختاری با متن گزارش تکمیل شده است', style: TextStyle(fontSize: 9, color: _muted))),
      if (evidence.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(evidence, style: const TextStyle(fontSize: 10, color: Colors.white60, height: 1.4))),
    ]));
  }

  Widget _tfTile(String title, String value, Color color, String hint) => Container(
    padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 7),
    decoration: BoxDecoration(color: color.withValues(alpha: .08), borderRadius: BorderRadius.circular(13), border: Border.all(color: color.withValues(alpha: .22))),
    child: Column(children: [Text(title, style: const TextStyle(color: _muted, fontSize: 11)), const SizedBox(height: 6), Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 14)), const SizedBox(height: 3), Text(hint, style: const TextStyle(color: _muted, fontSize: 9), textAlign: TextAlign.center)],),
  );
  Widget _miniMetric(String title, String value, Color color) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: Text(title, style: const TextStyle(color: _muted, fontSize: 10))), Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 11))]), const SizedBox(height: 5), ClipRRect(borderRadius: BorderRadius.circular(5), child: LinearProgressIndicator(value: (int.tryParse(value.replaceAll('%', '')) ?? 0) / 100, minHeight: 5, backgroundColor: Colors.white10, color: color))]);
  Widget _factorRow(IconData icon, String title, String value, Color color) => Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), child: Row(children: [Icon(icon, size: 18, color: _muted), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12))), Flexible(child: Text(value, textAlign: TextAlign.end, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)))]));
  Widget _detailLine(String title, String value) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Text(title, style: const TextStyle(color: _muted, fontSize: 11))), const SizedBox(width: 10), Flexible(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)))]));
  Widget _bullet(String text, Color color) => Padding(padding: const EdgeInsets.only(top: 6), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.circle, size: 5, color: color), const SizedBox(width: 7), Expanded(child: Text(text, style: const TextStyle(color: Colors.white70, fontSize: 11, height: 1.45)))]));
  Widget _emptyCard(String text) => Card(margin: EdgeInsets.zero, child: Padding(padding: const EdgeInsets.all(15), child: Text(text, style: const TextStyle(color: _muted, fontSize: 12))));
  Widget _sectionTitle(String title, {String? trailing}) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(children: [Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)), const Spacer(), if (trailing != null) Text(trailing, style: const TextStyle(color: _muted, fontSize: 10))]));
  Widget _statusPill(String text, Color color) => Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(20), border: Border.all(color: color.withValues(alpha: .25))), child: Text(text, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700)));
  Widget _livePill(bool loading) => Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: (loading ? Colors.orangeAccent : _mint).withValues(alpha: .10), borderRadius: BorderRadius.circular(18)), child: Row(children: [Icon(loading ? Icons.sync : Icons.circle, size: 8, color: loading ? Colors.orangeAccent : _mint), const SizedBox(width: 5), Text(loading ? 'در حال تحلیل' : 'داشبورد', style: TextStyle(color: loading ? Colors.orangeAccent : _mint, fontSize: 10, fontWeight: FontWeight.w700))]));

  static bool _isValid(AiModelResult p) => aiModelIsConsensusEligible(p);
  static String _decisionReason(AiConsensus? c, List<AiModelResult> valid) {
    if (c == null) return 'هنوز خروجی معتبری از تحلیل هوش مصنوعی ثبت نشده است.';
    if (valid.length < 2) return 'برای تصمیم جهت‌دار، حداقل دو پاسخ معتبر و قابل‌مقایسه لازم است. فعلاً ورود تأیید نمی‌شود.';
    if (c.decision == 'WAIT') return c.conflicts.isNotEmpty ? c.conflicts.first : 'مدل‌ها اجماع جهت‌دار کافی ندارند یا شرایط ورود کامل نشده است.';
    final summaries = valid.where((p) => (p.marketBias ?? p.bias)?.toUpperCase() == c.decision).map((p) => p.summary).whereType<String>().where((s) => s.trim().isNotEmpty).take(1).toList();
    return summaries.isNotEmpty ? summaries.first : 'حداقل دو مدل معتبر با جهت ${c.decision} هم‌نظر هستند؛ جزئیات و ریسک‌ها را پیش از اقدام بررسی کنید.';
  }
  static String _enumFa(String value) => switch (value.toUpperCase()) {
    'BULLISH' => 'صعودی', 'BEARISH' => 'نزولی', 'RANGE' => 'رنج', 'TRANSITION' => 'گذار',
    'TRENDING' => 'رونددار', 'RANGING' => 'نوسانی', 'ACCUMULATION' => 'تجمیع', 'DISTRIBUTION' => 'توزیع', 'REVERSAL' => 'بازگشت',
    'BUY_SIDE_SWEEP' => 'جاروب نقدینگی خرید', 'SELL_SIDE_SWEEP' => 'جاروب نقدینگی فروش', 'BUY_SIDE_LIQUIDITY_POOL' => 'استخر نقدینگی خرید', 'SELL_SIDE_LIQUIDITY_POOL' => 'استخر نقدینگی فروش', 'BOTH_SWEEPS' => 'جاروب هر دو سمت', 'BOTH_POOLS' => 'استخر هر دو سمت', 'NONE' => 'مشاهده نشد', 'UNKNOWN' => 'ارائه نشده', _ => value,
  };
  static String _eventFa(String value) => switch (value.toUpperCase()) {
    'BOS_BULLISH' => 'BOS صعودی', 'BOS_BEARISH' => 'BOS نزولی',
    'CHOCH_BULLISH' => 'CHOCH صعودی', 'CHOCH_BEARISH' => 'CHOCH نزولی',
    'MSS_BULLISH' => 'MSS صعودی', 'MSS_BEARISH' => 'MSS نزولی',
    'NONE' => 'رویداد تأییدشده ندارد', 'UNKNOWN' => 'ارائه نشده / نامشخص', _ => value,
  };
  static String _decisionFa(String d) => d == 'BUY' ? 'خرید' : d == 'SELL' ? 'فروش' : 'انتظار';
  static String _statusFa(AiModelResult p) => p.status == 'error' ? 'خطا' : p.directionalVoteEligible ? 'رأی جهت بازار معتبر' : p.contractStatus == 'VALID' && p.evidenceStatus == 'VALIDATED' ? 'قالب و شواهد معتبر • جهت غیرقابل‌رأی' : p.contractStatus == 'VALID' ? 'قالب کامل • شواهد تأییدنشده' : p.contractStatus == 'NORMALIZED' ? 'ساختار نرمال‌سازی‌شده' : p.contractStatus == 'PARTIAL' || p.contractStatus == 'DEGRADED' ? 'پاسخ ناقص' : 'قالب نامعتبر';
  static String _sectionFa(String key) => const {'regime':'رژیم بازار','structure':'ساختار بازار','liquidity':'نقدینگی','poi':'نواحی مهم','premiumDiscount':'Premium / Discount','volumeMomentum':'حجم و مومنتوم','scenarios':'سناریوها','execution':'اجرای معامله','dataQuality':'کیفیت داده'}[key] ?? key;
  static String _biasFa(TradeBias b) => switch (b) { TradeBias.bullish => 'صعودی', TradeBias.bearish => 'نزولی', TradeBias.neutral => 'خنثی' };
  static Color _biasColor(TradeBias b) => b == TradeBias.bullish ? const Color(0xFF36D69A) : b == TradeBias.bearish ? const Color(0xFFFF647C) : const Color(0xFFFFC45C);
  static String _p(double? v) => v == null ? '—' : v.toStringAsFixed(2);
  static String _date(DateTime d) => '${d.toLocal().month.toString().padLeft(2, '0')}/${d.toLocal().day.toString().padLeft(2, '0')} ${d.toLocal().hour.toString().padLeft(2, '0')}:${d.toLocal().minute.toString().padLeft(2, '0')}';
}
