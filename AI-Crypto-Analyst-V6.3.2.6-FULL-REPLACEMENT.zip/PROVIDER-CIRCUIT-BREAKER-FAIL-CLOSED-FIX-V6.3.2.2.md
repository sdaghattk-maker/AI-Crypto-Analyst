# Provider Circuit Breaker Fail-Closed Fix — V6.3.2.2

## Scope
Fixes the production safety issue identified in V6.3.2.1: the Worker previously fell back to isolate-local `Map` state when the `PROVIDER_CIRCUIT_BREAKER` Durable Object binding was missing.

## Changes
- Removed the isolate-local circuit-state fallback and its mutable state map.
- Circuit operations now require a valid `PROVIDER_CIRCUIT_BREAKER` namespace binding and valid Durable Object stub/response.
- Missing, malformed, or unavailable Durable Object binding/storage fails closed. Provider health reports `CIRCUIT_STATE_UNAVAILABLE`; it does not send inference probes without shared circuit state.
- `/health` now reports whether the Durable Object binding is configured (`providerCircuitBreaker`).
- Test fixtures now provide a simulated Durable Object namespace with persistent storage and serialized transactions.
- Added a regression test proving that missing binding blocks upstream inference.
- Synchronized all four Worker text snapshots with `ai-gateway/worker.js`.

## Verification
- `node --check ai-gateway/worker.js`: passed.
- Worker tests: 110 passed, 0 failed.
- Full Node regression suite (AI Gateway, app JS tests, Binance proxy): 138 passed, 0 failed.
- ZIP integrity: verified after packaging.

## Deployment note
This change intentionally requires the Durable Object binding. Deploy with the existing `PROVIDER_CIRCUIT_BREAKER` binding and migration `v1-provider-circuit-breaker` in `ai-gateway/wrangler.toml`. If the binding is absent or unavailable, provider inference is blocked rather than silently using per-isolate memory. No live Cloudflare deployment or live provider test was performed in this environment.
