# Index timeframe accordion redesign — V6.3.1 (2026-11-21)

## Scope
Presentation-only repair of the exact Snapshot report screen. No Worker, AI normalization, consensus, Technical Engine, altFINS acquisition, or trade-plan logic was changed.

## UI changes
- Replaced the crowded three-column timeframe/source presentation with three responsive, vertically stacked expandable timeframe sections: 1H, 15M, and 5M.
- Each timeframe accordion groups the same timeframe's independent data from Technical, Gemini, OpenRouter, Groq, and altFINS.
- Each source inside a timeframe has its own nested accordion. Missing timeframe data is explicitly shown as not provided; another timeframe or provider is never used to fill it.
- Direction and status chips are shown where the source actually provides them. Status values such as NOT_FETCHED, NOT_PROVIDED, UNKNOWN, NOT_CONFIRMED, PARTIAL, and INSUFFICIENT_DATA remain distinguishable and receive Persian display labels.
- Added a separate collapsed source archive for complete source-level fields, provider analysis sections, data categories, evidence validation, timeframe provenance, full timeframe maps, raw model text, and raw provider HTTP responses.
- Existing overall consensus, Hybrid decision, audit, and original Snapshot JSON sections remain available.
- Kept `index.html` and `assets/index.html` byte-identical for the WebView and standalone entry points.

## Data preservation guarantees
- This is a presentation-only change. Snapshot JSON is not mutated, rewritten, recalculated, or filtered before display.
- All timeframe objects are rendered in their matching timeframe section; complete source-level data and original raw payloads remain accessible in the source archive and raw Snapshot viewer.
- Missing source data is reported as missing, not inferred from another source.

## Validation
- Inline JavaScript syntax check: passed.
- Full Node regression suite: 131 passed, 0 failed.
- Dedicated rendering regression verifies timeframe grouping, all five source groups, evidence and buyer-strength fields, raw provider text, structured analysis sections, and missing altFINS status.
- `index.html` and `assets/index.html` are byte-identical.
- Flutter/Dart SDK and Android WebView runtime were not available; no APK build or on-device visual test was performed.
- No GitHub push or Cloudflare deployment was performed.
