# Durable Provider Circuit Breaker — V6.3.2 implementation

## What changed
- Replaced production isolate-local circuit state with the `PROVIDER_CIRCUIT_BREAKER` Durable Object binding.
- Uses one Durable Object identity per provider/model key, keeping Gemini, OpenRouter and Groq model circuits independent.
- Stores failure count, next-probe time, last error and half-open lease in Durable Object persistent storage.
- Uses a storage transaction for acquire/failure/success operations. After cooldown, only one request can acquire the half-open probe lease; competing Worker isolates are denied until the lease expires or a success/failure is recorded.
- Provider success clears the durable circuit. Failed health probes and failed full provider inference calls increment the same durable circuit.
- Fails closed if a configured Durable Object namespace becomes unavailable. The in-memory Map is retained only for local tests/development when the binding is absent; it is not the production persistence mechanism.

## Cloudflare configuration
`ai-gateway/wrangler.toml` now declares:
- Durable Object binding: `PROVIDER_CIRCUIT_BREAKER`
- Class: `ProviderCircuitBreaker`
- SQLite-backed migration: `v1-provider-circuit-breaker`

## Deployment prerequisite — preserve existing RATE_LIMITER
The user supplied the existing Cloudflare Rate Limiting namespace ID `1001`. The project now declares the `RATE_LIMITER` binding and preserves the displayed 5-per-60-second policy:

```toml
[[ratelimits]]
name = "RATE_LIMITER"
namespace_id = "1001"

[ratelimits.simple]
limit = 5
period = 60
```

Do not guess the namespace ID and do not deploy a config that may omit the existing binding. Once that exact ID is configured, deploy from `ai-gateway/`:

```bash
npx wrangler deploy
```

The existing Gemini, OpenRouter and Groq secrets must remain configured in the target Worker environment. No API-key validation or expiry check was added.

## Verification
- Worker syntax check: `node --check ai-gateway/worker.js`
- Complete Node regression suite: 137 passed, 0 failed.
- Durable Object class tests cover state surviving a new object instance, open-circuit blocking, concurrent half-open acquisition (exactly one winner), and recovery.
- Worker integration test confirms `/providers/health` uses the Durable Object namespace and blocks subsequent upstream calls after a 429.
- `wrangler.toml` parsed with Python `tomllib`; Durable Object binding and SQLite migration assertions passed.
- All four distributable Worker text mirrors compare byte-for-byte equal to `ai-gateway/worker.js`.

## Important deployment boundary
The binding and migration are declared in source, but this repository change does not deploy to the user's Cloudflare account. A live deployment is required before production requests use shared durable state. The existing `RATE_LIMITER` namespace ID `1001` was supplied by the user and is now included in `wrangler.toml`.
