# AI Crypto Analyst — Current Source Package

Current complete source baseline: **V6.3.1 Timeframe Accordion UI + V6.3.0 Factor Independence Repair**, based on verified V6.2.2 SHA256 `8ee6a70c5ecfc8d1173d55661fca024196b9f5745f38f36cb7bc0744e741117d`. Historical repair notes below are retained as project history; see `AI-FACTOR-INDEPENDENCE-REPAIR-V6.3.0.md` for the current stage-by-stage implementation.

## Current source of truth
- Flutter app: `lib/`
- AI Gateway Worker: `ai-gateway/worker.js`
- Binance Proxy Worker: `binance-proxy/worker.js`
- The generic and legacy-named Gateway text snapshots are synchronized with `ai-gateway/worker.js`.
- `index.html` and `assets/index.html` are byte-identical.

## Main corrections in this package
- Compact quantized OHLCV history validation with explicit precision metadata and timestamp/interval alignment checks.
- Model response normalization with raw response retention, explicit truncation metadata, full normalization diagnostics, and confidence range validation. Full provider narrative is parsed for explicit per-timeframe trend declarations when structured timeframe fields are missing.
- Candle-backed validation for BOS/CHOCH/MSS, liquidity sweeps, OB/FVG and execution levels. Directional Entry/SL/TP plans are additionally checked against live reference price, 5m ATR, POI proximity, and the POI invalidation boundary; failed checks downgrade to WAIT and expose structured diagnostics in Flutter.
- Cross-timeframe semantic checks: directional AI plans must agree with 5m trend or a validated 5m reversal; fully opposing 1h/15m structure requires a validated higher-timeframe reversal.
- Independent Gemini/OpenRouter/Groq responses and a minimum two-model consensus.
- Consensus overlays require corroboration across eligible agreeing providers; partial retries cannot union single-model levels into the aggregate layer.
- Final Decision treats AI only as confirmation: Technical BUY/SELL and a matching two-model AI consensus are both required; otherwise WAIT.
- altFINS comparisons are timeframe-matched (15m with 15m, 1h with 1h), freshness-aware, and auxiliary only.
- AI-declared buyer/seller percentages are distinguished from the Technical Engine's independently calculated OHLCV estimate. Missing/invalid OHLCV strength is isolated to that sub-section and does not invalidate otherwise complete timeframe structure.
- Route-scoped rate limiting protects model catalog, altFINS quota/validation/diagnostics, authenticated provider connectivity tests, and analysis without sharing the same per-IP bucket.

## Validation
- JavaScript syntax checks: passed.
- Automated Node regression suite (current V6.3.1): **131 passed, 0 failed, 0 skipped, 0 todo**.
- HTML mirrors and Worker text snapshots: synchronized.
- Flutter/Dart SDK is not installed in this environment. Included Dart tests and Flutter source changes still require `dart format`, `flutter analyze`, Flutter tests, and Android build verification in Flutter CI or on a development machine.
- No live Gemini/OpenRouter/Groq or altFINS requests were made.
- No Cloudflare Worker deployment, GitHub push, or APK build was performed.

See `INDEX-TIMEFRAME-ACCORDION-REDESIGN-V6.3.1.md` for the presentation-only Index redesign. See `AI-POST-DATA-ENGINE-PIPELINE-AUDIT-2026-11-21.md` for the detailed stage-by-stage findings and verification boundary, and `AI-DATA-ENGINE-QUALITY-REPAIR-2026-11-21.md` for the original Data Engine repair.


Follow-up audit note (2026-11-21): Dashboard/Hybrid provider eligibility is unified; persisted factor maps are validated before voting; aggregate overlays require corroboration from any two agreeing providers; partial retries cannot mix identified Snapshot IDs or discard a previous successful answer on transport failure. Added Dart regression tests cover these cases, and mocked altFINS tests verify source timestamp freshness. The latest local Node suite passes 98 tests, including nested Groq extraction, live-price/ATR/POI execution validation, raw-text truncation, quantized-history bounds, and exact Worker/HTML mirror checks. Dart tests still require Flutter CI because the local environment has no Flutter/Dart SDK.


Follow-up repair (2026-11-21): Added a deeply nested Groq JSON-string regression test covering 1H/15M/5M, buyer/seller percentages, analysis sections, and raw response retention. Added stricter provider-local Entry/SL/TP validation against the live reference, 5m ATR, and active candle-validated POI. Flutter now carries and displays the execution-price validation report. See `AI-GROQ-PRICE-VALIDATION-REPAIR-2026-11-21.md`.


Follow-up repair (2026-11-21): Fixed loss of 1H/15M/5M trend information between the model's complete Persian/English response, timeframe normalization, and dashboard. Each timeframe now displays independently when available; narrative-only trends are visibly marked and are excluded from verified AI consensus until structured candle evidence passes. Tests cover long text beyond the 420-character summary, structured-plus-narrative partial results, all three providers, and protection against stitching separate Groq branches. Historical Node suite at that follow-up: 103 passed. Flutter/Dart tests, live provider calls, deployment, GitHub push, and APK build were not performed.

## V6.2.2 follow-up — AI directional consensus / V3 contract repair (2026-11-21)
- The AI market-direction vote is now independent from execution-plan validity. `marketBias` preserves the model's evidenced BUY/SELL assessment, while executable `bias` remains WAIT when Entry/SL/TP/POI checks fail.
- Empty V3 findings are valid for explicitly unavailable, inapplicable, or insufficient sections; AVAILABLE still requires findings and a missing findings field remains invalid.
- Confidence, analytical weights, factor scores, and complete trade plans are no longer mandatory for directional vote eligibility. The Worker owns evidence/timeframe qualification and Flutter consumes its eligibility metadata.
- At least two same-direction eligible providers are required; a WAIT or unavailable third provider is not an opposing directional vote.
- See `AI-CONSENSUS-AND-V3-TRADEPLAN-SEPARATION-V6.2.2.md` for root causes, detailed behavior, and validation boundaries.

## V6.3.0 follow-up — Independent factor validation (2026-11-21)
- Each of the nine V3 analysis factors now has a local validity status and failure reason; an invalid sibling factor no longer invalidates the rest of the analysis.
- Evidence validation is isolated by timeframe and by factor. A bad 5m or liquidity claim cannot suppress a separately valid 1h market-structure vote.
- Timeframe vote eligibility is sent explicitly by the Worker and consumed by Dashboard and Market Intelligence; global provider evidence status is no longer used as a blanket gate.
- Missing AI factor scores/weights are `NOT_PROVIDED`, not fabricated 0/20/50 values. AI and Technical Hybrid scores include only factors with available independent data.
- Technical factor scores are computed from explicit Technical Engine state, not free-text reason keywords.
- Full Node regression suite: 129 passed, 0 failed. Flutter/Dart SDK unavailable; Dart tests/analyze/format/APK build remain unexecuted. No GitHub push or Cloudflare deployment was performed.
- See `AI-FACTOR-INDEPENDENCE-REPAIR-V6.3.0.md` for stage-by-stage details and verification limits.


## V6.3.1 follow-up — timeframe-grouped Index UI (2026-11-21)
- Reorganized the exact Snapshot report into expandable 1H/15M/5M sections, each grouping Technical, Gemini, OpenRouter, Groq, and altFINS data for that same timeframe.
- Added nested per-source accordions and a separate full source archive so raw text, raw HTTP response, evidence, normalization, factor sections, and all original source fields remain accessible.
- Missing timeframe data remains explicitly missing; no cross-timeframe or cross-provider substitution is performed.
- Presentation-only: no analysis, validation, consensus, or trade-plan logic changed.
- Full Node suite: 131 passed, 0 failed. Flutter/Dart tests, Android WebView runtime, and APK build remain unverified because the SDK/runtime are unavailable. No push or deployment.
