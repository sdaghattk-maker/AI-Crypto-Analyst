# RATE_LIMITER namespace configuration

Source: user-provided Cloudflare dashboard screenshot dated 2026-11-22.

- Binding name: `RATE_LIMITER`
- Namespace ID: `1001`
- Limit: 5 requests
- Period: 60 seconds

Configured in `ai-gateway/wrangler.toml` using the current Wrangler `[[ratelimits]]` TOML binding syntax. This configuration is not evidence of a successful Cloudflare deployment; deploy and live verification are still required.
