# Market History Diagnostics Repair — V6.3.2.4

## Scope
Flutter-side market-history diagnostics and cache-integrity safeguards. The exchange candle source, Cloudflare Worker implementation/configuration, provider API secrets, and deployment configuration are unchanged.

## Changes
1. `lib/services/ai_service.dart`
   - On HTTP 400, reads Worker `dataQuality.timeframes` and surfaces separate Persian diagnostics for 1h, 15m, and 5m.
   - Displays validation reason, row index (when supplied), candle count, and data age (when supplied).
   - Keeps the original HTTP status and Worker error message.
2. `lib/services/market_api.dart`
   - Cache normalization no longer silently overwrites conflicting OHLCV records sharing a timestamp.
   - Exact duplicate rows remain safe overlaps and are retained once.
   - Contradictory duplicate rows throw `MarketApiDataIntegrityException` and are not converted into an empty cache result.
3. Tests
   - Added Node contract checks for HTTP 400 diagnostics, duplicate cache protection, and the outgoing exchange/symbol/1h/15m/5m payload contract.
   - Added Flutter unit tests for independent chronological encoding of the three timeframe histories and empty-history behavior.

## Test status
- Node tests: 141 passed, 0 failed (see `TEST-REPORT-V6.3.2.4.txt`).
- Flutter/Dart tests and analyzer: not run in the current build environment because `flutter` and `dart` executables are unavailable. The new Dart test file is included for execution in a Flutter SDK environment.
- Live Gateway request and APK build: not run.

## Safety boundaries
- No Worker source or Wrangler configuration changed.
- No API key or secret changed or added.
- No main-branch or GitHub remote operation performed.
