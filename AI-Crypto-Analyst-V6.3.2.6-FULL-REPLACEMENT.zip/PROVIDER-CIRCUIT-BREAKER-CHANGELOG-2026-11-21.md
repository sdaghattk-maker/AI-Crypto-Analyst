# Changelog — Durable Circuit Breaker

- Added `ProviderCircuitBreaker` Durable Object class.
- Added atomic `acquire`, `failure`, and `success` operations backed by persistent DO storage.
- Added half-open probe lease to prevent concurrent recovery probes across Worker isolates.
- Wired both `/providers/health` and `/analyze` provider execution through the shared circuit interface.
- Added Wrangler Durable Object binding and SQLite migration.
- Kept isolate-local Map only as a test/development fallback when no DO binding is supplied; production DO errors fail closed.
- Added regression coverage for restart persistence, open-circuit blocking, half-open concurrency and recovery.
