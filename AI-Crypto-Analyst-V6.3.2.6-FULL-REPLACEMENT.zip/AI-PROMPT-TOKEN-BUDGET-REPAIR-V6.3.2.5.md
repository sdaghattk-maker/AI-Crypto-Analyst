# AI Prompt Token Budget Repair — V6.3.2.5

## Root cause confirmed from the installed-app diagnostic

Groq rejected the full analysis request with HTTP 413. The provider reported an input-tokens-per-minute allowance of 7,000 and a requested amount of 106,260. The Flutter controller was freezing and passing 1,000 closed 1H candles, 1,500 closed 15M candles, and 2,000 closed 5M candles to AI. The Worker prompt copied every encoded row into the same prompt sent to each provider. This is consistent with an oversized prompt; it is not an API-key or Gateway connectivity failure.

## Change

- The complete 1H/15M/5M candle arrays remain frozen in `AnalysisController` and remain part of the full snapshot identity/fingerprint used by the app.
- Only the AI inference payload is bounded to the latest 50 contiguous closed candles per timeframe. This matches the current Worker validation minimum of 50 rows per timeframe.
- The AI payload includes `sourceCandleCount`, `analysisWindowCandleCount`, and `windowPolicy` so the model can see that its inference window is bounded and recent.
- No candle aggregation or synthetic candles are introduced. Every candle sent to AI is an original closed candle in chronological order.
- Worker code, Cloudflare configuration, secrets, API keys, and provider credentials are unchanged.

## Important trade-off

AI models now receive 50 hours of 1H history, 12.5 hours of 15M history, and about 4.17 hours of 5M history. The app's local technical engine and snapshot fingerprint still use the full 1,000/1,500/2,000 candle histories. This narrows the AI context window to fit strict provider TPM limits; it does not alter the local technical-engine history.

## Tests

- Node test suite: 142 passed, 0 failed, 0 skipped.
- Added static contract coverage for bounded per-timeframe AI payloads.
- Added Dart unit tests for contiguous latest-50 selection and rejection of a window below the Worker minimum.
- Dart/Flutter SDK is not installed in the execution environment, so Dart tests, analyzer, and a new APK build have not yet been run here.

## Remaining provider conditions from the screenshots

- Gemini `RATE_LIMITED`: external provider quota/throughput condition; not fixed by the payload patch until a fresh health/inference check.
- OpenRouter `MODEL_UNAVAILABLE`: selected model availability condition; not fixed by the payload patch until a fresh model health check or an available model selection.
- Groq HTTP 413 / 106,260 requested vs 7,000 ITPM: addressed by reducing the AI inference window; must be verified by a fresh live analysis request.
