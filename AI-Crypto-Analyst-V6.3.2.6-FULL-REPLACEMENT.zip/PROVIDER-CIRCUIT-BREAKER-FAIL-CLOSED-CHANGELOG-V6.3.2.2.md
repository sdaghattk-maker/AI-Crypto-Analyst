# Changelog V6.3.2.2

- Removed unsafe isolate-local in-memory fallback for Circuit Breaker.
- Enforced fail-closed behavior when Durable Object binding or storage is unavailable.
- Added `providerCircuitBreaker` binding status to `/health`.
- Added regression coverage for missing Durable Object binding and zero upstream inference calls.
- Updated test fixtures to use simulated shared Durable Object storage.
- Synchronized Worker TXT snapshots with executable Worker source.
- Validation: 138 Node tests passed; Worker syntax and ZIP integrity passed.
