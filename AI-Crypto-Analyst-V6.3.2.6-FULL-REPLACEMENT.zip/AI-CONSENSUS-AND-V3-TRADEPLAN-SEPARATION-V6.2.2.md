# AI Directional Consensus and V3 Contract Repair — V6.2.2

## Verified base
- Base archive: `AI-Crypto-Analyst-DASHBOARD-DART-SYNTAX-REPAIR-FINAL-2026-11-21-V6.2.1.zip`
- Base SHA256: `527d33aa7d86b812fe6dcef44921176fac08c9e274978a575423fb0358b88403`

## Root causes fixed
1. `normalizeAnalysisContractV3` treated every empty `findings` array as invalid, contradicting the V3 contract for `NOT_AVAILABLE`, `NOT_APPLICABLE`, and `INSUFFICIENT_DATA`.
2. The Worker and Flutter tied directional AI votes to optional analytical weights, factor scores, model-declared confidence, and a complete Entry/SL/TP plan.
3. `validateProviderOverlays` changed a model's market direction to `WAIT` when only its execution plan was invalid, erasing the directional assessment needed for independent AI consensus.
4. POI availability was folded into `evidenceStatus`, conflating candle-evidence validity with trade-plan completeness.
5. Flutter reimplemented a stricter vote-eligibility rule, allowing Worker and client results to diverge.

## Changes
- V3 sections now accept explicitly empty findings for `NOT_AVAILABLE`, `NOT_APPLICABLE`, and `INSUFFICIENT_DATA`; `AVAILABLE` still requires at least one valid finding.
- A missing `findings` field remains malformed; empty is valid only when the field is explicitly present (or a supported legacy alias is supplied).
- Strict provider schema and prompt now permit empty findings for non-available statuses.
- Optional `confidence`, `analyticalWeights`, and `factorScores` are no longer required by the provider output schema and are not used to qualify a directional vote.
- Worker now preserves `marketBias` separately from executable `bias`. If the trade plan fails, executable `bias` remains `WAIT`, execution overlays are removed, and the original market direction remains available for the directional consensus layer.
- Candle evidence validity no longer fails solely because a POI or executable plan is absent. POI and Entry/SL/TP checks remain mandatory for trade-plan eligibility.
- Worker computes `directionalVoteEligible` and a Persian `directionalVoteReason` using structured direction, V3 validity, candle-validated evidence, and timeframe-direction coherence.
- Worker returns `tradePlanEligible` independently. The Worker is the single source of truth; Flutter consumes the explicit vote flag/reason and trade-plan eligibility instead of re-running Worker candle/price/POI checks or applying its own weights/confidence threshold.
- Flutter retains independent final execution checks. A directional AI consensus may be BUY/SELL while the final Hybrid decision remains WAIT if technical alignment or a valid execution plan is absent.
- AI Analysis and Dashboard now show market direction, directional-vote eligibility/reason, and trade-plan validity separately.
- Worker text snapshots were synchronized with `ai-gateway/worker.js`.

## Regression coverage
- Empty `findings` accepted for explicit insufficient/unavailable sections.
- Empty `findings` rejected for `AVAILABLE`.
- Missing `findings` property rejected.
- Two BUY providers can form consensus without optional confidence/weight metadata.
- Two SELL providers plus unavailable Groq form SELL consensus.
- Two SELL providers plus a third WAIT provider still form SELL consensus.
- Incomplete trade plans do not erase directional votes, but remain non-executable.
- Invalid candle evidence and cross-timeframe direction conflict do not qualify a directional vote.
- Flutter consumes Worker vote eligibility metadata; trade-plan checks remain separate.
- Existing source mirrors, snapshot, retry, and dashboard tests remain green.

## Validation
- `node --check ai-gateway/worker.js`: passed.
- `node --check binance-proxy/worker.js`: passed.
- Node regression suite: 121 passed, 0 failed.
- Flutter/Dart SDK unavailable in this environment; Dart tests, `dart format`, `flutter analyze`, APK build and Android runtime tests were not run.
- No live Gemini/OpenRouter/Groq calls were made.
- No GitHub push and no Cloudflare Worker deployment were performed.

## Important semantics
- `marketBias`: the model's independently evidenced market direction (BUY/SELL/WAIT).
- `bias`: executable model decision; remains WAIT when the model's own plan is invalid or incomplete.
- `directionalVoteEligible`: authoritative Worker result for AI market-direction consensus.
- `tradePlanEligible`: separate execution-plan qualification.
- At least two valid same-direction votes are required. An unavailable or WAIT model is not an opposing directional vote.
