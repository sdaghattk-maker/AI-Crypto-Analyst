# AI Provider Routing and TPM Guard Repair — V6.3.2.6

## Scope
This patch is based on V6.3.2.5 and preserves the existing Flutter + Cloudflare Worker architecture, provider-independent analysis, immutable market snapshot, three timeframe windows, validation, consensus, and Durable Object circuit breaker.

## Changes
1. Provider candidate routing is now identical between `/providers/health` and `/analyze`: one selected primary model plus at most one explicitly configured fallback. The ranked catalog is no longer appended as hidden automatic fallbacks.
2. A provider-wide HTTP 429 / rate-limit / TPM / ITPM response stops retries immediately. Switching model IDs cannot resolve a provider-wide tokens-per-minute limit, and retrying would worsen quota pressure.
3. Health probing also stops after a provider-wide rate-limit response rather than probing another model.
4. Failed provider results now include `errorCode` and the exact `attemptedModels` list, so a quota failure is distinguishable from a generic provider failure. Flutter preserves these fields and displays the failure code and attempted model IDs on the AI analysis screen.
5. The two distributable Worker text snapshots are synchronized byte-for-byte with `ai-gateway/worker.js`.

## Preserved behavior
- Flutter sends the latest 50 contiguous closed candles for each of 1H, 15M, and 5M.
- The complete market snapshot remains in the app; only the provider inference window is bounded.
- Health-selected model is passed to the analysis request by Flutter, avoiding a repeat of a model already rejected during health probing.
- No API keys, Cloudflare secrets, Worker deployment settings, or production endpoints were changed.

## Validation
- `node --check ai-gateway/worker.js`: passed.
- `node --test test/*.test.mjs ai-gateway/tests/*.test.mjs binance-proxy/tests/*.test.mjs`: 144 passed, 0 failed.
- Static contract test confirms Flutter parses and renders `errorCode` and `attemptedModels`.
- Worker snapshot mirror test: passed.
- Live provider calls, Cloudflare deployment, Flutter/Dart tests, analyzer, and APK build were not run in this environment; no claim of live deployment or APK verification is made.
